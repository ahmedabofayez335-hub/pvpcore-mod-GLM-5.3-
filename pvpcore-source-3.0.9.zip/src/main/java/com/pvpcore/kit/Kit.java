/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemStack
 */
package com.pvpcore.kit;

import com.pvpcore.util.ItemCodecUtil;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.item.ItemStack;

public class Kit {
    public String id = "kit";
    public String displayName = "&fKit";
    public String displayItem = "STONE";
    public boolean enabled = true;
    public int slot = 0;
    public List<String> layout = new ArrayList<String>();
    /**
     * 3.0.9: potion EFFECTS automatically applied to every fighter at the start
     * of each duel round. Spec format: "effectId:seconds:amplifier" where
     * seconds can be -1 for infinite (e.g. "speed:30:1", "night_vision:-1:0").
     */
    public List<String> autoEffects = new ArrayList<String>();
    /**
     * 3.0.9: items (e.g. potions, golden apples) automatically handed to every
     * fighter at the start of each duel round. Stored as item SNBT.
     */
    public List<String> autoItems = new ArrayList<String>();
    public static final int ARMOR_COUNT = 4;
    public static final int HOTBAR_COUNT = 9;
    public static final int INV_COUNT = 27;
    public static final int OFFHAND_INDEX = 40;
    public static final int TOTAL = 41;
    public static final int LEGACY_TOTAL = 40;

    public void initEmptyLayout() {
        while (this.layout.size() < 41) {
            this.layout.add("");
        }
    }

    public List<ItemStack> layoutStacks() {
        this.initEmptyLayout();
        ArrayList<ItemStack> out = new ArrayList<ItemStack>();
        for (String s : this.layout) {
            out.add(ItemCodecUtil.fromSnbt(s));
        }
        return out;
    }

    public void setLayout(List<ItemStack> stacks) {
        this.layout = new ArrayList<String>();
        for (int i = 0; i < 41; ++i) {
            this.layout.add(i < stacks.size() ? ItemCodecUtil.toSnbt(stacks.get(i)) : "");
        }
    }

    public ItemStack displayStack() {
        ItemStack st = ItemCodecUtil.parseMaterial(this.displayItem);
        if (st.isEmpty()) {
            st = ItemCodecUtil.parseMaterial("STONE");
        }
        return st;
    }

    public static List<ItemStack> padLayout(List<ItemStack> in) {
        ArrayList<ItemStack> out = new ArrayList<ItemStack>(in);
        while (out.size() < 41) {
            out.add(ItemStack.EMPTY);
        }
        return out;
    }
}

