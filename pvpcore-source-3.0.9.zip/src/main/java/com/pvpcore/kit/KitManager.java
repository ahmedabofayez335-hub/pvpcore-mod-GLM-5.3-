/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 *  com.google.gson.GsonBuilder
 *  com.google.gson.reflect.TypeToken
 *  net.minecraft.component.DataComponentTypes
 *  net.minecraft.component.type.PotionContentsComponent
 *  net.minecraft.enchantment.Enchantment
 *  net.minecraft.entity.effect.StatusEffectInstance
 *  net.minecraft.entity.effect.StatusEffects
 *  net.minecraft.entity.player.PlayerInventory
 *  net.minecraft.item.ItemConvertible
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.Items
 *  net.minecraft.registry.Registries
 *  net.minecraft.registry.entry.RegistryEntry
 *  net.minecraft.util.Identifier
 */
package com.pvpcore.kit;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.pvpcore.PvPCore;
import com.pvpcore.PvPCoreMod;
import com.pvpcore.arena.ArenaManager;
import com.pvpcore.data.PlayerData;
import com.pvpcore.data.Storage;
import com.pvpcore.kit.Kit;
import com.pvpcore.util.EnchantUtil;
import com.pvpcore.util.ItemCodecUtil;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.FileAttribute;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Identifier;

public final class KitManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private final Path file;
    private final Map<String, Kit> kits = new LinkedHashMap<String, Kit>();

    public KitManager(Path dataDir) {
        this.file = dataDir.resolve("kits.json");
        this.load();
        if (this.kits.isEmpty()) {
            this.createDefaultKits();
            this.save();
        }
    }

    public void load() {
        this.kits.clear();
        if (Files.exists(this.file, new LinkOption[0])) {
            try {
                String json = Files.readString(this.file, StandardCharsets.UTF_8);
                Map map = (Map)GSON.fromJson(json, new TypeToken<Map<String, Kit>>(){}.getType());
                if (map != null) {
                    this.kits.putAll(map);
                }
                for (Map.Entry<String, Kit> e : new ArrayList<Map.Entry<String, Kit>>(this.kits.entrySet())) {
                    String key = e.getKey() == null ? "" : e.getKey().toLowerCase();
                    Kit kit = e.getValue();
                    if (kit != null) {
                        kit.id = key;
                    }
                    if (key.equals(e.getKey())) continue;
                    this.kits.remove(e.getKey());
                    this.kits.put(key, kit);
                }
            }
            catch (Exception var7) {
                PvPCoreMod.LOGGER.error("Failed to load kits.json", (Throwable)var7);
            }
        }
    }

    public synchronized void save() {
        try {
            Files.createDirectories(this.file.getParent(), new FileAttribute[0]);
            Path tmp = this.file.resolveSibling("kits.json.tmp");
            Files.writeString(tmp, (CharSequence)GSON.toJson(this.kits), StandardCharsets.UTF_8, new OpenOption[0]);
            Files.move(tmp, this.file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        }
        catch (IOException var21) {
            PvPCoreMod.LOGGER.error("Failed to save kits.json", (Throwable)var21);
        }
    }

    public Kit get(String id) {
        return this.kits.get(id.toLowerCase());
    }

    public Collection<Kit> all() {
        return this.kits.values();
    }

    public List<Kit> sortedAll() {
        ArrayList<Kit> out = new ArrayList<Kit>(this.kits.values());
        out.sort(Comparator.comparingInt(k -> k.slot));
        return out;
    }

    public void put(Kit kit) {
        kit.id = kit.id.toLowerCase();
        this.kits.put(kit.id, kit);
        this.save();
    }

    /**
     * 3.0.9: resolves a potion effect id like "speed", "fire_resistance" or
     * "minecraft:strength" to its registry entry. Returns null when unknown.
     */
    public static RegistryEntry<StatusEffect> effectById(String id) {
        if (id == null || id.isBlank()) {
            return null;
        }
        String cleaned = id.trim().toLowerCase();
        Identifier identifier = cleaned.indexOf(58) >= 0 ? Identifier.of(cleaned.substring(0, cleaned.indexOf(58)), cleaned.substring(cleaned.indexOf(58) + 1)) : Identifier.of("minecraft", cleaned);
        return Registries.STATUS_EFFECT.getEntry(identifier).map(e -> (RegistryEntry<StatusEffect>)e).orElse(null);
    }

    /**
     * 3.0.9: parses one auto-effect spec "effectId:seconds:amplifier" into its
     * parts. The id may be namespaced ("minecraft:speed:30:1") so the LAST two
     * segments are seconds/amplifier and everything before them is the effect id.
     * Returns null when the spec is malformed or the effect is unknown.
     */
    public static Object[] parseAutoEffect(String spec) {
        if (spec == null || spec.isBlank()) {
            return null;
        }
        String[] parts = spec.split(":");
        if (parts.length < 3) {
            return null;
        }
        try {
            int last = parts.length - 1;
            int amplifier = Math.max(0, Integer.parseInt(parts[last]));
            int seconds = Integer.parseInt(parts[last - 1]);
            StringBuilder id = new StringBuilder();
            for (int i = 0; i < last - 1; ++i) {
                if (i > 0) {
                    id.append(':');
                }
                id.append(parts[i]);
            }
            RegistryEntry<StatusEffect> effect = KitManager.effectById(id.toString());
            if (effect == null) {
                return null;
            }
            return new Object[]{effect, seconds, amplifier};
        }
        catch (NumberFormatException numberFormatException) {
            return null;
        }
    }

    /**
     * 3.0.9: human readable duration for the auto-potion list output.
     */
    public static String formatAutoSeconds(int seconds) {
        return seconds < 0 ? "infinite" : seconds + "s";
    }

    public void delete(String id) {
        ArenaManager arenas;
        String key = id.toLowerCase();
        this.kits.remove(key);
        this.save();
        try {
            Storage storage = PvPCore.get().storage();
            if (storage != null) {
                for (Map.Entry<UUID, PlayerData> entry : storage.all().entrySet()) {
                    PlayerData data = entry.getValue();
                    if (data == null) continue;
                    boolean removed = data.loadouts != null && data.loadouts.remove(key) != null;
                    // 3.0.7: FFA layouts are cleaned up together with the regular ones.
                    removed = (data.ffaLoadouts != null && data.ffaLoadouts.remove(key) != null) || removed;
                    if (!removed) continue;
                    storage.markDirty(entry.getKey());
                }
            }
        }
        catch (Throwable storage) {
            // empty catch block
        }
        ArenaManager arenaManager = arenas = PvPCore.get() != null ? PvPCore.get().arenaManager() : null;
        if (arenas != null) {
            arenas.removeKitReferences(key);
        }
    }

    public Kit rename(String oldId, String newId, String newDisplayName) {
        boolean idChanged;
        String oldKey = oldId.toLowerCase();
        Kit kit = this.kits.get(oldKey);
        if (kit == null) {
            return null;
        }
        if (newId != null && newId.contains(":")) {
            int split = newId.indexOf(58);
            String idPart = newId.substring(0, split).trim();
            String namePart = newId.substring(split + 1).trim();
            if (!namePart.isEmpty()) {
                newDisplayName = namePart;
            }
            newId = idPart;
        }
        boolean bl = idChanged = newId != null && !newId.isBlank() && !newId.equalsIgnoreCase(oldKey);
        if (idChanged) {
            String newKey = newId.trim().toLowerCase();
            if (!KitManager.validId(newKey) || this.kits.containsKey(newKey)) {
                return null;
            }
            this.kits.remove(oldKey);
            kit.id = newKey;
            this.kits.put(newKey, kit);
        }
        if (newDisplayName != null && !newDisplayName.isBlank()) {
            kit.displayName = newDisplayName;
        }
        this.save();
        if (idChanged) {
            this.syncReferences(oldKey, kit.id);
        }
        return kit;
    }

    private void syncReferences(String oldId, String newId) {
        try {
            ArenaManager arenas;
            ArenaManager arenaManager = arenas = PvPCore.get() != null ? PvPCore.get().arenaManager() : null;
            if (arenas != null) {
                arenas.renameKitReferences(oldId, newId);
            }
        }
        catch (Throwable arenas) {
            // empty catch block
        }
        try {
            Storage storage;
            Storage storage2 = storage = PvPCore.get() != null ? PvPCore.get().storage() : null;
            if (storage != null) {
                for (Map.Entry<UUID, PlayerData> entry : storage.all().entrySet()) {
                    PlayerData data = entry.getValue();
                    if (data == null) continue;
                    boolean dirty = false;
                    if (data.stats != null && data.stats.containsKey(oldId)) {
                        data.stats.put(newId, data.stats.remove(oldId));
                        dirty = true;
                    }
                    if (data.ratings != null && data.ratings.containsKey(oldId)) {
                        data.ratings.put(newId, data.ratings.remove(oldId));
                        dirty = true;
                    }
                    if (data.loadouts != null && data.loadouts.containsKey(oldId)) {
                        data.loadouts.put(newId, data.loadouts.remove(oldId));
                        dirty = true;
                    }
                    if (data.ffaLoadouts != null && data.ffaLoadouts.containsKey(oldId)) {
                        // 3.0.7: keep the player's FFA layout across kit renames too.
                        data.ffaLoadouts.put(newId, data.ffaLoadouts.remove(oldId));
                        dirty = true;
                    }
                    if (!dirty) continue;
                    storage.markDirty(entry.getKey());
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    public void clearLoadouts(String kitId) {
        if (kitId != null) {
            String key = kitId.toLowerCase();
            try {
                Storage storage;
                Storage storage2 = storage = PvPCore.get() != null ? PvPCore.get().storage() : null;
                if (storage != null) {
                    for (Map.Entry<UUID, PlayerData> entry : storage.all().entrySet()) {
                        PlayerData data = entry.getValue();
                        if (data == null) continue;
                        boolean removed = data.loadouts != null && data.loadouts.remove(key) != null;
                        // 3.0.7: template changes reset FFA layouts as well, so players
                        // get the fresh template instead of a stale arrangement.
                        removed = (data.ffaLoadouts != null && data.ffaLoadouts.remove(key) != null) || removed;
                        if (!removed) continue;
                        storage.markDirty(entry.getKey());
                    }
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
    }

    public Kit resetToDefault(String id) {
        Kit fresh = null;
        String key = id.toLowerCase();
        switch (key) {
            case "nodebuff": {
                fresh = this.buildNoDebuff();
                break;
            }
            case "classic": {
                fresh = this.buildClassic();
                break;
            }
            case "gapple": {
                fresh = this.buildGapple();
                break;
            }
        }
        if (fresh == null) {
            return null;
        }
        Kit existing = this.kits.get(key);
        if (existing != null) {
            fresh.displayName = existing.displayName;
            fresh.displayItem = existing.displayItem;
            fresh.enabled = existing.enabled;
            fresh.slot = existing.slot;
            // 3.0.9: a layout template reset must not throw away the admin's
            // auto potion configuration for this kit.
            if (existing.autoEffects != null && !existing.autoEffects.isEmpty()) {
                fresh.autoEffects = new ArrayList<String>(existing.autoEffects);
            }
            if (existing.autoItems != null && !existing.autoItems.isEmpty()) {
                fresh.autoItems = new ArrayList<String>(existing.autoItems);
            }
        }
        fresh.id = key;
        this.put(fresh);
        this.clearLoadouts(key);
        return fresh;
    }

    public Kit createFromInventory(String id, String displayName, PlayerInventory inv) {
        Kit kit = new Kit();
        kit.id = id.toLowerCase();
        kit.displayName = displayName != null && !displayName.isBlank() ? displayName : "&f" + id;
        ArrayList<ItemStack> layout = new ArrayList<ItemStack>(Collections.nCopies(41, ItemStack.EMPTY));
        for (int i = 0; i < 4; ++i) {
            layout.set(i, ItemCodecUtil.copy(inv.getStack(36 + i)));
        }
        layout.set(40, ItemCodecUtil.copy(inv.getStack(40)));
        for (int var10 = 0; var10 < 9; ++var10) {
            layout.set(4 + var10, ItemCodecUtil.copy(inv.getStack(var10)));
        }
        for (int var11 = 0; var11 < 27; ++var11) {
            layout.set(13 + var11, ItemCodecUtil.copy(inv.getStack(9 + var11)));
        }
        kit.setLayout(layout);
        String display = null;
        for (int i2 = 4; i2 < 40 && display == null; ++i2) {
            ItemStack st = layout.get(i2);
            if (st.isEmpty()) continue;
            display = Registries.ITEM.getId(st.getItem()).toString();
        }
        if (display == null) {
            display = "STONE";
        }
        kit.displayItem = display;
        return kit;
    }

    public static boolean validId(String id) {
        return id != null && id.matches("[a-zA-Z0-9_-]{1,32}");
    }

    private void createDefaultKits() {
        this.kits.put("nodebuff", this.buildNoDebuff());
        this.kits.put("classic", this.buildClassic());
        this.kits.put("gapple", this.buildGapple());
    }

    private ItemStack ench(String material, String enchId, int level) {
        ItemStack st = ItemCodecUtil.parseMaterial(material);
        RegistryEntry<Enchantment> entry = EnchantUtil.byId(enchId);
        if (entry != null) {
            st.addEnchantment(entry, level);
        }
        return st;
    }

    private ItemStack healingPotion() {
        ItemStack st = new ItemStack((ItemConvertible)Items.SPLASH_POTION);
        Optional potion = Registries.POTION.getEntry(Identifier.of((String)"minecraft", (String)"strong_healing"));
        potion.ifPresent(p -> st.set(DataComponentTypes.POTION_CONTENTS, new PotionContentsComponent((RegistryEntry)p)));
        return st;
    }

    private ItemStack speedPotion() {
        ItemStack st = new ItemStack((ItemConvertible)Items.POTION);
        StatusEffectInstance speed = new StatusEffectInstance(StatusEffects.SPEED, 1200, 1);
        st.set(DataComponentTypes.POTION_CONTENTS, new PotionContentsComponent(Optional.empty(), Optional.empty(), List.of(speed), Optional.empty()));
        return st;
    }

    private ItemStack totem() {
        return ItemCodecUtil.parseMaterial("TOTEM_OF_UNDYING");
    }

    private Kit buildNoDebuff() {
        Kit kit = new Kit();
        kit.id = "nodebuff";
        kit.displayName = "&bNoDebuff";
        kit.displayItem = "SPLASH_POTION";
        ArrayList<ItemStack> layout = new ArrayList<ItemStack>(Collections.nCopies(41, ItemStack.EMPTY));
        layout.set(0, this.ench("DIAMOND_HELMET", "protection", 2));
        layout.set(1, this.ench("DIAMOND_CHESTPLATE", "protection", 2));
        layout.set(2, this.ench("DIAMOND_LEGGINGS", "protection", 2));
        layout.set(3, this.ench("DIAMOND_BOOTS", "protection", 2));
        layout.set(4, this.ench("DIAMOND_SWORD", "sharpness", 1));
        for (int i = 5; i < 13; ++i) {
            layout.set(i, this.healingPotion());
        }
        layout.set(40, this.totem());
        kit.setLayout(layout);
        return kit;
    }

    private Kit buildClassic() {
        Kit kit = new Kit();
        kit.id = "classic";
        kit.displayName = "&6Classic";
        kit.displayItem = "IRON_SWORD";
        ArrayList<ItemStack> layout = new ArrayList<ItemStack>(Collections.nCopies(41, ItemStack.EMPTY));
        layout.set(0, this.ench("IRON_HELMET", "protection", 1));
        layout.set(1, this.ench("IRON_CHESTPLATE", "protection", 1));
        layout.set(2, this.ench("IRON_LEGGINGS", "protection", 1));
        layout.set(3, this.ench("IRON_BOOTS", "protection", 1));
        layout.set(4, this.ench("IRON_SWORD", "sharpness", 2));
        ItemStack bow = this.ench("BOW", "power", 2);
        layout.set(5, bow);
        ItemStack arrows = new ItemStack((ItemConvertible)Items.ARROW, 32);
        layout.set(6, arrows);
        ItemStack steak = new ItemStack((ItemConvertible)Items.COOKED_BEEF, 16);
        layout.set(7, steak);
        ItemStack gapple = new ItemStack((ItemConvertible)Items.GOLDEN_APPLE, 4);
        layout.set(8, gapple);
        layout.set(9, this.speedPotion());
        kit.setLayout(layout);
        return kit;
    }

    private Kit buildGapple() {
        Kit kit = new Kit();
        kit.id = "gapple";
        kit.displayName = "&eGapple";
        kit.displayItem = "GOLDEN_APPLE";
        ArrayList<ItemStack> layout = new ArrayList<ItemStack>(Collections.nCopies(41, ItemStack.EMPTY));
        layout.set(0, this.ench("DIAMOND_HELMET", "protection", 3));
        layout.set(1, this.ench("DIAMOND_CHESTPLATE", "protection", 3));
        layout.set(2, this.ench("DIAMOND_LEGGINGS", "protection", 3));
        layout.set(3, this.ench("DIAMOND_BOOTS", "protection", 3));
        layout.set(4, this.ench("DIAMOND_SWORD", "sharpness", 3));
        layout.set(5, this.ench("DIAMOND_AXE", "sharpness", 2));
        ItemStack gaps = new ItemStack((ItemConvertible)Items.GOLDEN_APPLE, 64);
        layout.set(6, gaps);
        layout.set(7, new ItemStack((ItemConvertible)Items.GOLDEN_APPLE, 64));
        kit.setLayout(layout);
        return kit;
    }
}

