/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.command.permission.LeveledPermissionPredicate
 *  net.minecraft.command.permission.PermissionLevel
 *  net.minecraft.command.permission.PermissionPredicate
 *  net.minecraft.entity.player.PlayerInventory
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.Items
 *  net.minecraft.server.MinecraftServer
 *  net.minecraft.server.command.ServerCommandSource
 *  net.minecraft.server.network.ServerPlayerEntity
 *  net.minecraft.server.world.ServerWorld
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.world.GameMode
 */
package com.pvpcore.player;

import com.pvpcore.PvPCore;
import com.pvpcore.PvPCoreMod;
import com.pvpcore.config.GuiConfig;
import com.pvpcore.config.MainConfig;
import com.pvpcore.duel.Duel;
import com.pvpcore.item.ItemBuilder;
import com.pvpcore.player.InventorySnapshot;
import com.pvpcore.player.PlayerState;
import com.pvpcore.util.TeleportUtil;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.UUID;
import net.minecraft.command.permission.LeveledPermissionPredicate;
import net.minecraft.command.permission.PermissionLevel;
import net.minecraft.command.permission.PermissionPredicate;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.GameMode;

public final class PlayerManager {
    private final Map<UUID, Session> sessions = new HashMap<UUID, Session>();
    private final List<UUID> pendingRespawnRecovery = new ArrayList<UUID>();
    // 3.0.6: uuid -> tick at which the delayed login cleanup (zone exit to lobby)
    // should fire for that player.
    private final Map<UUID, Long> pendingLoginCleanup = new HashMap<UUID, Long>();
    private long tickCounter = 0L;
    private long lastAutosave = 0L;

    public void onJoin(ServerPlayerEntity player) {
        MinecraftServer server = PvPCore.get().server();
        if (server != null) {
            Session session = new Session();
            session.joinTick = server.getTicks();
            session.joinPos = player.getEntityPos();
            this.sessions.put(player.getUuid(), session);
            PvPCore.get().storage().get(player.getUuid(), player.getGameProfile().name());
            Duel activeDuel = PvPCore.get().duelManager().duelOf(player.getUuid());
            if (activeDuel != null) {
                session.loginSynced = true;
                PvPCore.get().duelManager().onPlayerReconnectToLobby(player);
            } else if (PvPCore.get().zoneManager().hasZoneMembership(player)) {
                // 3.0.6: a player reconnecting after disconnecting inside an FFA zone
                // is NOT thrown back into the fight with the stale items of the previous
                // session. They are cleanly removed from the zone and returned to the
                // lobby with the default lobby items. The cleanup is delayed a few ticks
                // so the vanilla join sequence (which sends the stale saved inventory to
                // the client) finishes first - our clean state is applied last and wins.
                session.loginSynced = true;
                session.state = PlayerState.LOBBY;
                this.scheduleLoginCleanup(player);
            } else {
                if (PvPCore.get().snapshotStore().has(player.getUuid())) {
                    PvPCore.get().snapshotStore().restore(player);
                    this.recoverToLobby(player);
                    session.loginSynced = true;
                }
                if (player.interactionManager.getGameMode() == GameMode.SPECTATOR) {
                    // 3.0.6: stuck spectators (e.g. relogging while spectating) get the
                    // FULL lobby recovery - gamemode, default items and a lobby teleport
                    // - instead of only a gamemode swap that left them itemless.
                    this.recoverToLobby(player);
                }
                if (PvPCore.get().config().lobby.loginSyncMode.toUpperCase().equals("INSTANT")) {
                    this.applyLobby(player);
                }
            }
        }
    }

    public void onQuit(ServerPlayerEntity player) {
        Session session = this.sessions.get(player.getUuid());
        PvPCore.get().guiManager().cleanup(player.getUuid());
        PvPCore.get().queueManager().remove(player);
        PvPCore.get().spectateManager().onQuit(player);
        PvPCore.get().partyManager().onQuit(player);
        PvPCore.get().lobbyScoreboardManager().onQuit(player);
        PvPCore.get().zoneManager().onQuit(player);
        if (session != null) {
            if (session.state == PlayerState.DUELING) {
                Duel duel = PvPCore.get().duelManager().duelOf(player);
                if (duel != null) {
                    PvPCore.get().duelManager().onPlayerDisconnect(player);
                }
            } else {
                this.removeLobbyItems(player);
                this.restoreLobbyStash(player);
                session.preDuel = null;
            }
        }
        PvPCore.get().storage().saveNow(player.getUuid());
        this.sessions.remove(player.getUuid());
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void scheduleRespawnRecovery(ServerPlayerEntity player) {
        if (player != null) {
            List<UUID> list = this.pendingRespawnRecovery;
            synchronized (list) {
                this.pendingRespawnRecovery.add(player.getUuid());
            }
        }
    }

    public void onRespawn(ServerPlayerEntity player) {
        if (player == null || PvPCore.get().server() == null) {
            return;
        }
        Session session = this.session(player);
        session.loginSynced = true;
        PvPCore core = PvPCore.get();
        if (core.duelManager().duelOf(player.getUuid()) != null) {
            return;
        }
        if (core.zoneManager().isInZone(player)) {
            core.zoneManager().handleMemberRespawn(player);
            return;
        }
        if (core.snapshotStore().has(player.getUuid())) {
            core.snapshotStore().restore(player);
        }
        this.recoverToLobby(player);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void tick() {
        ++this.tickCounter;
        MinecraftServer server = PvPCore.get().server();
        if (server != null) {
            String mode;
            if (!this.pendingRespawnRecovery.isEmpty()) {
                ArrayList<UUID> drain;
                List<UUID> list = this.pendingRespawnRecovery;
                synchronized (list) {
                    drain = new ArrayList<UUID>(this.pendingRespawnRecovery);
                    this.pendingRespawnRecovery.clear();
                }
                for (UUID uuid : drain) {
                    ServerPlayerEntity p = server.getPlayerManager().getPlayer(uuid);
                    if (p == null) continue;
                    try {
                        this.onRespawn(p);
                    }
                    catch (Throwable t) {
                        PvPCoreMod.LOGGER.warn("Respawn recovery failed for {}: {}", (Object)uuid, (Object)t.getMessage());
                    }
                }
            }
            if (!this.pendingLoginCleanup.isEmpty()) {
                Iterator<Map.Entry<UUID, Long>> it = this.pendingLoginCleanup.entrySet().iterator();
                while (it.hasNext()) {
                    Map.Entry<UUID, Long> e = it.next();
                    if (this.tickCounter < e.getValue().longValue()) continue;
                    it.remove();
                    ServerPlayerEntity p = server.getPlayerManager().getPlayer(e.getKey());
                    if (p == null) continue;
                    try {
                        this.doLoginCleanup(p);
                    }
                    catch (Throwable t) {
                        PvPCoreMod.LOGGER.warn("Login cleanup failed for {}: {}", (Object)e.getKey(), (Object)t.getMessage());
                    }
                }
            }
            if (!(mode = PvPCore.get().config().lobby.loginSyncMode.toUpperCase()).equals("INSTANT")) {
                int timeout = PvPCore.get().config().lobby.loginTimeoutTicks;
                boolean smart = mode.equals("SMART");
                for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                    boolean moved;
                    Session session = this.sessions.get(player.getUuid());
                    if (session == null || session.loginSynced || session.state != PlayerState.LOBBY) continue;
                    long waited = this.tickCounter - session.joinTick;
                    boolean timedOut = waited >= (long)timeout;
                    boolean bl = moved = smart && session.joinPos != null && player.squaredDistanceTo(session.joinPos) > 0.25;
                    if (!timedOut && !moved) continue;
                    this.applyLobby(player);
                }
            }
            if (PvPCore.get().config().lobby.invulnerable) {
                for (ServerPlayerEntity playerx : server.getPlayerManager().getPlayerList()) {
                    Session session = this.sessions.get(playerx.getUuid());
                    if (session == null || session.state != PlayerState.LOBBY && session.state != PlayerState.QUEUEING) continue;
                    if (playerx.getHealth() < playerx.getMaxHealth()) {
                        playerx.setHealth(playerx.getMaxHealth());
                    }
                    if (playerx.getHungerManager().getFoodLevel() >= 20) continue;
                    playerx.getHungerManager().setFoodLevel(20);
                }
            }
            if (this.tickCounter % 40L == 0L) {
                this.sweepStuckSpectators();
            }
        }
    }

    public void autosaveTick() {
        int interval = Math.max(10, PvPCore.get().config().storage.saveIntervalSeconds) * 20;
        if (this.tickCounter - this.lastAutosave >= (long)interval) {
            this.lastAutosave = this.tickCounter;
            PvPCore.get().storage().saveAll();
            PvPCore.get().leaderboardManager().refresh();
        }
    }

    public void saveAllNow() {
        PvPCore.get().storage().saveAll();
    }

    public void applyLobby(ServerPlayerEntity player) {
        Session session = this.session(player);
        if (!session.loginSynced) {
            session.loginSynced = true;
            session.state = PlayerState.LOBBY;
            MainConfig.Lobby lobby = PvPCore.get().config().lobby;
            this.applyLobbyGameMode(player);
            if (lobby.teleportOnJoin) {
                this.teleportToLobby(player);
            }
            if (lobby.giveItems) {
                this.giveLobbyItems(player);
            }
        }
    }

    public void backToLobby(ServerPlayerEntity player) {
        Session session = this.session(player);
        session.state = PlayerState.LOBBY;
        session.preDuel = null;
        MainConfig.Lobby lobby = PvPCore.get().config().lobby;
        this.applyLobbyGameMode(player);
        if (PvPCore.get().config().duel.healAfterDuel) {
            this.revivePlayer(player);
            player.clearStatusEffects();
            player.experienceLevel = 0;
            player.experienceProgress = 0.0f;
        } else {
            this.clearDeathVisuals(player);
        }
        if (lobby.giveItems) {
            this.giveLobbyItems(player);
        }
    }

    public void recoverToLobby(ServerPlayerEntity player) {
        PvPCore core = PvPCore.get();
        if (core.spectateManager().isSpectating(player)) {
            core.spectateManager().returnPlayer(player);
        }
        player.clearStatusEffects();
        this.revivePlayer(player);
        this.forceLobbyGameMode(player);
        Session session = this.session(player);
        session.state = PlayerState.LOBBY;
        session.preDuel = null;
        session.loginSynced = true;
        if (core.config().lobby.giveItems) {
            this.giveLobbyItems(player);
        }
        this.teleportToLobby(player);
    }

    public void scheduleLoginCleanup(ServerPlayerEntity player) {
        if (player != null) {
            this.pendingLoginCleanup.put(player.getUuid(), this.tickCounter + 10L);
        }
    }

    private void doLoginCleanup(ServerPlayerEntity player) {
        PvPCore core = PvPCore.get();
        if (core.duelManager().duelOf(player.getUuid()) != null) {
            // Safety net: duels have their own reconnect handling.
            return;
        }
        // 3.0.6: clean exit from a zone the player disconnected from.
        core.zoneManager().removeMembership(player);
        // Give back their pre-zone inventory; if none exists (edge case) wipe the
        // stale kit items completely so they can never leak into the lobby.
        if (core.snapshotStore().has(player.getUuid())) {
            core.snapshotStore().restore(player);
        } else {
            this.clearAfterDuel(player, null);
        }
        this.recoverToLobby(player);
        try {
            player.playerScreenHandler.updateToClient();
            player.currentScreenHandler.updateToClient();
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        player.sendMessage((Text)Text.literal((String)core.messages().get("zone.login-lobby")), false);
    }

    public boolean applyLobbyGameMode(ServerPlayerEntity player) {
        return this.applyLobbyGameMode(player, false);
    }

    public boolean applyLobbyGameMode(ServerPlayerEntity player, boolean force) {
        try {
            Session s;
            if (player == null) {
                return false;
            }
            if (!force && PlayerManager.isAdmin(player)) {
                return false;
            }
            GameMode wanted = GameMode.byId((String)PvPCore.get().config().lobby.gameMode, (GameMode)GameMode.ADVENTURE);
            if (player.interactionManager.getGameMode() != wanted) {
                player.changeGameMode(wanted);
            }
            if ((s = this.sessions.get(player.getUuid())) != null) {
                s.modSpectator = false;
            }
            return true;
        }
        catch (Throwable var4) {
            return false;
        }
    }

    public void forceLobbyGameMode(ServerPlayerEntity player) {
        this.applyLobbyGameMode(player, true);
    }

    public void revivePlayer(ServerPlayerEntity player) {
        try {
            player.setHealth(player.getMaxHealth());
            this.clearDeathVisuals(player);
            player.getHungerManager().setFoodLevel(20);
            player.getHungerManager().setSaturationLevel(5.0f);
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private void clearDeathVisuals(ServerPlayerEntity player) {
        try {
            if (player.getHealth() <= 0.0f) {
                player.setHealth(1.0f);
            }
            player.deathTime = 0;
            player.hurtTime = 0;
            player.maxHurtTime = 10;
            player.setFireTicks(0);
            player.setFrozenTicks(0);
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    public void giveLobbyItems(ServerPlayerEntity player) {
        GuiConfig cfg = PvPCore.get().guiConfig();
        PlayerInventory inv = player.getInventory();
        Session session = this.session(player);
        boolean queued = PvPCore.get().queueManager().isQueued(player);
        boolean inParty = PvPCore.get().partyManager().partyOf(player) != null;
        boolean spectating = PvPCore.get().spectateManager().isSpectating(player);
        if (spectating && PvPCore.get().spectateManager().spectatedDuel(player) == null) {
            PvPCore.get().spectateManager().clearStale(player);
            spectating = false;
        }
        this.removeLobbyItems(player);
        TreeMap<Integer, Map.Entry<String, ItemStack>> desired = new TreeMap<Integer, Map.Entry<String, ItemStack>>();
        GuiConfig.ItemSpec spec;
        if (spectating) {
            spec = cfg.lobbyItem("spectate_return");
            if (spec.enabled) {
                desired.put(spec.slot, Map.entry("spectate", cfg.build(spec)));
            }
        } else if (queued) {
            spec = cfg.lobbyItem("queue_leave");
            desired.put(spec.slot, Map.entry("queue_leave", cfg.build(spec)));
        } else {
            GuiConfig.ItemSpec partySpec;
            GuiConfig.ItemSpec unrankedSpec = cfg.lobbyItem("unranked");
            if (unrankedSpec.enabled) {
                desired.put(unrankedSpec.slot, Map.entry("unranked", cfg.build(unrankedSpec)));
            }
            GuiConfig.ItemSpec rankedSpec = cfg.lobbyItem("ranked");
            if (rankedSpec.enabled) {
                desired.put(rankedSpec.slot, Map.entry("ranked", cfg.build(rankedSpec)));
            }
            for (String key : List.of("duel", "kits", "profile", "spectate")) {
                GuiConfig.ItemSpec spec2 = cfg.lobbyItem(key);
                if (!spec2.enabled) continue;
                desired.put(spec2.slot, Map.entry(key, cfg.build(spec2)));
            }
            GuiConfig.ItemSpec itemSpec = partySpec = inParty ? cfg.lobbyItem("party_active") : cfg.lobbyItem("party");
            if (partySpec.enabled) {
                desired.put(partySpec.slot, Map.entry("party", cfg.build(partySpec)));
            }
            if (PlayerManager.isAdmin(player)) {
                GuiConfig.ItemSpec adminSpec = cfg.lobbyItem("admin");
                if (adminSpec.enabled) {
                    desired.put(adminSpec.slot, Map.entry("admin", cfg.build(adminSpec)));
                }
            }
        }
        for (Map.Entry e : desired.entrySet()) {
            ItemStack toSet;
            int slot = (Integer)e.getKey();
            if (slot < 0 || slot > 8) continue;
            ItemStack current = inv.getStack(slot);
            if (!current.isEmpty()) {
                session.lobbyStash.put(slot, current.copy());
            }
            if ((toSet = (ItemStack)((Map.Entry)e.getValue()).getValue()).getItem() == Items.PLAYER_HEAD) {
                toSet = ItemBuilder.of(toSet).skullOwner(player).build();
            }
            toSet = ItemBuilder.of(toSet).tag((String)((Map.Entry)e.getValue()).getKey()).build();
            inv.setStack(slot, toSet);
        }
        inv.markDirty();
        player.currentScreenHandler.updateToClient();
    }

    public void removeLobbyItems(ServerPlayerEntity player) {
        Session session = this.session(player);
        PlayerInventory inv = player.getInventory();
        GuiConfig cfg = PvPCore.get().guiConfig();
        TreeSet<Integer> occupied = new TreeSet<Integer>();
        for (String key : cfg.lobby.items.keySet()) {
            GuiConfig.ItemSpec spec = cfg.lobbyItem(key);
            if (spec.slot < 0 || spec.slot > 8) continue;
            occupied.add(spec.slot);
        }
        Iterator<Integer> iterator = occupied.iterator();
        while (iterator.hasNext()) {
            int slot = iterator.next();
            ItemStack current = inv.getStack(slot);
            ItemStack stashed = session.lobbyStash.remove(slot);
            if (stashed != null) {
                inv.setStack(slot, stashed);
                continue;
            }
            if (!this.isLobbyItem(current, cfg)) continue;
            inv.setStack(slot, ItemStack.EMPTY);
        }
        inv.markDirty();
        player.currentScreenHandler.updateToClient();
    }

    private boolean isLobbyItem(ItemStack stack, GuiConfig cfg) {
        return ItemBuilder.actionOf(stack) != null;
    }

    private void restoreLobbyStash(ServerPlayerEntity player) {
        Session session = this.sessions.get(player.getUuid());
        if (session != null) {
            PlayerInventory inv = player.getInventory();
            for (Map.Entry<Integer, ItemStack> e : session.lobbyStash.entrySet()) {
                int slot = e.getKey();
                if (slot < 0 || slot >= 36 || !inv.getStack(slot).isEmpty()) continue;
                inv.setStack(slot, e.getValue());
            }
            session.lobbyStash.clear();
            inv.markDirty();
        }
    }

    public InventorySnapshot snapshotAndClear(ServerPlayerEntity player) {
        Session session = this.session(player);
        InventorySnapshot snap = new InventorySnapshot();
        PlayerInventory inv = player.getInventory();
        for (int i = 0; i < 36; ++i) {
            snap.main[i] = inv.getStack(i).copy();
            inv.setStack(i, ItemStack.EMPTY);
        }
        for (int var9 = 0; var9 < 4; ++var9) {
            snap.armor[var9] = inv.getStack(36 + var9).copy();
        }
        snap.offhand = inv.getStack(40).copy();
        inv.setStack(40, ItemStack.EMPTY);
        snap.selectedSlot = inv.getSelectedSlot();
        snap.health = player.getHealth();
        snap.food = player.getHungerManager().getFoodLevel();
        snap.saturation = player.getHungerManager().getSaturationLevel();
        snap.xpLevel = player.experienceLevel;
        snap.xpProgress = player.experienceProgress;
        ServerWorld world = player.getEntityWorld();
        snap.world = world.getRegistryKey().getValue().toString();
        Vec3d pos = player.getEntityPos();
        snap.x = pos.x;
        snap.y = pos.y;
        snap.z = pos.z;
        snap.yaw = player.getYaw();
        snap.pitch = player.getPitch();
        for (int i2 = 0; i2 < 4; ++i2) {
            inv.setStack(36 + i2, ItemStack.EMPTY);
        }
        inv.markDirty();
        player.currentScreenHandler.sendContentUpdates();
        session.preDuel = snap;
        PvPCore.get().snapshotStore().save(player.getUuid(), snap);
        return snap;
    }

    public void restoreSnapshot(ServerPlayerEntity player, InventorySnapshot snap) {
        if (snap != null) {
            Session session = this.session(player);
            PlayerInventory inv = player.getInventory();
            for (int i = 0; i < 36; ++i) {
                inv.setStack(i, ItemStack.EMPTY);
            }
            for (int var7 = 36; var7 < 40; ++var7) {
                inv.setStack(var7, ItemStack.EMPTY);
            }
            inv.setStack(40, ItemStack.EMPTY);
            for (int var8 = 0; var8 < 36; ++var8) {
                if (snap.main[var8] == null) continue;
                inv.setStack(var8, snap.main[var8].copy());
            }
            for (int ix = 0; ix < 4; ++ix) {
                if (snap.armor[ix] == null) continue;
                inv.setStack(36 + ix, snap.armor[ix].copy());
            }
            if (snap.offhand != null) {
                inv.setStack(40, snap.offhand.copy());
            }
            inv.setSelectedSlot(snap.selectedSlot);
            player.setHealth(Math.max(1.0f, snap.health));
            player.getHungerManager().setFoodLevel(snap.food);
            player.getHungerManager().setSaturationLevel(snap.saturation);
            player.experienceLevel = snap.xpLevel;
            player.experienceProgress = snap.xpProgress;
            inv.markDirty();
            player.currentScreenHandler.updateToClient();
            session.preDuel = null;
            PvPCore.get().snapshotStore().delete(player.getUuid());
        }
    }

    public InventorySnapshot preDuelSnapshot(ServerPlayerEntity player) {
        Session s = this.sessions.get(player.getUuid());
        return s != null ? s.preDuel : null;
    }

    public void clearAfterDuel(ServerPlayerEntity player, InventorySnapshot snap) {
        PlayerInventory inv = player.getInventory();
        for (int i = 0; i < 36; ++i) {
            inv.setStack(i, ItemStack.EMPTY);
        }
        for (int var5 = 36; var5 < 40; ++var5) {
            inv.setStack(var5, ItemStack.EMPTY);
        }
        inv.setStack(40, ItemStack.EMPTY);
        inv.markDirty();
        player.currentScreenHandler.updateToClient();
        if (snap != null) {
            player.setHealth(Math.max(1.0f, snap.health));
            player.getHungerManager().setFoodLevel(snap.food);
            player.getHungerManager().setSaturationLevel(snap.saturation);
        }
        this.session((ServerPlayerEntity)player).preDuel = null;
        PvPCore.get().snapshotStore().delete(player.getUuid());
    }

    public void teleportToSnapshot(ServerPlayerEntity player, InventorySnapshot snap) {
        if (snap != null) {
            MinecraftServer server = PvPCore.get().server();
            ServerWorld world = TeleportUtil.world(server, snap.world);
            if (world == null) {
                world = player.getEntityWorld();
            }
            TeleportUtil.teleport(player, world, snap.x, snap.y, snap.z, snap.yaw, snap.pitch);
        }
    }

    public void setDuelGameMode(ServerPlayerEntity player) {
        Session s = this.session(player);
        if (s.preDuelGamemode == null) {
            s.preDuelGamemode = player.interactionManager.getGameMode();
        }
        if (PvPCore.get().config().duel.forceSurvival && player.interactionManager.getGameMode() != GameMode.SURVIVAL) {
            player.changeGameMode(GameMode.SURVIVAL);
        }
    }

    public void restoreGameMode(ServerPlayerEntity player) {
        Session s = this.sessions.get(player.getUuid());
        GameMode wanted = null;
        if (s != null && s.preDuelGamemode != null && s.preDuelGamemode != GameMode.SPECTATOR) {
            wanted = s.preDuelGamemode;
        }
        if (wanted == null) {
            this.forceLobbyGameMode(player);
        } else {
            if (player.interactionManager.getGameMode() != wanted) {
                player.changeGameMode(wanted);
            }
            s.modSpectator = false;
        }
        if (s != null) {
            s.preDuelGamemode = null;
        }
    }

    public void markModSpectator(ServerPlayerEntity player, boolean value) {
        Session s = this.sessions.get(player.getUuid());
        if (s == null) {
            s = this.session(player);
        }
        s.modSpectator = value;
    }

    public boolean isInventoryLocked(ServerPlayerEntity player) {
        boolean active;
        MainConfig cfg = PvPCore.get().config();
        if (!cfg.lobby.lockInventory) {
            return false;
        }
        Session session = this.sessions.get(player.getUuid());
        if (session == null) {
            return false;
        }
        if (!session.loginSynced) {
            return false;
        }
        boolean bl = active = session.state == PlayerState.LOBBY || session.state == PlayerState.QUEUEING || session.state == PlayerState.SPECTATING && cfg.lobby.lockSpectators;
        if (!active) {
            return false;
        }
        return PvPCore.get().guiManager().hasGuiOpen(player) ? false : !PlayerManager.isAdmin(player) || !cfg.lobby.adminBypassLock && !this.buildBreak(player) && !this.buildPlace(player);
    }

    public static boolean isAdmin(ServerPlayerEntity player) {
        try {
            boolean bl;
            PermissionPredicate permissionPredicate = player.getPermissions();
            if (permissionPredicate instanceof LeveledPermissionPredicate) {
                LeveledPermissionPredicate leveled = (LeveledPermissionPredicate)permissionPredicate;
                bl = leveled.getLevel().isAtLeast(PermissionLevel.GAMEMASTERS);
            } else {
                bl = false;
            }
            return bl;
        }
        catch (Throwable var4) {
            return false;
        }
    }

    public static boolean isAdminSource(ServerCommandSource source) {
        try {
            boolean bl;
            PermissionPredicate permissionPredicate = source.getPermissions();
            if (permissionPredicate instanceof LeveledPermissionPredicate) {
                LeveledPermissionPredicate leveled = (LeveledPermissionPredicate)permissionPredicate;
                bl = leveled.getLevel().isAtLeast(PermissionLevel.GAMEMASTERS);
            } else {
                bl = false;
            }
            return bl;
        }
        catch (Throwable var4) {
            return false;
        }
    }

    public Session session(ServerPlayerEntity player) {
        return this.sessions.computeIfAbsent(player.getUuid(), u -> new Session());
    }

    public boolean buildBreak(ServerPlayerEntity player) {
        Session s = this.sessions.get(player.getUuid());
        return s != null && s.buildBreak;
    }

    public boolean buildPlace(ServerPlayerEntity player) {
        Session s = this.sessions.get(player.getUuid());
        return s != null && s.buildPlace;
    }

    public void setBuildBreak(ServerPlayerEntity player, boolean value) {
        this.session((ServerPlayerEntity)player).buildBreak = value;
    }

    public void setBuildPlace(ServerPlayerEntity player, boolean value) {
        this.session((ServerPlayerEntity)player).buildPlace = value;
    }

    public boolean buildBypass(ServerPlayerEntity player) {
        return this.buildBreak(player) || this.buildPlace(player);
    }

    public PlayerState state(ServerPlayerEntity player) {
        Session s = this.sessions.get(player.getUuid());
        return s != null ? s.state : PlayerState.LOBBY;
    }

    public void sweepStuckSpectators() {
        MinecraftServer server = PvPCore.get().server();
        if (server == null) {
            return;
        }
        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            Session s;
            if (player == null || player.interactionManager.getGameMode() != GameMode.SPECTATOR || PvPCore.get().spectateManager().isSpectating(player) || PvPCore.get().duelManager().duelOf(player) != null || PvPCore.get().zoneManager().isInZone(player) || (s = this.sessions.get(player.getUuid())) == null || !s.modSpectator && PlayerManager.isAdmin(player)) continue;
            this.forceLobbyGameMode(player);
        }
    }

    public void setState(ServerPlayerEntity player, PlayerState state) {
        this.session((ServerPlayerEntity)player).state = state;
    }

    public boolean loginSynced(ServerPlayerEntity player) {
        Session s = this.sessions.get(player.getUuid());
        return s == null || s.loginSynced;
    }

    public void teleportToLobby(ServerPlayerEntity player) {
        MainConfig.Lobby cfg = PvPCore.get().config().lobby;
        ServerWorld world = TeleportUtil.world(PvPCore.get().server(), cfg.lobbyWorld);
        if (world == null) {
            world = player.getEntityWorld();
        }
        TeleportUtil.teleport(player, world, cfg.lobbyX, cfg.lobbyY, cfg.lobbyZ, cfg.lobbyYaw, cfg.lobbyPitch);
    }

    public void refreshAllLobby() {
        MinecraftServer server = PvPCore.get().server();
        if (server != null) {
            for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                Session s = this.sessions.get(player.getUuid());
                if (s == null || !s.loginSynced || s.state != PlayerState.LOBBY && s.state != PlayerState.QUEUEING) continue;
                this.giveLobbyItems(player);
            }
        }
    }

    public void refreshLobby(ServerPlayerEntity player) {
        Session s = this.sessions.get(player.getUuid());
        if (s != null && s.loginSynced && (s.state == PlayerState.LOBBY || s.state == PlayerState.QUEUEING)) {
            this.giveLobbyItems(player);
        }
    }

    public static class Session {
        public PlayerState state = PlayerState.LOBBY;
        public boolean loginSynced = false;
        public long joinTick = 0L;
        public Vec3d joinPos;
        public final Map<Integer, ItemStack> lobbyStash = new HashMap<Integer, ItemStack>();
        public InventorySnapshot preDuel;
        public boolean spectatingReturnPending;
        public GameMode preDuelGamemode = null;
        public boolean buildBreak = false;
        public boolean buildPlace = false;
        public boolean modSpectator = false;
    }
}

