/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemStack
 */
package com.pvpcore.player;

import net.minecraft.item.ItemStack;

public class InventorySnapshot {
    public final ItemStack[] main = new ItemStack[36];
    public final ItemStack[] armor = new ItemStack[4];
    public ItemStack offhand = ItemStack.EMPTY;
    public int selectedSlot;
    public float health = 20.0f;
    public int food = 20;
    public float saturation = 5.0f;
    public int xpLevel;
    public float xpProgress;
    public String world;
    public double x;
    public double y;
    public double z;
    public float yaw;
    public float pitch;
    public String gameMode = "SURVIVAL";
}

