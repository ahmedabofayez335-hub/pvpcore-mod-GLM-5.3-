/*
 * Decompiled with CFR 0.152.
 */
package com.pvpcore.player;

public enum PlayerState {
    LOBBY,
    QUEUEING,
    DUELING,
    SPECTATING,
    ZONE;

}

