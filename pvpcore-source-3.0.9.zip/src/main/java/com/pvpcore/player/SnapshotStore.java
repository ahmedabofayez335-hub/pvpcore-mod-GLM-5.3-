/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 *  com.google.gson.GsonBuilder
 *  net.minecraft.entity.player.PlayerInventory
 *  net.minecraft.item.ItemStack
 *  net.minecraft.server.network.ServerPlayerEntity
 */
package com.pvpcore.player;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.pvpcore.PvPCoreMod;
import com.pvpcore.player.InventorySnapshot;
import com.pvpcore.util.ItemCodecUtil;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.FileAttribute;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;

public final class SnapshotStore {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private final Path dir;

    public SnapshotStore(Path dataDir) {
        this.dir = dataDir.resolve("pending");
        try {
            Files.createDirectories(this.dir, new FileAttribute[0]);
        }
        catch (IOException var3) {
            PvPCoreMod.LOGGER.error("Failed to create pending dir", (Throwable)var3);
        }
    }

    public void save(UUID uuid, InventorySnapshot snapshot) {
        Pending p = new Pending();
        p.world = snapshot.world;
        p.x = snapshot.x;
        p.y = snapshot.y;
        p.z = snapshot.z;
        p.yaw = snapshot.yaw;
        p.pitch = snapshot.pitch;
        p.health = snapshot.health;
        p.food = snapshot.food;
        p.saturation = snapshot.saturation;
        p.xpLevel = snapshot.xpLevel;
        p.xpProgress = snapshot.xpProgress;
        p.selectedSlot = snapshot.selectedSlot;
        for (int i = 0; i < 36; ++i) {
            p.main.add(ItemCodecUtil.toSnbt(snapshot.main[i]));
        }
        for (int var8 = 0; var8 < 4; ++var8) {
            p.armor.add(ItemCodecUtil.toSnbt(snapshot.armor[var8]));
        }
        p.offhand = ItemCodecUtil.toSnbt(snapshot.offhand);
        try {
            Path tmp = this.dir.resolve(String.valueOf(uuid) + ".json.tmp");
            Path file = this.dir.resolve(String.valueOf(uuid) + ".json");
            Files.writeString(tmp, (CharSequence)GSON.toJson((Object)p), StandardCharsets.UTF_8, new OpenOption[0]);
            Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        }
        catch (IOException var7) {
            PvPCoreMod.LOGGER.error("Failed to save pending snapshot for {}", (Object)uuid, (Object)var7);
        }
    }

    public boolean has(UUID uuid) {
        return Files.exists(this.dir.resolve(String.valueOf(uuid) + ".json"), new LinkOption[0]);
    }

    public Pending load(UUID uuid) {
        try {
            return (Pending)GSON.fromJson(Files.readString(this.dir.resolve(String.valueOf(uuid) + ".json"), StandardCharsets.UTF_8), Pending.class);
        }
        catch (Exception var3) {
            return null;
        }
    }

    public void delete(UUID uuid) {
        try {
            Files.deleteIfExists(this.dir.resolve(String.valueOf(uuid) + ".json"));
        }
        catch (IOException iOException) {
            // empty catch block
        }
    }

    public void restore(ServerPlayerEntity player) {
        UUID uuid = player.getUuid();
        Pending p = this.load(uuid);
        if (p != null) {
            ItemStack st;
            PlayerInventory inv = player.getInventory();
            for (int i = 0; i < 36; ++i) {
                inv.setStack(i, ItemStack.EMPTY);
            }
            for (int var9 = 36; var9 < 41; ++var9) {
                inv.setStack(var9, ItemStack.EMPTY);
            }
            for (int var10 = 0; var10 < Math.min(36, p.main.size()); ++var10) {
                st = ItemCodecUtil.fromSnbt(p.main.get(var10));
                if (st.isEmpty()) continue;
                inv.setStack(var10, st);
            }
            for (int ix = 0; ix < Math.min(4, p.armor.size()); ++ix) {
                st = ItemCodecUtil.fromSnbt(p.armor.get(ix));
                if (st.isEmpty()) continue;
                inv.setStack(36 + ix, st);
            }
            ItemStack off = ItemCodecUtil.fromSnbt(p.offhand);
            if (!off.isEmpty()) {
                inv.setStack(40, off);
            }
            inv.setSelectedSlot(p.selectedSlot);
            inv.markDirty();
            player.currentScreenHandler.sendContentUpdates();
            this.delete(uuid);
            PvPCoreMod.LOGGER.info("Restored pending inventory for {}", (Object)player.getGameProfile().name());
        }
    }

    public static class Pending {
        public String world;
        public double x;
        public double y;
        public double z;
        public float yaw;
        public float pitch;
        public float health = 20.0f;
        public int food = 20;
        public float saturation = 5.0f;
        public int xpLevel;
        public float xpProgress;
        public int selectedSlot;
        public List<String> main = new ArrayList<String>();
        public List<String> armor = new ArrayList<String>();
        public String offhand = "";
    }
}

