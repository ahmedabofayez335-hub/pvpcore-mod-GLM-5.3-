/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.Items
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.server.PlayerManager
 *  net.minecraft.server.network.ServerPlayerEntity
 *  net.minecraft.text.Text
 */
package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.config.Messages;
import com.pvpcore.data.PlayerData;
import com.pvpcore.gui.Gui;
import com.pvpcore.gui.guis.ConfirmGui;
import com.pvpcore.gui.guis.PartySplitGui;
import com.pvpcore.item.ItemBuilder;
import com.pvpcore.party.PartyManager;
import com.pvpcore.player.PlayerState;
import com.pvpcore.util.TextUtil;
import java.util.ArrayList;
import java.util.Map;
import java.util.UUID;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.PlayerManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

public class PartyGui
extends Gui {
    private static final int[] MEMBER_SLOTS = new int[]{10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25};

    public PartyGui(ServerPlayerEntity player) {
        super(player.getUuid(), "party_menu", 5);
    }

    private PartyManager.Party party() {
        return PvPCore.get().partyManager().partyOf(this.playerId);
    }

    @Override
    public void build() {
        PartyManager.Party party = this.party();
        if (party != null) {
            for (int i = 0; i < this.inv.size(); ++i) {
                this.set(i, ItemStack.EMPTY);
            }
            Messages mm = PvPCore.get().messages();
            PlayerManager pm = PvPCore.get().server().getPlayerManager();
            boolean leader = party.isLeader(this.playerId);
            String colorCode = party.color != null ? "&" + party.color.getCode() : "&d";
            this.buttonVar("info", Map.of("online", String.valueOf(party.onlineMembers().size()), "max", String.valueOf(PvPCore.get().config().party.maxSize), "leader", this.nameOf(party.leader), "color", colorCode + (party.color != null ? party.color.getName() : "PARTY")));
            ArrayList<UUID> members = new ArrayList<UUID>(party.members);
            members.sort((a, b) -> {
                int la = party.leader.equals(a) ? -1 : 0;
                int lb = party.leader.equals(b) ? -1 : 0;
                return la != lb ? Integer.compare(la, lb) : this.nameOf((UUID)a).compareToIgnoreCase(this.nameOf((UUID)b));
            });
            for (int i = 0; i < MEMBER_SLOTS.length && i < members.size(); ++i) {
                UUID u = members.get(i);
                ServerPlayerEntity member = pm.getPlayer(u);
                boolean isLeader = party.leader.equals(u);
                boolean online = member != null;
                String nameColor = online ? PvPCore.get().teamColors().colorCodeOf(member) : "&7";
                ArrayList<String> lore = new ArrayList<String>();
                lore.add(isLeader ? "&6Party Leader" : "&7Member");
                if (online) {
                    lore.add("&7Status: " + this.stateStr(PvPCore.get().playerManager().state(member)));
                    lore.add("&7Ping: &f" + this.ping(member) + "ms");
                } else {
                    lore.add("&cOffline");
                }
                if (leader && !u.equals(this.playerId)) {
                    lore.add("");
                    lore.add("&eLeft-Click &7to kick");
                    lore.add("&eRight-Click &7to promote to leader");
                }
                this.set(MEMBER_SLOTS[i], ItemBuilder.of(Items.PLAYER_HEAD).skullOwner(u, this.nameOf(u)).name((isLeader ? "&6\u2605 " : "") + nameColor + this.nameOf(u) + (isLeader ? " &6\u2605" : "")).lore(lore).build());
            }
            this.button("invite");
            PlayerData data = PvPCore.get().storage().get(this.playerId, null);
            boolean partyChat = data != null && data.partyChat;
            this.buttonVar("chat", Map.of("status", partyChat ? "&aON" : "&cOFF"));
            if (leader) {
                this.button("duel");
                this.button("split");
            }
            this.buttonVar(leader ? "disband" : "leave", Map.of());
            this.button("close");
            for (int i = 0; i < this.inv.size(); ++i) {
                if (!this.inv.getStack(i).isEmpty()) continue;
                this.set(i, this.filler());
            }
        }
    }

    private String stateStr(PlayerState state) {
        return switch (state) {
            default -> throw new MatchException(null, null);
            case PlayerState.LOBBY -> "&aLobby";
            case PlayerState.QUEUEING -> "&eIn Queue";
            case PlayerState.DUELING -> "&cDueling";
            case PlayerState.SPECTATING -> "&5Spectating";
            case PlayerState.ZONE -> "&cFighting";
        };
    }

    private String nameOf(UUID uuid) {
        ServerPlayerEntity p = PvPCore.get().server().getPlayerManager().getPlayer(uuid);
        return p != null ? p.getGameProfile().name() : "?";
    }

    private int ping(ServerPlayerEntity p) {
        try {
            return Math.max(0, p.networkHandler.getLatency());
        }
        catch (Throwable var3) {
            return 0;
        }
    }

    private UUID memberAt(int slot, PartyManager.Party party) {
        ArrayList<UUID> members = new ArrayList<UUID>(party.members);
        members.sort((a, b) -> {
            int la = party.leader.equals(a) ? -1 : 0;
            int lb = party.leader.equals(b) ? -1 : 0;
            return la != lb ? Integer.compare(la, lb) : this.nameOf((UUID)a).compareToIgnoreCase(this.nameOf((UUID)b));
        });
        int idx = -1;
        for (int i = 0; i < MEMBER_SLOTS.length; ++i) {
            if (MEMBER_SLOTS[i] != slot) continue;
            idx = i;
        }
        return idx >= 0 && idx < members.size() ? members.get(idx) : null;
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        PartyManager.Party party = this.party();
        if (party == null) {
            PvPCore.get().guiManager().close(player);
        } else {
            boolean leader = party.isLeader(player.getUuid());
            UUID memberUuid = this.memberAt(slot, party);
            if (memberUuid != null && !memberUuid.equals(player.getUuid()) && leader) {
                PlayerManager pm = PvPCore.get().server().getPlayerManager();
                ServerPlayerEntity member = pm.getPlayer(memberUuid);
                if (member != null) {
                    if (this.isLeftClick(type, button)) {
                        new ConfirmGui(player, TextUtil.colorize("&cKick &e" + member.getGameProfile().name() + "&c?"), () -> {
                            PvPCore.get().partyManager().kick(player, member);
                            new PartyGui(player).open(player);
                        }, () -> new PartyGui(player).open(player)).open(player);
                    } else if (this.isRightClick(type, button)) {
                        new ConfirmGui(player, TextUtil.colorize("&6Promote &e" + member.getGameProfile().name() + "&6 to leader?"), () -> {
                            PvPCore.get().partyManager().promote(player, member);
                            new PartyGui(player).open(player);
                        }, () -> new PartyGui(player).open(player)).open(player);
                    }
                }
            } else if (this.isLeftClick(type, button)) {
                String var10;
                String b = this.buttonAt(slot);
                String member = b == null ? "" : b;
                switch (var10 = member) {
                    case "invite": {
                        PvPCore.get().partyManager().openInvitePicker(player);
                        break;
                    }
                    case "chat": {
                        PlayerData data = PvPCore.get().storage().get(player.getUuid(), player.getGameProfile().name());
                        data.partyChat = !data.partyChat;
                        PvPCore.get().storage().markDirty(player.getUuid());
                        player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get(data.partyChat ? "party.chat-on" : "party.chat-off")), false);
                        this.refresh(player);
                        break;
                    }
                    case "duel": {
                        if (!leader) {
                            player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("party.not-leader")), false);
                            return;
                        }
                        PvPCore.get().partyManager().openDuelPicker(player);
                        break;
                    }
                    case "split": {
                        if (!leader) {
                            player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("party.not-leader")), false);
                            return;
                        }
                        new PartySplitGui(player).open(player);
                        break;
                    }
                    case "leave": {
                        PvPCore.get().guiManager().close(player);
                        PvPCore.get().partyManager().leave(player);
                        break;
                    }
                    case "disband": {
                        if (!leader) {
                            player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("party.not-leader")), false);
                            return;
                        }
                        new ConfirmGui(player, TextUtil.colorize("&cDisband the party?"), () -> PvPCore.get().partyManager().disband(player), () -> new PartyGui(player).open(player)).open(player);
                        break;
                    }
                    case "close": {
                        PvPCore.get().guiManager().close(player);
                    }
                }
            }
        }
    }
}

