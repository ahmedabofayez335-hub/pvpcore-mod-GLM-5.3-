/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemStack
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.server.network.ServerPlayerEntity
 *  net.minecraft.text.Text
 */
package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.config.Messages;
import com.pvpcore.data.PlayerData;
import com.pvpcore.gui.Gui;
import com.pvpcore.gui.guis.KitStatsGui;
import com.pvpcore.item.ItemBuilder;
import com.pvpcore.kit.Kit;
import com.pvpcore.kit.KitManager;
import com.pvpcore.player.PlayerManager;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

public class KitListGui
extends Gui {
    private int page = 0;

    public KitListGui(ServerPlayerEntity player) {
        super(player.getUuid(), "kit_list", 5);
    }

    private List<Kit> kits() {
        return PvPCore.get().kitManager().sortedAll().stream().filter(k -> k.enabled).toList();
    }

    private List<Integer> kitSlots() {
        return PvPCore.get().guiConfig().kitSlots("kit_list");
    }

    @Override
    public void build() {
        List<Kit> kits = this.kits();
        List<Integer> slots = this.kitSlots();
        int perPage = slots.size();
        int pages = Math.max(1, (kits.size() + perPage - 1) / perPage);
        if (this.page >= pages) {
            this.page = pages - 1;
        }
        for (int i = 0; i < this.inv.size(); ++i) {
            this.set(i, ItemStack.EMPTY);
        }
        boolean admin = PlayerManager.isAdmin(PvPCore.get().server().getPlayerManager().getPlayer(this.playerId));
        for (int i = 0; i < slots.size(); ++i) {
            int idx = this.page * perPage + i;
            if (idx >= kits.size()) continue;
            Kit kit = kits.get(idx);
            boolean custom = PvPCore.get().storage().get((UUID)this.playerId, null).loadouts.containsKey(kit.id);
            ArrayList<String> lore = new ArrayList<String>(List.of("&7Your layout: " + (custom ? "&aCustom" : "&7Default"), "", "&eLeft-Click &7to view & edit", "&cRight-Click &7to reset to default"));
            if (admin) {
                lore.addAll(List.of("", "&cAdmin: manage this kit (rename,", "&cicon, position, delete) via Left-Click"));
            }
            this.set(slots.get(i), ItemBuilder.of(kit.displayStack()).name(kit.displayName).lore(lore).build());
        }
        for (int ix = 0; ix < this.inv.size(); ++ix) {
            if (!this.inv.getStack(ix).isEmpty()) continue;
            this.set(ix, this.filler());
        }
        this.set(4, this.item("info"));
        if (admin) {
            this.button("create");
        }
        this.button("prev");
        this.button("next");
        this.button("close");
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        List<Kit> kits = this.kits();
        List<Integer> slots = this.kitSlots();
        int idx = slots.indexOf(slot);
        if (idx >= 0) {
            int kitIdx = this.page * slots.size() + idx;
            if (kitIdx < kits.size()) {
                Kit kit = kits.get(kitIdx);
                if (this.isLeftClick(type, button)) {
                    new KitStatsGui(player, kit.id).open(player);
                } else if (this.isRightClick(type, button)) {
                    PlayerData data = PvPCore.get().storage().get(player.getUuid(), player.getGameProfile().name());
                    data.loadouts.remove(kit.id);
                    PvPCore.get().storage().markDirty(player.getUuid());
                    player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("kit.layout-reset", Map.of("kit", kit.displayName))), false);
                    this.refresh(player);
                } else if ((type == SlotActionType.SWAP || type == SlotActionType.CLONE) && PlayerManager.isAdmin(player)) {
                    PvPCore.get().kitManager().delete(kit.id);
                    PvPCore.get().auditLog().log(player.getGameProfile().name(), "Deleted kit " + kit.id);
                    player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("kit.deleted", Map.of("kit", kit.id))), false);
                    this.refresh(player);
                }
            }
        } else if (this.isLeftClick(type, button)) {
            String var14;
            String b = this.buttonAt(slot);
            String kit = b == null ? "" : b;
            switch (var14 = kit) {
                case "create": {
                    if (!PlayerManager.isAdmin(player)) {
                        return;
                    }
                    PvPCore.get().guiManager().close(player);
                    PvPCore.get().guiManager().openAnvil(player, "&8New Kit - enter an id", name -> {
                        Kit created = KitListGui.createKitFromInventory(player, name);
                        new KitListGui(player).open(player);
                    });
                    break;
                }
                case "prev": {
                    this.page = Math.max(0, this.page - 1);
                    this.refresh(player);
                    break;
                }
                case "next": {
                    ++this.page;
                    this.refresh(player);
                    break;
                }
                case "close": {
                    PvPCore.get().guiManager().close(player);
                }
            }
        }
    }

    public static Kit createKitFromInventory(ServerPlayerEntity player, String rawName) {
        String id;
        Messages mm = PvPCore.get().messages();
        String string = id = rawName == null ? "" : rawName.trim().toLowerCase().replaceAll("[^a-z0-9_-]", "");
        if (!KitManager.validId(id)) {
            player.sendMessage((Text)Text.literal((String)mm.get("kit.invalid-name")), false);
            return null;
        }
        if (PvPCore.get().kitManager().get(id) != null) {
            player.sendMessage((Text)Text.literal((String)mm.get("kit.already-exists", Map.of("kit", id))), false);
            return null;
        }
        Kit kit = PvPCore.get().kitManager().createFromInventory(id, "&f" + rawName.trim(), player.getInventory());
        PvPCore.get().kitManager().put(kit);
        PvPCore.get().auditLog().log(player.getGameProfile().name(), "Created kit " + id + " from inventory");
        player.sendMessage((Text)Text.literal((String)mm.get("kit.created-from-inventory", Map.of("kit", id))), false);
        return kit;
    }
}

