/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.Items
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.server.network.ServerPlayerEntity
 */
package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.data.PlayerData;
import com.pvpcore.data.PlayerStats;
import com.pvpcore.gui.Gui;
import com.pvpcore.item.ItemBuilder;
import com.pvpcore.kit.Kit;
import java.util.ArrayList;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;

public class StatsGui
extends Gui {
    private final ServerPlayerEntity target;

    public StatsGui(ServerPlayerEntity viewer, ServerPlayerEntity target) {
        super(viewer.getUuid(), "stats", 6);
        this.target = target;
    }

    @Override
    public void build() {
        for (int i2 = 0; i2 < 54; ++i2) {
            this.set(i2, ItemStack.EMPTY);
        }
        PlayerData data = PvPCore.get().storage().get(this.target.getUuid(), this.target.getGameProfile().name());
        PlayerStats global = data.globalStats();
        this.set(4, ItemBuilder.of(Items.PLAYER_HEAD).skullOwner(this.target).name("&e" + this.target.getGameProfile().name()).lore("&7Global Wins: &a" + global.wins, "&7Global Losses: &c" + global.losses, "&7Global ELO: &f" + data.ratingFor("global", PvPCore.get().config().elo.startRating)).build());
        ArrayList<Kit> kits = new ArrayList<Kit>(PvPCore.get().kitManager().all());
        int[] slots = new int[36];
        for (int i = 0; i < 36; ++i) {
            slots[i] = 9 + i;
        }
        for (int var8 = 0; var8 < slots.length && var8 < kits.size(); ++var8) {
            Kit kit = kits.get(var8);
            PlayerStats stats = data.statsFor(kit.id);
            this.set(slots[var8], ItemBuilder.of(kit.displayStack()).name(kit.displayName).lore("&7Wins: &a" + stats.wins, "&7Losses: &c" + stats.losses, "&7Win rate: &f" + String.format("%.1f", stats.winRate()) + "%", "&7Hits: &f" + stats.hits, "&7ELO: &f" + data.ratingFor(kit.id, PvPCore.get().config().elo.startRating), "&7Best streak: &6" + stats.bestStreak).build());
        }
        this.button("back");
        this.button("close");
        for (int var9 = 0; var9 < 54; ++var9) {
            if (!this.inv.getStack(var9).isEmpty()) continue;
            this.set(var9, this.filler());
        }
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        String b;
        if (this.isLeftClick(type, button) && ("back".equals(b = this.buttonAt(slot)) || "close".equals(b))) {
            PvPCore.get().guiManager().close(player);
        }
    }
}

