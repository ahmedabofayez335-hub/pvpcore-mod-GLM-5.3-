/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.Items
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.server.network.ServerPlayerEntity
 */
package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.data.PlayerData;
import com.pvpcore.data.PlayerStats;
import com.pvpcore.gui.Gui;
import com.pvpcore.gui.guis.KitStatsGui;
import com.pvpcore.gui.guis.LeaderboardGui;
import com.pvpcore.item.ItemBuilder;
import com.pvpcore.kit.Kit;
import java.util.ArrayList;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;

public class ProfileGui
extends Gui {
    private final ServerPlayerEntity target;
    private static final int[] KIT_SLOTS = new int[]{28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 42, 43};

    public ProfileGui(ServerPlayerEntity viewer, ServerPlayerEntity target) {
        super(viewer.getUuid(), "profile", 6);
        this.target = target;
    }

    private static String rank(int rank) {
        return rank > 0 ? "&f#" + rank : "&7unranked";
    }

    @Override
    public void build() {
        for (int i = 0; i < 54; ++i) {
            this.set(i, ItemStack.EMPTY);
        }
        PlayerData data = PvPCore.get().storage().get(this.target.getUuid(), this.target.getGameProfile().name());
        PlayerStats global = data.globalStats();
        String name = this.target.getGameProfile().name();
        int elo = data.ratingFor("global", PvPCore.get().config().elo.startRating);
        int globalRank = PvPCore.get().leaderboardManager().rankOf(name, "global", "elo");
        String wr = String.format("%.1f", global.winRate());
        this.set(4, ItemBuilder.of(Items.PLAYER_HEAD).skullOwner(this.target).name("&e&l" + name).lore("&8Global Overview", "", "&7ELO: &f" + elo + " &8- " + ProfileGui.rank(globalRank), "&7Record: &a" + global.wins + " &7wins &c" + global.losses + " &7losses", "&7Win rate: &f" + wr + "%", "", "&7Duels played: &f" + global.duels, "&7Best streak: &6" + global.bestStreak).build());
        this.set(19, this.stat("GOLDEN_APPLE", "&a&lWins", "&f" + global.wins, "&7Duels won.", "&7Win rate: &f" + wr + "%"));
        this.set(20, this.stat("IRON_SWORD", "&c&lLosses", "&f" + global.losses, "&7Duels lost.", "&7Keep fighting!"));
        this.set(21, this.stat("SPYGLASS", "&e&lWin Rate", "&f" + wr + "%", "&7Across all gamemodes.", "&7Duels: &f" + global.duels));
        this.set(22, this.stat("BOW", "&f&lDuels", "&f" + global.duels, "&7Duels played.", "&7Hits dealt: &f" + global.hits));
        this.set(23, this.stat("ARROW", "&f&lHits Dealt", "&f" + global.hits, "&7Total hits in duels."));
        this.set(24, this.stat("BLAZE_ROD", "&6&lStreak", "&f" + global.streak, "&7Current win streak.", global.streak > 0 ? "&aOn fire!" : "&7Start a duel!"));
        this.set(25, this.stat("BLAZE_POWDER", "&6&lBest Streak", "&f" + global.bestStreak, "&7Your record streak."));
        ArrayList<Kit> kits = new ArrayList<Kit>(PvPCore.get().kitManager().sortedAll());
        kits.removeIf(k -> !k.enabled);
        for (int i = 0; i < KIT_SLOTS.length && i < kits.size(); ++i) {
            Kit kit = kits.get(i);
            PlayerStats stats = data.statsFor(kit.id);
            int kitElo = data.ratingFor(kit.id, PvPCore.get().config().elo.startRating);
            int kitRank = PvPCore.get().leaderboardManager().rankOf(name, kit.id, "elo");
            int playing = PvPCore.get().duelManager().playersFighting(kit.id);
            int queued = PvPCore.get().queueManager().queueSize(kit.id, true) + PvPCore.get().queueManager().queueSize(kit.id, false);
            this.set(KIT_SLOTS[i], ItemBuilder.of(kit.displayStack()).name(kit.displayName).lore("&7Your statistics for this kit.", "", "&7ELO: &f" + kitElo + " &8- " + ProfileGui.rank(kitRank), "&7Record: &a" + stats.wins + " &7wins &c" + stats.losses + " &7losses &8(&f" + String.format("%.1f", stats.winRate()) + "%&8)", "&7Streak: &f" + stats.streak + " &8(&6" + stats.bestStreak + " best&8)", "", "&7Playing now: &e" + playing + " &8| &7In queue: &e" + queued, "", "&eClick &7for details & actions").build());
        }
        this.set(45, ItemBuilder.of("EMERALD").name("&a&lLeaderboards").lore("&7View the top players", "&7by wins and ELO.", "", "&eClick &7to open").build());
        this.button("close");
    }

    private ItemStack stat(String material, String title, String value, String ... lore) {
        ArrayList<String> lines = new ArrayList<String>();
        lines.add("");
        lines.add(value);
        for (String l : lore) {
            lines.add(l);
        }
        return ItemBuilder.of(material).name(title).lore(lines).build();
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        if (this.isLeftClick(type, button)) {
            String b = this.buttonAt(slot);
            if ("close".equals(b)) {
                PvPCore.get().guiManager().close(player);
            } else if (slot == 45) {
                new LeaderboardGui(player).open(player);
            } else {
                for (int i = 0; i < KIT_SLOTS.length; ++i) {
                    if (KIT_SLOTS[i] != slot) continue;
                    ArrayList<Kit> kits = new ArrayList<Kit>(PvPCore.get().kitManager().sortedAll());
                    kits.removeIf(k -> !k.enabled);
                    if (i < kits.size()) {
                        new KitStatsGui(player, kits.get((int)i).id).open(player);
                    }
                    return;
                }
            }
        }
    }
}

