/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemStack
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.server.network.ServerPlayerEntity
 *  net.minecraft.text.Text
 */
package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.config.MainConfig;
import com.pvpcore.gui.Gui;
import com.pvpcore.gui.guis.AdminGui;
import com.pvpcore.player.PlayerManager;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

public class ScoreboardSettingsGui
extends Gui {
    private static final int[] LINE_SLOTS = new int[]{10, 11, 12, 13, 14, 15, 16, 28, 29, 30, 31, 32, 33, 34};

    public ScoreboardSettingsGui(ServerPlayerEntity player) {
        super(player.getUuid(), "scoreboard_settings", 6);
    }

    private MainConfig.ScoreboardSection sb() {
        return PvPCore.get().config().scoreboard;
    }

    private List<String> lines() {
        return new ArrayList<String>(this.sb().lines);
    }

    private void persist() {
        PvPCore.get().config().save();
    }

    @Override
    public void build() {
        MainConfig.ScoreboardSection cfg = this.sb();
        List<String> lines = this.lines();
        for (int i = 0; i < this.inv.size(); ++i) {
            this.set(i, ItemStack.EMPTY);
        }
        this.buttonVar("toggle", Map.of("state", cfg.enabled ? "&aON" : "&cOFF"));
        this.buttonVar("title", Map.of("title", cfg.title));
        this.buttonVar("interval", Map.of("interval", String.valueOf(cfg.updateIntervalTicks)));
        for (int var5 = 0; var5 < LINE_SLOTS.length && var5 < lines.size(); ++var5) {
            String raw = lines.get(var5);
            this.set(LINE_SLOTS[var5], this.itemVar("line", Map.of("index", String.valueOf(var5 + 1), "preview", raw.isEmpty() ? "(empty line)" : raw)));
        }
        this.button("reset");
        this.button("add");
        this.button("back");
        this.button("close");
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        if (!PlayerManager.isAdmin(player)) {
            PvPCore.get().guiManager().close(player);
        } else {
            int lineIdx = -1;
            for (int i = 0; i < LINE_SLOTS.length; ++i) {
                if (LINE_SLOTS[i] != slot) continue;
                lineIdx = i;
            }
            if (lineIdx >= 0) {
                this.clickLine(lineIdx, button, type, player);
            } else if (type != SlotActionType.QUICK_MOVE || button != 0) {
                if (this.isLeftClick(type, button)) {
                    String var9;
                    String b2 = this.buttonAt(slot);
                    String key = b2 == null ? "" : b2;
                    switch (var9 = key) {
                        case "toggle": {
                            MainConfig.ScoreboardSection cfg = this.sb();
                            cfg.enabled = !cfg.enabled;
                            this.persist();
                            player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get(cfg.enabled ? "sb.enabled" : "sb.disabled")), false);
                            this.refresh(player);
                            break;
                        }
                        case "title": {
                            PvPCore.get().guiManager().close(player);
                            PvPCore.get().guiManager().openAnvil(player, "&8Scoreboard Title - type it", name -> {
                                if (name != null && !name.isBlank()) {
                                    this.sb().title = name.trim();
                                    this.persist();
                                    player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("sb.title-set")), false);
                                }
                                new ScoreboardSettingsGui(player).open(player);
                            });
                            break;
                        }
                        case "interval": {
                            MainConfig.ScoreboardSection cfg2 = this.sb();
                            cfg2.updateIntervalTicks = Math.max(5, cfg2.updateIntervalTicks - 5);
                            this.persist();
                            this.refresh(player);
                            break;
                        }
                        case "add": {
                            if (this.lines().size() >= LINE_SLOTS.length) {
                                player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("sb.too-many-lines", Map.of("max", String.valueOf(LINE_SLOTS.length)))), false);
                                return;
                            }
                            PvPCore.get().guiManager().close(player);
                            PvPCore.get().guiManager().openAnvil(player, "&8New Line - &o{player1} {ping1} &7...", name -> {
                                if (name != null && !name.isBlank()) {
                                    List<String> ls = this.lines();
                                    ls.add(name.trim());
                                    this.sb().lines = ls;
                                    this.persist();
                                    player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("sb.line-added")), false);
                                }
                                new ScoreboardSettingsGui(player).open(player);
                            });
                            break;
                        }
                        case "reset": {
                            this.resetToDefaults();
                            this.persist();
                            player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("sb.reset")), false);
                            this.refresh(player);
                            break;
                        }
                        case "back": {
                            new AdminGui(player).open(player);
                            break;
                        }
                        case "close": {
                            PvPCore.get().guiManager().close(player);
                        }
                    }
                } else if (this.isRightClick(type, button) && "interval".equals(this.buttonAt(slot))) {
                    MainConfig.ScoreboardSection cfg = this.sb();
                    cfg.updateIntervalTicks = Math.min(200, cfg.updateIntervalTicks + 5);
                    this.persist();
                    this.refresh(player);
                }
            }
        }
    }

    private void clickLine(int index, int button, SlotActionType type, ServerPlayerEntity player) {
        List<String> lines = this.lines();
        if (index >= 0 && index < lines.size()) {
            if (type == SlotActionType.QUICK_MOVE && button == 0) {
                lines.remove(index);
                this.sb().lines = lines;
                this.persist();
                player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("sb.line-removed")), false);
                this.refresh(player);
            } else if (this.isLeftClick(type, button) && index > 0) {
                String moved = lines.remove(index);
                lines.add(index - 1, moved);
                this.sb().lines = lines;
                this.persist();
                this.refresh(player);
            } else if (this.isRightClick(type, button) && index < lines.size() - 1) {
                String moved = lines.remove(index);
                lines.add(index + 1, moved);
                this.sb().lines = lines;
                this.persist();
                this.refresh(player);
            }
        }
    }

    private void resetToDefaults() {
        MainConfig.ScoreboardSection fresh = new MainConfig.ScoreboardSection();
        MainConfig.ScoreboardSection cfg = this.sb();
        cfg.title = fresh.title;
        cfg.lines = fresh.lines;
        cfg.updateIntervalTicks = fresh.updateIntervalTicks;
    }
}

