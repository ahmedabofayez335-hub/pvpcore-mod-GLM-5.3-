/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.server.network.ServerPlayerEntity
 */
package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.gui.Gui;
import java.util.Map;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;

public class ConfirmGui
extends Gui {
    private final String titleText;
    private final Runnable onYes;
    private final Runnable onNo;

    public ConfirmGui(ServerPlayerEntity player, String title, Runnable onYes, Runnable onNo) {
        super(player.getUuid(), "confirm", 3);
        this.titleText = title;
        this.onYes = onYes;
        this.onNo = onNo;
    }

    @Override
    public void build() {
        this.fillAll(this.filler());
        this.buttonVar("info", Map.of("title", this.titleText, "lines", ""));
        this.button("yes");
        this.button("no");
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        if (this.isLeftClick(type, button)) {
            String b = this.buttonAt(slot);
            if ("yes".equals(b)) {
                PvPCore.get().guiManager().close(player);
                if (this.onYes != null) {
                    this.onYes.run();
                }
            } else if ("no".equals(b)) {
                PvPCore.get().guiManager().close(player);
                if (this.onNo != null) {
                    this.onNo.run();
                }
            }
        }
    }
}

