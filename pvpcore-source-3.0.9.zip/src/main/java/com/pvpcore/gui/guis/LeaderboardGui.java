/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.Items
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.server.network.ServerPlayerEntity
 */
package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.gui.Gui;
import com.pvpcore.item.ItemBuilder;
import com.pvpcore.kit.Kit;
import com.pvpcore.leaderboard.LeaderboardManager;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;

public class LeaderboardGui
extends Gui {
    private static final int MODE_GLOBAL = -1;
    private int kitIndex = -1;
    private String type = "wins";
    private int page = 0;

    public LeaderboardGui(ServerPlayerEntity player) {
        super(player.getUuid(), "leaderboard", 6);
    }

    private List<Kit> kits() {
        return new ArrayList<Kit>(PvPCore.get().kitManager().all());
    }

    @Override
    public void build() {
        int i;
        List<Kit> kits = this.kits();
        if (this.kitIndex >= kits.size()) {
            this.kitIndex = -1;
        }
        for (int i2 = 0; i2 < 54; ++i2) {
            this.set(i2, ItemStack.EMPTY);
        }
        this.set(9, ItemBuilder.of(Items.NETHER_STAR).name("&e&lGlobal").lore(this.kitIndex == -1 ? List.of("&aCurrently selected") : List.of("&7Click to view global")).glow(this.kitIndex == -1).build());
        for (int var13 = 0; var13 < kits.size() && var13 < 7; ++var13) {
            Kit kit = kits.get(var13);
            this.set(10 + var13, ItemBuilder.of(kit.displayStack()).name(kit.displayName).lore(this.kitIndex == var13 ? List.of("&aCurrently selected") : List.of("&7Click to view this kit")).glow(this.kitIndex == var13).build());
        }
        String kitId = this.kitIndex == -1 ? "global" : kits.get((int)this.kitIndex).id;
        List<LeaderboardManager.Entry> top = PvPCore.get().leaderboardManager().top(kitId, this.type, 50);
        int perPage = 27;
        int pages = Math.max(1, (top.size() + perPage - 1) / perPage);
        if (this.page >= pages) {
            this.page = pages - 1;
        }
        int[] slots = new int[perPage];
        for (i = 0; i < 7; ++i) {
        }
        i = 0;
        for (int row = 2; row <= 4 && i < perPage; ++row) {
            for (int col = 1; col <= 7 && i < perPage; ++col) {
                slots[i++] = row * 9 + col;
            }
        }
        for (int ix = 0; ix < perPage; ++ix) {
            int idx = this.page * perPage + ix;
            if (idx >= top.size()) continue;
            LeaderboardManager.Entry entry = top.get(idx);
            this.set(slots[ix], ItemBuilder.of(Items.PLAYER_HEAD).skullOwner(entry.name()).name("&e#" + (idx + 1) + " &f" + entry.name()).lore("&7" + (this.type.equals("elo") ? "ELO" : "Wins") + ": &f" + entry.value()).build());
        }
        this.button("global");
        this.button("prev");
        this.buttonVar("switch", Map.of("type", this.type.equals("elo") ? "ELO" : "Wins"));
        this.button("next");
        this.button("back");
        for (int ixx = 0; ixx < 54; ++ixx) {
            if (!this.inv.getStack(ixx).isEmpty()) continue;
            this.set(ixx, this.filler());
        }
    }

    @Override
    public void click(int slot, int button, SlotActionType type2, ServerPlayerEntity player) {
        List<Kit> kits = this.kits();
        if (this.isLeftClick(type2, button)) {
            String b = this.buttonAt(slot);
            if (slot == 9) {
                this.kitIndex = -1;
                this.page = 0;
                this.refresh(player);
            } else if (slot >= 10 && slot <= 16) {
                int idx = slot - 10;
                if (idx < kits.size()) {
                    this.kitIndex = idx;
                    this.page = 0;
                    this.refresh(player);
                }
            } else if ("prev".equals(b)) {
                this.page = Math.max(0, this.page - 1);
                this.refresh(player);
            } else if ("next".equals(b)) {
                ++this.page;
                this.refresh(player);
            } else if ("switch".equals(b)) {
                this.type = this.type.equals("wins") ? "elo" : "wins";
                this.page = 0;
                this.refresh(player);
            } else if ("back".equals(b)) {
                PvPCore.get().guiManager().close(player);
            }
        }
    }
}

