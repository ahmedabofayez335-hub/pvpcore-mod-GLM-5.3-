/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemStack
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.server.network.ServerPlayerEntity
 */
package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.data.PlayerData;
import com.pvpcore.data.PlayerStats;
import com.pvpcore.gui.Gui;
import com.pvpcore.item.ItemBuilder;
import com.pvpcore.kit.Kit;
import com.pvpcore.util.ItemCodecUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;

public class KitPickerGui
extends Gui {
    private final boolean ranked;
    private final ServerPlayerEntity challengeTarget;
    private final boolean partyMode;
    private final boolean pickRounds;
    private int rounds;
    protected String customHint = null;
    private int page = 0;

    public KitPickerGui(ServerPlayerEntity player, boolean ranked, ServerPlayerEntity challengeTarget) {
        this(player, ranked, challengeTarget, false);
    }

    public KitPickerGui(ServerPlayerEntity player, boolean ranked, ServerPlayerEntity challengeTarget, boolean partyMode) {
        this(player, ranked, challengeTarget, partyMode, true);
    }

    public KitPickerGui(ServerPlayerEntity player, boolean ranked, ServerPlayerEntity challengeTarget, boolean partyMode, boolean pickRounds) {
        super(player.getUuid(), "queue", 5);
        this.ranked = ranked;
        this.challengeTarget = challengeTarget;
        this.partyMode = partyMode;
        this.pickRounds = pickRounds;
        this.rounds = Math.max(1, PvPCore.get().config().duel.defaultRounds);
    }

    private List<Kit> kits() {
        return new ArrayList<Kit>(PvPCore.get().kitManager().all()).stream().filter(k -> k.enabled).toList();
    }

    private List<Integer> kitSlots() {
        return PvPCore.get().guiConfig().kitSlots("queue");
    }

    private int maxRounds() {
        return Math.max(1, PvPCore.get().config().duel.maxRounds);
    }

    public int currentRounds() {
        return this.rounds;
    }

    @Override
    public void build() {
        List<Kit> kits = this.kits();
        List<Integer> kitSlots = this.kitSlots();
        int perPage = kitSlots.size();
        int pages = Math.max(1, (kits.size() + perPage - 1) / perPage);
        if (this.page >= pages) {
            this.page = pages - 1;
        }
        for (int i = 0; i < this.inv.size(); ++i) {
            this.set(i, ItemStack.EMPTY);
        }
        for (int var18 = 0; var18 < kitSlots.size(); ++var18) {
            int idx = this.page * perPage + var18;
            if (idx >= kits.size()) continue;
            Kit kit = kits.get(idx);
            PlayerData data = PvPCore.get().storage().get(this.playerId, null);
            PlayerStats stats = data.statsFor(kit.id);
            int elo = data.ratingFor(kit.id, PvPCore.get().config().elo.startRating);
            int queued = PvPCore.get().queueManager().queueSize(kit.id, this.ranked);
            int queuedAll = PvPCore.get().queueManager().queueSize(kit.id, true) + PvPCore.get().queueManager().queueSize(kit.id, false);
            int playing = PvPCore.get().duelManager().playingCount(kit.id);
            int fighting = PvPCore.get().duelManager().playersFighting(kit.id);
            // 3.0.8: the stack count ON the item shows the duels running in THIS
            // kit and THIS mode (unranked/ranked); the lore spells it out.
            int activeMode = PvPCore.get().duelManager().playingCount(kit.id, this.ranked);
            int usableArenas = PvPCore.get().arenaManager().countUsable(kit.id);
            int dedicatedArenas = PvPCore.get().arenaManager().countDedicated(kit.id);
            String modeName = this.ranked ? "ranked" : "unranked";
            ArrayList<String> lore = new ArrayList<String>(List.of("&7Click to " + (this.challengeTarget != null ? "challenge with" : "queue for") + " this kit.", "", "&8Live activity", "&7In queue: &e" + queued + " &8(" + modeName + ")", "&7In queue (all): &e" + queuedAll, "&7Active duels &8(" + modeName + "): &e" + activeMode, "&7Playing now: &e" + playing + " &7duel" + (playing == 1 ? "" : "s") + " &8(" + fighting + " player" + (fighting == 1 ? "" : "s") + " &8- all modes)", "&7Arenas: &e" + usableArenas + " &8(" + dedicatedArenas + " for this kit)", "", "&8Your record", "&7ELO: &f" + elo, "&7Record: &a" + stats.wins + " &7wins &c" + stats.losses + " &7losses &8(&f" + String.format("%.1f", stats.winRate()) + "%&8)", "&7Streak: &f" + stats.streak + " &8(&6" + stats.bestStreak + " best&8)", "", this.ranked ? "&6Ranked mode" : "&bUnranked mode"));
            if (this.pickRounds) {
                lore.add("&7Rounds selected: &e" + this.rounds);
            }
            this.set(kitSlots.get(var18), ItemBuilder.of(kit.displayStack()).amount(activeMode).name(kit.displayName).lore(lore).build());
        }
        for (int ix = 0; ix < this.inv.size(); ++ix) {
            ItemStack cur = this.inv.getStack(ix);
            if (!cur.isEmpty() || kitSlots.contains(ix)) continue;
            this.set(ix, this.filler());
        }
        this.set(4, ItemBuilder.of(ItemCodecUtil.parseMaterial(this.ranked ? "NETHERITE_SWORD" : "IRON_SWORD")).amount(Math.max(1, PvPCore.get().duelManager().playingCount(this.ranked))).name(this.ranked ? "&6&lRanked Queue" : "&b&lUnranked Queue").lore(this.challengeTarget != null ? List.of("&7Opponent: &f" + this.challengeTarget.getGameProfile().name()) : List.of(this.customHint != null ? this.customHint : "&7Pick a kit to join the queue.", "", "&7Players queued: &e" + PvPCore.get().queueManager().totalQueued(), "&7Duels running &8(" + (this.ranked ? "ranked" : "unranked") + "): &e" + PvPCore.get().duelManager().playingCount(this.ranked), "&7Players fighting: &e" + PvPCore.get().duelManager().playersFighting(), "&7Duels running: &e" + PvPCore.get().duelManager().allDuels().size(), "&7Free arenas: &e" + PvPCore.get().arenaManager().countUsable())).build());
        if (this.pickRounds) {
            this.buttonVar("rounds", Map.of("rounds", String.valueOf(this.rounds), "max", String.valueOf(this.maxRounds())));
        }
        this.button("prev");
        this.button("next");
        this.button("back");
    }

    protected void onKitPicked(ServerPlayerEntity player, String kitId) {
        if (this.challengeTarget != null) {
            if (this.partyMode) {
                PvPCore.get().duelManager().sendPartyChallenge(player, this.challengeTarget, kitId, this.rounds);
            } else {
                PvPCore.get().duelManager().sendChallenge(player, this.challengeTarget, kitId, this.rounds);
            }
        } else {
            PvPCore.get().queueManager().join(player, kitId, this.ranked, this.rounds);
        }
    }

    private void clickRoundItem(ServerPlayerEntity player, int button, boolean shift) {
        int max = this.maxRounds();
        this.rounds = shift && button == 0 ? Math.max(1, PvPCore.get().config().duel.defaultRounds) : (button == 1 ? (this.rounds <= 1 ? max : this.rounds - 1) : (this.rounds >= max ? 1 : this.rounds + 1));
        this.refresh(player);
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        String b;
        if ((this.isLeftClick(type, button) || this.isRightClick(type, button)) && "rounds".equals(b = this.buttonAt(slot))) {
            this.clickRoundItem(player, button, type == SlotActionType.QUICK_MOVE);
            return;
        }
        if (this.isLeftClick(type, button) || type == SlotActionType.PICKUP) {
            List<Kit> kits = this.kits();
            List<Integer> slots = this.kitSlots();
            int idx = slots.indexOf(slot);
            if (idx >= 0) {
                int kitIdx = this.page * slots.size() + idx;
                if (kitIdx < kits.size()) {
                    Kit kit = kits.get(kitIdx);
                    PvPCore.get().guiManager().close(player);
                    this.onKitPicked(player, kit.id);
                }
                return;
            }
            String b2 = this.buttonAt(slot);
            if ("prev".equals(b2)) {
                this.page = Math.max(0, this.page - 1);
                this.refresh(player);
            } else if ("next".equals(b2)) {
                ++this.page;
                this.refresh(player);
            } else if ("back".equals(b2)) {
                PvPCore.get().guiManager().close(player);
            }
        }
    }
}

