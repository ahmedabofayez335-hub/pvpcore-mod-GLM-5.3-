/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemStack
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.server.network.ServerPlayerEntity
 *  net.minecraft.server.world.ServerWorld
 *  net.minecraft.text.Text
 */
package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.arena.Arena;
import com.pvpcore.gui.Gui;
import com.pvpcore.gui.guis.AdminGui;
import com.pvpcore.gui.guis.ArenaEditorGui;
import com.pvpcore.item.ItemBuilder;
import com.pvpcore.kit.Kit;
import com.pvpcore.util.TeleportUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;

public class ArenaListGui
extends Gui {
    private int page = 0;

    public ArenaListGui(ServerPlayerEntity player) {
        super(player.getUuid(), "arenas", 6);
    }

    private List<Arena> arenas() {
        return new ArrayList<Arena>(PvPCore.get().arenaManager().all());
    }

    private String arenaIcon(Arena arena) {
        if (arena.kitIds == null) {
            return "GRASS_BLOCK";
        }
        for (String kitId : arena.kitIds) {
            Kit kit = PvPCore.get().kitManager().get(kitId);
            if (kit == null) continue;
            return kit.displayItem;
        }
        return "GRASS_BLOCK";
    }

    @Override
    public void build() {
        List<Arena> arenas = this.arenas();
        int perPage = 27;
        int pages = Math.max(1, (arenas.size() + perPage - 1) / perPage);
        if (this.page >= pages) {
            this.page = pages - 1;
        }
        for (int i = 0; i < 54; ++i) {
            this.set(i, ItemStack.EMPTY);
        }
        int[] slots = new int[perPage];
        int s = 0;
        for (int row = 2; row <= 4 && s < perPage; ++row) {
            for (int col = 1; col <= 7 && s < perPage; ++col) {
                slots[s++] = row * 9 + col;
            }
        }
        for (int i = 0; i < perPage; ++i) {
            int idx = this.page * perPage + i;
            if (idx >= arenas.size()) continue;
            Arena arena = arenas.get(idx);
            this.set(slots[i], ItemBuilder.of(arena.kitIds != null && !arena.kitIds.isEmpty() ? this.arenaIcon(arena) : "GRASS_BLOCK").name("&e" + arena.id).lore("&7Display name: &f" + arena.displayName, "&7Gamemode: " + arena.kitDisplayName(), "&7Status: " + arena.statusColored(), "&7Spawns: &f" + (arena.spawn1Set ? "&a1" : "&c-") + "&7/&f" + (arena.spawn2Set ? "&a2" : "&c-") + " &7Spec: &f" + (arena.spectatorSet ? "&aY" : "&c-"), "", "&eLeft-Click &7to edit", "&dRight-Click &7to teleport").build());
        }
        this.buttonVar("info", Map.of("count", String.valueOf(arenas.size())));
        this.button("create");
        this.button("prev");
        this.button("back");
        this.button("next");
        for (int ix = 0; ix < 54; ++ix) {
            if (!this.inv.getStack(ix).isEmpty()) continue;
            this.set(ix, this.filler());
        }
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        List<Arena> arenas = this.arenas();
        int[] slots = new int[27];
        int s = 0;
        for (int row = 2; row <= 4 && s < 27; ++row) {
            for (int col = 1; col <= 7 && s < 27; ++col) {
                slots[s++] = row * 9 + col;
            }
        }
        for (int i = 0; i < 27; ++i) {
            if (slots[i] != slot) continue;
            int idx = this.page * 27 + i;
            if (idx < arenas.size()) {
                ServerWorld world;
                Arena arena = arenas.get(idx);
                if (this.isLeftClick(type, button)) {
                    new ArenaEditorGui(player, arena.id).open(player);
                } else if (this.isRightClick(type, button) && (world = TeleportUtil.world(PvPCore.get().server(), arena.world)) != null) {
                    TeleportUtil.teleport(player, world, arena.spawn1Set ? arena.spawn1X : arena.spectatorX, arena.spawn1Set ? arena.spawn1Y : arena.spectatorY, arena.spawn1Set ? arena.spawn1Z : arena.spectatorZ, 0.0f, 0.0f);
                    PvPCore.get().guiManager().close(player);
                    player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("arena.teleported", Map.of("arena", arena.id))), false);
                }
            }
            return;
        }
        if (this.isLeftClick(type, button)) {
            String b = this.buttonAt(slot);
            if ("create".equals(b)) {
                PvPCore.get().guiManager().openAnvil(player, "&8Enter Arena Name", name -> {
                    String clean = name.trim();
                    if (clean.isEmpty() || clean.length() > 32) {
                        player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("input.invalid-name")), false);
                    } else if (PvPCore.get().arenaManager().get(clean) != null) {
                        player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("input.invalid-name")), false);
                    } else {
                        Arena arenax = PvPCore.get().arenaManager().create(clean);
                        arenax.world = player.getEntityWorld().getRegistryKey().getValue().toString();
                        PvPCore.get().arenaManager().save();
                        PvPCore.get().auditLog().log(player.getGameProfile().name(), "Created arena " + clean);
                        player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("arena.created", Map.of("arena", clean))), false);
                        new ArenaEditorGui(player, arenax.id).open(player);
                    }
                });
            } else if ("prev".equals(b)) {
                this.page = Math.max(0, this.page - 1);
                this.refresh(player);
            } else if ("next".equals(b)) {
                ++this.page;
                this.refresh(player);
            } else if ("back".equals(b)) {
                new AdminGui(player).open(player);
            }
        }
    }
}

