/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.player.PlayerInventory
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.Items
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.server.PlayerManager
 *  net.minecraft.server.network.ServerPlayerEntity
 *  net.minecraft.text.Text
 */
package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.data.PlayerData;
import com.pvpcore.gui.Gui;
import com.pvpcore.gui.guis.EnchantGui;
import com.pvpcore.gui.guis.ItemPaletteGui;
import com.pvpcore.gui.guis.KitStatsGui;
import com.pvpcore.item.ItemBuilder;
import com.pvpcore.kit.Kit;
import com.pvpcore.player.PlayerManager;
import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

public class KitEditorGui
extends Gui {
    private final String kitId;
    private final boolean templateMode;
    private final boolean ffaMode;
    private boolean dirty = false;
    private boolean firstBuild = true;
    private final Set<ItemStack> borrowedItems = Collections.newSetFromMap(new IdentityHashMap());
    public static final int[] ARMOR_SLOTS = new int[]{0, 1, 2, 3};
    public static final int OFFHAND_SLOT = 4;
    public static final int[] HOTBAR_SLOTS = new int[]{9, 10, 11, 12, 13, 14, 15, 16, 17};
    public static final int[] INV_SLOTS = KitEditorGui.buildInvSlots();
    public static final int ENCHANT_SLOT = 46;
    private static final int LAYOUT_SIZE = 41;

    private static int[] buildInvSlots() {
        int[] slots = new int[27];
        for (int i = 0; i < 27; ++i) {
            slots[i] = 18 + i;
        }
        return slots;
    }

    public static int chestToLayout(int slot) {
        if (slot >= 0 && slot <= 3) {
            return slot;
        }
        if (slot == 4) {
            return 40;
        }
        if (slot >= 9 && slot <= 17) {
            return 4 + (slot - 9);
        }
        return slot >= 18 && slot <= 44 ? 13 + (slot - 18) : -1;
    }

    public static int layoutToChest(int layoutIndex) {
        if (layoutIndex >= 0 && layoutIndex <= 3) {
            return layoutIndex;
        }
        if (layoutIndex == 40) {
            return 4;
        }
        if (layoutIndex >= 4 && layoutIndex <= 12) {
            return 9 + (layoutIndex - 4);
        }
        return layoutIndex >= 13 && layoutIndex <= 39 ? 18 + (layoutIndex - 13) : -1;
    }

    public KitEditorGui(ServerPlayerEntity player, String kitId) {
        this(player, kitId, false, false);
    }

    public KitEditorGui(ServerPlayerEntity player, String kitId, boolean templateMode) {
        this(player, kitId, templateMode, false);
    }

    /**
     * @param templateMode admin mode - edits the kit template everyone gets.
     * @param ffaMode      edits the player's SEPARATE FFA layout (used in fight zones).
     */
    public KitEditorGui(ServerPlayerEntity player, String kitId, boolean templateMode, boolean ffaMode) {
        super(player.getUuid(), "kit_editor", 6);
        this.kitId = kitId;
        this.templateMode = templateMode;
        this.ffaMode = ffaMode;
        String mode;
        if (templateMode) {
            mode = " &7(Template)";
        } else if (ffaMode) {
            mode = PvPCore.get().messages().get("kit.ffa-editor-title");
        } else {
            mode = " &7(Layout)";
        }
        this.titleVar("mode", mode);
    }

    @Override
    public boolean allowItemMoves() {
        return true;
    }

    @Override
    public boolean allowPlayerInventoryPickup() {
        if (this.templateMode) {
            ServerPlayerEntity viewer = PvPCore.get().server().getPlayerManager().getPlayer(this.playerId);
            return viewer != null && PlayerManager.isAdmin(viewer);
        }
        // In FFA mode the player drags items from their own (kit) inventory.
        return this.ffaMode;
    }

    @Override
    public boolean isEditableSlot(int slot) {
        if (slot == this.slot("enchant_target") && (this.templateMode || this.ffaMode)) {
            ItemStack st = this.inv.getStack(slot);
            return !st.isEmpty() && !this.isEnchantTargetMarker(st);
        }
        return KitEditorGui.chestToLayout(slot) >= 0;
    }

    @Override
    public void build() {
        Kit kit = PvPCore.get().kitManager().get(this.kitId);
        if (kit != null) {
            int i;
            int enchantSlot;
            ItemStack enchantItem = this.inv.getStack(46);
            if (this.firstBuild) {
                List<ItemStack> layout;
                if (this.templateMode) {
                    layout = kit.layoutStacks();
                } else {
                    PlayerData data = PvPCore.get().storage().get(this.playerId, null);
                    List<ItemStack> list = this.ffaMode ? (data != null ? data.ffaLoadoutFor(this.kitId) : null) : (data != null ? data.loadoutFor(this.kitId) : null);
                    if (this.ffaMode && (list == null || list.isEmpty()) && data != null) {
                        // 3.0.7: no separate FFA layout yet - start the FFA editor from the
                        // player's regular kit layout so their arrangement carries over.
                        list = data.loadoutFor(this.kitId);
                    }
                    layout = list;
                    if (layout != null && !layout.isEmpty()) {
                        layout = Kit.padLayout(layout);
                    }
                    if (layout == null || layout.size() < 41) {
                        layout = kit.layoutStacks();
                    }
                }
                for (i = 0; i < 41; ++i) {
                    int chestSlot = KitEditorGui.layoutToChest(i);
                    this.set(chestSlot, layout.get(i) == null ? ItemStack.EMPTY : layout.get(i).copy());
                }
                this.firstBuild = false;
            }
            ItemStack filler = ItemBuilder.of("GRAY_STAINED_GLASS_PANE").name("&r").build();
            for (i = 5; i <= 8; ++i) {
                this.set(i, filler);
            }
            this.button("armor_info");
            this.button("offhand_info");
            for (int var7 = 45; var7 <= 53; ++var7) {
                this.set(var7, filler);
            }
            this.button("back");
            if (!this.templateMode && !this.ffaMode) {
                enchantSlot = this.slot("enchant_target");
                if (KitEditorGui.chestToLayout(enchantSlot) < 0) {
                    this.set(enchantSlot, filler);
                }
            } else {
                enchantSlot = this.slot("enchant_target");
                this.set(enchantSlot, !enchantItem.isEmpty() && !this.isEnchantTargetMarker(enchantItem) ? enchantItem : this.item("enchant_target"));
                this.button("palette");
                this.button("enchant");
            }
            this.button("save");
            if (this.templateMode || this.ffaMode) {
                this.button("get_kit");
                this.button("from_inventory");
                this.button("clear");
            }
            this.button("close");
        }
    }

    @Override
    public void itemMoved(ServerPlayerEntity player) {
        this.dirty = true;
    }

    @Override
    public void absorbCursor(ItemStack cursor) {
        int enchantSlot;
        for (int i = 0; i < 41; ++i) {
            int chestSlot = KitEditorGui.layoutToChest(i);
            if (!this.inv.getStack(chestSlot).isEmpty()) continue;
            this.inv.setStack(chestSlot, cursor);
            return;
        }
        if (this.templateMode && this.inv.getStack(enchantSlot = this.slot("enchant_target")).isEmpty()) {
            this.inv.setStack(enchantSlot, cursor);
        }
    }

    public boolean addPaletteItem(ItemStack stack) {
        for (int i = 0; i < 41; ++i) {
            int chestSlot = KitEditorGui.layoutToChest(i);
            if (!this.inv.getStack(chestSlot).isEmpty()) continue;
            this.inv.setStack(chestSlot, stack.copy());
            this.dirty = true;
            return true;
        }
        return false;
    }

    @Override
    public ItemStack acceptFromPlayerInventory(ServerPlayerEntity player, ItemStack stack) {
        if (!this.templateMode && !this.ffaMode) {
            return stack;
        }
        for (int i = 0; i < 41; ++i) {
            int chestSlot = KitEditorGui.layoutToChest(i);
            if (!this.inv.getStack(chestSlot).isEmpty()) continue;
            this.inv.setStack(chestSlot, stack.copy());
            this.borrowedItems.add(this.inv.getStack(chestSlot));
            this.dirty = true;
            return ItemStack.EMPTY;
        }
        player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("kit.editor-full")), false);
        return stack;
    }

    @Override
    public boolean takeBackToPlayer(ServerPlayerEntity player, ItemStack stack) {
        if (!this.templateMode && !this.ffaMode) {
            return false;
        }
        ItemStack rest = stack.copy();
        if (!player.getInventory().insertStack(rest)) {
            player.dropItem(stack.copy(), false);
        }
        this.borrowedItems.remove(stack);
        this.dirty = true;
        return true;
    }

    public void save(ServerPlayerEntity player, boolean notify) {
        Kit kit = PvPCore.get().kitManager().get(this.kitId);
        if (kit != null) {
            int enchantSlot;
            ItemStack ench;
            ArrayList<ItemStack> layout = new ArrayList<ItemStack>(Collections.nCopies(41, ItemStack.EMPTY));
            for (int i = 0; i < 41; ++i) {
                int chestSlot = KitEditorGui.layoutToChest(i);
                ItemStack st = this.inv.getStack(chestSlot);
                if (st == null || st.isEmpty()) continue;
                layout.set(i, st.copy());
            }
            if ((this.templateMode || this.ffaMode) && !(ench = this.inv.getStack(enchantSlot = this.slot("enchant_target"))).isEmpty() && !this.isEnchantTargetMarker(ench)) {
                for (int ix = 0; ix < 41; ++ix) {
                    if (!layout.get(ix).isEmpty()) continue;
                    layout.set(ix, ench.copy());
                    this.inv.setStack(enchantSlot, ItemStack.EMPTY);
                    break;
                }
            }
            if (this.templateMode) {
                kit.setLayout(layout);
                PvPCore.get().kitManager().put(kit);
                PvPCore.get().kitManager().clearLoadouts(this.kitId);
                PvPCore.get().auditLog().log(player.getGameProfile().name(), "Edited kit template " + this.kitId);
            } else if (this.ffaMode) {
                PlayerData data = PvPCore.get().storage().get(player.getUuid(), player.getGameProfile().name());
                data.setFfaLoadout(this.kitId, layout);
                PvPCore.get().storage().markDirty(player.getUuid());
            } else {
                PlayerData data = PvPCore.get().storage().get(player.getUuid(), player.getGameProfile().name());
                data.setLoadout(this.kitId, layout);
                PvPCore.get().storage().markDirty(player.getUuid());
            }
            this.dirty = false;
            if (notify) {
                String key = this.templateMode ? "kit.template-saved" : (this.ffaMode ? "kit.ffa-layout-saved" : "kit.layout-saved");
                player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get(key, Map.of("kit", kit.displayName))), false);
            }
        }
    }

    private boolean isEnchantTargetMarker(ItemStack stack) {
        return stack.getItem() == Items.YELLOW_STAINED_GLASS_PANE;
    }

    private void giveKitToInventory(ServerPlayerEntity player) {
        Kit kit = PvPCore.get().kitManager().get(this.kitId);
        if (kit != null) {
            List<ItemStack> layout = kit.layoutStacks();
            int given = 0;
            for (int i = 0; i < layout.size() && i < 41; ++i) {
                ItemStack st = layout.get(i);
                if (st == null || st.isEmpty()) continue;
                ItemStack copy = st.copy();
                if (i == 40 && player.getInventory().getStack(40).isEmpty()) {
                    player.getInventory().setStack(40, copy);
                    ++given;
                    continue;
                }
                if (player.getInventory().insertStack(copy)) {
                    ++given;
                    continue;
                }
                player.dropItem(st.copy(), false);
            }
            player.currentScreenHandler.updateToClient();
            player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("kit.items-given", Map.of("kit", kit.displayName, "count", String.valueOf(given)))), false);
        }
    }

    private void saveKitFromInventory(ServerPlayerEntity player) {
        Kit kit = PvPCore.get().kitManager().get(this.kitId);
        if (kit != null) {
            ArrayList<ItemStack> layout = new ArrayList<ItemStack>(Collections.nCopies(41, ItemStack.EMPTY));
            PlayerInventory inv = player.getInventory();
            for (int i = 0; i < 4; ++i) {
                ItemStack st = inv.getStack(36 + i);
                if (st == null || st.isEmpty()) continue;
                layout.set(i, st.copy());
            }
            ItemStack st = inv.getStack(40);
            if (st != null && !st.isEmpty()) {
                layout.set(40, st.copy());
            }
            for (int var11 = 0; var11 < 9; ++var11) {
                st = inv.getStack(var11);
                if (st == null || st.isEmpty()) continue;
                layout.set(4 + var11, st.copy());
            }
            for (int var12 = 0; var12 < 27; ++var12) {
                st = inv.getStack(9 + var12);
                if (st == null || st.isEmpty()) continue;
                layout.set(13 + var12, st.copy());
            }
            if (this.ffaMode) {
                PlayerData data = PvPCore.get().storage().get(player.getUuid(), player.getGameProfile().name());
                data.setFfaLoadout(this.kitId, layout);
                PvPCore.get().storage().markDirty(player.getUuid());
                player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("kit.ffa-layout-saved", Map.of("kit", kit.displayName))), false);
            } else {
                kit.setLayout(layout);
                PvPCore.get().kitManager().put(kit);
                PvPCore.get().kitManager().clearLoadouts(this.kitId);
                PvPCore.get().auditLog().log(player.getGameProfile().name(), "Saved kit " + this.kitId + " from inventory");
                player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("kit.saved-from-inventory", Map.of("kit", kit.displayName))), false);
            }
            for (int var13 = 0; var13 < 41; ++var13) {
                int chestSlot = KitEditorGui.layoutToChest(var13);
                this.inv.setStack(chestSlot, layout.get(var13) == null ? ItemStack.EMPTY : layout.get(var13).copy());
            }
            this.borrowedItems.clear();
            this.dirty = false;
            this.refresh(player);
        }
    }

    @Override
    public void closed() {
        net.minecraft.server.PlayerManager pm = PvPCore.get().server().getPlayerManager();
        ServerPlayerEntity player = pm.getPlayer(this.playerId);
        if (this.dirty && player != null) {
            this.save(player, false);
        }
        if (player != null && (this.templateMode || this.ffaMode)) {
            for (int i = 0; i < 41; ++i) {
                int chestSlot = KitEditorGui.layoutToChest(i);
                ItemStack st = this.inv.getStack(chestSlot);
                if (st.isEmpty() || !this.borrowedItems.remove(st)) continue;
                ItemStack rest = st.copy();
                if (!player.getInventory().insertStack(rest)) {
                    player.dropItem(st.copy(), false);
                }
                this.inv.setStack(chestSlot, ItemStack.EMPTY);
            }
        }
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        if (this.isLeftClick(type, button)) {
            String var7;
            String b = this.buttonAt(slot);
            String var6 = b == null ? "" : b;
            switch (var7 = var6) {
                case "back": {
                    this.save(player, false);
                    com.pvpcore.ffa.FightZone zone = PvPCore.get().zoneManager().zoneOf(player);
                    if (this.ffaMode && zone != null) {
                        new com.pvpcore.gui.guis.ZoneKitGui(player, zone).open(player);
                    } else {
                        new KitStatsGui(player, this.kitId).open(player);
                    }
                    break;
                }
                case "save": {
                    this.save(player, true);
                    this.refresh(player);
                    break;
                }
                case "clear": {
                    for (int i = 0; i < 41; ++i) {
                        int chestSlot = KitEditorGui.layoutToChest(i);
                        ItemStack st = this.inv.getStack(chestSlot);
                        if (st.isEmpty()) continue;
                        ItemStack rest = st.copy();
                        if (!player.getInventory().insertStack(rest)) {
                            player.dropItem(st.copy(), false);
                        }
                        this.inv.setStack(chestSlot, ItemStack.EMPTY);
                    }
                    int enchantSlot = this.slot("enchant_target");
                    ItemStack ench = this.inv.getStack(enchantSlot);
                    if (!ench.isEmpty() && !this.isEnchantTargetMarker(ench)) {
                        ItemStack rest = ench.copy();
                        if (!player.getInventory().insertStack(rest)) {
                            player.dropItem(ench.copy(), false);
                        }
                        this.inv.setStack(enchantSlot, ItemStack.EMPTY);
                    }
                    this.borrowedItems.clear();
                    this.dirty = true;
                    player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("kit.cleared")), false);
                    this.refresh(player);
                    break;
                }
                case "palette": {
                    if (!this.templateMode && !this.ffaMode) {
                        return;
                    }
                    new ItemPaletteGui(player, this).open(player);
                    break;
                }
                case "get_kit": {
                    if (!this.templateMode && !this.ffaMode) {
                        return;
                    }
                    if (this.templateMode && !PlayerManager.isAdmin(player)) {
                        return;
                    }
                    this.giveKitToInventory(player);
                    break;
                }
                case "from_inventory": {
                    if (!this.templateMode && !this.ffaMode) {
                        return;
                    }
                    if (this.templateMode && !PlayerManager.isAdmin(player)) {
                        return;
                    }
                    this.saveKitFromInventory(player);
                    break;
                }
                case "enchant": {
                    if (!this.templateMode && !this.ffaMode) {
                        return;
                    }
                    ItemStack target = this.inv.getStack(this.slot("enchant_target"));
                    if (target.isEmpty() || this.isEnchantTargetMarker(target)) {
                        player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("kit.no-item-to-enchant")), false);
                        return;
                    }
                    new EnchantGui(player, this, target).open(player);
                    break;
                }
                case "close": {
                    PvPCore.get().guiManager().close(player);
                }
            }
        }
    }
}

