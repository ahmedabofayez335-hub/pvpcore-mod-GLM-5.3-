/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemStack
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.server.network.ServerPlayerEntity
 *  net.minecraft.text.Text
 */
package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.arena.Arena;
import com.pvpcore.gui.Gui;
import com.pvpcore.gui.guis.ArenaEditorGui;
import com.pvpcore.gui.guis.ArenaListGui;
import com.pvpcore.item.ItemBuilder;
import com.pvpcore.kit.Kit;
import java.lang.invoke.CallSite;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

public class ArenaKitsGui
extends Gui {
    private final String arenaId;
    private int page = 0;

    public ArenaKitsGui(ServerPlayerEntity player, String arenaId) {
        super(player.getUuid(), "arena_kits", 5);
        this.arenaId = arenaId;
        this.titleVar("arena", arenaId);
    }

    private Arena arena() {
        return PvPCore.get().arenaManager().get(this.arenaId);
    }

    private List<Kit> kits() {
        return PvPCore.get().kitManager().sortedAll();
    }

    private List<Integer> kitSlots() {
        return PvPCore.get().guiConfig().kitSlots("arena_kits");
    }

    @Override
    public void build() {
        Arena arena = this.arena();
        if (arena != null) {
            List<Kit> kits = this.kits();
            List<Integer> slots = this.kitSlots();
            int perPage = slots.size();
            int pages = Math.max(1, (kits.size() + perPage - 1) / perPage);
            if (this.page >= pages) {
                this.page = pages - 1;
            }
            for (int i = 0; i < this.inv.size(); ++i) {
                this.set(i, ItemStack.EMPTY);
            }
            for (int var11 = 0; var11 < slots.size(); ++var11) {
                int idx = this.page * perPage + var11;
                if (idx >= kits.size()) continue;
                Kit kit = kits.get(idx);
                boolean assigned = arena.hasKit(kit.id);
                ArrayList<String> lore = new ArrayList<String>(List.of(assigned ? "&aAssigned to this arena" : "&7Not assigned", "", assigned ? "&eLeft-Click &7to &cremove" : "&eLeft-Click &7to &aassign", "&7This arena can hold kits:", "&7" + arena.kitDisplayName()));
                this.set(slots.get(var11), ItemBuilder.of(kit.displayStack()).name(assigned ? "&a" + kit.displayName : "&7" + kit.displayName).glow(assigned).lore(lore).build());
            }
            this.buttonVar("info", Map.of("arena", arena.displayName));
            this.button("clear");
            this.button("back");
            for (int var12 = 0; var12 < this.inv.size(); ++var12) {
                if (!this.inv.getStack(var12).isEmpty()) continue;
                this.set(var12, this.filler());
            }
        }
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        if (this.isLeftClick(type, button)) {
            Arena arena = this.arena();
            if (arena == null) {
                new ArenaListGui(player).open(player);
            } else {
                int kitIdx;
                List<Kit> kits = this.kits();
                List<Integer> slots = this.kitSlots();
                int idx = slots.indexOf(slot);
                if (idx >= 0 && (kitIdx = this.page * slots.size() + idx) < kits.size()) {
                    Kit kit = kits.get(kitIdx);
                    if (arena.hasKit(kit.id)) {
                        PvPCore.get().arenaManager().unassign(arena.id, kit.id);
                        PvPCore.get().auditLog().log(player.getGameProfile().name(), "Removed kit " + kit.id + " from arena " + arena.id);
                        player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("arena.unassigned", Map.of("arena", arena.id, "kit", PvPCore.get().duelManager().kitDisplayName(kit.id)))), false);
                    } else {
                        PvPCore.get().arenaManager().assign(arena.id, kit.id);
                        PvPCore.get().auditLog().log(player.getGameProfile().name(), "Assigned arena " + arena.id + " to gamemode " + kit.id);
                        player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("arena.assigned", Map.of("arena", arena.id, "kit", PvPCore.get().duelManager().kitDisplayName(kit.id)))), false);
                    }
                    this.refresh(player);
                    return;
                }
                String b = this.buttonAt(slot);
                if ("clear".equals(b)) {
                    PvPCore.get().arenaManager().clearAssignment(arena.id);
                    PvPCore.get().auditLog().log(player.getGameProfile().name(), "Set arena " + arena.id + " gamemode to any");
                    player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("arena.assigned-any", Map.of("arena", arena.id))), false);
                    this.refresh(player);
                } else if ("back".equals(b)) {
                    new ArenaEditorGui(player, arena.id).open(player);
                }
            }
        }
    }
}

