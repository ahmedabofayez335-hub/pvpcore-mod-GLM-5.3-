/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.server.PlayerManager
 *  net.minecraft.server.network.ServerPlayerEntity
 */
package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.duel.DuelRequest;
import com.pvpcore.gui.Gui;
import java.util.Map;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.PlayerManager;
import net.minecraft.server.network.ServerPlayerEntity;

public class ChallengeGui
extends Gui {
    private final DuelRequest request;

    public ChallengeGui(ServerPlayerEntity player, DuelRequest request) {
        super(player.getUuid(), "challenge", 3);
        this.request = request;
    }

    @Override
    public void build() {
        boolean party;
        this.fillAll(this.filler());
        PlayerManager pm = PvPCore.get().server().getPlayerManager();
        ServerPlayerEntity sender = pm.getPlayer(this.request.sender);
        String senderName = sender != null ? sender.getGameProfile().name() : "?";
        String kitName = PvPCore.get().duelManager().kitDisplayName(this.request.kitId);
        boolean bl = party = this.request.type == DuelRequest.Type.PARTY_DUEL;
        if (party) {
            this.buttonVar("info", Map.of("player", senderName + "'s party (" + this.request.senderParty.size() + " players)", "kit", kitName));
        } else {
            this.buttonVar("info", Map.of("player", senderName, "kit", kitName));
        }
        this.button("accept");
        this.button("deny");
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        if (this.isLeftClick(type, button)) {
            String b = this.buttonAt(slot);
            if ("accept".equals(b)) {
                PvPCore.get().guiManager().close(player);
                PvPCore.get().duelManager().acceptRequest(player);
            } else if ("deny".equals(b)) {
                PvPCore.get().guiManager().close(player);
                PvPCore.get().duelManager().denyRequest(player);
            }
        }
    }
}

