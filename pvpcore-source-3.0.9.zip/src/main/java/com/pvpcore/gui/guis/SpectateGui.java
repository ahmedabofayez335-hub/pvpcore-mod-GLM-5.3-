/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.Items
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.server.network.ServerPlayerEntity
 */
package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.duel.Duel;
import com.pvpcore.duel.DuelState;
import com.pvpcore.gui.Gui;
import com.pvpcore.item.ItemBuilder;
import java.util.List;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;

public class SpectateGui
extends Gui {
    private int page = 0;

    public SpectateGui(ServerPlayerEntity player) {
        super(player.getUuid(), "spectate", 6);
    }

    @Override
    public void build() {
        List<Duel> duels = PvPCore.get().duelManager().activeDuels();
        int perPage = 27;
        int pages = Math.max(1, (duels.size() + perPage - 1) / perPage);
        if (this.page >= pages) {
            this.page = pages - 1;
        }
        for (int i = 0; i < 54; ++i) {
            this.set(i, ItemStack.EMPTY);
        }
        int[] slots = new int[perPage];
        int s = 0;
        for (int row = 2; row <= 4 && s < perPage; ++row) {
            for (int col = 1; col <= 7 && s < perPage; ++col) {
                slots[s++] = row * 9 + col;
            }
        }
        for (int i = 0; i < perPage; ++i) {
            int idx = this.page * perPage + i;
            if (idx >= duels.size()) continue;
            Duel duel = duels.get(idx);
            String kitName = PvPCore.get().duelManager().kitDisplayName(duel.kitId);
            this.set(slots[i], ItemBuilder.of(Items.IRON_SWORD).name("&e" + duel.firstAName() + " &7vs &e" + duel.firstBName()).lore("&7Kit: &f" + kitName, "&7Ranked: " + (duel.ranked ? "&6Yes" : "&7No"), "&7State: &f" + (duel.state == DuelState.COUNTDOWN ? "Starting" : "Fighting"), "", "&aClick to spectate").build());
        }
        this.button("info");
        this.button("prev");
        this.button("back");
        this.button("next");
        for (int ix = 0; ix < 54; ++ix) {
            if (!this.inv.getStack(ix).isEmpty()) continue;
            this.set(ix, this.filler());
        }
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        if (this.isLeftClick(type, button)) {
            List<Duel> duels = PvPCore.get().duelManager().activeDuels();
            int[] slots = new int[27];
            int s = 0;
            for (int row = 2; row <= 4 && s < 27; ++row) {
                for (int col = 1; col <= 7 && s < 27; ++col) {
                    slots[s++] = row * 9 + col;
                }
            }
            for (int i = 0; i < 27; ++i) {
                if (slots[i] != slot) continue;
                int idx = this.page * 27 + i;
                if (idx < duels.size()) {
                    PvPCore.get().guiManager().close(player);
                    PvPCore.get().spectateManager().join(player, duels.get(idx));
                }
                return;
            }
            String b = this.buttonAt(slot);
            if ("prev".equals(b)) {
                this.page = Math.max(0, this.page - 1);
                this.refresh(player);
            } else if ("next".equals(b)) {
                ++this.page;
                this.refresh(player);
            } else if ("back".equals(b)) {
                PvPCore.get().guiManager().close(player);
            }
        }
    }
}

