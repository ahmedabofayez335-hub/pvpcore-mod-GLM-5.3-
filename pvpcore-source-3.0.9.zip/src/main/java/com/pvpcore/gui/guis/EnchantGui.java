/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.component.DataComponentTypes
 *  net.minecraft.component.type.ItemEnchantmentsComponent
 *  net.minecraft.component.type.ItemEnchantmentsComponent$Builder
 *  net.minecraft.enchantment.Enchantment
 *  net.minecraft.item.ItemStack
 *  net.minecraft.registry.entry.RegistryEntry
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.server.network.ServerPlayerEntity
 *  net.minecraft.text.Text
 */
package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.gui.Gui;
import com.pvpcore.gui.guis.KitEditorGui;
import com.pvpcore.item.ItemBuilder;
import com.pvpcore.util.EnchantUtil;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

public class EnchantGui
extends Gui {
    private final KitEditorGui editor;
    private final ItemStack target;
    private int page = 0;

    public EnchantGui(ServerPlayerEntity player, KitEditorGui editor, ItemStack target) {
        super(player.getUuid(), "enchant", 6);
        this.editor = editor;
        this.target = target;
    }

    private List<RegistryEntry<Enchantment>> enchantments() {
        ArrayList<RegistryEntry<Enchantment>> out = new ArrayList<RegistryEntry<Enchantment>>();
        for (RegistryEntry<Enchantment> entry : EnchantUtil.all()) {
            Enchantment ench = (Enchantment)entry.value();
            if (!ench.isSupportedItem(this.target)) continue;
            out.add(entry);
        }
        out.sort(Comparator.comparing(e -> ((Enchantment)e.value()).description().getString()));
        return out;
    }

    private static String roman(int level) {
        return switch (level) {
            case 1 -> "I";
            case 2 -> "II";
            case 3 -> "III";
            case 4 -> "IV";
            case 5 -> "V";
            case 6 -> "VI";
            case 7 -> "VII";
            case 8 -> "VIII";
            case 9 -> "IX";
            case 10 -> "X";
            default -> String.valueOf(level);
        };
    }

    private static int levelOf(ItemStack stack, RegistryEntry<Enchantment> ench) {
        ItemEnchantmentsComponent levels = stack.getEnchantments();
        return levels == null ? 0 : levels.getLevel(ench);
    }

    @Override
    public void build() {
        List<RegistryEntry<Enchantment>> enchants = this.enchantments();
        int perPage = 45;
        int pages = Math.max(1, (enchants.size() + perPage - 1) / perPage);
        if (this.page >= pages) {
            this.page = pages - 1;
        }
        for (int i = 0; i < 45; ++i) {
            int idx = this.page * perPage + i;
            if (idx < enchants.size()) {
                RegistryEntry<Enchantment> entry = enchants.get(idx);
                Enchantment ench = (Enchantment)entry.value();
                int level = EnchantGui.levelOf(this.target, entry);
                int max = ench.getMaxLevel();
                String displayName = ench.description().getString();
                ArrayList<String> lore = new ArrayList<String>();
                lore.add("&7Max level: &f" + max);
                lore.add("&7Current: " + (String)(level == 0 ? "&cNone" : "&a" + level));
                lore.add("");
                lore.add("&eClick &7to cycle level");
                this.set(i, ItemBuilder.of("ENCHANTED_BOOK").name("&d" + displayName + (String)(level > 0 ? " " + EnchantGui.roman(level) : "")).lore(lore).glow(true).build());
                continue;
            }
            this.set(i, ItemStack.EMPTY);
        }
        for (int ix = 45; ix < 54; ++ix) {
            this.set(ix, this.filler());
        }
        this.button("back");
        this.set(this.slot("target"), ItemBuilder.of(this.target.copy()).name("&dTarget: &f" + this.target.getName().getString()).build());
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        if (this.isLeftClick(type, button) || type == SlotActionType.PICKUP) {
            if (slot >= 0 && slot < 45) {
                int idx = this.page * 45 + slot;
                List<RegistryEntry<Enchantment>> enchants = this.enchantments();
                if (idx >= enchants.size()) {
                    return;
                }
                RegistryEntry<Enchantment> entry = enchants.get(idx);
                Enchantment ench = (Enchantment)entry.value();
                int level = EnchantGui.levelOf(this.target, entry);
                int max = ench.getMaxLevel();
                String displayName = ench.description().getString();
                if (level >= max) {
                    ItemEnchantmentsComponent.Builder builder = new ItemEnchantmentsComponent.Builder(this.target.getEnchantments());
                    builder.remove(e -> e.equals((Object)entry));
                    this.target.set(DataComponentTypes.ENCHANTMENTS, builder.build());
                    player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("kit.enchant-removed", Map.of("enchant", displayName))), false);
                } else {
                    this.target.addEnchantment(entry, level + 1);
                    player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("kit.enchanted", Map.of("enchant", displayName, "level", String.valueOf(level + 1)))), false);
                }
                this.editor.itemMoved(player);
                this.refresh(player);
                return;
            }
            if ("back".equals(this.buttonAt(slot))) {
                this.editor.open(player);
            }
        }
    }
}

