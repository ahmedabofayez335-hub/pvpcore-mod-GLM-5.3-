/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemConvertible
 *  net.minecraft.item.ItemStack
 *  net.minecraft.registry.Registries
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.server.network.ServerPlayerEntity
 *  net.minecraft.text.Text
 */
package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.gui.Gui;
import com.pvpcore.gui.guis.KitEditorGui;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

public class ItemPaletteGui
extends Gui {
    private static final Set<String> EXCLUDED = Set.of("command_block", "chain_command_block", "repeating_command_block", "barrier", "structure_void", "debug_stick", "jigsaw", "structure_block", "light", "spawn_egg");
    private final KitEditorGui editor;
    private final Consumer<String> iconCallback;
    private int page = 0;

    public ItemPaletteGui(ServerPlayerEntity player, KitEditorGui editor) {
        super(player.getUuid(), "palette", 6);
        this.editor = editor;
        this.iconCallback = null;
    }

    public ItemPaletteGui(ServerPlayerEntity player, Consumer<String> iconCallback) {
        super(player.getUuid(), "palette", 6);
        this.editor = null;
        this.iconCallback = iconCallback;
        this.titleVar("mode", " &7(Icon)");
    }

    private List<ItemStack> items() {
        ArrayList<ItemStack> out = new ArrayList<ItemStack>();
        for (Item item : Registries.ITEM) {
            String id = Registries.ITEM.getId(item).getPath();
            if (EXCLUDED.contains(id) || id.endsWith("_spawn_egg")) continue;
            out.add(new ItemStack((ItemConvertible)item));
        }
        out.sort(Comparator.comparing(st -> Registries.ITEM.getId(st.getItem()).toString()));
        return out;
    }

    @Override
    public void build() {
        List<ItemStack> items = this.items();
        int perPage = 45;
        int pages = Math.max(1, (items.size() + perPage - 1) / perPage);
        if (this.page >= pages) {
            this.page = pages - 1;
        }
        for (int i = 0; i < 45; ++i) {
            int idx = this.page * perPage + i;
            this.set(i, idx < items.size() ? items.get(idx) : ItemStack.EMPTY);
        }
        for (int var6 = 45; var6 < 54; ++var6) {
            this.set(var6, this.filler());
        }
        this.button("prev");
        this.button("back");
        this.buttonVar("page", Map.of("page", String.valueOf(this.page + 1), "pages", String.valueOf(pages)));
        this.button("next");
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        if ((type == SlotActionType.PICKUP || type == SlotActionType.QUICK_MOVE) && slot >= 0 && slot < 45) {
            int idx = this.page * 45 + slot;
            List<ItemStack> items = this.items();
            if (idx < items.size()) {
                ItemStack picked = items.get(idx).copy();
                if (this.iconCallback != null) {
                    String materialId = Registries.ITEM.getId(picked.getItem()).toString();
                    PvPCore.get().guiManager().close(player);
                    this.iconCallback.accept(materialId);
                } else if (this.editor != null) {
                    if (type != SlotActionType.QUICK_MOVE && button != 1) {
                        picked.setCount(1);
                    } else {
                        picked.setCount(picked.getMaxCount());
                    }
                    if (this.editor.addPaletteItem(picked)) {
                        player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("kit.item-added", Map.of("item", picked.getName().getString()))), true);
                    }
                }
            }
        } else {
            String b = this.buttonAt(slot);
            if (this.isLeftClick(type, button)) {
                if ("prev".equals(b)) {
                    this.page = Math.max(0, this.page - 1);
                    this.refresh(player);
                } else if ("next".equals(b)) {
                    ++this.page;
                    this.refresh(player);
                } else if ("back".equals(b)) {
                    if (this.editor != null) {
                        this.editor.open(player);
                    } else {
                        PvPCore.get().guiManager().close(player);
                    }
                }
            }
        }
    }
}

