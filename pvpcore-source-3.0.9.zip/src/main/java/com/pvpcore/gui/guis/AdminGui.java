/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.server.network.ServerPlayerEntity
 *  net.minecraft.server.world.ServerWorld
 *  net.minecraft.text.Text
 */
package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.config.MainConfig;
import com.pvpcore.config.Messages;
import com.pvpcore.gui.Gui;
import com.pvpcore.gui.guis.ArenaListGui;
import com.pvpcore.gui.guis.KitListGui;
import com.pvpcore.gui.guis.ScoreboardSettingsGui;
import java.util.Map;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;

public class AdminGui
extends Gui {
    public AdminGui(ServerPlayerEntity player) {
        super(player.getUuid(), "admin", 6);
    }

    @Override
    public void build() {
        this.fillAll(this.filler());
        this.button("reload");
        this.button("save");
        this.button("arenas");
        this.button("kits");
        this.button("setlobby");
        this.button("scoreboard");
        this.button("close");
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        if (this.isLeftClick(type, button)) {
            String var9;
            PvPCore core = PvPCore.get();
            Messages mm = core.messages();
            String b = this.buttonAt(slot);
            String var8 = b == null ? "" : b;
            switch (var9 = var8) {
                case "reload": {
                    long ms = core.reloadConfigs();
                    player.sendMessage((Text)Text.literal((String)mm.get("reload-done", Map.of("ms", String.valueOf(ms)))), false);
                    core.auditLog().log(player.getGameProfile().name(), "Reloaded configs");
                    this.refresh(player);
                    break;
                }
                case "save": {
                    core.storage().saveAll();
                    core.kitManager().save();
                    core.arenaManager().save();
                    core.auditLog().save();
                    player.sendMessage((Text)Text.literal((String)mm.get("data-saved")), false);
                    break;
                }
                case "arenas": {
                    new ArenaListGui(player).open(player);
                    break;
                }
                case "kits": {
                    new KitListGui(player).open(player);
                    break;
                }
                case "setlobby": {
                    MainConfig.Lobby cfg = core.config().lobby;
                    ServerWorld world = player.getEntityWorld();
                    cfg.lobbyWorld = world.getRegistryKey().getValue().toString();
                    cfg.lobbyX = player.getX();
                    cfg.lobbyY = player.getY();
                    cfg.lobbyZ = player.getZ();
                    cfg.lobbyYaw = player.getYaw();
                    cfg.lobbyPitch = player.getPitch();
                    core.config().save();
                    core.auditLog().log(player.getGameProfile().name(), "Set lobby spawn");
                    player.sendMessage((Text)Text.literal((String)mm.get("admin.lobby-set")), false);
                    break;
                }
                case "scoreboard": {
                    new ScoreboardSettingsGui(player).open(player);
                    break;
                }
                case "close": {
                    core.guiManager().close(player);
                }
            }
        }
    }
}

