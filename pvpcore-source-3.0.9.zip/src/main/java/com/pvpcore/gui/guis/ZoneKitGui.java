/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemStack
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.server.network.ServerPlayerEntity
 */
package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.ffa.FightZone;
import com.pvpcore.gui.Gui;
import com.pvpcore.item.ItemBuilder;
import com.pvpcore.kit.Kit;
import java.lang.invoke.CallSite;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;

public class ZoneKitGui
extends Gui {
    private final String zoneId;
    private int page = 0;

    public ZoneKitGui(ServerPlayerEntity player, FightZone zone) {
        super(player.getUuid(), "zonekits", 5);
        this.zoneId = zone != null ? zone.id : null;
    }

    private List<Kit> kits() {
        FightZone zone = PvPCore.get().zoneManager().get(this.zoneId);
        return zone == null ? List.of() : PvPCore.get().zoneManager().zoneKits(zone);
    }

    private List<Integer> kitSlots() {
        return PvPCore.get().guiConfig().kitSlots("zonekits");
    }

    @Override
    public void build() {
        int i;
        List<Kit> kits = this.kits();
        List<Integer> kitSlots = this.kitSlots();
        int perPage = kitSlots.size();
        int pages = Math.max(1, (kits.size() + perPage - 1) / perPage);
        if (this.page >= pages) {
            this.page = pages - 1;
        }
        for (int i2 = 0; i2 < this.inv.size(); ++i2) {
            this.set(i2, ItemStack.EMPTY);
        }
        FightZone zone = PvPCore.get().zoneManager().get(this.zoneId);
        for (i = 0; i < kitSlots.size(); ++i) {
            int idx = this.page * perPage + i;
            if (idx >= kits.size()) continue;
            Kit kit = kits.get(idx);
            FightZone.ZoneStats stats = zone != null ? zone.stats.get(this.playerId.toString()) : null;
            boolean hasFfaLayout = false;
            boolean hasKitLayout = false;
            try {
                com.pvpcore.data.PlayerData data = PvPCore.get().storage().get(this.playerId, null);
                hasFfaLayout = data != null && data.ffaLoadoutFor(kit.id) != null;
                hasKitLayout = data != null && data.loadoutFor(kit.id) != null;
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            // 3.0.7: FFA kits now use the player's regular kit layout when they have no
            // separate FFA layout - show which source is currently active.
            String layoutNote = hasFfaLayout ? "&aFFA layout set" : (hasKitLayout ? "&buses your kit layout" : "&7uses kit default");
            ArrayList<String> lore = new ArrayList<String>(List.of("&eLeft-Click &7to get this kit", "&eRight-Click &7to edit your &eFFA layout", "&7(" + layoutNote + "&7)", "", "&7Zone: &f" + (zone != null ? zone.id : "?")));
            if (stats != null) {
                lore.add("&7Your kills: &a" + stats.kills + " &7deaths: &c" + stats.deaths);
            }
            this.set(kitSlots.get(i), ItemBuilder.of(kit.displayStack()).name(kit.displayName).lore(lore).build());
        }
        for (i = 0; i < this.inv.size(); ++i) {
            ItemStack cur = this.inv.getStack(i);
            if (!cur.isEmpty() || kitSlots.contains(i)) continue;
            this.set(i, this.filler());
        }
        this.button("info");
        if (pages > 1) {
            this.button("prev");
            this.button("next");
        }
        this.button("close");
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        if (this.isLeftClick(type, button) || this.isRightClick(type, button)) {
            int idx;
            String b = this.buttonAt(slot);
            if ("prev".equals(b)) {
                this.page = Math.max(0, this.page - 1);
                this.refresh(player);
                return;
            }
            if ("next".equals(b)) {
                ++this.page;
                this.refresh(player);
                return;
            }
            if ("close".equals(b)) {
                player.closeHandledScreen();
                return;
            }
            List<Kit> kits = this.kits();
            List<Integer> kitSlots = this.kitSlots();
            int pos = kitSlots.indexOf(slot);
            if (pos >= 0 && (idx = this.page * kitSlots.size() + pos) < kits.size()) {
                String kitId = kits.get((int)idx).id;
                if (this.isRightClick(type, button)) {
                    // Right-click: edit this player's SEPARATE FFA layout for the kit.
                    player.closeHandledScreen();
                    PvPCore.get().server().execute(() -> {
                        Kit k = PvPCore.get().kitManager().get(kitId);
                        if (k != null) {
                            new KitEditorGui(player, kitId, false, true).open(player);
                        }
                    });
                } else {
                    player.closeHandledScreen();
                    PvPCore.get().server().execute(() -> PvPCore.get().zoneManager().chooseKit(player, kitId));
                }
            }
        }
    }
}

