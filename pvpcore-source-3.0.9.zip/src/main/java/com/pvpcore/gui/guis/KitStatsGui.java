/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemStack
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.server.network.ServerPlayerEntity
 *  net.minecraft.text.Text
 */
package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.data.PlayerData;
import com.pvpcore.data.PlayerStats;
import com.pvpcore.gui.Gui;
import com.pvpcore.gui.guis.ConfirmGui;
import com.pvpcore.gui.guis.ItemPaletteGui;
import com.pvpcore.gui.guis.KitEditorGui;
import com.pvpcore.gui.guis.KitListGui;
import com.pvpcore.item.ItemBuilder;
import com.pvpcore.kit.Kit;
import com.pvpcore.kit.KitManager;
import com.pvpcore.player.PlayerManager;
import com.pvpcore.util.TextUtil;
import java.util.Map;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

public class KitStatsGui
extends Gui {
    private final String kitId;

    public KitStatsGui(ServerPlayerEntity player, String kitId) {
        super(player.getUuid(), "kit_stats", 5);
        this.kitId = kitId;
    }

    @Override
    public void build() {
        Kit kit = PvPCore.get().kitManager().get(this.kitId);
        if (kit != null) {
            boolean admin;
            for (int i = 0; i < 45; ++i) {
                this.set(i, ItemStack.EMPTY);
            }
            PlayerData data = PvPCore.get().storage().get(this.playerId, null);
            PlayerStats stats = data.statsFor(this.kitId);
            int elo = data.ratingFor(this.kitId, PvPCore.get().config().elo.startRating);
            this.set(13, ItemBuilder.of(kit.displayStack()).name(kit.displayName).lore("&7Your statistics for this kit.", "", "&7Wins: &a" + stats.wins, "&7Losses: &c" + stats.losses, "&7Win rate: &f" + String.format("%.1f", stats.winRate()) + "%", "&7Hits dealt: &f" + stats.hits, "&7Current streak: &f" + stats.streak, "&7Best streak: &6" + stats.bestStreak, "&7ELO: &f" + elo).build());
            this.button("edit");
            this.button("back");
            this.button("close");
            ServerPlayerEntity viewer = PvPCore.get().server().getPlayerManager().getPlayer(this.playerId);
            boolean bl = admin = viewer != null && PlayerManager.isAdmin(viewer);
            if (admin) {
                this.button("edit_template");
                this.buttonVar("rename", Map.of("name", kit.displayName));
                this.buttonVar("icon", Map.of());
                this.buttonVar("position", Map.of("slot", String.valueOf(kit.slot)));
                this.buttonVar("toggle", Map.of("state", kit.enabled ? "&aEnabled" : "&cDisabled"));
                this.button("delete");
            }
            for (int i = 0; i < 45; ++i) {
                if (!this.inv.getStack(i).isEmpty()) continue;
                this.set(i, this.filler());
            }
        }
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        Kit kit = PvPCore.get().kitManager().get(this.kitId);
        if (kit == null) {
            new KitListGui(player).open(player);
        } else {
            String b = this.buttonAt(slot);
            if ("position".equals(b)) {
                if (PlayerManager.isAdmin(player)) {
                    if (this.isLeftClick(type, button)) {
                        kit.slot = Math.max(0, kit.slot - 1);
                    } else {
                        if (!this.isRightClick(type, button)) {
                            return;
                        }
                        kit.slot = Math.min(999, kit.slot + 1);
                    }
                    PvPCore.get().kitManager().put(kit);
                    player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("kit.slot-changed", Map.of("kit", kit.displayName, "slot", String.valueOf(kit.slot)))), false);
                    this.refresh(player);
                }
            } else if (this.isLeftClick(type, button)) {
                String var8;
                String var7 = b == null ? "" : b;
                switch (var8 = var7) {
                    case "edit": {
                        if (PvPCore.get().config().kit.editorBaseOnOriginal) {
                            player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("kit.editor-original", Map.of("kit", kit.displayName))), false);
                        }
                        new KitEditorGui(player, this.kitId).open(player);
                        break;
                    }
                    case "edit_template": {
                        if (!PlayerManager.isAdmin(player)) {
                            return;
                        }
                        new KitEditorGui(player, this.kitId, true).open(player);
                        break;
                    }
                    case "rename": {
                        if (!PlayerManager.isAdmin(player)) {
                            return;
                        }
                        PvPCore.get().guiManager().close(player);
                        PvPCore.get().guiManager().openAnvil(player, "&8Rename Kit - type a name", name -> {
                            String clean;
                            String string = clean = name == null ? "" : name.trim();
                            if (!clean.isEmpty() && clean.length() <= 48) {
                                Kit k;
                                String newId = null;
                                String newName = clean;
                                int colon = clean.indexOf(58);
                                if (colon > 0 && KitManager.validId(clean.substring(0, colon).trim().toLowerCase())) {
                                    newId = clean.substring(0, colon).trim();
                                    String rest = clean.substring(colon + 1).trim();
                                    if (!rest.isEmpty()) {
                                        newName = rest;
                                    }
                                }
                                if ((k = PvPCore.get().kitManager().rename(this.kitId, newId, newName)) != null) {
                                    PvPCore.get().auditLog().log(player.getGameProfile().name(), "Renamed kit " + this.kitId + " to " + newName);
                                    player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("kit.renamed", Map.of("kit", newName))), false);
                                }
                                new KitStatsGui(player, k != null ? k.id : this.kitId).open(player);
                            } else {
                                player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("input.invalid-name")), false);
                                new KitStatsGui(player, this.kitId).open(player);
                            }
                        });
                        break;
                    }
                    case "icon": {
                        if (!PlayerManager.isAdmin(player)) {
                            return;
                        }
                        new ItemPaletteGui(player, materialId -> {
                            Kit k = PvPCore.get().kitManager().get(this.kitId);
                            if (k != null) {
                                k.displayItem = materialId;
                                PvPCore.get().kitManager().put(k);
                                PvPCore.get().auditLog().log(player.getGameProfile().name(), "Changed icon of kit " + this.kitId + " to " + materialId);
                                player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("kit.icon-changed", Map.of("kit", k.displayName))), false);
                                new KitStatsGui(player, this.kitId).open(player);
                            }
                        }).open(player);
                        break;
                    }
                    case "toggle": {
                        if (!PlayerManager.isAdmin(player)) {
                            return;
                        }
                        kit.enabled = !kit.enabled;
                        PvPCore.get().kitManager().put(kit);
                        player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get(kit.enabled ? "kit.enabled" : "kit.disabled", Map.of("kit", kit.displayName))), false);
                        this.refresh(player);
                        break;
                    }
                    case "delete": {
                        if (!PlayerManager.isAdmin(player)) {
                            return;
                        }
                        new ConfirmGui(player, TextUtil.colorize("&cDelete kit &e" + kit.displayName + "&c?"), () -> {
                            PvPCore.get().kitManager().delete(kit.id);
                            PvPCore.get().auditLog().log(player.getGameProfile().name(), "Deleted kit " + kit.id);
                            player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("kit.deleted", Map.of("kit", kit.id))), false);
                            new KitListGui(player).open(player);
                        }, () -> new KitStatsGui(player, this.kitId).open(player)).open(player);
                        break;
                    }
                    case "back": {
                        new KitListGui(player).open(player);
                        break;
                    }
                    case "close": {
                        PvPCore.get().guiManager().close(player);
                    }
                }
            }
        }
    }
}

