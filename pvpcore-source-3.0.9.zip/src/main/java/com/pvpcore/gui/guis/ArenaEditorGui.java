/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.server.network.ServerPlayerEntity
 *  net.minecraft.server.world.ServerWorld
 *  net.minecraft.text.Text
 */
package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.arena.Arena;
import com.pvpcore.audit.AuditLog;
import com.pvpcore.config.Messages;
import com.pvpcore.gui.Gui;
import com.pvpcore.gui.guis.ArenaKitsGui;
import com.pvpcore.gui.guis.ArenaListGui;
import com.pvpcore.gui.guis.ConfirmGui;
import com.pvpcore.util.TeleportUtil;
import java.util.Map;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;

public class ArenaEditorGui
extends Gui {
    private final String arenaId;

    public ArenaEditorGui(ServerPlayerEntity player, String arenaId) {
        super(player.getUuid(), "arena_editor", 5);
        this.arenaId = arenaId;
    }

    private Arena arena() {
        return PvPCore.get().arenaManager().get(this.arenaId);
    }

    @Override
    public void build() {
        Arena arena = this.arena();
        if (arena != null) {
            this.fillAll(this.filler());
            this.buttonVar("info", Map.of("arena", arena.displayName, "status", arena.statusColored(), "spawns", (arena.spawn1Set ? "&a1" : "&c-") + "&7/&f" + (arena.spawn2Set ? "&a2" : "&c-") + "&7 spec:" + (arena.spectatorSet ? "&aY" : "&c-"), "kit", arena.kitDisplayName()));
            this.button("setspawn1");
            this.button("setspawn2");
            this.button("setspectator");
            this.button("teleport");
            this.buttonVar("enable", Map.of("status", arena.enabled ? "&aEnabled" : "&cDisabled"));
            this.buttonVar("gamemode", Map.of("kit", arena.kitDisplayName()));
            this.button("validate");
            this.button("rename");
            this.button("delete");
            this.button("back");
        }
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        Arena arena;
        if (this.isLeftClick(type, button) && (arena = this.arena()) != null) {
            String var12;
            PvPCore core = PvPCore.get();
            Messages mm = core.messages();
            AuditLog audit = core.auditLog();
            String actor = player.getGameProfile().name();
            String b = this.buttonAt(slot);
            String var11 = b == null ? "" : b;
            switch (var12 = var11) {
                case "setspawn1": {
                    ServerWorld world = player.getEntityWorld();
                    arena.world = world.getRegistryKey().getValue().toString();
                    arena.spawn1X = player.getX();
                    arena.spawn1Y = player.getY();
                    arena.spawn1Z = player.getZ();
                    arena.spawn1Yaw = player.getYaw();
                    arena.spawn1Pitch = player.getPitch();
                    arena.spawn1Set = true;
                    core.arenaManager().save();
                    audit.log(actor, "Set spawn 1 of arena " + arena.id);
                    player.sendMessage((Text)Text.literal((String)mm.get("arena.spawn-set", Map.of("arena", arena.id, "spawn", "Spawn 1"))), false);
                    this.refresh(player);
                    break;
                }
                case "setspawn2": {
                    ServerWorld world = player.getEntityWorld();
                    arena.world = world.getRegistryKey().getValue().toString();
                    arena.spawn2X = player.getX();
                    arena.spawn2Y = player.getY();
                    arena.spawn2Z = player.getZ();
                    arena.spawn2Yaw = player.getYaw();
                    arena.spawn2Pitch = player.getPitch();
                    arena.spawn2Set = true;
                    core.arenaManager().save();
                    audit.log(actor, "Set spawn 2 of arena " + arena.id);
                    player.sendMessage((Text)Text.literal((String)mm.get("arena.spawn-set", Map.of("arena", arena.id, "spawn", "Spawn 2"))), false);
                    this.refresh(player);
                    break;
                }
                case "setspectator": {
                    ServerWorld world = player.getEntityWorld();
                    arena.world = world.getRegistryKey().getValue().toString();
                    arena.spectatorX = player.getX();
                    arena.spectatorY = player.getY();
                    arena.spectatorZ = player.getZ();
                    arena.spectatorYaw = player.getYaw();
                    arena.spectatorPitch = player.getPitch();
                    arena.spectatorSet = true;
                    core.arenaManager().save();
                    audit.log(actor, "Set spectator spawn of arena " + arena.id);
                    player.sendMessage((Text)Text.literal((String)mm.get("arena.spawn-set", Map.of("arena", arena.id, "spawn", "Spectator spawn"))), false);
                    this.refresh(player);
                    break;
                }
                case "teleport": {
                    ServerWorld world = TeleportUtil.world(core.server(), arena.world);
                    if (world == null) break;
                    double x = arena.spawn1Set ? arena.spawn1X : arena.spectatorX;
                    double y = arena.spawn1Set ? arena.spawn1Y : arena.spectatorY;
                    double z = arena.spawn1Set ? arena.spawn1Z : arena.spectatorZ;
                    TeleportUtil.teleport(player, world, x, y, z, 0.0f, 0.0f);
                    core.guiManager().close(player);
                    player.sendMessage((Text)Text.literal((String)mm.get("arena.teleported", Map.of("arena", arena.id))), false);
                    break;
                }
                case "gamemode": {
                    new ArenaKitsGui(player, arena.id).open(player);
                    break;
                }
                case "enable": {
                    arena.enabled = !arena.enabled;
                    core.arenaManager().save();
                    audit.log(actor, (arena.enabled ? "Enabled" : "Disabled") + " arena " + arena.id);
                    player.sendMessage((Text)Text.literal((String)mm.get(arena.enabled ? "arena.enabled" : "arena.disabled", Map.of("arena", arena.id))), false);
                    this.refresh(player);
                    break;
                }
                case "validate": {
                    if (arena.isValid()) {
                        player.sendMessage((Text)Text.literal((String)mm.get("arena.valid", Map.of("arena", arena.id))), false);
                        break;
                    }
                    player.sendMessage((Text)Text.literal((String)mm.get("arena.invalid", Map.of("arena", arena.id, "reason", arena.invalidReason()))), false);
                    break;
                }
                case "rename": {
                    core.guiManager().openAnvil(player, "&8Rename Arena", name -> {
                        String clean = name.trim();
                        if (!clean.isEmpty() && clean.length() <= 32) {
                            arena.displayName = "&f" + clean;
                            core.arenaManager().save();
                            audit.log(player.getGameProfile().name(), "Renamed arena " + arena.id + " to " + clean);
                            player.sendMessage((Text)Text.literal((String)mm.get("arena.renamed", Map.of("name", clean))), false);
                            new ArenaEditorGui(player, arena.id).open(player);
                        } else {
                            player.sendMessage((Text)Text.literal((String)mm.get("input.invalid-name")), false);
                        }
                    });
                    break;
                }
                case "delete": {
                    new ConfirmGui(player, "&cDelete arena " + arena.id + "?", () -> {
                        if (arena.status != Arena.Status.FREE) {
                            player.sendMessage((Text)Text.literal((String)mm.get("arena.in-use")), false);
                        } else {
                            core.arenaManager().delete(arena.id);
                            audit.log(player.getGameProfile().name(), "Deleted arena " + arena.id);
                            player.sendMessage((Text)Text.literal((String)mm.get("arena.deleted", Map.of("arena", arena.id))), false);
                        }
                    }, () -> new ArenaEditorGui(player, arena.id).open(player)).open(player);
                    break;
                }
                case "back": {
                    new ArenaListGui(player).open(player);
                }
            }
        }
    }
}

