/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.Items
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.server.network.ServerPlayerEntity
 */
package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.gui.Gui;
import com.pvpcore.item.ItemBuilder;
import com.pvpcore.player.PlayerState;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Predicate;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;

public class PlayerPickerGui
extends Gui {
    private final String title;
    private final Consumer<ServerPlayerEntity> callback;
    private final Predicate<ServerPlayerEntity> filter;
    private int page = 0;

    public PlayerPickerGui(ServerPlayerEntity player, String title, Consumer<ServerPlayerEntity> callback) {
        this(player, title, callback, null);
    }

    public PlayerPickerGui(ServerPlayerEntity player, String title, Consumer<ServerPlayerEntity> callback, Predicate<ServerPlayerEntity> filter) {
        super(player.getUuid(), "player_picker", 6);
        this.title = title;
        this.callback = callback;
        this.filter = filter;
    }

    private List<ServerPlayerEntity> targets() {
        ArrayList<ServerPlayerEntity> out = new ArrayList<ServerPlayerEntity>();
        for (ServerPlayerEntity p : PvPCore.get().server().getPlayerManager().getPlayerList()) {
            if (p.getUuid().equals(this.playerId) || this.filter != null && !this.filter.test(p)) continue;
            out.add(p);
        }
        out.sort((a, b) -> a.getGameProfile().name().compareToIgnoreCase(b.getGameProfile().name()));
        return out;
    }

    @Override
    public void build() {
        List<ServerPlayerEntity> players = this.targets();
        int perPage = 36;
        int pages = Math.max(1, (players.size() + perPage - 1) / perPage);
        if (this.page >= pages) {
            this.page = pages - 1;
        }
        for (int i = 0; i < 36; ++i) {
            int idx = this.page * perPage + i;
            if (idx < players.size()) {
                ServerPlayerEntity target = players.get(idx);
                PlayerState state = PvPCore.get().playerManager().state(target);
                String stateStr = switch (state) {
                    default -> throw new MatchException(null, null);
                    case PlayerState.LOBBY -> "&aLobby";
                    case PlayerState.QUEUEING -> "&eIn Queue";
                    case PlayerState.DUELING -> "&cDueling";
                    case PlayerState.SPECTATING -> "&5Spectating";
                    case PlayerState.ZONE -> "&cFighting";
                };
                this.set(i, ItemBuilder.of(Items.PLAYER_HEAD).skullOwner(target).name("&e" + target.getGameProfile().name()).lore("&7Status: " + stateStr, "&7Ping: &f" + this.ping(target) + "ms", "", "&aClick to select").build());
                continue;
            }
            this.set(i, ItemStack.EMPTY);
        }
        if (players.isEmpty()) {
            this.set(22, ItemBuilder.of(Items.BARRIER).name("&cNo players available").lore("&7Nobody can be picked right now.", "&7Players must be in the lobby", "&7and free to play.").build());
        }
        for (int ix = 36; ix < 54; ++ix) {
            this.set(ix, this.filler());
        }
        this.button("prev");
        this.button("back");
        this.buttonVar("page", Map.of("page", String.valueOf(this.page + 1), "pages", String.valueOf(pages)));
        this.button("next");
    }

    private int ping(ServerPlayerEntity p) {
        try {
            return Math.max(0, p.networkHandler.getLatency());
        }
        catch (Throwable var3) {
            return 0;
        }
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        if (slot >= 0 && slot < 36) {
            int idx = this.page * 36 + slot;
            List<ServerPlayerEntity> players = this.targets();
            if (idx < players.size()) {
                ServerPlayerEntity target = players.get(idx);
                PvPCore.get().guiManager().close(player);
                this.callback.accept(target);
            }
        } else {
            String b = this.buttonAt(slot);
            if (this.isLeftClick(type, button)) {
                if ("prev".equals(b)) {
                    this.page = Math.max(0, this.page - 1);
                    this.refresh(player);
                } else if ("next".equals(b)) {
                    ++this.page;
                    this.refresh(player);
                } else if ("back".equals(b)) {
                    PvPCore.get().guiManager().close(player);
                }
            }
        }
    }
}

