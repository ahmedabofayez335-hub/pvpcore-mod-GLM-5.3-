/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.Items
 *  net.minecraft.registry.entry.RegistryEntry
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.server.PlayerManager
 *  net.minecraft.server.network.ServerPlayerEntity
 *  net.minecraft.sound.SoundCategory
 *  net.minecraft.sound.SoundEvents
 *  net.minecraft.text.Text
 */
package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.config.Messages;
import com.pvpcore.gui.Gui;
import com.pvpcore.gui.guis.KitPickerGui;
import com.pvpcore.gui.guis.PartyGui;
import com.pvpcore.item.ItemBuilder;
import com.pvpcore.party.PartyManager;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.PlayerManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;

public class PartySplitGui
extends Gui {
    private static final int[] WALL_SLOTS = new int[]{13, 22, 31, 40};
    private static final int[] RED_SLOTS = new int[]{9, 10, 11, 12, 18, 19, 20, 21, 27, 28, 29, 30, 36, 37, 38, 39};
    private static final int[] BLUE_SLOTS = new int[]{14, 15, 16, 17, 23, 24, 25, 26, 32, 33, 34, 35, 41, 42, 43, 44};
    private static final int[] BENCH_SLOTS = new int[]{0, 1, 2, 3, 5, 6, 7, 8};
    private final Map<UUID, Integer> assignment = new LinkedHashMap<UUID, Integer>();

    public PartySplitGui(ServerPlayerEntity player) {
        super(player.getUuid(), "party_split", 6);
    }

    private PartyManager.Party party() {
        return PvPCore.get().partyManager().partyOf(this.playerId);
    }

    @Override
    public void build() {
        PartyManager.Party party = this.party();
        if (party != null) {
            for (int i2 = 0; i2 < this.inv.size(); ++i2) {
                this.set(i2, ItemStack.EMPTY);
            }
            PlayerManager pm = PvPCore.get().server().getPlayerManager();
            ArrayList<UUID> members = new ArrayList<UUID>(party.members);
            int red = 0;
            int blue = 0;
            int bench = 0;
            for (UUID uUID : members) {
                int t = this.assignment.getOrDefault(uUID, 0);
                if (t == 1) {
                    ++red;
                    continue;
                }
                if (t == 2) {
                    ++blue;
                    continue;
                }
                ++bench;
            }
            this.buttonVar("info", Map.of("red", String.valueOf(red), "blue", String.valueOf(blue), "bench", String.valueOf(bench)));
            ItemStack wall = ItemBuilder.of(Items.IRON_BARS).name("&8&l|  THE WALL  |").lore("&7Left side fights the", "&7right side!", "", "&8Left-Click a head: &cred team", "&8Right-Click a head: &9blue team").build();
            for (int slot : WALL_SLOTS) {
                this.set(slot, wall);
            }
            ItemStack itemStack = ItemBuilder.of(Items.RED_STAINED_GLASS_PANE).name("&cRED team").lore("&7Click to pull the next", "&7benched player into &cRED&7.").build();
            ItemStack blueSlot = ItemBuilder.of(Items.BLUE_STAINED_GLASS_PANE).name("&9BLUE team").lore("&7Click to pull the next", "&7benched player into &9BLUE&7.").build();
            for (int slot : RED_SLOTS) {
                if (!this.inv.getStack(slot).isEmpty()) continue;
                this.set(slot, itemStack);
            }
            for (int slotx : BLUE_SLOTS) {
                if (!this.inv.getStack(slotx).isEmpty()) continue;
                this.set(slotx, blueSlot);
            }
            ItemStack benchPane = ItemBuilder.of(Items.GRAY_STAINED_GLASS_PANE).name("&8Bench").lore("&7Waiting to be assigned").build();
            for (int slotxx : BENCH_SLOTS) {
                if (!this.inv.getStack(slotxx).isEmpty()) continue;
                this.set(slotxx, benchPane);
            }
            ArrayList<UUID> redMembers = new ArrayList<UUID>();
            ArrayList<UUID> blueMembers = new ArrayList<UUID>();
            ArrayList<UUID> benchMembers = new ArrayList<UUID>();
            for (UUID ux : members) {
                int t = this.assignment.getOrDefault(ux, 0);
                if (t == 1) {
                    redMembers.add(ux);
                    continue;
                }
                if (t == 2) {
                    blueMembers.add(ux);
                    continue;
                }
                benchMembers.add(ux);
            }
            for (int i = 0; i < RED_SLOTS.length && i < redMembers.size(); ++i) {
                this.set(RED_SLOTS[i], this.memberHead(party, (UUID)redMembers.get(i), 1));
            }
            for (int var18 = 0; var18 < BLUE_SLOTS.length && var18 < blueMembers.size(); ++var18) {
                this.set(BLUE_SLOTS[var18], this.memberHead(party, (UUID)blueMembers.get(var18), 2));
            }
            for (int var19 = 0; var19 < BENCH_SLOTS.length && var19 < benchMembers.size(); ++var19) {
                this.set(BENCH_SLOTS[var19], this.memberHead(party, (UUID)benchMembers.get(var19), 0));
            }
            this.buttonVar("auto", Map.of("red", String.valueOf(red), "blue", String.valueOf(blue)));
            this.button("reset");
            this.button("start");
            this.button("back");
        }
    }

    private ItemStack memberHead(PartyManager.Party party, UUID u, int team) {
        PlayerManager pm = PvPCore.get().server().getPlayerManager();
        ServerPlayerEntity member = pm.getPlayer(u);
        boolean isLeader = party.leader.equals(u);
        String teamColor = team == 1 ? "&c" : (team == 2 ? "&9" : "&7");
        String teamName = team == 1 ? "&cRED" : (team == 2 ? "&9BLUE" : "&8Bench");
        ArrayList<String> lore = new ArrayList<String>(List.of("&7Team: " + teamName, isLeader ? "&6Party Leader" : "&7Member", member == null ? "&cOffline" : "&aOnline", "", "&eLeft-Click &7to move to &cRED", "&eRight-Click &7to move to &9BLUE", "&7Click the same side to bench"));
        return ItemBuilder.of(Items.PLAYER_HEAD).skullOwner(u, this.nameOf(u)).name((isLeader ? "&6\u2605 " : "") + teamColor + this.nameOf(u)).lore(lore).glow(team != 0).build();
    }

    private String nameOf(UUID uuid) {
        ServerPlayerEntity p = PvPCore.get().server().getPlayerManager().getPlayer(uuid);
        return p != null ? p.getGameProfile().name() : "?";
    }

    private UUID memberAt(int slot, PartyManager.Party party) {
        ArrayList<UUID> members = new ArrayList<UUID>(party.members);
        for (UUID u : members) {
            if (this.assignment.getOrDefault(u, 0) != 0 && this.headSlotOf(u, this.assignment.get(u)) == slot) {
                return u;
            }
            if (this.assignment.getOrDefault(u, 0) != 0) continue;
            int benchIdx = 0;
            for (UUID m : members) {
                if (this.assignment.getOrDefault(m, 0) != 0) continue;
                if (m.equals(u)) break;
                ++benchIdx;
            }
            if (benchIdx >= BENCH_SLOTS.length || BENCH_SLOTS[benchIdx] != slot) continue;
            return u;
        }
        return null;
    }

    private int headSlotOf(UUID u, int team) {
        ArrayList<UUID> members = new ArrayList<UUID>(PvPCore.get().partyManager().partyOf((UUID)this.playerId).members);
        int idx = 0;
        for (UUID m : members) {
            if (this.assignment.getOrDefault(m, 0) != team) continue;
            if (m.equals(u)) break;
            ++idx;
        }
        int[] slots = team == 1 ? RED_SLOTS : BLUE_SLOTS;
        return idx < slots.length ? slots[idx] : -1;
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        PartyManager.Party party = this.party();
        if (party == null) {
            PvPCore.get().guiManager().close(player);
        } else if (!party.isLeader(player.getUuid())) {
            player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("party.not-leader")), false);
        } else {
            boolean left = this.isLeftClick(type, button);
            boolean right = this.isRightClick(type, button);
            if (left || right) {
                UUID memberUuid = this.memberAt(slot, party);
                if (memberUuid != null) {
                    int current = this.assignment.getOrDefault(memberUuid, 0);
                    int target = left ? (current == 1 ? 0 : 1) : (current == 2 ? 0 : 2);
                    this.assignment.put(memberUuid, target);
                    this.playClick(player);
                    this.actionbar(player, this.nameOf(memberUuid), target);
                    this.refresh(player);
                } else {
                    String b;
                    String var18;
                    if (left) {
                        if (this.contains(RED_SLOTS, slot) && this.inv.getStack(slot).getItem() == Items.RED_STAINED_GLASS_PANE) {
                            UUID next = this.firstBench(party);
                            if (next != null) {
                                this.assignment.put(next, 1);
                                this.playClick(player);
                                this.actionbar(player, this.nameOf(next), 1);
                                this.refresh(player);
                            }
                            return;
                        }
                    } else if (this.contains(BLUE_SLOTS, slot) && this.inv.getStack(slot).getItem() == Items.BLUE_STAINED_GLASS_PANE) {
                        UUID next = this.firstBench(party);
                        if (next != null) {
                            this.assignment.put(next, 2);
                            this.playClick(player);
                            this.actionbar(player, this.nameOf(next), 2);
                            this.refresh(player);
                        }
                        return;
                    }
                    switch (var18 = (b = this.buttonAt(slot)) == null ? "" : b) {
                        case "auto": {
                            this.assignment.clear();
                            ArrayList<UUID> members = new ArrayList<UUID>(party.members);
                            int i = 0;
                            for (UUID u : members) {
                                if (party.leader.equals(u)) {
                                    this.assignment.put(u, 1);
                                    continue;
                                }
                                this.assignment.put(u, i++ % 2 == 0 ? 2 : 1);
                            }
                            this.playClick(player);
                            this.refresh(player);
                            break;
                        }
                        case "reset": {
                            this.assignment.clear();
                            this.playClick(player);
                            this.refresh(player);
                            break;
                        }
                        case "start": {
                            this.startEvent(player, party);
                            break;
                        }
                        case "back": {
                            new PartyGui(player).open(player);
                        }
                    }
                }
            }
        }
    }

    private UUID firstBench(PartyManager.Party party) {
        for (UUID u : party.members) {
            if (this.assignment.getOrDefault(u, 0) != 0) continue;
            return u;
        }
        return null;
    }

    private boolean contains(int[] slots, int slot) {
        for (int s : slots) {
            if (s != slot) continue;
            return true;
        }
        return false;
    }

    private void actionbar(ServerPlayerEntity player, String memberName, int team) {
        try {
            String teamStr = team == 1 ? "&cRED" : (team == 2 ? "&9BLUE" : "&7Bench");
            player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("party.split-assigned", Map.of("player", memberName, "team", teamStr))), true);
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private void startEvent(final ServerPlayerEntity player, final PartyManager.Party party) {
        Messages mm = PvPCore.get().messages();
        PlayerManager pm = PvPCore.get().server().getPlayerManager();
        ArrayList<ServerPlayerEntity> red = new ArrayList<ServerPlayerEntity>();
        ArrayList<ServerPlayerEntity> blue = new ArrayList<ServerPlayerEntity>();
        ArrayList<String> ineligible = new ArrayList<String>();
        for (Map.Entry<UUID, Integer> e : this.assignment.entrySet()) {
            boolean eligible;
            ServerPlayerEntity member;
            if (e.getValue() == 0 || (member = pm.getPlayer(e.getKey())) == null) continue;
            boolean bl = eligible = PvPCore.get().duelManager().duelOf(member) == null && !PvPCore.get().spectateManager().isSpectating(member);
            if (!eligible) {
                ineligible.add(member.getGameProfile().name());
                continue;
            }
            if (e.getValue() == 1) {
                red.add(member);
                continue;
            }
            blue.add(member);
        }
        if (red.isEmpty() || blue.isEmpty()) {
            player.sendMessage((Text)Text.literal((String)mm.get("party.split-need-both")), false);
        } else if (!ineligible.isEmpty()) {
            player.sendMessage((Text)Text.literal((String)mm.get("party.split-busy", Map.of("players", String.join((CharSequence)", ", ineligible)))), false);
        } else {
            KitPickerGui picker = new KitPickerGui(player, false, null, false, true){

                @Override
                protected void onKitPicked(ServerPlayerEntity p, String kitId) {
                    PartySplitGui.this.launchEvent(player, party, kitId, this.currentRounds());
                }
            };
            picker.customHint = mm.get("party.split-kit-hint");
            picker.open(player);
        }
    }

    private void launchEvent(ServerPlayerEntity player, PartyManager.Party party, String kitId, int rounds) {
        Messages mm = PvPCore.get().messages();
        PlayerManager pm = PvPCore.get().server().getPlayerManager();
        ArrayList<ServerPlayerEntity> red = new ArrayList<ServerPlayerEntity>();
        ArrayList<ServerPlayerEntity> blue = new ArrayList<ServerPlayerEntity>();
        for (Map.Entry<UUID, Integer> e : this.assignment.entrySet()) {
            ServerPlayerEntity member;
            if (e.getValue() == 0 || (member = pm.getPlayer(e.getKey())) == null) continue;
            if ((Integer)e.getValue() == 1) {
                red.add(member);
                continue;
            }
            blue.add(member);
        }
        if (!red.isEmpty() && !blue.isEmpty()) {
            StringBuilder redNames = new StringBuilder();
            for (ServerPlayerEntity p : red) {
                if (!redNames.isEmpty()) {
                    redNames.append("&7, ");
                }
                redNames.append("&c").append(p.getGameProfile().name());
            }
            StringBuilder blueNames = new StringBuilder();
            for (ServerPlayerEntity p : blue) {
                if (!blueNames.isEmpty()) {
                    blueNames.append("&7, ");
                }
                blueNames.append("&9").append(p.getGameProfile().name());
            }
            for (ServerPlayerEntity member : party.onlineMembers()) {
                member.sendMessage((Text)Text.literal((String)mm.get("party.split-announced", Map.of("kit", PvPCore.get().duelManager().kitDisplayName(kitId), "red", redNames.toString(), "blue", blueNames.toString(), "rounds", String.valueOf(rounds)))), false);
            }
            PvPCore.get().duelManager().startDuel(kitId, false, red, blue, rounds);
        } else {
            player.sendMessage((Text)Text.literal((String)mm.get("party.split-need-both")), false);
        }
    }

    private void playClick(ServerPlayerEntity player) {
        try {
            player.getEntityWorld().playSound(null, player.getX(), player.getY(), player.getZ(), (RegistryEntry)SoundEvents.UI_BUTTON_CLICK, SoundCategory.MASTER, 0.5f, 1.2f);
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }
}

