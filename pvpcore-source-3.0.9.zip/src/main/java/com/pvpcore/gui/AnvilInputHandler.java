/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.entity.player.PlayerInventory
 *  net.minecraft.item.ItemStack
 *  net.minecraft.screen.AnvilScreenHandler
 *  net.minecraft.screen.ScreenHandlerContext
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.server.network.ServerPlayerEntity
 *  net.minecraft.text.Text
 */
package com.pvpcore.gui;

import com.pvpcore.PvPCore;
import com.pvpcore.item.ItemBuilder;
import java.util.function.Consumer;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.AnvilScreenHandler;
import net.minecraft.screen.ScreenHandlerContext;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

public class AnvilInputHandler
extends AnvilScreenHandler {
    private final ServerPlayerEntity player;
    private final Consumer<String> callback;
    private String currentName = "";

    public AnvilInputHandler(int syncId, PlayerInventory playerInventory, ServerPlayerEntity player, Consumer<String> callback) {
        super(syncId, playerInventory, ScreenHandlerContext.EMPTY);
        this.player = player;
        this.callback = callback;
        this.getSlot(0).setStackNoCallbacks(ItemBuilder.of("PAPER").name("&fType a name...").build());
        this.getSlot(1).setStackNoCallbacks(ItemBuilder.of("LIME_DYE").name("&a&lConfirm").lore("&7Click to confirm the name above.").build());
    }

    public boolean setNewItemName(String newItemName) {
        this.currentName = newItemName == null ? "" : newItemName;
        return true;
    }

    public boolean canTakeOutput(PlayerEntity player, boolean present) {
        return false;
    }

    public void onSlotClick(int slotIndex, int button, SlotActionType actionType, PlayerEntity player) {
        if (slotIndex == 1) {
            String name = this.currentName == null ? "" : this.currentName.trim();
            ((ServerPlayerEntity)player).closeHandledScreen();
            if (!name.isEmpty()) {
                this.callback.accept(name);
            } else {
                player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("input.invalid-name")), false);
            }
        } else {
            this.sendContentUpdates();
            this.syncState();
        }
    }

    public void onClosed(PlayerEntity player) {
        this.setCursorStack(ItemStack.EMPTY);
        super.onClosed(player);
    }
}

