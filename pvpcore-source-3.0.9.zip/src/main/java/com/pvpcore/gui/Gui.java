/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.StainedGlassPaneBlock
 *  net.minecraft.component.DataComponentTypes
 *  net.minecraft.inventory.SimpleInventory
 *  net.minecraft.item.BlockItem
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.Items
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.server.network.ServerPlayerEntity
 *  net.minecraft.text.Text
 */
package com.pvpcore.gui;

import com.pvpcore.PvPCore;
import com.pvpcore.config.GuiConfig;
import com.pvpcore.item.ItemBuilder;
import com.pvpcore.util.ItemCodecUtil;
import com.pvpcore.util.TextUtil;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.block.StainedGlassPaneBlock;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

public abstract class Gui {
    protected final UUID playerId;
    protected final String key;
    protected final int rows;
    protected final SimpleInventory inv;
    private final Map<String, String> titleVars;
    private final Map<Integer, String> placedButtons = new HashMap<Integer, String>();

    protected Gui(UUID playerId, String key, int rows) {
        this.playerId = playerId;
        this.key = key;
        this.rows = Math.max(1, Math.min(6, rows));
        this.inv = new SimpleInventory(this.rows * 9);
        this.titleVars = new HashMap<String, String>();
    }

    public String key() {
        return this.key;
    }

    public UUID playerId() {
        return this.playerId;
    }

    public SimpleInventory inventory() {
        return this.inv;
    }

    public int rows() {
        return this.rows;
    }

    protected void titleVar(String k, String v) {
        this.titleVars.put(k, v);
    }

    public Text title() {
        String t = PvPCore.get().guiConfig().title(this.key);
        return TextUtil.text(t, this.titleVars);
    }

    public abstract void build();

    public abstract void click(int var1, int var2, SlotActionType var3, ServerPlayerEntity var4);

    public void closed() {
    }

    public boolean allowItemMoves() {
        return false;
    }

    public boolean isEditableSlot(int slot) {
        return false;
    }

    public void itemMoved(ServerPlayerEntity player) {
    }

    public ItemStack acceptFromPlayerInventory(ServerPlayerEntity player, ItemStack stack) {
        return stack;
    }

    public boolean allowPlayerInventoryPickup() {
        return false;
    }

    public boolean takeBackToPlayer(ServerPlayerEntity player, ItemStack stack) {
        return false;
    }

    public void absorbCursor(ItemStack cursor) {
    }

    public void open(ServerPlayerEntity player) {
        PvPCore.get().guiManager().open(player, this);
    }

    public void refresh(ServerPlayerEntity player) {
        this.placedButtons.clear();
        this.build();
        this.decorate();
        player.currentScreenHandler.sendContentUpdates();
    }

    protected void set(int slot, ItemStack stack) {
        if (slot >= 0 && slot < this.inv.size()) {
            this.inv.setStack(slot, stack);
        }
    }

    protected int slot(String itemKey) {
        return PvPCore.get().guiConfig().item((String)this.key, (String)itemKey).slot;
    }

    protected String buttonAt(int slot) {
        return this.placedButtons.get(slot);
    }

    protected void button(String itemKey) {
        this.set(this.slot(itemKey), this.item(itemKey));
        this.placedButtons.put(this.slot(itemKey), itemKey);
    }

    protected void buttonVar(String itemKey, Map<String, String> vars) {
        this.set(this.slot(itemKey), this.itemVar(itemKey, vars));
        this.placedButtons.put(this.slot(itemKey), itemKey);
    }

    protected void unplaceButton(String itemKey) {
        this.placedButtons.values().removeIf(k -> k.equals(itemKey));
    }

    protected ItemStack item(String itemKey) {
        return PvPCore.get().guiConfig().buildItem(this.key, itemKey);
    }

    protected ItemStack itemVar(String itemKey, Map<String, String> vars) {
        GuiConfig.ItemSpec spec = PvPCore.get().guiConfig().item(this.key, itemKey);
        String name = spec.name;
        ArrayList<String> lore = new ArrayList<String>();
        for (String string : spec.lore) {
            lore.add(string);
        }
        if (vars != null) {
            for (Map.Entry entry : vars.entrySet()) {
                name = name.replace("{" + (String)entry.getKey() + "}", (CharSequence)entry.getValue());
                for (int i = 0; i < lore.size(); ++i) {
                    lore.set(i, lore.get(i).replace("{" + (String)entry.getKey() + "}", (CharSequence)entry.getValue()));
                }
            }
        }
        return ItemBuilder.of(ItemCodecUtil.parseMaterial(spec.material)).amount(spec.amount).name(name).lore(lore).glow(spec.glow).build();
    }

    protected void fillRow(int row, ItemStack stack) {
        int start = row * 9;
        for (int i = 0; i < 9; ++i) {
            this.set(start + i, stack.copy());
        }
    }

    protected void fillAll(ItemStack stack) {
        for (int i = 0; i < this.inv.size(); ++i) {
            this.set(i, stack.copy());
        }
    }

    protected ItemStack filler() {
        return PvPCore.get().guiConfig().buildItem(this.key, "filler");
    }

    public void decorate() {
        int size;
        int rows;
        if (!this.allowItemMoves() && (rows = (size = this.inv.size()) / 9) >= 2) {
            ItemStack border = this.borderPane();
            ItemStack dark = this.darkPane();
            for (int i = 0; i < size; ++i) {
                int row = i / 9;
                int col = i % 9;
                boolean edge = row == 0 || row == rows - 1 || col == 0 || col == 8;
                ItemStack cur = this.inv.getStack(i);
                if (!cur.isEmpty() && !this.isFillerLike(cur)) continue;
                this.set(i, edge ? border : dark);
            }
        }
    }

    protected ItemStack darkPane() {
        return ItemBuilder.of(Items.BLACK_STAINED_GLASS_PANE).name("&r").build();
    }

    protected ItemStack borderPane() {
        String var3;
        String var2 = this.key;
        String material = switch (var3 = this.key) {
            case "kit_list", "kit_stats", "kit_editor", "palette", "enchant" -> "ORANGE_STAINED_GLASS_PANE";
            case "party_menu", "party_split" -> "MAGENTA_STAINED_GLASS_PANE";
            case "challenge", "rounds", "confirm" -> "RED_STAINED_GLASS_PANE";
            case "queue", "player_picker" -> "CYAN_STAINED_GLASS_PANE";
            case "leaderboard" -> "YELLOW_STAINED_GLASS_PANE";
            case "spectate" -> "PURPLE_STAINED_GLASS_PANE";
            case "stats", "profile" -> "LIME_STAINED_GLASS_PANE";
            case "admin", "arenas", "arena_editor" -> "LIGHT_BLUE_STAINED_GLASS_PANE";
            default -> "GRAY_STAINED_GLASS_PANE";
        };
        return ItemBuilder.of(ItemCodecUtil.parseMaterial(material)).name("&r").build();
    }

    protected boolean isFillerLike(ItemStack stack) {
        if (stack.isEmpty()) {
            return true;
        }
        Item item = stack.getItem();
        if (item instanceof BlockItem) {
            BlockItem block = (BlockItem)item;
            if (!(block.getBlock() instanceof StainedGlassPaneBlock)) {
                return false;
            }
            Text name = (Text)stack.get(DataComponentTypes.CUSTOM_NAME);
            return name == null || name.getString().isBlank() || name.getString().equals("\u00a7r");
        }
        return false;
    }

    protected ItemStack selfHead(ServerPlayerEntity viewer, String name, List<String> lore) {
        return ItemBuilder.of(Items.PLAYER_HEAD).skullOwner(viewer).name(name).lore(lore).build();
    }

    protected boolean isLeftClick(SlotActionType type, int button) {
        return (type == SlotActionType.PICKUP || type == SlotActionType.QUICK_MOVE) && button == 0;
    }

    protected boolean isRightClick(SlotActionType type, int button) {
        return type == SlotActionType.PICKUP && button == 1;
    }
}

