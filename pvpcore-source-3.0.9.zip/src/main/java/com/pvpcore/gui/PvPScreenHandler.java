/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.entity.player.PlayerInventory
 *  net.minecraft.inventory.Inventory
 *  net.minecraft.inventory.SimpleInventory
 *  net.minecraft.item.ItemStack
 *  net.minecraft.screen.ScreenHandler
 *  net.minecraft.screen.ScreenHandlerType
 *  net.minecraft.screen.slot.Slot
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.server.network.ServerPlayerEntity
 */
package com.pvpcore.gui;

import com.pvpcore.PvPCore;
import com.pvpcore.gui.Gui;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;

public class PvPScreenHandler
extends ScreenHandler {
    private final Gui gui;
    private final SimpleInventory inv;
    private final int chestSlots;

    public PvPScreenHandler(int syncId, PlayerInventory playerInventory, Gui gui) {
        super(PvPScreenHandler.type(gui.rows()), syncId);
        int col;
        this.gui = gui;
        this.inv = gui.inventory();
        this.chestSlots = gui.rows() * 9;
        for (int row = 0; row < gui.rows(); ++row) {
            for (col = 0; col < 9; ++col) {
                this.addSlot(new Slot((Inventory)this.inv, col + row * 9, 8 + col * 18, 18 + row * 18));
            }
        }
        int offset = (gui.rows() - 4) * 18;
        for (int row = 0; row < 3; ++row) {
            for (int col2 = 0; col2 < 9; ++col2) {
                this.addSlot(new Slot((Inventory)playerInventory, 9 + col2 + row * 9, 8 + col2 * 18, 103 + row * 18 + offset));
            }
        }
        for (col = 0; col < 9; ++col) {
            this.addSlot(new Slot((Inventory)playerInventory, col, 8 + col * 18, 161 + offset));
        }
    }

    public Gui gui() {
        return this.gui;
    }

    private static ScreenHandlerType<?> type(int rows) {
        return switch (rows) {
            case 1 -> ScreenHandlerType.GENERIC_9X1;
            case 2 -> ScreenHandlerType.GENERIC_9X2;
            case 3 -> ScreenHandlerType.GENERIC_9X3;
            case 4 -> ScreenHandlerType.GENERIC_9X4;
            case 5 -> ScreenHandlerType.GENERIC_9X5;
            default -> ScreenHandlerType.GENERIC_9X6;
        };
    }

    public boolean canUse(PlayerEntity player) {
        return true;
    }

    public ItemStack quickMove(PlayerEntity player, int slot) {
        return ItemStack.EMPTY;
    }

    public void onSlotClick(int slotIndex, int button, SlotActionType actionType, PlayerEntity player) {
        if (player instanceof ServerPlayerEntity) {
            ServerPlayerEntity sp = (ServerPlayerEntity)player;
            if (actionType == SlotActionType.QUICK_MOVE && this.gui.allowItemMoves()) {
                this.handleQuickMove(sp, slotIndex);
                this.updateToClient();
                return;
            }
            if (this.gui.allowItemMoves() && actionType == SlotActionType.PICKUP && slotIndex >= 0 && slotIndex < this.chestSlots && this.gui.isEditableSlot(slotIndex)) {
                super.onSlotClick(slotIndex, button, actionType, player);
                this.gui.itemMoved(sp);
                this.updateToClient();
            } else if (this.gui.allowItemMoves() && this.gui.allowPlayerInventoryPickup() && actionType == SlotActionType.PICKUP && slotIndex >= this.chestSlots && slotIndex < this.slots.size()) {
                super.onSlotClick(slotIndex, button, actionType, player);
                this.gui.itemMoved(sp);
                this.updateToClient();
            } else {
                if (slotIndex >= 0 && slotIndex < this.chestSlots) {
                    this.gui.click(slotIndex, button, actionType, sp);
                }
                this.updateToClient();
            }
        }
    }

    private void handleQuickMove(ServerPlayerEntity player, int slotIndex) {
        Slot slot;
        ItemStack stack;
        if (slotIndex >= 0 && slotIndex < this.slots.size() && (stack = (slot = (Slot)this.slots.get(slotIndex)).getStack()) != null && !stack.isEmpty()) {
            if (slotIndex >= this.chestSlots) {
                ItemStack rest = this.gui.acceptFromPlayerInventory(player, stack);
                slot.setStack(rest == null ? ItemStack.EMPTY : rest);
            } else if (this.gui.isEditableSlot(slotIndex) && this.gui.takeBackToPlayer(player, stack)) {
                slot.setStack(ItemStack.EMPTY);
            }
            player.currentScreenHandler.sendContentUpdates();
        }
    }

    public void onClosed(PlayerEntity player) {
        ItemStack cursor = this.getCursorStack();
        if (!cursor.isEmpty() && this.gui.allowItemMoves()) {
            this.gui.absorbCursor(cursor);
            this.setCursorStack(ItemStack.EMPTY);
        }
        super.onClosed(player);
        if (player instanceof ServerPlayerEntity) {
            ServerPlayerEntity sp = (ServerPlayerEntity)player;
            PvPCore.get().guiManager().handleClosed(this, sp);
            sp.playerScreenHandler.updateToClient();
        }
    }
}

