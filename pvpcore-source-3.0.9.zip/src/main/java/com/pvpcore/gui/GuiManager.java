/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.screen.NamedScreenHandlerFactory
 *  net.minecraft.screen.ScreenHandler
 *  net.minecraft.screen.SimpleNamedScreenHandlerFactory
 *  net.minecraft.server.network.ServerPlayerEntity
 */
package com.pvpcore.gui;

import com.pvpcore.PvPCore;
import com.pvpcore.gui.AnvilInputHandler;
import com.pvpcore.gui.Gui;
import com.pvpcore.gui.PvPScreenHandler;
import com.pvpcore.gui.guis.KitPickerGui;
import com.pvpcore.util.TextUtil;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import net.minecraft.screen.NamedScreenHandlerFactory;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.server.network.ServerPlayerEntity;

public final class GuiManager {
    private final Map<UUID, OpenGui> open = new ConcurrentHashMap<UUID, OpenGui>();
    private long tick = 0L;

    /**
     * 3.0.8: once per second, rebuilds open queue (unranked/ranked) GUIs so the
     * live duel/queue counts shown on the kit items stay fresh while the menu
     * is open. Other GUIs are untouched.
     */
    public void tick() {
        ++this.tick;
        if (this.tick % 20L != 0L || this.open.isEmpty()) {
            return;
        }
        if (PvPCore.get() == null || PvPCore.get().server() == null) {
            return;
        }
        net.minecraft.server.PlayerManager pm = PvPCore.get().server().getPlayerManager();
        for (Map.Entry<UUID, OpenGui> e : Map.copyOf(this.open).entrySet()) {
            if (!(e.getValue().gui() instanceof KitPickerGui)) continue;
            ServerPlayerEntity p = pm.getPlayer(e.getKey());
            if (p == null || p.isDisconnected() || !(p.currentScreenHandler instanceof PvPScreenHandler)) continue;
            PvPScreenHandler h = (PvPScreenHandler)p.currentScreenHandler;
            if (h.syncId == e.getValue().syncId) {
                e.getValue().gui().refresh(p);
            }
        }
    }

    public void open(ServerPlayerEntity player, Gui gui) {
        if (player != null && gui != null) {
            gui.build();
            gui.decorate();
            OpenGui previous = this.open.get(player.getUuid());
            if (previous != null && previous.syncId == player.currentScreenHandler.syncId) {
                player.closeHandledScreen();
            }
            player.openHandledScreen((NamedScreenHandlerFactory)new SimpleNamedScreenHandlerFactory((syncId, inv, p) -> new PvPScreenHandler(syncId, inv, gui), gui.title()));
            ScreenHandler screenHandler = player.currentScreenHandler;
            if (screenHandler instanceof PvPScreenHandler) {
                PvPScreenHandler pvph = (PvPScreenHandler)screenHandler;
                this.open.put(player.getUuid(), new OpenGui(pvph.syncId, gui));
            }
        }
    }

    public void handleClosed(PvPScreenHandler handler, ServerPlayerEntity player) {
        OpenGui current = this.open.get(player.getUuid());
        if (current != null && current.syncId == handler.syncId) {
            this.open.remove(player.getUuid());
            current.gui().closed();
        }
    }

    public Gui openGui(ServerPlayerEntity player) {
        OpenGui current = this.open.get(player.getUuid());
        if (current == null) {
            return null;
        }
        ScreenHandler screenHandler = player.currentScreenHandler;
        if (!(screenHandler instanceof PvPScreenHandler)) {
            return null;
        }
        PvPScreenHandler h = (PvPScreenHandler)screenHandler;
        return h.syncId != current.syncId ? null : current.gui();
    }

    public void close(ServerPlayerEntity player) {
        if (player.currentScreenHandler instanceof PvPScreenHandler) {
            player.closeHandledScreen();
        } else {
            OpenGui current = this.open.remove(player.getUuid());
            if (current != null) {
                current.gui().closed();
            }
        }
    }

    public void cleanup(UUID playerId) {
        this.open.remove(playerId);
    }

    public void openAnvil(ServerPlayerEntity player, String title, Consumer<String> callback) {
        player.openHandledScreen((NamedScreenHandlerFactory)new SimpleNamedScreenHandlerFactory((syncId, inv, p) -> new AnvilInputHandler(syncId, inv, player, callback), TextUtil.text(title)));
    }

    public boolean hasGuiOpen(ServerPlayerEntity player) {
        return this.openGui(player) != null;
    }

    private record OpenGui(int syncId, Gui gui) {
    }
}

