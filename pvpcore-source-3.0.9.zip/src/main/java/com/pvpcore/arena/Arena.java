/*
 * Decompiled with CFR 0.152.
 */
package com.pvpcore.arena;

import com.pvpcore.PvPCore;
import com.pvpcore.kit.Kit;
import java.util.ArrayList;
import java.util.List;

public class Arena {
    public String id = "arena";
    public String displayName = "&fArena";
    public boolean enabled = true;
    public List<String> kitIds = new ArrayList<String>();
    public String kitId;
    public String world = "minecraft:overworld";
    public double spawn1X;
    public double spawn1Y;
    public double spawn1Z;
    public float spawn1Yaw;
    public float spawn1Pitch;
    public double spawn2X;
    public double spawn2Y;
    public double spawn2Z;
    public float spawn2Yaw;
    public float spawn2Pitch;
    public double spectatorX;
    public double spectatorY;
    public double spectatorZ;
    public float spectatorYaw;
    public float spectatorPitch;
    public boolean spawn1Set = false;
    public boolean spawn2Set = false;
    public boolean spectatorSet = false;
    public transient Status status = Status.FREE;

    public boolean isValid() {
        return this.spawn1Set && this.spawn2Set;
    }

    public void migrateLegacyKit() {
        String legacy;
        if (this.kitId != null && !this.kitId.isBlank() && !this.kitIds.contains(legacy = this.kitId.trim().toLowerCase())) {
            this.kitIds.add(legacy);
        }
        this.kitId = null;
    }

    public boolean matchesKit(String kitId) {
        if (this.kitIds != null && !this.kitIds.isEmpty()) {
            if (kitId != null && this.hasKit(kitId)) {
                return true;
            }
            for (String k : this.kitIds) {
                if (PvPCore.get() == null || PvPCore.get().kitManager() == null || PvPCore.get().kitManager().get(k) == null) continue;
                return false;
            }
            return true;
        }
        return true;
    }

    public boolean hasKit(String kitId) {
        if (this.kitIds != null && kitId != null) {
            for (String k : this.kitIds) {
                if (!k.equalsIgnoreCase(kitId)) continue;
                return true;
            }
            return false;
        }
        return false;
    }

    public boolean addKit(String kitId) {
        if (kitId != null && !kitId.isBlank() && !this.hasKit(kitId)) {
            if (this.kitIds == null) {
                this.kitIds = new ArrayList<String>();
            }
            this.kitIds.add(kitId.trim().toLowerCase());
            return true;
        }
        return false;
    }

    public boolean removeKit(String kitId) {
        return this.kitIds != null && kitId != null ? this.kitIds.removeIf(k -> k.equalsIgnoreCase(kitId.trim())) : false;
    }

    public void clearKits() {
        if (this.kitIds != null) {
            this.kitIds.clear();
        }
    }

    public boolean isDedicated() {
        if (this.kitIds != null && !this.kitIds.isEmpty()) {
            for (String k : this.kitIds) {
                if (PvPCore.get() == null || PvPCore.get().kitManager() == null || PvPCore.get().kitManager().get(k) == null) continue;
                return true;
            }
            return false;
        }
        return false;
    }

    public String kitDisplayName() {
        if (this.kitIds != null && !this.kitIds.isEmpty()) {
            if (PvPCore.get() != null && PvPCore.get().kitManager() != null) {
                ArrayList<String> names = new ArrayList<String>();
                ArrayList<String> orphaned = new ArrayList<String>();
                for (String k : this.kitIds) {
                    Kit kit = PvPCore.get().kitManager().get(k);
                    if (kit != null) {
                        names.add(kit.displayName);
                        continue;
                    }
                    orphaned.add(k);
                }
                return names.isEmpty() ? "&fAny Gamemode" : String.join((CharSequence)"&7, ", names);
            }
            return "&fAny Gamemode";
        }
        return "&fAny Gamemode";
    }

    public String invalidReason() {
        if (!this.spawn1Set) {
            return "Spawn 1 is not set";
        }
        return !this.spawn2Set ? "Spawn 2 is not set" : "valid";
    }

    public String statusColored() {
        if (!this.enabled) {
            return "&cDisabled";
        }
        return switch (this.status.ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> "&aFree";
            case 1 -> "&eReserved";
            case 2 -> "&cIn Use";
            case 3 -> "&dResetting";
        };
    }

    public static enum Status {
        FREE,
        RESERVED,
        ACTIVE,
        RESETTING;

    }
}

