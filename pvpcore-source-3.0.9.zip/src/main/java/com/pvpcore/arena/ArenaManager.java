/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 *  com.google.gson.GsonBuilder
 *  com.google.gson.reflect.TypeToken
 */
package com.pvpcore.arena;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.pvpcore.PvPCoreMod;
import com.pvpcore.arena.Arena;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.FileAttribute;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class ArenaManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private final Path file;
    private final Map<String, Arena> arenas = new LinkedHashMap<String, Arena>();
    private int rrIndex = 0;

    public ArenaManager(Path dataDir) {
        this.file = dataDir.resolve("arenas.json");
        this.load();
    }

    public void load() {
        this.arenas.clear();
        if (Files.exists(this.file, new LinkOption[0])) {
            try {
                String json = Files.readString(this.file, StandardCharsets.UTF_8);
                List<Arena> list = (List<Arena>)GSON.fromJson(json, new TypeToken<List<Arena>>(){}.getType());
                if (list != null) {
                    for (Arena a : list) {
                        if (a == null || a.id == null) continue;
                        if (a.kitIds == null) {
                            a.kitIds = new ArrayList<String>();
                        }
                        a.migrateLegacyKit();
                        this.arenas.put(a.id, a);
                    }
                }
            }
            catch (Exception var51) {
                PvPCoreMod.LOGGER.error("Failed to load arenas.json", (Throwable)var51);
            }
        }
    }

    public synchronized void save() {
        try {
            Files.createDirectories(this.file.getParent(), new FileAttribute[0]);
            Path tmp = this.file.resolveSibling("arenas.json.tmp");
            Files.writeString(tmp, (CharSequence)GSON.toJson(new ArrayList<Arena>(this.arenas.values())), StandardCharsets.UTF_8, new OpenOption[0]);
            Files.move(tmp, this.file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        }
        catch (IOException var21) {
            PvPCoreMod.LOGGER.error("Failed to save arenas.json", (Throwable)var21);
        }
    }

    public Arena create(String id) {
        Arena a = new Arena();
        a.id = id.toLowerCase().replace(" ", "_");
        a.displayName = "&f" + id;
        this.arenas.put(a.id, a);
        this.save();
        return a;
    }

    public Arena get(String id) {
        return this.arenas.get(id.toLowerCase());
    }

    public Collection<Arena> all() {
        return this.arenas.values();
    }

    public void delete(String id) {
        this.arenas.remove(id.toLowerCase());
        this.save();
    }

    public synchronized Arena reserve() {
        return this.reserve("");
    }

    public synchronized Arena reserve(String kitId) {
        List<Arena> dedicated;
        List<Arena> candidates = this.arenas.values().stream().filter(a -> a.enabled && a.isValid() && a.status == Arena.Status.FREE && a.matchesKit(kitId)).toList();
        if (candidates.isEmpty()) {
            return null;
        }
        List<Arena> pool = candidates;
        if (kitId != null && !kitId.isBlank() && !(dedicated = candidates.stream().filter(a -> a.hasKit(kitId)).toList()).isEmpty()) {
            pool = dedicated;
        }
        Arena picked = pool.get(Math.floorMod(this.rrIndex++, pool.size()));
        picked.status = Arena.Status.RESERVED;
        return picked;
    }

    public void markActive(Arena arena) {
        arena.status = Arena.Status.ACTIVE;
    }

    public void release(Arena arena) {
        if (arena != null) {
            arena.status = Arena.Status.FREE;
        }
    }

    public int countUsable() {
        return (int)this.arenas.values().stream().filter(a -> a.enabled && a.isValid()).count();
    }

    public int countUsable(String kitId) {
        return (int)this.arenas.values().stream().filter(a -> a.enabled && a.isValid() && a.matchesKit(kitId)).count();
    }

    public int countDedicated(String kitId) {
        return (int)this.arenas.values().stream().filter(a -> a.enabled && a.isValid() && kitId != null && a.hasKit(kitId)).count();
    }

    public boolean assign(String arenaId, String kitId) {
        Arena arena = this.arenas.get(arenaId.toLowerCase());
        if (arena != null && kitId != null && !kitId.isBlank()) {
            boolean added = arena.addKit(kitId);
            this.save();
            return added;
        }
        return false;
    }

    public boolean unassign(String arenaId, String kitId) {
        Arena arena = this.arenas.get(arenaId.toLowerCase());
        if (arena != null && kitId != null) {
            boolean removed = arena.removeKit(kitId);
            this.save();
            return removed;
        }
        return false;
    }

    public boolean clearAssignment(String arenaId) {
        Arena arena = this.arenas.get(arenaId.toLowerCase());
        if (arena == null) {
            return false;
        }
        arena.clearKits();
        this.save();
        return true;
    }

    public void renameKitReferences(String oldId, String newId) {
        if (oldId != null && newId != null) {
            boolean changed = false;
            for (Arena arena : this.arenas.values()) {
                if (arena == null || arena.kitIds == null) continue;
                for (int i = 0; i < arena.kitIds.size(); ++i) {
                    if (!arena.kitIds.get(i).equalsIgnoreCase(oldId)) continue;
                    arena.kitIds.set(i, newId.toLowerCase());
                    changed = true;
                }
            }
            if (changed) {
                this.save();
                PvPCoreMod.LOGGER.info("Synced arena references for kit rename {} -> {}", (Object)oldId, (Object)newId);
            }
        }
    }

    public void removeKitReferences(String kitId) {
        if (kitId != null) {
            boolean changed = false;
            for (Arena arena : this.arenas.values()) {
                if (arena == null || arena.kitIds == null || !arena.removeKit(kitId)) continue;
                changed = true;
            }
            if (changed) {
                this.save();
                PvPCoreMod.LOGGER.info("Removed arena references to deleted kit {}", (Object)kitId);
            }
        }
    }
}

