/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.BlockState
 *  net.minecraft.block.entity.BlockEntity
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.ExperienceOrbEntity
 *  net.minecraft.entity.FallingBlockEntity
 *  net.minecraft.entity.ItemEntity
 *  net.minecraft.entity.TntEntity
 *  net.minecraft.entity.projectile.PersistentProjectileEntity
 *  net.minecraft.entity.projectile.thrown.EnderPearlEntity
 *  net.minecraft.nbt.NbtCompound
 *  net.minecraft.registry.DynamicRegistryManager
 *  net.minecraft.registry.RegistryWrapper$WrapperLookup
 *  net.minecraft.server.world.ServerWorld
 *  net.minecraft.storage.NbtReadView
 *  net.minecraft.util.ErrorReporter
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.BlockPos$Mutable
 *  net.minecraft.util.math.Box
 *  net.minecraft.util.math.MathHelper
 */
package com.pvpcore.arena;

import com.pvpcore.PvPCoreMod;
import com.pvpcore.arena.Arena;
import java.util.List;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.entity.FallingBlockEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.TntEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.storage.NbtReadView;
import net.minecraft.util.ErrorReporter;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;

public final class ArenaRestorer {
    private final ServerWorld world;
    private final RegistryWrapper.WrapperLookup registries;
    private final int minX;
    private final int minY;
    private final int minZ;
    private final int sizeX;
    private final int sizeY;
    private final int sizeZ;
    private final BlockState[] states;
    private final NbtCompound[] blockEntities;

    private ArenaRestorer(ServerWorld world, RegistryWrapper.WrapperLookup registries, int minX, int minY, int minZ, int sizeX, int sizeY, int sizeZ, BlockState[] states, NbtCompound[] blockEntities) {
        this.world = world;
        this.registries = registries;
        this.minX = minX;
        this.minY = minY;
        this.minZ = minZ;
        this.sizeX = sizeX;
        this.sizeY = sizeY;
        this.sizeZ = sizeZ;
        this.states = states;
        this.blockEntities = blockEntities;
    }

    public static ArenaRestorer snapshot(ServerWorld world, Arena arena, int radius) {
        if (world == null || arena == null || !arena.spawn1Set || !arena.spawn2Set) {
            return null;
        }
        int r = Math.max(4, Math.min(64, radius));
        // The region must cover BOTH spawn platforms plus the radius - not just a cube
        // around the midpoint (spawns far apart used to leave the platforms outside
        // the snapshot, so blocks broken there were never restored).
        // Auto-shrink the radius until the region fits under the block cap.
        while (r >= 4 && ArenaRestorer.regionVolume(world, arena, r) > 1000000L) {
            --r;
        }
        if (r < 4) {
            PvPCoreMod.LOGGER.warn("Arena reset region still too large at minimum radius, skipping snapshot for arena {}", (Object)arena.id);
            return null;
        }
        int minX = Math.min(MathHelper.floor(arena.spawn1X), MathHelper.floor(arena.spawn2X)) - r;
        int maxX = Math.max(MathHelper.floor(arena.spawn1X), MathHelper.floor(arena.spawn2X)) + r;
        int minZ = Math.min(MathHelper.floor(arena.spawn1Z), MathHelper.floor(arena.spawn2Z)) - r;
        int maxZ = Math.max(MathHelper.floor(arena.spawn1Z), MathHelper.floor(arena.spawn2Z)) + r;
        int minY = MathHelper.floor((double)Math.min(arena.spawn1Y, arena.spawn2Y)) - r;
        int maxY = MathHelper.floor((double)Math.max(arena.spawn1Y, arena.spawn2Y)) + r;
        if ((minY = Math.max(minY, world.getBottomY() + 1)) > (maxY = Math.min(maxY, world.getTopYInclusive() - 1))) {
            return null;
        }
        int sizeX = maxX - minX + 1;
        int sizeY = maxY - minY + 1;
        int sizeZ = maxZ - minZ + 1;
        long volume = (long)sizeX * (long)sizeY * (long)sizeZ;
        if (volume <= 0L || volume > 1000000L) {
            PvPCoreMod.LOGGER.warn("Arena reset region too large ({} blocks), skipping snapshot", (Object)volume);
            return null;
        }
        DynamicRegistryManager registries = world.getRegistryManager();
        BlockState[] states = new BlockState[(int)volume];
        NbtCompound[] blockEntities = new NbtCompound[(int)volume];
        BlockPos.Mutable pos = new BlockPos.Mutable();
        int i = 0;
        for (int y = 0; y < sizeY; ++y) {
            for (int z = 0; z < sizeZ; ++z) {
                for (int x = 0; x < sizeX; ++x) {
                    BlockState state;
                    pos.set(minX + x, minY + y, minZ + z);
                    states[i] = state = world.getBlockState((BlockPos)pos);
                    if (state.hasBlockEntity()) {
                        try {
                            BlockEntity be = world.getBlockEntity((BlockPos)pos);
                            if (be != null) {
                                blockEntities[i] = be.createNbt((RegistryWrapper.WrapperLookup)registries);
                            }
                        }
                        catch (Throwable throwable) {
                            // empty catch block
                        }
                    }
                    ++i;
                }
            }
        }
        PvPCoreMod.LOGGER.info("[PvPCore] Arena snapshot for '{}' region {}x{}x{} at ({}, {}, {}) - {} blocks", new Object[]{arena.id, sizeX, sizeY, sizeZ, minX, minY, minZ, volume});
        return new ArenaRestorer(world, (RegistryWrapper.WrapperLookup)registries, minX, minY, minZ, sizeX, sizeY, sizeZ, states, blockEntities);
    }

    private static long regionVolume(ServerWorld world, Arena arena, int r) {
        int sizeX = Math.abs(MathHelper.floor(arena.spawn1X) - MathHelper.floor(arena.spawn2X)) + 2 * r + 1;
        int sizeZ = Math.abs(MathHelper.floor(arena.spawn1Z) - MathHelper.floor(arena.spawn2Z)) + 2 * r + 1;
        int minY = MathHelper.floor((double)Math.min(arena.spawn1Y, arena.spawn2Y)) - r;
        int maxY = MathHelper.floor((double)Math.max(arena.spawn1Y, arena.spawn2Y)) + r;
        minY = Math.max(minY, world.getBottomY() + 1);
        maxY = Math.min(maxY, world.getTopYInclusive() - 1);
        if (minY > maxY) {
            return 0L;
        }
        return (long)sizeX * (long)(maxY - minY + 1) * (long)sizeZ;
    }

    public void restore() {
        BlockPos.Mutable pos = new BlockPos.Mutable();
        int i = 0;
        for (int y = 0; y < this.sizeY; ++y) {
            for (int z = 0; z < this.sizeZ; ++z) {
                for (int x = 0; x < this.sizeX; ++x) {
                    BlockState saved = this.states[i];
                    if (saved != null) {
                        pos.set(this.minX + x, this.minY + y, this.minZ + z);
                        try {
                            BlockEntity be;
                            NbtCompound nbt;
                            if (!this.world.getBlockState((BlockPos)pos).equals((Object)saved)) {
                                this.world.setBlockState((BlockPos)pos, saved, 3);
                            }
                            if ((nbt = this.blockEntities[i]) != null && (be = this.world.getBlockEntity((BlockPos)pos)) != null) {
                                be.read(NbtReadView.create((ErrorReporter)ErrorReporter.EMPTY, (RegistryWrapper.WrapperLookup)this.registries, (NbtCompound)nbt));
                                be.markDirty();
                            }
                        }
                        catch (Throwable throwable) {
                            // empty catch block
                        }
                    }
                    ++i;
                }
            }
        }
        try {
            Box box = new Box((double)this.minX, (double)this.minY, (double)this.minZ, (double)(this.minX + this.sizeX), (double)(this.minY + this.sizeY), (double)(this.minZ + this.sizeZ));
            List<Entity> junk = this.world.getOtherEntities(null, box, ArenaRestorer::isFightJunk);
            for (Entity e : junk) {
                try {
                    e.discard();
                }
                catch (Throwable throwable) {}
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private static boolean isFightJunk(Entity e) {
        return e instanceof ItemEntity || e instanceof PersistentProjectileEntity || e instanceof TntEntity || e instanceof EnderPearlEntity || e instanceof ExperienceOrbEntity || e instanceof FallingBlockEntity;
    }
}

