/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 *  com.google.gson.GsonBuilder
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonParser
 */
package com.pvpcore.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.pvpcore.PvPCoreMod;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.FileAttribute;
import java.util.Map;

public final class ConfigFile {
    public static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();

    private ConfigFile() {
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static JsonObject load(Path file) {
        try {
            if (!Files.exists(file, new LinkOption[0])) {
                return new JsonObject();
            }
            try (BufferedReader reader = Files.newBufferedReader(file, StandardCharsets.UTF_8);){
                JsonObject jsonObject;
                JsonElement el = JsonParser.parseReader((Reader)reader);
                if (el != null && el.isJsonObject()) {
                    JsonObject jsonObject2 = el.getAsJsonObject();
                    return jsonObject2;
                }
                JsonObject var4 = jsonObject = new JsonObject();
                return var4;
            }
        }
        catch (Exception var7) {
            PvPCoreMod.LOGGER.error("Failed to load config {}", (Object)file, (Object)var7);
            return new JsonObject();
        }
    }

    public static void save(Path file, JsonObject obj) {
        try {
            Files.createDirectories(file.getParent(), new FileAttribute[0]);
            Path tmp = file.resolveSibling(String.valueOf(file.getFileName()) + ".tmp");
            Files.writeString(tmp, (CharSequence)GSON.toJson((JsonElement)obj), StandardCharsets.UTF_8, new OpenOption[0]);
            Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        }
        catch (IOException var31) {
            PvPCoreMod.LOGGER.error("Failed to save config {}", (Object)file, (Object)var31);
        }
    }

    public static JsonObject deepMerge(JsonObject base, JsonObject overrides) {
        if (overrides == null) {
            return base;
        }
        for (Map.Entry entry : overrides.entrySet()) {
            String key = (String)entry.getKey();
            JsonElement value = (JsonElement)entry.getValue();
            if (base.has(key) && base.get(key).isJsonObject() && value != null && value.isJsonObject()) {
                ConfigFile.deepMerge(base.getAsJsonObject(key), value.getAsJsonObject());
                continue;
            }
            base.add(key, value);
        }
        return base;
    }
}

