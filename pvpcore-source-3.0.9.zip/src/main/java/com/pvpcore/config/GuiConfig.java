/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  net.minecraft.item.ItemStack
 */
package com.pvpcore.config;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.pvpcore.PvPCoreMod;
import com.pvpcore.config.ConfigFile;
import com.pvpcore.item.ItemBuilder;
import com.pvpcore.util.ItemCodecUtil;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.item.ItemStack;

public final class GuiConfig {
    private transient Path file;
    private JsonObject root;
    public static final int LAYOUT_VERSION = 7;
    public LobbyItems lobby = new LobbyItems();
    public Map<String, GuiSpec> guis = new LinkedHashMap<String, GuiSpec>();
    public int layoutVersion = 7;
    public static final List<Integer> DEFAULT_KIT_SLOTS = List.of(10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34);

    public void load(Path configDir) {
        boolean resetLayout;
        this.file = configDir.resolve("guis.json");
        JsonObject defaults = ConfigFile.GSON.toJsonTree((Object)this.buildDefaults()).getAsJsonObject();
        JsonObject user = ConfigFile.load(this.file);
        int userLayout = 0;
        try {
            if (user != null && user.has("layoutVersion") && user.get("layoutVersion").isJsonPrimitive()) {
                userLayout = user.get("layoutVersion").getAsInt();
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        boolean bl = resetLayout = userLayout < 7;
        if (resetLayout && user != null) {
            user.remove("guis");
            user.addProperty("layoutVersion", (Number)7);
            PvPCoreMod.LOGGER.info("guis.json layout v{} -> v{}: applying the modern 2.8.0 GUI layout (rounds item, off-hand slot)", (Object)userLayout, (Object)7);
        }
        this.root = ConfigFile.deepMerge(defaults, user);
        GuiConfig.sanitizeSlots(this.root, defaults);
        GuiConfig merged = (GuiConfig)ConfigFile.GSON.fromJson((JsonElement)this.root, GuiConfig.class);
        this.lobby = merged.lobby;
        this.guis = merged.guis;
        this.layoutVersion = 7;
        ConfigFile.save(this.file, this.root);
        PvPCoreMod.LOGGER.info("Loaded guis.json ({} guis)", (Object)this.guis.size());
    }

    public void save() {
        if (this.file != null) {
            JsonObject defaults = ConfigFile.GSON.toJsonTree((Object)this.buildDefaults()).getAsJsonObject();
            this.root = ConfigFile.deepMerge(defaults, this.root);
            ConfigFile.save(this.file, this.root);
        }
    }

    public ItemSpec lobbyItem(String key) {
        ItemSpec spec = this.lobby.items.get(key);
        return spec != null ? spec : this.fallback(key);
    }

    public ItemSpec item(String guiKey, String itemKey) {
        ItemSpec item;
        GuiSpec spec = this.guis.get(guiKey);
        return spec != null && (item = spec.items.get(itemKey)) != null ? item : this.fallback(itemKey);
    }

    public String title(String guiKey) {
        GuiSpec spec = this.guis.get(guiKey);
        return spec != null ? spec.title : "&8Menu";
    }

    public int rows(String guiKey) {
        GuiSpec spec = this.guis.get(guiKey);
        return spec != null ? Math.max(1, Math.min(6, spec.rows)) : 5;
    }

    public List<Integer> kitSlots(String guiKey) {
        GuiSpec spec = this.guis.get(guiKey);
        return spec != null && spec.kitSlots != null && !spec.kitSlots.isEmpty() ? spec.kitSlots.stream().filter(s -> s >= 0 && s < 54).toList() : DEFAULT_KIT_SLOTS;
    }

    private ItemSpec fallback(String key) {
        ItemSpec spec = new ItemSpec();
        if ("filler".equals(key)) {
            spec.material = "BLACK_STAINED_GLASS_PANE";
            spec.name = "&r";
            spec.slot = 0;
            return spec;
        }
        spec.material = "GRAY_DYE";
        spec.name = "&cMissing item: " + key;
        spec.slot = 0;
        return spec;
    }

    public ItemStack buildItem(String guiKey, String itemKey) {
        return this.build(this.item(guiKey, itemKey));
    }

    public ItemStack buildLobbyItem(String key) {
        return this.build(this.lobbyItem(key));
    }

    public ItemStack build(ItemSpec spec) {
        ItemStack st = ItemCodecUtil.parseMaterial(spec.material);
        if (st.isEmpty()) {
            st = ItemCodecUtil.parseMaterial("STONE");
        }
        ItemBuilder b = ItemBuilder.of(st).amount(spec.amount).name(spec.name).lore(spec.lore).glow(spec.glow);
        return b.build();
    }

    public GuiConfig buildDefaults() {
        GuiConfig cfg = new GuiConfig();
        cfg.lobby.items.put("unranked", GuiConfig.item(0, "IRON_SWORD", "&b&lUnranked Queue", List.of("&7Click to browse kits", "&7and join the unranked queue.")));
        cfg.lobby.items.put("ranked", GuiConfig.item(1, "NETHERITE_SWORD", "&6&lRanked Queue", List.of("&7Click to browse kits", "&7and join the ranked queue.", "&eELO is on the line!")));
        cfg.lobby.items.put("duel", GuiConfig.item(2, "BLAZE_ROD", "&c&lDuel a Player", List.of("&7Click to pick an opponent", "&7and challenge them to a duel.")));
        cfg.lobby.items.put("kits", GuiConfig.item(3, "BOOK", "&3&lKits", List.of("&7Browse, view and edit", "&7your kit layouts.")));
        cfg.lobby.items.put("party", GuiConfig.item(4, "NAME_TAG", "&d&lParty", List.of("&7Click to open the party", "&7menu in chat!")));
        cfg.lobby.items.put("profile", GuiConfig.item(6, "PLAYER_HEAD", "&e&lProfile", List.of("&7View your statistics", "&7and match history.")));
        cfg.lobby.items.put("spectate", GuiConfig.item(7, "ENDER_EYE", "&5&lSpectate", List.of("&7Watch ongoing duels.")));
        cfg.lobby.items.put("party_active", GuiConfig.item(4, "NAME_TAG", "&d&lParty &7(Open Menu)", List.of("&7Click to open the party", "&7menu in chat: invite, kick,", "&7chat & party duels.")));
        cfg.lobby.items.put("queue_leave", GuiConfig.item(0, "REDSTONE", "&c&lLeave Queue", List.of("&7You are queued.", "&7Click to leave the queue.")));
        cfg.lobby.items.put("spectate_return", GuiConfig.item(7, "ENDER_PEARL", "&5&lReturn to Lobby", List.of("&7Click to stop spectating", "&7and return.")));
        cfg.lobby.items.put("admin", GuiConfig.item(8, "COMMAND_BLOCK", "&c&lAdmin Menu", List.of("&7Open the PvP admin menu:", "&7arenas, kits, lobby,", "&7scoreboard & data.", "", "&cAdmins only")));
        cfg.lobby.items.put("filler", GuiConfig.item(8, "BLACK_STAINED_GLASS_PANE", "&r", List.of()));
        ItemSpec leaderboard = GuiConfig.item(5, "EMERALD", "&a&lLeaderboards", List.of("&7View the top players", "&7by wins and ELO."));
        leaderboard.enabled = false;
        cfg.lobby.items.put("leaderboard", leaderboard);
        GuiConfig.gui(cfg, "kit_list", "&8Kits", 5);
        cfg.guis.get((Object)"kit_list").items.put("info", GuiConfig.item(4, "BOOK", "&3&lKits", List.of("&7Click a kit to open its details:", "&8- &fLeft-Click &7to edit your layout", "&8- &fRight-Click &7to reset to default")));
        cfg.guis.get((Object)"kit_list").items.put("create", GuiConfig.item(42, "LIME_DYE", "&a&lCreate Kit", List.of("&7Creates a NEW kit from YOUR", "&7current inventory.", "", "&7Armor, hotbar & inventory", "&7are copied exactly.", "&cAdmin only")));
        cfg.guis.get((Object)"kit_list").items.put("prev", GuiConfig.item(39, "ARROW", "&ePrevious Page", List.of()));
        cfg.guis.get((Object)"kit_list").items.put("next", GuiConfig.item(41, "ARROW", "&eNext Page", List.of()));
        cfg.guis.get((Object)"kit_list").items.put("close", GuiConfig.item(40, "BARRIER", "&cClose", List.of()));
        GuiConfig.gui(cfg, "kit_stats", "&8Kit Statistics", 5);
        cfg.guis.get((Object)"kit_stats").items.put("edit", GuiConfig.item(20, "ANVIL", "&eEdit Layout", List.of("&7Open the kit editor for", "&7this kit.", "", "&7Players customize the layout", "&7and slots of this kit only -", "&7items come from the admin", "&7template.")));
        cfg.guis.get((Object)"kit_stats").items.put("edit_template", GuiConfig.item(24, "COMMAND_BLOCK", "&c&lEdit Template", List.of("&7Edit the DEFAULT layout for", "&7this kit (all players).", "&7Includes the item palette", "&7and enchant menu.", "&cAdmin only")));
        cfg.guis.get((Object)"kit_stats").items.put("rename", GuiConfig.item(29, "NAME_TAG", "&e&lRename Kit", List.of("&7Current: {name}", "&7Click and type the new name", "&7in the anvil that opens.", "", "&8Type &fnewid:Name &8to change", "&8the kit id at the same time", "&8(arena refs stay in sync).", "&cAdmin only")));
        cfg.guis.get((Object)"kit_stats").items.put("icon", GuiConfig.item(30, "ITEM_FRAME", "&e&lChange Icon", List.of("&7Pick a new display icon", "&7for this kit from the", "&7item palette.", "&cAdmin only")));
        cfg.guis.get((Object)"kit_stats").items.put("position", GuiConfig.item(31, "COMPASS", "&e&lPosition: &f{slot}", List.of("&7The kit's position in the", "&7kit list and kit pickers.", "", "&eLeft-Click &7to move up", "&eRight-Click &7to move down", "&cAdmin only")));
        cfg.guis.get((Object)"kit_stats").items.put("toggle", GuiConfig.item(32, "LIME_DYE", "&a&l{state}", List.of("&7Toggle whether players can", "&7see and use this kit.", "&cAdmin only")));
        cfg.guis.get((Object)"kit_stats").items.put("delete", GuiConfig.item(34, "TNT", "&c&lDelete Kit", List.of("&7Permanently delete this kit", "&7and all personal layouts", "&7players saved for it.", "&7Asks for confirmation.", "&cAdmin only")));
        cfg.guis.get((Object)"kit_stats").items.put("back", GuiConfig.item(39, "ARROW", "&eBack", List.of()));
        cfg.guis.get((Object)"kit_stats").items.put("close", GuiConfig.item(41, "BARRIER", "&cClose", List.of()));
        GuiConfig.gui(cfg, "kit_editor", "&8Kit Editor{mode}", 6);
        cfg.guis.get((Object)"kit_editor").items.put("armor_info", GuiConfig.item(5, "ARMOR_STAND", "&fArmor", List.of("&7Place armor pieces in the", "&7top-left 4 slots.")));
        cfg.guis.get((Object)"kit_editor").items.put("offhand_info", GuiConfig.item(6, "TOTEM_OF_UNDYING", "&eOff-hand", List.of("&7The slot next to the armor", "&7is the OFF-HAND slot.", "&7Put totems or shields", "&7there!")));
        cfg.guis.get((Object)"kit_editor").items.put("enchant_target", GuiConfig.item(46, "YELLOW_STAINED_GLASS_PANE", "&e&lEnchant Slot", List.of("&7Place an item here,", "&7then click the Enchant", "&7button to enchant it.", "&cAdmin template mode only")));
        cfg.guis.get((Object)"kit_editor").items.put("save", GuiConfig.item(49, "LIME_DYE", "&a&lSave Kit", List.of("&7Save this layout as", "&7your kit layout.")));
        cfg.guis.get((Object)"kit_editor").items.put("get_kit", GuiConfig.item(47, "HOPPER", "&b&lGet Kit Items", List.of("&7Puts every item of this kit", "&7into YOUR inventory so you", "&7can edit & test it freely.", "&cAdmin template mode only")));
        cfg.guis.get((Object)"kit_editor").items.put("from_inventory", GuiConfig.item(48, "ITEM_FRAME", "&e&lSave From Inventory", List.of("&7Turns YOUR whole inventory", "&7(armor + hotbar + storage)", "&7into this kit's layout.", "", "&7Add single items instead:", "&8- &fDrag &7an item from below", "&8  &7into any kit slot (moves it in)", "&8- &fShift-Click &7an item below", "&8  &7to copy it into the kit", "&cAdmin template mode only")));
        cfg.guis.get((Object)"kit_editor").items.put("clear", GuiConfig.item(50, "RED_DYE", "&c&lClear Kit", List.of("&7Remove all items from", "&7this layout.", "&cAdmin template mode only")));
        cfg.guis.get((Object)"kit_editor").items.put("palette", GuiConfig.item(51, "CHEST", "&b&lItem Palette", List.of("&7Browse every item and", "&7add it to the kit template.", "&cAdmin template mode only")));
        cfg.guis.get((Object)"kit_editor").items.put("enchant", GuiConfig.item(52, "ENCHANTED_BOOK", "&d&lEnchant Item", List.of("&7Enchant the item placed", "&7in the enchant slot.", "&cAdmin template mode only")));
        cfg.guis.get((Object)"kit_editor").items.put("back", GuiConfig.item(45, "ARROW", "&eBack", List.of()));
        cfg.guis.get((Object)"kit_editor").items.put("close", GuiConfig.item(53, "BARRIER", "&cClose", List.of()));
        cfg.guis.get((Object)"kit_editor").items.put("filler", GuiConfig.item(4, "BLACK_STAINED_GLASS_PANE", "&r", List.of()));
        GuiConfig.gui(cfg, "palette", "&8Item Palette{mode}", 6);
        cfg.guis.get((Object)"palette").items.put("prev", GuiConfig.item(45, "ARROW", "&ePrevious Page", List.of()));
        cfg.guis.get((Object)"palette").items.put("back", GuiConfig.item(48, "ARROW", "&eBack to Editor", List.of()));
        cfg.guis.get((Object)"palette").items.put("page", GuiConfig.item(49, "PAPER", "&fPage &e{page}&f/&e{pages}", List.of()));
        cfg.guis.get((Object)"palette").items.put("next", GuiConfig.item(53, "ARROW", "&eNext Page", List.of()));
        GuiConfig.gui(cfg, "enchant", "&8Enchant Item", 6);
        cfg.guis.get((Object)"enchant").items.put("target", GuiConfig.item(49, "PAPER", "&dTarget Item", List.of("&7Click an enchantment to", "&7cycle its level.")));
        cfg.guis.get((Object)"enchant").items.put("back", GuiConfig.item(45, "ARROW", "&eBack to Editor", List.of()));
        GuiConfig.gui(cfg, "queue", "&8Select a Kit", 5);
        cfg.guis.get((Object)"queue").items.put("rounds", GuiConfig.item(42, "CLOCK", "&e&lRounds: &f{rounds}", List.of("&7The duel will be played over", "&7this many rounds.", "", "&eLeft-Click &7+1 round &8(wraps)", "&eRight-Click &7-1 round", "&eShift+Left &7reset to default", "", "&7Maximum: &f{max}")));
        cfg.guis.get((Object)"queue").items.put("prev", GuiConfig.item(36, "ARROW", "&ePrevious Page", List.of()));
        cfg.guis.get((Object)"queue").items.put("next", GuiConfig.item(44, "ARROW", "&eNext Page", List.of()));
        cfg.guis.get((Object)"queue").items.put("back", GuiConfig.item(40, "ARROW", "&eBack", List.of()));
        GuiConfig.gui(cfg, "player_picker", "&8Select a Player", 6);
        cfg.guis.get((Object)"player_picker").items.put("prev", GuiConfig.item(45, "ARROW", "&ePrevious Page", List.of()));
        cfg.guis.get((Object)"player_picker").items.put("page", GuiConfig.item(49, "PAPER", "&fPage &e{page}&f/&e{pages}", List.of()));
        cfg.guis.get((Object)"player_picker").items.put("next", GuiConfig.item(53, "ARROW", "&eNext Page", List.of()));
        cfg.guis.get((Object)"player_picker").items.put("back", GuiConfig.item(48, "ARROW", "&eBack", List.of()));
        GuiConfig.gui(cfg, "challenge", "&8Duel Request", 3);
        cfg.guis.get((Object)"challenge").items.put("info", GuiConfig.item(13, "PAPER", "&6{player} &7challenges you!", List.of("&7Kit: &f{kit}", "&7Click accept to duel!")));
        cfg.guis.get((Object)"challenge").items.put("accept", GuiConfig.item(11, "LIME_DYE", "&a&lAccept", List.of("&7Accept the duel request.")));
        cfg.guis.get((Object)"challenge").items.put("deny", GuiConfig.item(15, "RED_DYE", "&c&lDeny", List.of("&7Deny the duel request.")));
        GuiConfig.gui(cfg, "stats", "&8Statistics", 6);
        cfg.guis.get((Object)"stats").items.put("back", GuiConfig.item(45, "ARROW", "&eBack", List.of()));
        cfg.guis.get((Object)"stats").items.put("close", GuiConfig.item(53, "BARRIER", "&cClose", List.of()));
        GuiConfig.gui(cfg, "profile", "&8Profile", 6);
        cfg.guis.get((Object)"profile").items.put("head", GuiConfig.item(4, "PLAYER_HEAD", "&e{player}", List.of("&7View your duel statistics.")));
        cfg.guis.get((Object)"profile").items.put("global", GuiConfig.item(11, "NETHER_STAR", "&e&lGlobal Stats", List.of()));
        cfg.guis.get((Object)"profile").items.put("kit", GuiConfig.item(15, "BOOK", "&e&lKit Stats", List.of("&7Click a kit to view details.")));
        cfg.guis.get((Object)"profile").items.put("close", GuiConfig.item(49, "BARRIER", "&cClose", List.of()));
        GuiConfig.gui(cfg, "leaderboard", "&8Leaderboards", 6);
        cfg.guis.get((Object)"leaderboard").items.put("global", GuiConfig.item(4, "NETHER_STAR", "&e&lGlobal", List.of("&7Top players across", "&7all kits.")));
        cfg.guis.get((Object)"leaderboard").items.put("switch", GuiConfig.item(49, "EMERALD", "&e&lTop by: &f{type}", List.of("&7Click to switch between", "&7Wins and ELO.")));
        cfg.guis.get((Object)"leaderboard").items.put("prev", GuiConfig.item(45, "ARROW", "&ePrevious Page", List.of()));
        cfg.guis.get((Object)"leaderboard").items.put("next", GuiConfig.item(53, "ARROW", "&eNext Page", List.of()));
        cfg.guis.get((Object)"leaderboard").items.put("back", GuiConfig.item(48, "ARROW", "&eBack", List.of()));
        GuiConfig.gui(cfg, "spectate", "&8Spectate Duels", 6);
        cfg.guis.get((Object)"spectate").items.put("info", GuiConfig.item(4, "ENDER_EYE", "&5&lOngoing Duels", List.of("&7Click a duel to spectate it.")));
        cfg.guis.get((Object)"spectate").items.put("prev", GuiConfig.item(45, "ARROW", "&ePrevious Page", List.of()));
        cfg.guis.get((Object)"spectate").items.put("next", GuiConfig.item(53, "ARROW", "&eNext Page", List.of()));
        cfg.guis.get((Object)"spectate").items.put("back", GuiConfig.item(49, "BARRIER", "&cClose", List.of()));
        GuiConfig.gui(cfg, "zonekits", "&8Pick your Zone Kit", 5);
        cfg.guis.get((Object)"zonekits").items.put("info", GuiConfig.item(4, "NETHERITE_SWORD", "&c&lFight Zone Kits", List.of("&7Pick a kit to fight with.", "&7You respawn with it here.")));
        cfg.guis.get((Object)"zonekits").items.put("prev", GuiConfig.item(36, "ARROW", "&ePrevious Page", List.of()));
        cfg.guis.get((Object)"zonekits").items.put("next", GuiConfig.item(44, "ARROW", "&eNext Page", List.of()));
        cfg.guis.get((Object)"zonekits").items.put("close", GuiConfig.item(49, "BARRIER", "&cClose", List.of()));
        cfg.guis.get((Object)"zonekits").items.put("filler", GuiConfig.item(0, "GRAY_STAINED_GLASS_PANE", "&r", List.of()));
        GuiConfig.gui(cfg, "confirm", "&8Confirm", 3);
        cfg.guis.get((Object)"confirm").items.put("info", GuiConfig.item(13, "PAPER", "&e{title}", List.of("{lines}")));
        cfg.guis.get((Object)"confirm").items.put("yes", GuiConfig.item(11, "LIME_DYE", "&a&lYes", List.of("&7Confirm the action.")));
        cfg.guis.get((Object)"confirm").items.put("no", GuiConfig.item(15, "RED_DYE", "&c&lNo", List.of("&7Cancel the action.")));
        GuiConfig.gui(cfg, "party_menu", "&8Party", 5);
        cfg.guis.get((Object)"party_menu").items.put("info", GuiConfig.item(4, "NAME_TAG", "&d&lYour Party", List.of("&7Online: &f{online}&7/&f{max}", "&7Leader: &f{leader}", "&7Name color: {color}")));
        cfg.guis.get((Object)"party_menu").items.put("invite", GuiConfig.item(28, "LIME_DYE", "&a&lInvite", List.of("&7Invite online players", "&7to your party.", "&7They accept in chat.")));
        cfg.guis.get((Object)"party_menu").items.put("chat", GuiConfig.item(30, "WRITABLE_BOOK", "&5&lParty Chat: {status}", List.of("&7Toggle party-only chat.", "&7While dueling, chat always", "&7goes to the duel channel.")));
        cfg.guis.get((Object)"party_menu").items.put("duel", GuiConfig.item(32, "IRON_SWORD", "&c&lDuel a Party", List.of("&7Challenge another party", "&7to a party-vs-party duel.", "&eLeader only")));
        cfg.guis.get((Object)"party_menu").items.put("split", GuiConfig.item(34, "RED_BED", "&6&lSplit Teams", List.of("&7Organize a party event:", "&7assign every member to", "&cthe RED &7or &9the BLUE &7team", "&7(any N vs M!) and start", "&7the duel. &eLeader only")));
        cfg.guis.get((Object)"party_menu").items.put("leave", GuiConfig.item(39, "RED_DYE", "&c&lLeave Party", List.of("&7Leave this party.")));
        cfg.guis.get((Object)"party_menu").items.put("disband", GuiConfig.item(41, "TNT", "&4&lDisband Party", List.of("&7Kick everyone and", "&7delete this party.", "&eLeader only")));
        cfg.guis.get((Object)"party_menu").items.put("close", GuiConfig.item(43, "BARRIER", "&cClose", List.of()));
        GuiConfig.gui(cfg, "party_split", "&8Party Event - Who vs Who", 6);
        cfg.guis.get((Object)"party_split").items.put("info", GuiConfig.item(4, "COMPARATOR", "&6&lParty Event", List.of("&8Left-Click a head: &cred team", "&8Right-Click a head: &9blue team", "&7Click again: back to the bench", "", "&cRED&7: &f{red} &8| &9BLUE&7: &f{blue} &8| &7Bench: &f{bench}", "&7Any N vs M is allowed (2v5, 1v3...).")));
        cfg.guis.get((Object)"party_split").items.put("auto", GuiConfig.item(45, "LIME_DYE", "&a&lAuto Balance", List.of("&7Spread everyone evenly:", "&c{red} &7vs &9{blue}")));
        cfg.guis.get((Object)"party_split").items.put("reset", GuiConfig.item(46, "RED_DYE", "&c&lReset", List.of("&7Clear all team", "&7assignments.")));
        cfg.guis.get((Object)"party_split").items.put("start", GuiConfig.item(49, "NETHER_STAR", "&e&lStart Event", List.of("&7Pick a kit, pick the rounds", "&7and fight! The fighters get", "&cRED &7/ &9BLUE &7name colors.")));
        cfg.guis.get((Object)"party_split").items.put("back", GuiConfig.item(53, "ARROW", "&eBack", List.of("&7Back to the party menu.")));
        GuiConfig.gui(cfg, "admin", "&8PvP Admin", 6);
        cfg.guis.get((Object)"admin").items.put("reload", GuiConfig.item(20, "REPEATER", "&e&lReload Configs", List.of("&7Reload settings.json,", "&7guis.json and messages.json.")));
        cfg.guis.get((Object)"admin").items.put("save", GuiConfig.item(21, "HOPPER", "&e&lSave Data", List.of("&7Force-save all player data", "&7kits and arenas.")));
        cfg.guis.get((Object)"admin").items.put("arenas", GuiConfig.item(22, "GRASS_BLOCK", "&e&lArenas", List.of("&7Manage duel arenas.")));
        cfg.guis.get((Object)"admin").items.put("kits", GuiConfig.item(23, "BOOK", "&e&lKits", List.of("&7Manage kits.")));
        cfg.guis.get((Object)"admin").items.put("setlobby", GuiConfig.item(24, "BEACON", "&e&lSet Lobby", List.of("&7Set the lobby spawn to", "&7your current location.")));
        cfg.guis.get((Object)"admin").items.put("scoreboard", GuiConfig.item(25, "COMMAND_BLOCK", "&d&lDuel Scoreboard", List.of("&7Customise the duel scoreboard:", "&7title, lines, order and more.")));
        cfg.guis.get((Object)"admin").items.put("close", GuiConfig.item(49, "BARRIER", "&cClose", List.of()));
        GuiConfig.gui(cfg, "scoreboard_settings", "&8Duel Scoreboard", 6);
        cfg.guis.get((Object)"scoreboard_settings").items.put("toggle", GuiConfig.item(4, "EMERALD", "&a&lScoreboard: {state}", List.of("&7Show the scoreboard during duels.", "&eClick &7to toggle on/off.")));
        cfg.guis.get((Object)"scoreboard_settings").items.put("title", GuiConfig.item(20, "NAME_TAG", "&6&lTitle: &f{title}", List.of("&7The big heading at the top", "&7of the duel scoreboard.", "&eClick &7to type a new one.", "&8Supports &f& & color codes")));
        cfg.guis.get((Object)"scoreboard_settings").items.put("interval", GuiConfig.item(24, "CLOCK", "&e&lUpdate Speed: &f{interval} ticks", List.of("&7How often the scoreboard", "&7refreshes (20 ticks = 1s).", "&eLeft-Click &7faster", "&eRight-Click &7slower")));
        cfg.guis.get((Object)"scoreboard_settings").items.put("line", GuiConfig.item(0, "FILLED_MAP", "&fLine {index}", List.of("&7Content: &r{preview}", "", "&eLeft-Click &7move up", "&eRight-Click &7move down", "&eShift+Left &7remove line")));
        cfg.guis.get((Object)"scoreboard_settings").items.put("add", GuiConfig.item(48, "PAPER", "&b&lAdd Line", List.of("&7Add a new line at the end.", "&8Placeholders: &f{player1} {player2}", "&f{score1} {score2} {round}", "&f{rounds} {duration} {hits1}", "&f{hits2} {ping1} {ping2}", "&8Colors: &f&c&l& &7codes")));
        cfg.guis.get((Object)"scoreboard_settings").items.put("reset", GuiConfig.item(47, "SUNFLOWER", "&6&lReset to Defaults", List.of("&7Restore the default scoreboard", "&7title and lines.")));
        cfg.guis.get((Object)"scoreboard_settings").items.put("back", GuiConfig.item(45, "ARROW", "&eBack", List.of()));
        cfg.guis.get((Object)"scoreboard_settings").items.put("close", GuiConfig.item(53, "BARRIER", "&cClose", List.of()));
        GuiConfig.gui(cfg, "arenas", "&8Arenas", 6);
        cfg.guis.get((Object)"arenas").items.put("create", GuiConfig.item(45, "LIME_DYE", "&a&lCreate Arena", List.of("&7Create a new arena.")));
        cfg.guis.get((Object)"arenas").items.put("info", GuiConfig.item(4, "GRASS_BLOCK", "&e&lArenas &7({count})", List.of("&7Left-click an arena to edit.", "&7Right-click to teleport.")));
        cfg.guis.get((Object)"arenas").items.put("prev", GuiConfig.item(48, "ARROW", "&ePrevious Page", List.of()));
        cfg.guis.get((Object)"arenas").items.put("next", GuiConfig.item(52, "ARROW", "&eNext Page", List.of()));
        cfg.guis.get((Object)"arenas").items.put("back", GuiConfig.item(49, "ARROW", "&eBack", List.of()));
        GuiConfig.gui(cfg, "arena_editor", "&8Edit Arena", 5);
        cfg.guis.get((Object)"arena_editor").items.put("info", GuiConfig.item(4, "PAPER", "&e&l{arena}", List.of("&7Status: {status}", "&7Spawns set: {spawns}", "&7Gamemode: {kit}")));
        cfg.guis.get((Object)"arena_editor").items.put("setspawn1", GuiConfig.item(19, "RED_BED", "&c&lSet Spawn 1", List.of("&7Set spawn 1 to your", "&7current location.")));
        cfg.guis.get((Object)"arena_editor").items.put("setspawn2", GuiConfig.item(20, "BLUE_BED", "&9&lSet Spawn 2", List.of("&7Set spawn 2 to your", "&7current location.")));
        cfg.guis.get((Object)"arena_editor").items.put("setspectator", GuiConfig.item(21, "ENDER_EYE", "&5&lSet Spectator Spawn", List.of("&7Set the spectator spawn", "&7to your current location.")));
        cfg.guis.get((Object)"arena_editor").items.put("teleport", GuiConfig.item(23, "ENDER_PEARL", "&d&lTeleport", List.of("&7Teleport to this arena.")));
        cfg.guis.get((Object)"arena_editor").items.put("gamemode", GuiConfig.item(22, "DIAMOND_SWORD", "&6&lGamemode: {kit}", List.of("&7The gamemode (kit) this arena", "&7hosts duels for.", "", "&7An arena can be assigned to", "&7MULTIPLE kits at once.", "&7Dedicated arenas are always", "&7picked before generic ones.", "", "&eClick &7to manage the kit list")));
        cfg.guis.get((Object)"arena_editor").items.put("enable", GuiConfig.item(24, "LIME_DYE", "&a&lToggle Enabled", List.of("&7Currently: {status}")));
        cfg.guis.get((Object)"arena_editor").items.put("validate", GuiConfig.item(25, "EMERALD", "&e&lValidate", List.of("&7Check that this arena", "&7is ready for duels.")));
        cfg.guis.get((Object)"arena_editor").items.put("rename", GuiConfig.item(31, "ANVIL", "&e&lRename", List.of("&7Rename this arena.")));
        cfg.guis.get((Object)"arena_editor").items.put("delete", GuiConfig.item(40, "TNT", "&c&lDelete Arena", List.of("&7Delete this arena", "&7permanently!")));
        cfg.guis.get((Object)"arena_editor").items.put("back", GuiConfig.item(36, "ARROW", "&eBack", List.of()));
        GuiConfig.gui(cfg, "arena_kits", "&8Arena Kits - {arena}", 5);
        cfg.guis.get((Object)"arena_kits").items.put("info", GuiConfig.item(4, "DIAMOND_SWORD", "&6&lArena Gamemodes", List.of("&7Assign this arena to one or", "&7more kits, or leave it open", "&7for every gamemode.", "", "&eLeft-Click &7a kit to toggle it", "&7on / off.")));
        cfg.guis.get((Object)"arena_kits").items.put("clear", GuiConfig.item(8, "BARRIER", "&c&lAny Gamemode", List.of("&7Remove every kit assignment", "&7so this arena hosts duels", "&7for ALL gamemodes.")));
        cfg.guis.get((Object)"arena_kits").items.put("back", GuiConfig.item(49, "ARROW", "&eBack", List.of("&7Back to the arena editor.")));
        for (GuiSpec spec : cfg.guis.values()) {
            if (spec.items.containsKey("filler")) continue;
            spec.items.put("filler", GuiConfig.item(0, "GRAY_STAINED_GLASS_PANE", "&r", List.of()));
        }
        return cfg;
    }

    private static void gui(GuiConfig cfg, String key, String title, int rows) {
        GuiSpec spec = new GuiSpec();
        spec.title = title;
        spec.rows = rows;
        cfg.guis.put(key, spec);
    }

    private static void sanitizeSlots(JsonObject root, JsonObject defaults) {
        try {
            JsonObject guis = root.getAsJsonObject("guis");
            JsonObject defGuis = defaults.getAsJsonObject("guis");
            if (guis == null) {
                return;
            }
            for (Map.Entry e : guis.entrySet()) {
                if (!((JsonElement)e.getValue()).isJsonObject()) continue;
                JsonObject spec = ((JsonElement)e.getValue()).getAsJsonObject();
                int rows = spec.has("rows") && spec.get("rows").isJsonPrimitive() ? spec.get("rows").getAsInt() : 5;
                int size = Math.max(1, Math.min(6, rows)) * 9;
                JsonObject items = spec.has("items") && spec.get("items").isJsonObject() ? spec.getAsJsonObject("items") : null;
                if (items == null) continue;
                JsonObject defSpec = defGuis != null && defGuis.has((String)e.getKey()) ? defGuis.getAsJsonObject((String)e.getKey()) : null;
                JsonObject defItems = defSpec != null && defSpec.has("items") ? defSpec.getAsJsonObject("items") : null;
                for (Map.Entry it : items.entrySet()) {
                    int slot;
                    JsonObject item;
                    if (!((JsonElement)it.getValue()).isJsonObject() || !(item = ((JsonElement)it.getValue()).getAsJsonObject()).has("slot") || !item.get("slot").isJsonPrimitive() || (slot = item.get("slot").getAsInt()) >= 0 && slot < size) continue;
                    int defSlot = 0;
                    if (defItems != null && defItems.has((String)it.getKey()) && defItems.get((String)it.getKey()).isJsonObject()) {
                        defSlot = defItems.getAsJsonObject((String)it.getKey()).get("slot").getAsInt();
                    }
                    if (defSlot < 0 || defSlot >= size) {
                        defSlot = size - 1;
                    }
                    item.addProperty("slot", (Number)defSlot);
                }
            }
        }
        catch (Exception var171) {
            PvPCoreMod.LOGGER.warn("Could not sanitize GUI slots: {}", (Object)var171.getMessage());
        }
    }

    private static ItemSpec item(int slot, String material, String name, List<String> lore) {
        ItemSpec spec = new ItemSpec();
        spec.slot = slot;
        spec.material = material;
        spec.name = name;
        spec.lore = new ArrayList<String>(lore);
        return spec;
    }

    public static class LobbyItems {
        public Map<String, ItemSpec> items = new LinkedHashMap<String, ItemSpec>();
    }

    public static class ItemSpec {
        public boolean enabled = true;
        public int slot = 0;
        public String material = "STONE";
        public int amount = 1;
        public String name = "&fItem";
        public List<String> lore = new ArrayList<String>();
        public boolean glow = false;
        public String headOwner = "";
    }

    public static class GuiSpec {
        public String title = "&8Menu";
        public int rows = 5;
        public Map<String, ItemSpec> items = new LinkedHashMap<String, ItemSpec>();
        public List<Integer> kitSlots = new ArrayList<Integer>(DEFAULT_KIT_SLOTS);
    }
}

