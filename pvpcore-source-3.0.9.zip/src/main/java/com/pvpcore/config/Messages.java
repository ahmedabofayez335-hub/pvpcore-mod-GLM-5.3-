/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 */
package com.pvpcore.config;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.pvpcore.PvPCoreMod;
import com.pvpcore.config.ConfigFile;
import com.pvpcore.util.TextUtil;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

public final class Messages {
    private transient Path file;
    private JsonObject root;
    private final Map<String, String> defaults = new LinkedHashMap<String, String>();
    private final Map<String, String> values = new LinkedHashMap<String, String>();

    public void load(Path configDir) {
        this.file = configDir.resolve("messages.json");
        if (this.defaults.isEmpty()) {
            this.registerDefaults();
        }
        JsonObject defObj = new JsonObject();
        this.defaults.forEach((arg_0, arg_1) -> defObj.addProperty(arg_0, arg_1));
        JsonObject user = ConfigFile.load(this.file);
        this.root = ConfigFile.deepMerge(defObj, user);
        this.values.clear();
        for (Map.Entry e : this.root.entrySet()) {
            if (!((JsonElement)e.getValue()).isJsonPrimitive()) continue;
            this.values.put((String)e.getKey(), ((JsonElement)e.getValue()).getAsString());
        }
        ConfigFile.save(this.file, this.root);
        String oldCreated = "&aZone &e{zone} &acreated. Set its spawn with &f/zone setspawn&7.";
        String newCreated = "&aZone &e{zone} &acreated. Set its spawn with &f/pvpzone setspawn&7.";
        if (oldCreated.equals(this.values.get("zone.created"))) {
            this.set("zone.created", newCreated);
            ConfigFile.save(this.file, this.root);
        }
        // 3.0.6: /spawn and /lobby no longer exit fight zones - migrate the hint.
        String oldHint = "&7Die and you respawn here. Type &f/spawn&7, &f/leave &7or &f/lobby &7to exit.";
        String newHint = "&7Die and you respawn here. Type &f/leave &7to exit the fight zone.";
        if (oldHint.equals(this.values.get("zone.leave-hint"))) {
            this.set("zone.leave-hint", newHint);
            ConfigFile.save(this.file, this.root);
        }
        PvPCoreMod.LOGGER.info("Loaded messages.json ({} messages)", (Object)this.values.size());
    }

    public String raw(String key) {
        String v = this.values.get(key);
        return v != null ? v : this.defaults.getOrDefault(key, key);
    }

    public String get(String key, Map<String, String> vars) {
        return TextUtil.colorAndPlace(this.raw(key), vars);
    }

    public String get(String key) {
        return TextUtil.colorize(this.raw(key));
    }

    public String plain(String key, Map<String, String> vars) {
        return TextUtil.placeholders(this.raw(key), vars);
    }

    public void set(String key, String value) {
        this.values.put(key, value);
        if (this.root == null) {
            this.root = new JsonObject();
        }
        this.root.addProperty(key, value);
    }

    public Map<String, String> all() {
        return this.values;
    }

    public void save() {
        if (this.file != null) {
            ConfigFile.save(this.file, this.root);
        }
    }

    private void reg(String key, String value) {
        this.defaults.put(key, value);
    }

    private void registerDefaults() {
        this.reg("prefix", "&8[&6PvP&8] &r");
        this.reg("no-permission", "&cYou don't have permission to do that.");
        this.reg("player-not-found", "&cPlayer &e{player} &cwas not found.");
        this.reg("player-only", "&cThis can only be used by players.");
        this.reg("not-in-lobby", "&cYou can't do that right now.");
        this.reg("reload-done", "&aReloaded all configs in &f{ms}ms&a.");
        this.reg("data-saved", "&aAll data saved.");
        this.reg("lobby.applied", "&7Lobby items applied.");
        this.reg("lobby.items-locked", "&cYour lobby items are locked.");
        this.reg("lobby.teleported", "&7Teleported to the lobby.");
        this.reg("spawn.blocked-duel", "&cYou can't use &f/spawn &cor &f/lobby &cwhile in a duel. Use &e/leave &cto forfeit.");
        this.reg("spawn.blocked-zone", "&cYou can't use &f/spawn &cor &f/lobby &cwhile in a fight zone. Use &e/leave &cto exit.");
        this.reg("lobby.not-set", "&cThe lobby location is not set yet. An admin must run &f/pvpadmin setlobby&c.");
        this.reg("queue.joined", "&aYou joined the &e{type} &aqueue for kit &e{kit}&a. &7Rounds: &f{rounds}");
        this.reg("queue.left", "&cYou left the queue.");
        this.reg("queue.not-queued", "&cYou are not in a queue.");
        this.reg("queue.status", "&7In queue: &f{kit} &8({type}) &7- &f{position} &7player(s) waiting &f{range}");
        this.reg("queue.matched", "&aMatch found! &7Kit: &f{kit} &8| &7Arena: &f{arena} &8| &7Rounds: &f{rounds}");
        this.reg("queue.rounds-selected", "&7Rounds: &f{rounds} &8- change it with the clock item in the kit picker.");
        this.reg("queue.already", "&cYou are already in a queue. Click the leave item or use /leavequeue.");
        this.reg("duel.challenge-sent", "&aChallenge sent to &e{player}&a. Kit: &f{kit}");
        this.reg("duel.challenge-received-title", "&6DUEL REQUEST");
        this.reg("duel.challenge-received-subtitle", "&e{player} &7challenged you!");
        this.reg("duel.challenge-expired", "&cThe duel request from &e{player} &cexpired.");
        this.reg("duel.challenge-expired-sender", "&cYour duel request to &e{player} &cexpired.");
        this.reg("duel.challenge-denied", "&c&e{player} &cdenied your duel request.");
        this.reg("duel.challenge-busy", "&c{player} is busy right now.");
        this.reg("duel.challenge-chat-header", "&e{player} &7challenged you to a &f{kit} &7duel!");
        this.reg("duel.challenge-accept-button", " [ACCEPT] ");
        this.reg("duel.challenge-deny-button", " [DENY] ");
        this.reg("duel.challenge-accept-hover", "&aClick to accept the duel");
        this.reg("duel.challenge-deny-hover", "&cClick to deny the duel");
        this.reg("duel.challenge-chat-expire", "&7This request expires in &f{seconds}s&7.");
        this.reg("duel.best-of-line", "&7Rounds: &f{rounds}");
        this.reg("duel.already-in-duel", "&cYou are already in a duel! Finish it first.");
        this.reg("duel.busy", "&c{player} is busy right now.");
        this.reg("duel.target-in-duel", "&e{player} &cis already in a duel. Wait until they are back in the lobby.");
        this.reg("duel.not-ready", "&cYou can't start a duel right now - return to the lobby first (&f/spawn&c).");
        this.reg("duel.target-not-ready", "&e{player} &ccan't be challenged right now - they must be in the lobby.");
        this.reg("duel.rejoined-lobby", "&7You rejoined while a duel was still running, so you were sent back to the lobby.");
        this.reg("duel.round-won", "&e{winner} &awon round &f{round}&a! &7({score1} - {score2})");
        this.reg("duel.round-next", "&7Next round &f({round}&7/&f{rounds}&7) starts in &f{seconds}s&7...");
        this.reg("duel.round-countdown-title", "&6Round {round}");
        this.reg("duel.round-lost-subtitle", "&7You lost this round! Spectating until the next one...");
        this.reg("duel.no-request", "&cYou have no pending duel request.");
        this.reg("leave.duel-left", "&cYou left the duel. Your opponent wins.");
        this.reg("leave.queue-left", "&cYou left the queue.");
        this.reg("leave.nothing", "&cYou are not in a duel or a queue.");
        this.reg("duel.countdown-title", "&c{seconds}");
        this.reg("duel.fight-title", "&aFIGHT!");
        this.reg("duel.win-title", "&6&lVICTORY!");
        this.reg("duel.win-subtitle", "&7You defeated &f{loser}");
        this.reg("duel.lose-title", "&c&lDEFEAT");
        this.reg("duel.lose-subtitle", "&7You were defeated by &f{winner}");
        this.reg("duel.draw-title", "&e&lDRAW");
        this.reg("duel.end-line", "&8&m                                              ");
        this.reg("duel.end-victory", "       &a&lVICTORY!");
        this.reg("duel.end-defeat", "       &c&lDEFEAT");
        this.reg("duel.end-draw", "        &e&lDRAW");
        this.reg("duel.end-victory-sub", "   &7You defeated &f{opponent}");
        this.reg("duel.end-defeat-sub", "   &7You were defeated by &f{opponent}");
        this.reg("duel.end-draw-sub", "   &7The duel vs &f{opponent} &7ended in a draw");
        this.reg("duel.end-spectator", "        &6&lDUEL OVER");
        this.reg("duel.end-spectator-sub", "   &7{winner} &7won the duel");
        this.reg("duel.end-team-victory-sub", "   &7Your team defeated &f{opponent}");
        this.reg("duel.end-team-defeat-sub", "   &7Your team was defeated by &f{opponent}");
        this.reg("duel.end-rounds", "   &7Rounds: &a{wins} &7- &c{losses} &8(of {rounds})");
        this.reg("duel.end-duration", "   &7Duration: &f{duration}");
        this.reg("duel.end-hits", "   &7Your hits: &f{hits1} &8| &7Theirs: &f{hits2}");
        this.reg("duel.started", "&7The duel &e{kit} &7between &f{player1} &7and &f{player2} &7has started in &f{arena}&7!");
        this.reg("duel.ended", "&e{winner} &adefeated &e{loser} &7in a &f{kit} &7duel &8(&f{duration}&8)");
        this.reg("duel.draw", "&7The duel between &f{player1} &7and &f{player2} &7ended in a draw &8(&f{duration}&8)");
        this.reg("duel.timeout", "&cThe duel timed out.");
        this.reg("duel.elo-change", "&7ELO: &f{kit} &8- &e{player1} {delta1} &8({rating1}) &7| &e{player2} {delta2} &8({rating2})");
        this.reg("duel.opponent-disconnected", "&e{player} &edisconnected! Waiting &f{seconds}s &efor them to reconnect...");
        this.reg("duel.opponent-returned", "&a{player} &areconnected!");
        this.reg("duel.won-by-disconnect", "&7Your opponent did not return in time.");
        this.reg("duel.opponent-left", "&cYour opponent left.");
        this.reg("duel.eliminated", "&e{player} &7was eliminated! They spectate until the round ends.");
        this.reg("duel.eliminated-by", "&e{player} &7was eliminated by {killer}&7!");
        this.reg("duel.eliminated-title", "&c&lELIMINATED");
        this.reg("duel.eliminated-subtitle", "&7Spectating until the next round starts...");
        this.reg("duel.same-color-blocked", "&cYou can't fight &e{player} &c- you have the same name color (same team).");
        this.reg("duel.round-lost-items", "&7Your items dropped where you fell!");
        this.reg("kit.not-found", "&cKit &e{kit} &cnot found.");
        this.reg("kit.layout-saved", "&aKit layout saved: &f{kit}");
        this.reg("kit.layout-reset", "&aKit layout reset to default: &f{kit}");
        this.reg("kit.cleared", "&7Kit layout cleared.");
        this.reg("kit.item-added", "&7Added &f{item} &7to your layout.");
        this.reg("kit.enchanted", "&7Enchanted: &f{enchant} {level}");
        this.reg("kit.enchant-removed", "&7Removed enchant: &f{enchant}");
        this.reg("kit.renamed", "&aKit renamed to &f{name}&a.");
        this.reg("kit.created", "&aKit &e{kit} &acreated.");
        this.reg("kit.deleted", "&cKit &e{kit} &cdeleted.");
        this.reg("kit.already-exists", "&cKit &e{kit} &calready exists.");
        this.reg("kit.invalid-name", "&cInvalid kit id. Use letters, numbers, - and _ only.");
        this.reg("kit.created-from-inventory", "&aKit &e{kit} &acreated from your inventory! Edit it in the Kits menu.");
        this.reg("kit.template-saved", "&aKit template saved: &f{kit} &7(all players get this layout by default).");
        this.reg("kit.ffa-layout-saved", "&aFFA kit layout saved: &f{kit} &7(used in fight zones).");
        this.reg("kit.ffa-editor-title", " &8(FFA Layout)");
        this.reg("kit.no-item-to-enchant", "&cPlace an item in the enchant slot first.");
        this.reg("kit.save-hint", "&7Remember to press &aSave &7or close to auto-save.");
        this.reg("kit.editor-original", "&7Editing a copy of the &foriginal {kit} &7kit. Saving stores your personal layout.");
        this.reg("kit.items-given", "&aKit &f{kit} &aitems ({count}) copied to your inventory! Edit freely, then use &eSave From Inventory&a.");
        this.reg("kit.saved-from-inventory", "&aKit &f{kit} &asaved from your inventory (armor + hotbar + storage).");
        this.reg("kit.editor-full", "&cThe kit editor is full - remove an item first.");
        this.reg("sb.enabled", "&aDuel scoreboard enabled.");
        this.reg("sb.disabled", "&cDuel scoreboard disabled.");
        this.reg("sb.title-set", "&aScoreboard title updated.");
        this.reg("sb.line-added", "&aLine added to the scoreboard.");
        this.reg("sb.line-removed", "&cLine removed from the scoreboard.");
        this.reg("sb.too-many-lines", "&cToo many lines (max {max}). Remove one first.");
        this.reg("sb.reset", "&7Scoreboard reset to the default layout.");
        this.reg("kit.icon-changed", "&aKit icon changed: &f{kit}");
        this.reg("kit.slot-changed", "&aKit position set to &f#{slot} &afor &f{kit}&a.");
        this.reg("kit.enabled", "&aKit &f{kit} &aenabled.");
        this.reg("kit.disabled", "&cKit &f{kit} &cdisabled.");
        this.reg("kit.autopot-header", "&6Auto potions for &e{kit} &6(applied at every duel/round start):");
        this.reg("kit.autopot-effect-entry", "&7 #{index} &8- &b{effect} &7lvl {level} &8({duration})");
        this.reg("kit.autopot-item-entry", "&7 #{index} &8- &f{item} &7x{count}");
        this.reg("kit.autopot-empty", "&7No auto potions set for &f{kit}&7. Add with &f/pvpadmin kit autopotions {kit} addeffect <effect> <seconds> [amplifier] &7or &fadditem&7.");
        this.reg("kit.autopot-effect-added", "&aAuto potion effect added to &f{kit}&a: &b{effect} &7lvl {level} &7({duration})");
        this.reg("kit.autopot-item-added", "&aAuto item added to &f{kit}&a: &f{item} &7x{count}");
        this.reg("kit.autopot-removed", "&aRemoved auto potion &f#{index} &afrom &f{kit}&a.");
        this.reg("kit.autopot-cleared", "&aCleared all auto potions from &f{kit}&a.");
        this.reg("kit.autopot-invalid-effect", "&cUnknown potion effect: &f{effect}&c. Try &fspeed&c, &ffire_resistance&c, &fstrength&c...");
        this.reg("kit.autopot-bad-index", "&cNo auto potion at index &f{index}&c.");
        this.reg("kit.autopot-held-empty", "&cHold the potion/item you want to add in your main hand first.");
        this.reg("party.created", "&dYou created a party! Invite players with &f/party invite <player>&d.");
        this.reg("party.disbanded", "&dThe party was disbanded.");
        this.reg("party.disbanded-leader-left", "&d{player} &7disconnected - the party was disbanded.");
        this.reg("party.left", "&dYou left the party.");
        this.reg("party.joined", "&dYou joined &e{player}&d's party!");
        this.reg("party.player-joined", "&d{player} &djoined the party!");
        this.reg("party.player-left", "&d{player} &dleft the party.");
        this.reg("party.kicked", "&c{player} &cwas kicked from the party.");
        this.reg("party.you-kicked", "&cYou were kicked from the party.");
        this.reg("party.invite-sent", "&dInvite sent to &e{player}&d.");
        this.reg("party.invite-received-title", "&dPARTY INVITE");
        this.reg("party.invite-received-subtitle", "&e{player} &7invited you to their party!");
        this.reg("party.invite-expired", "&cThe party invite expired.");
        this.reg("party.invite-denied", "&c{player} &cdeclined the party invite.");
        this.reg("party.promoted", "&d{player} &dis now the party leader.");
        this.reg("party.you-promoted", "&dYou are now the party leader!");
        this.reg("party.full", "&cThe party is full &8({max}&c).");
        this.reg("party.already-in-party", "&cYou are already in a party.");
        this.reg("party.not-in-party", "&cYou are not in a party.");
        this.reg("party.not-leader", "&cOnly the party leader can do that.");
        this.reg("party.no-friendly-duel", "&cYou can't duel &e{player} &c- you're in the same party! Only the party leader can start events (&f/party split&c).");
        this.reg("party.chat-on", "&dParty chat: &aON");
        this.reg("party.chat-off", "&dParty chat: &cOFF");
        this.reg("party.no-parties", "&cThere are no other parties to duel.");
        this.reg("party.challenge-sent", "&dParty duel challenge sent to &e{leader}&d's party!");
        this.reg("party.challenge-received-title", "&dPARTY DUEL");
        this.reg("party.challenge-received-subtitle", "&e{leader} &7challenged your party to a {kit} duel!");
        this.reg("party.menu-header", "&8&m--------&r &d&lPARTY &7({online}&7/&f{max}&7) &8&m--------");
        this.reg("party.menu-members", "&dMembers: {members}");
        this.reg("party.invite-chat-header", "&d{player} &7invited you to their party!");
        this.reg("party.accept-button", " [ACCEPT] ");
        this.reg("party.deny-button", " [DENY] ");
        this.reg("party.accept-hover", "&aClick to join the party");
        this.reg("party.deny-hover", "&cClick to decline the invite");
        this.reg("party.menu-invite-players", "&dClick a player to invite them:");
        this.reg("party.menu-invite-none", "&7No online players can be invited right now.");
        this.reg("party.menu-invite-button", " [INVITE] ");
        this.reg("party.menu-invite-hover", "&aClick to pick players to invite");
        this.reg("party.menu-chat-button", " [CHAT: {status}] ");
        this.reg("party.menu-chat-hover", "&7Click to toggle party-only chat");
        this.reg("party.menu-duel-button", " [DUEL] ");
        this.reg("party.menu-duel-hover", "&7Click to challenge another party");
        this.reg("party.menu-duel-leaders", "&dClick a party leader to duel:");
        this.reg("party.menu-duel-none", "&7There are no other parties to duel right now.");
        this.reg("party.menu-manage-button", " [MANAGE] ");
        this.reg("party.menu-manage-hover", "&7Click to promote / kick members");
        this.reg("party.menu-members-line", "&d{player} &8-");
        this.reg("party.menu-leave-button", " [LEAVE] ");
        this.reg("party.menu-leave-hover", "&cClick to leave the party");
        this.reg("party.menu-disband-button", " [DISBAND] ");
        this.reg("party.menu-disband-hover", "&cClick to disband the party");
        this.reg("party.menu-close-button", " [CLOSE] ");
        this.reg("party.menu-close-hover", "&7Close the party menu");
        this.reg("party.menu-hint", "&7Tip: the party menu is always in chat - click your &dParty &7item!");
        this.reg("party.target-in-duel", "&c{player} is in a duel right now.");
        this.reg("party.target-no-party", "&c{player} is not in a party.");
        this.reg("party.you-in-duel", "&cYou can't manage parties while dueling!");
        this.reg("party.cant-while-dueling", "&cYou can't join a party while you are in a duel!");
        this.reg("party.menu-close-hint", "&7Click your &dParty &7item or use &f/party &7any time to reopen the menu.");
        this.reg("party.split-need-both", "&cAssign at least one player to &cRED &cand one to &9BLUE&c!");
        this.reg("party.split-busy", "&cThese players are busy (duel/spectate): &e{players}");
        this.reg("party.split-rounds-title", "Party Event");
        this.reg("party.split-kit-hint", "&7Pick the kit for your party event.");
        this.reg("party.split-announced", "&6Party event: &c{red} &7vs &9{blue} &7- &f{kit} &7- Best of {rounds}");
        this.reg("party.split-assigned", "&7{player} &8\u00bb {team}");
        this.reg("party.split-bench-full", "&cToo many party members for the bench - unassigned players are hidden.");
        this.reg("spectate.started", "&5You are now spectating &e{player1} &7vs &e{player2}&7. &5(You can fly!)");
        this.reg("spectate.ended", "&5You are no longer spectating.");
        this.reg("spectate.no-duels", "&7There are no ongoing duels right now.");
        this.reg("spectate.return", "&7Click the &5Return &7item or use this item again to go back.");
        this.reg("spectate.loser-started", "&cYou lost the duel! You are now spectating. Click the &5Return &7item, the button below or use &f/leave &7to go back to the lobby.");
        this.reg("spectate.loser-return-button", " [RETURN TO LOBBY] ");
        this.reg("spectate.loser-return-hover", "&aClick to return to the lobby");
        this.reg("stats.header", "&8&m----------&r &e{player} &8&m----------");
        this.reg("stats.line", "&7{kit}: &f{wins}W&7/&f{losses}L &8- &f{elo} ELO");
        this.reg("leaderboard.header", "&8&m--------&r &eTop {type} &8[&f{kit}&8] &8&m--------");
        this.reg("leaderboard.entry", "&e#{position} &f{player} &8- &f{value}");
        this.reg("leaderboard.empty", "&7No entries yet. Be the first!");
        this.reg("arena.created", "&aArena &e{arena} &acreated! Set its spawns in the arena editor.");
        this.reg("arena.deleted", "&cArena &e{arena} &cdeleted.");
        this.reg("arena.spawn-set", "&a{arena}: &f{spawn} &aset to your current location.");
        this.reg("arena.enabled", "&aArena &e{arena} &aenabled.");
        this.reg("arena.disabled", "&cArena &e{arena} &cdisabled.");
        this.reg("arena.valid", "&aArena &e{arena} &ais valid and ready for duels!");
        this.reg("arena.invalid", "&cArena &e{arena} &cis not ready: {reason}");
        this.reg("arena.teleported", "&7Teleported to arena &f{arena}&7.");
        this.reg("arena.renamed", "&aArena renamed to &f{name}&a.");
        this.reg("arena.none", "&cNo arenas exist yet.");
        this.reg("arena.in-use", "&cThat arena is currently in use.");
        this.reg("arena.none-for-kit", "&cNo free arena hosts the &e{kit} &cgamemode yet. Ask an admin to assign one (/arena assign).");
        this.reg("arena.assigned", "&aArena &e{arena} &anow hosts the {kit} &agamemode.");
        this.reg("arena.assigned-any", "&aArena &e{arena} &anow hosts &fall gamemodes&a.");
        this.reg("arena.unassigned", "&cArena &e{arena} &cno longer hosts the {kit} &cgamemode.");
        this.reg("rounds.invalid-number", "&cThat is not a valid number of rounds.");
        this.reg("rounds.too-many", "&cThe maximum number of rounds on this server is &e{max}&c.");
        this.reg("build.no-player", "&cOnly players can toggle their build mode.");
        this.reg("build.status", "&6Build mode&7: {break} &7blocks, {place} &7blocks. &7Global protection: {protection}&7. Use &f/pvpadmin build on/off&7, &f... break on&7, &f... place on&7.");
        this.reg("build.on", "&aBuild mode enabled: you can now break and place blocks.");
        this.reg("build.off", "&cBuild mode disabled: block protection applies to you again.");
        this.reg("build.break-on", "&aYou can now break blocks.");
        this.reg("build.break-off", "&cYou can no longer break blocks.");
        this.reg("build.place-on", "&aYou can now place blocks.");
        this.reg("build.place-off", "&cYou can no longer place blocks.");
        this.reg("build.protection-on", "&aWorld interaction protection enabled for everyone.");
        this.reg("build.protection-off", "&cWorld interaction protection disabled for everyone.");
        this.reg("admin.gui-opened", "&7Admin panel opened.");
        this.reg("admin.lobby-set", "&aLobby spawn set to your current location.");
        this.reg("admin.audit-recorded", "&7Logged: {entry}");
        this.reg("input.enter-name", "&7Type a name in the text field, then click &aConfirm&7.");
        this.reg("input.invalid-name", "&cInvalid name. Try again.");
        this.reg("zone.npc-unavailable", "&cThis NPC is not linked to an active zone.");
        // 3.0.8: live player count hologram under zone NPC names. Blank hides it.
        this.reg("zone.npc-count", "&e{count} &7playing");
        this.reg("zone.join-in-duel", "&cYou can't join a zone while in a duel.");
        this.reg("zone.world-missing", "&cThe world of zone &e{zone} &cis not available.");
        this.reg("zone.joined", "&aYou entered &e{zone}&a!");
        this.reg("zone.leave-hint", "&7Die and you respawn here. Type &f/leave &7to exit the fight zone.");
        this.reg("zone.login-lobby", "&7You reconnected after disconnecting from a fight - you've been returned to the lobby.");
        this.reg("zone.left", "&7You left the fight zone and returned to the lobby.");
        this.reg("zone.kit-given", "&aKit &e{kit} &aapplied!");
        this.reg("zone.kit-pick-hint", "&7Pick a kit to fight with:");
        this.reg("zone.layout-hint", "&7Right-Click a kit to edit your &eFFA layout&7; Left-Click to use it.");
        this.reg("zone.kit-fixed", "&7This zone uses the fixed kit &e{kit}&7.");
        this.reg("zone.not-in-zone", "&cYou are not inside a fight zone.");
        this.reg("zone.no-kits", "&cThis zone has no kits configured yet. Ask an admin.");
        this.reg("zone.kill-message", "&c{player} &7was slain by &a{killer} &8[{zone}&8]");
        this.reg("zone.death-message", "&c{player} &7died &8[{zone}&8]");
        this.reg("zone.created", "&aZone &e{zone} &acreated. Set its spawn with &f/pvpzone setspawn&7.");
        this.reg("zone.deleted", "&cZone &e{zone} &cdeleted.");
        this.reg("zone.not-found", "&cZone &e{zone} &cwas not found.");
        this.reg("zone.already-exists", "&cA zone with id &e{zone} &calready exists.");
        this.reg("zone.spawn-set", "&aZone &e{zone} &aspawn set to your position.");
        this.reg("zone.name-set", "&aZone display name updated.");
        this.reg("zone.mode-set", "&aZone mode set to &e{mode}&a.");
        this.reg("zone.kit-set", "&aZone kit set to &e{kit}&a. Everyone who joins now receives it automatically.");
        this.reg("zone.kits-list", "&7Zone &e{zone} &7kits: &f{kits}");
        this.reg("zone.kit-added", "&aKit &e{kit} &aadded to zone &e{zone}&a.");
        this.reg("zone.kit-removed", "&cKit &e{kit} &cremoved from zone &e{zone}&c.");
        this.reg("zone.kit-already", "&cKit &e{kit} &cis already in the zone.");
        this.reg("zone.kit-not-in-zone", "&cKit &e{kit} &cis not in this zone.");
        this.reg("zone.sb-title-set", "&aZone scoreboard title updated.");
        this.reg("zone.sb-line-set", "&aLine &e#{index} &aset to: &r{line}");
        this.reg("zone.sb-line-removed", "&cLine &e#{index} &cremoved.");
        this.reg("zone.sb-line-added", "&aLine added: &r{line}");
        this.reg("zone.sb-lines-cleared", "&cAll scoreboard lines cleared.");
        this.reg("zone.sb-reset", "&aScoreboard reset to the default layout.");
        this.reg("zone.list-header", "&6Fight zones:");
        this.reg("zone.list-entry", "&8 - &e{zone} &7({online} playing) &8- {state}");
        this.reg("zone.deleted-members", "&7Players inside were sent back to the lobby.");
        this.reg("npc.created", "&aNPC &r{name} &aspawned and linked to zone &e{zone}&a.");
        this.reg("npc.removed", "&cNPC &r{name} &cremoved.");
        this.reg("npc.not-found", "&cNo NPC with id/name &e{id} &cwas found.");
        this.reg("npc.list-header", "&6Zone NPCs:");
        this.reg("npc.list-entry", "&8 - &r{name} &8-> &e{zone}");
        this.reg("npc.hint", "&7Right-click the NPC to enter its zone.");
    }
}

