/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 */
package com.pvpcore.config;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.pvpcore.PvPCoreMod;
import com.pvpcore.config.ConfigFile;
import java.nio.file.Path;
import java.util.List;

public final class MainConfig {
    private transient Path file;
    private JsonObject root;
    public int configVersion = 5;
    public General general = new General();
    public Lobby lobby = new Lobby();
    public Duel duel = new Duel();
    public Elo elo = new Elo();
    public QueueSection queue = new QueueSection();
    public PartySection party = new PartySection();
    public Chat chat = new Chat();
    public ScoreboardSection scoreboard = new ScoreboardSection();
    public LobbyScoreboardSection lobbyScoreboard = new LobbyScoreboardSection();
    public KitSection kit = new KitSection();
    public SpectateSection spectate = new SpectateSection();
    public ZoneSection zone = new ZoneSection();
    public StorageSection storage = new StorageSection();

    public void load(Path configDir) {
        this.file = configDir.resolve("settings.json");
        JsonObject defaults = ConfigFile.GSON.toJsonTree((Object)this).getAsJsonObject();
        JsonObject user = ConfigFile.load(this.file);
        JsonArray defaultScoreboardLines = null;
        try {
            defaultScoreboardLines = defaults.getAsJsonObject("scoreboard").getAsJsonArray("lines").deepCopy();
        }
        catch (Exception exception) {
            // empty catch block
        }
        this.root = ConfigFile.deepMerge(defaults, user);
        MainConfig.migrateV2(this.root, defaultScoreboardLines, user);
        MainConfig loaded = (MainConfig)ConfigFile.GSON.fromJson((JsonElement)this.root, MainConfig.class);
        this.general = loaded.general;
        this.lobby = loaded.lobby;
        this.duel = loaded.duel;
        this.elo = loaded.elo;
        this.queue = loaded.queue;
        this.party = loaded.party;
        this.chat = loaded.chat;
        this.scoreboard = loaded.scoreboard;
        this.lobbyScoreboard = loaded.lobbyScoreboard;
        this.kit = loaded.kit;
        this.spectate = loaded.spectate;
        this.zone = loaded.zone;
        this.storage = loaded.storage;
        ConfigFile.save(this.file, this.root);
        PvPCoreMod.LOGGER.info("Loaded settings.json");
    }

    public void save() {
        if (this.file != null) {
            this.root = ConfigFile.GSON.toJsonTree((Object)this).getAsJsonObject();
            ConfigFile.save(this.file, this.root);
        }
    }

    private static void migrateV2(JsonObject root, JsonArray defaultLines, JsonObject user) {
        try {
            boolean legacy = true;
            try {
                if (user != null && user.has("configVersion") && user.get("configVersion").isJsonPrimitive()) {
                    legacy = user.get("configVersion").getAsInt() < 2;
                }
            }
            catch (Exception exception) {
                // empty catch block
            }
            if (legacy) {
                JsonObject sb;
                JsonObject duel = root.getAsJsonObject("duel");
                if (duel != null) {
                    duel.addProperty("dropItemsOnDeath", Boolean.valueOf(false));
                }
                if (defaultLines != null && (sb = root.getAsJsonObject("scoreboard")) != null) {
                    try {
                        boolean oldFormat = false;
                        if (sb.has("lines") && sb.get("lines").isJsonArray()) {
                            for (JsonElement el : sb.getAsJsonArray("lines")) {
                                String line;
                                if (!el.isJsonPrimitive() || !((line = el.getAsString()).contains("{player1}") && line.contains("{player2}") || line.contains("{ping1}") && !line.contains("{player1}") || line.contains("{kit}")) && !line.contains("{arena}")) continue;
                                oldFormat = true;
                                break;
                            }
                        }
                        if (oldFormat) {
                            sb.add("lines", (JsonElement)defaultLines.deepCopy());
                            PvPCoreMod.LOGGER.info("Migrated scoreboard.lines to the 2.5.0 format (per-player lines with ping)");
                        }
                    }
                    catch (Exception oldFormat) {
                        // empty catch block
                    }
                }
                root.addProperty("configVersion", (Number)2);
                PvPCoreMod.LOGGER.info("Migrated settings.json to 2.5.0 (no duel drops, per-player scoreboard lines)");
            }
            boolean legacyRounds = true;
            try {
                if (user != null && user.has("configVersion") && user.get("configVersion").isJsonPrimitive()) {
                    legacyRounds = user.get("configVersion").getAsInt() < 3;
                }
            }
            catch (Exception sb) {
                // empty catch block
            }
            if (legacyRounds) {
                JsonObject duelx = root.getAsJsonObject("duel");
                if (duelx != null) {
                    try {
                        int oldMax;
                        int oldDefault = duelx.has("defaultBestOf") && duelx.get("defaultBestOf").isJsonPrimitive() ? duelx.get("defaultBestOf").getAsInt() : -1;
                        int n = oldMax = duelx.has("maxBestOf") && duelx.get("maxBestOf").isJsonPrimitive() ? duelx.get("maxBestOf").getAsInt() : -1;
                        if (oldDefault > 0 && !duelx.has("defaultRounds")) {
                            duelx.addProperty("defaultRounds", (Number)oldDefault);
                        }
                        if (oldMax > 0 && !duelx.has("maxRounds")) {
                            duelx.addProperty("maxRounds", (Number)Math.max(oldMax, 10));
                        }
                    }
                    catch (Exception exception) {
                        // empty catch block
                    }
                    duelx.remove("defaultBestOf");
                    duelx.remove("maxBestOf");
                }
                root.addProperty("configVersion", (Number)3);
                PvPCoreMod.LOGGER.info("Migrated settings.json to 2.7.0 (best-of settings became rounds settings)");
            }
            boolean legacyEditorBase = true;
            try {
                if (user != null && user.has("configVersion") && user.get("configVersion").isJsonPrimitive()) {
                    legacyEditorBase = user.get("configVersion").getAsInt() < 4;
                }
            }
            catch (Exception exception) {
                // empty catch block
            }
            if (legacyEditorBase) {
                root.addProperty("configVersion", (Number)4);
                PvPCoreMod.LOGGER.info("Migrated settings.json to 2.8.0 (damage multiplier, team scoreboard lines, editor base)");
            }
            boolean legacyUptime = true;
            try {
                if (user != null && user.has("configVersion") && user.get("configVersion").isJsonPrimitive()) {
                    legacyUptime = user.get("configVersion").getAsInt() < 5;
                }
            }
            catch (Exception exception) {
                // empty catch block
            }
            if (legacyUptime) {
                // 3.0.8: every scoreboard gains an "&7Uptime: &f{uptime}" line.
                MainConfig.insertUptimeLine(root, "lobbyScoreboard", "lines");
                MainConfig.insertUptimeLine(root, "scoreboard", "lines");
                MainConfig.insertUptimeLine(root, "scoreboard", "teamLines");
                root.addProperty("configVersion", (Number)5);
                PvPCoreMod.LOGGER.info("Migrated settings.json to 3.0.8 (uptime line on lobby and duel scoreboards)");
            }
        }
        catch (Exception var15) {
            PvPCoreMod.LOGGER.warn("Could not run the settings migration: {}", (Object)var15.getMessage());
        }
    }

    /**
     * 3.0.8: one-time helper for the configVersion 5 migration - inserts the
     * uptime line into an existing scoreboard line list (below a {ping} line,
     * otherwise before the closing separator, otherwise at the end). Skips
     * lists that already contain {uptime} so admins keep full control.
     */
    private static void insertUptimeLine(JsonObject root, String section, String linesKey) {
        try {
            JsonObject sec = root.getAsJsonObject(section);
            if (sec == null || !sec.has(linesKey) || !sec.get(linesKey).isJsonArray()) {
                return;
            }
            JsonArray lines = sec.getAsJsonArray(linesKey);
            for (JsonElement el : lines) {
                if (el.isJsonPrimitive() && el.getAsString().contains("{uptime}")) {
                    return;
                }
            }
            int insertAt = -1;
            for (int i = 0; i < lines.size(); ++i) {
                JsonElement el = lines.get(i);
                if (!el.isJsonPrimitive() || !el.getAsString().contains("{ping")) continue;
                insertAt = i + 1;
                break;
            }
            if (insertAt < 0) {
                for (int i = lines.size() - 1; i >= 0; --i) {
                    JsonElement el = lines.get(i);
                    if (!el.isJsonPrimitive() || !el.getAsString().contains("&m")) continue;
                    insertAt = i;
                    break;
                }
            }
            if (insertAt < 0) {
                insertAt = lines.size();
            }
            // Rebuild the array (JsonArray has no positional add).
            JsonArray out = new JsonArray(lines.size() + 1);
            for (int i = 0; i < lines.size(); ++i) {
                if (i == insertAt) {
                    out.add(new JsonPrimitive("&7Uptime: &f{uptime}"));
                }
                out.add(lines.get(i));
            }
            if (insertAt >= lines.size()) {
                out.add(new JsonPrimitive("&7Uptime: &f{uptime}"));
            }
            sec.add(linesKey, (JsonElement)out);
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public static class General {
        public String prefix = "&8[&6PvP&8] &r";
        public boolean debug = false;
    }

    public static class Lobby {
        public boolean giveItems = true;
        public String gameMode = "adventure";
        public boolean lockInventory = true;
        public boolean adminBypassLock = false;
        public boolean blockItemUse = true;
        public boolean blockWorldInteraction = true;
        public boolean lockSpectators = true;
        public boolean clearInventoryAfterDuel = true;
        public boolean teleportAfterDuel = true;
        public String loginSyncMode = "SMART";
        public int loginTimeoutTicks = 200;
        public boolean invulnerable = true;
        public boolean teleportOnJoin = false;
        public String lobbyWorld = "minecraft:overworld";
        public double lobbyX = 0.0;
        public double lobbyY = 64.0;
        public double lobbyZ = 0.0;
        public float lobbyYaw = 0.0f;
        public float lobbyPitch = 0.0f;
    }

    public static class Duel {
        public int countdownSeconds = 3;
        public int endDurationSeconds = 3;
        public int timeoutMinutes = 15;
        public int disconnectGraceSeconds = 10;
        public boolean disableHunger = true;
        public boolean healOnStart = true;
        public boolean healAfterDuel = true;
        public boolean showEndTitles = true;
        public boolean challengeViaChat = true;
        public float damageMultiplier = 1.0f;
        public boolean scaleEnvironmentalDamage = true;
        public int defaultRounds = 1;
        public int maxRounds = 10;
        public boolean playAllRounds = true;
        public transient int defaultBestOf = -1;
        public transient int maxBestOf = -1;
        public int roundIntermissionSeconds = 5;
        public boolean loserSpectates = false;
        public boolean eliminatedSpectates = true;
        public boolean showHeartsBelowName = true;
        public String heartFormat = "&c\u2764 &f{health}";
        public boolean forceSurvival = true;
        public boolean teamColors = true;
        public String teamAColor = "RED";
        public String teamBColor = "BLUE";
        public boolean dropItemsOnDeath = false;
        public int dropsDespawnSeconds = 15;
        public boolean arenaReset = true;
        public int arenaResetRadius = 24;
        public boolean countdownSounds = true;
        public boolean freezeDuringCountdown = true;
        public boolean broadcastStarts = false;
        public boolean broadcastEnds = false;
    }

    public static class Elo {
        public int startRating = 1000;
        public int kFactor = 32;
        public int range0to10s = 50;
        public int range10to20s = 100;
        public int range20to30s = 150;
        public int range30plus = 250;
    }

    public static class QueueSection {
        public int matchmakingIntervalTicks = 10;
        public int statusIntervalTicks = 200;
        public int crossKitMatchAfterSeconds = 10;
    }

    public static class PartySection {
        public int maxSize = 8;
        public int inviteExpirySeconds = 60;
        public boolean membersCanInvite = true;
        public boolean autoCreateOnItemClick = true;
        public boolean partyColors = true;
        public boolean disbandOnLeaderQuit = true;
    }

    public static class Chat {
        public boolean manageChat = true;
        public boolean isolateDuels = true;
        public boolean hideGlobalFromDuelists = true;
        public boolean duelChatIncludesSpectators = true;
        // 3.0.8: FFA zone chat is fully separated from the rest of the server.
        public boolean isolateZones = true;
        public boolean hideGlobalFromZoneMembers = true;
        public String zoneFormat = "&8[&cFFA&8] &7{player}&8: &f{message}";
        public String globalFormat = "&7{player}&8: &f{message}";
        public String duelFormat = "&8[&6Duel&8] &7{player}&8: &f{message}";
        public String partyFormat = "&8[&5Party&8] &d{player}&8: &f{message}";
        public String specFormat = "&8[&5Spec&8] &7{player}&8: &f{message}";
    }

    public static class ScoreboardSection {
        public boolean enabled = true;
        public String title = "&6&lDUEL";
        public List<String> lines = List.of("&8&m----------------", "{player1} &f{score1} &8- &a{ping1}ms", "{player2} &f{score2} &8- &a{ping2}ms", "&7Round &f{round}&7/&f{rounds} &8| &7{duration}", "", "&7Hits: &f{hits1} &8/ &f{hits2}", "&7Uptime: &f{uptime}");
        public List<String> teamLines = List.of("&8&m----------------", "&c{player1} &7vs &9{player2}", "&7Round &f{round}&7/&f{rounds} &8| &c{score1} &8- &9{score2} &8| &7{duration}", "&8&m----------------", "{teamAList}", "{teamBList}", "&7Uptime: &f{uptime}");
        public String teamLineA = "&c{player} &8- &c{hp}\u2764 &8(&a{ping}ms&8)";
        public String teamLineB = "&9{player} &8- &c{hp}\u2764 &8(&a{ping}ms&8)";
        public int updateIntervalTicks = 20;
    }

    public static class LobbyScoreboardSection {
        public boolean enabled = true;
        public String title = "&6&lPvP CORE";
        public String serverIp = "&eplay.example.com";
        public int updateIntervalTicks = 20;
        public List<String> lines = List.of("&8&m------------------", "&7Player: &f{player}", "&7Rank: &f#{rank} &8(&f{elo}&8)", "&7Wins: &a{wins} &7Losses: &c{losses}", "&7Streak: &f{streak}", "", "&7Online: &f{online}&7/&f{max}", "&7Ping: &f{ping}ms", "&7Uptime: &f{uptime}", "", "{ip}", "&8&m------------------");
    }

    public static class KitSection {
        public boolean editorBaseOnOriginal = false;
    }

    public static class SpectateSection {
        public boolean enabled = true;
        public boolean hideFromFighters = true;
    }

    public static class ZoneSection {
        public boolean blockWorldInteraction = true;
        public boolean showHeartsBelowName = true;
        public String heartFormat = "&c\u2764 &f{health}";
        public String nameTagColor = "&e";
    }

    public static class StorageSection {
        public int saveIntervalSeconds = 60;
    }
}

