package com.pvpcore.util;

import com.pvpcore.PvPCore;
import java.util.ArrayDeque;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.network.packet.c2s.common.CommonPongC2SPacket;
import net.minecraft.network.packet.s2c.common.CommonPingS2CPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerCommonNetworkHandler;
import net.minecraft.server.network.ServerPlayerEntity;

/**
 * 3.0.8: live server statistics for every scoreboard (lobby, duel, FFA zone).
 *
 * PING: vanilla only refreshes the latency shown by ServerCommonNetworkHandler
 * every ~15 seconds (keepalive round-trip) and additionally smooths it with a
 * heavy (x3+i)/4 moving average, so scoreboard ping values were stale for a
 * minute or more. PvPCore instead sends the unused vanilla CommonPingS2CPacket
 * once per second; vanilla clients reply with CommonPongC2SPacket echoing the
 * same id (vanilla's server-side onPong is an empty no-op, which is why the
 * ServerCommonNetworkHandlerMixin can safely observe it). The result is a real
 * round-trip measurement with 1-second resolution, averaged over the last five
 * samples. Until the first samples arrive (the first second after join) the
 * vanilla keepalive value is used as the initial estimate.
 *
 * UPTIME / TPS: derived from the server tick counter and the average tick time.
 */
public final class ServerStats {
    private static final int WINDOW = 5;
    private static final long OUTSTANDING_TIMEOUT_MS = 5000L;
    private static final long SAMPLE_EXPIRY_MS = 10000L;

    private static final class PingState {
        int lastId;
        long sentAt;
        boolean outstanding;
        final ArrayDeque<Integer> samples = new ArrayDeque<Integer>();
        long lastSampleAt;
    }

    private static final Map<UUID, PingState> PINGS = new ConcurrentHashMap<UUID, PingState>();

    private ServerStats() {
    }

    /**
     * Called once per server tick from PvPCore.tick(): sends a ping to every
     * online player (once per second, one outstanding ping at a time).
     */
    public static void tick(MinecraftServer server) {
        if (server == null || PvPCore.get() == null) {
            return;
        }
        if (server.getTicks() % 20 != 0) {
            return;
        }
        long now = System.currentTimeMillis();
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            if (p == null || p.networkHandler == null || p.isDisconnected()) continue;
            try {
                // Never ping the fake join-NPCs (their connection is a no-op stub).
                if (PvPCore.get().zoneManager() != null && PvPCore.get().zoneManager().isNpc(p)) continue;
            }
            catch (Throwable ignored) {
                // empty catch block
            }
            PingState st = PINGS.computeIfAbsent(p.getUuid(), u -> new PingState());
            if (st.outstanding && now - st.sentAt > OUTSTANDING_TIMEOUT_MS) {
                st.outstanding = false;
            }
            if (st.outstanding) continue;
            st.lastId = st.lastId + 1 & 0x7FFFFFFF;
            st.sentAt = now;
            st.outstanding = true;
            try {
                p.networkHandler.sendPacket(new CommonPingS2CPacket(st.lastId));
            }
            catch (Throwable t) {
                st.outstanding = false;
            }
        }
        // Drop state of players that went offline.
        PINGS.keySet().removeIf(u -> server.getPlayerManager().getPlayer(u) == null);
    }

    /**
     * Called from ServerCommonNetworkHandlerMixin when a client answers our
     * ping. Matches the pong to the sending player and records the round-trip
     * time as a new sample.
     */
    public static void handlePong(ServerCommonNetworkHandler handler, CommonPongC2SPacket packet) {
        try {
            PvPCore core = PvPCore.get();
            if (handler == null || packet == null || core == null || core.server() == null) {
                return;
            }
            for (ServerPlayerEntity p : core.server().getPlayerManager().getPlayerList()) {
                if (p == null || p.networkHandler != handler) continue;
                PingState st = PINGS.get(p.getUuid());
                if (st == null || !st.outstanding || packet.getParameter() != st.lastId) {
                    return;
                }
                st.outstanding = false;
                long rtt = System.currentTimeMillis() - st.sentAt;
                st.samples.addLast((int)Math.max(0L, Math.min(30000L, rtt)));
                st.lastSampleAt = System.currentTimeMillis();
                while (st.samples.size() > WINDOW) {
                    st.samples.pollFirst();
                }
                return;
            }
        }
        catch (Throwable ignored) {
            // empty catch block
        }
    }

    /**
     * The player's live ping in ms, averaged over the last five one-second
     * samples. Falls back to the vanilla keepalive estimate when no fresh
     * samples exist yet (first seconds after joining).
     */
    public static int ping(ServerPlayerEntity player) {
        if (player == null) {
            return 0;
        }
        try {
            PingState st = PINGS.get(player.getUuid());
            if (st != null && !st.samples.isEmpty() && System.currentTimeMillis() - st.lastSampleAt < SAMPLE_EXPIRY_MS) {
                int sum = 0;
                for (int s : st.samples) {
                    sum += s;
                }
                return Math.max(0, (sum + st.samples.size() / 2) / st.samples.size());
            }
            return Math.max(0, player.networkHandler.getLatency());
        }
        catch (Throwable t) {
            return 0;
        }
    }

    /** Server uptime for the {uptime} placeholder, e.g. "41m" / "2h 05m" / "3d 7h". */
    public static String uptime(MinecraftServer server) {
        if (server == null) {
            return "-";
        }
        return ServerStats.formatUptime(server.getTicks() / 20L);
    }

    public static String formatUptime(long seconds) {
        seconds = Math.max(0L, seconds);
        if (seconds < 60L) {
            return seconds + "s";
        }
        long m = seconds / 60L;
        if (m < 60L) {
            return m + "m";
        }
        long h = m / 60L;
        m %= 60L;
        if (h < 24L) {
            return h + "h " + String.format(Locale.ROOT, "%02dm", m);
        }
        long d = h / 24L;
        return d + "d " + h % 24L + "h";
    }

    /** Server ticks-per-second for the {tps} placeholder, e.g. "20.0" / "18.7". */
    public static String tps(MinecraftServer server) {
        try {
            float avg = server == null ? 0.0f : server.getAverageTickTime();
            if (avg <= 0.0f) {
                return "20.0";
            }
            return String.format(Locale.ROOT, "%.1f", Float.valueOf(Math.min(20.0f, 1000.0f / avg)));
        }
        catch (Throwable t) {
            return "20.0";
        }
    }
}
