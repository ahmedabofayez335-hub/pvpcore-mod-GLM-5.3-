/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.text.Text
 *  net.minecraft.util.Formatting
 */
package com.pvpcore.util;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public final class TextUtil {
    private static final Pattern HEX_PATTERN = Pattern.compile("&(#([0-9a-fA-F]{6}))");

    private TextUtil() {
    }

    public static String colorize(String s) {
        if (s == null) {
            return "";
        }
        Matcher m = HEX_PATTERN.matcher(s);
        StringBuilder sb = new StringBuilder();
        while (m.find()) {
            String hex = m.group(2);
            StringBuilder rep = new StringBuilder("\u00a7x");
            for (char c : hex.toCharArray()) {
                rep.append('\u00a7').append(Character.toLowerCase(c));
            }
            m.appendReplacement(sb, Matcher.quoteReplacement(rep.toString()));
        }
        m.appendTail(sb);
        return sb.toString().replace('&', '\u00a7');
    }

    public static String placeholders(String s, Map<String, String> vars) {
        if (s == null) {
            return "";
        }
        if (vars != null) {
            for (Map.Entry<String, String> e : vars.entrySet()) {
                s = s.replace("{" + e.getKey() + "}", e.getValue() == null ? "" : e.getValue());
            }
        }
        return s;
    }

    public static String colorAndPlace(String s, Map<String, String> vars) {
        return TextUtil.colorize(TextUtil.placeholders(s, vars));
    }

    public static Text text(String s) {
        return Text.literal((String)TextUtil.colorize(s));
    }

    public static Text text(String s, Map<String, String> vars) {
        return Text.literal((String)TextUtil.colorAndPlace(s, vars));
    }

    public static String formatDurationTicks(long ticks) {
        long totalSeconds = Math.max(0L, ticks / 20L);
        return String.format("%02d:%02d", totalSeconds / 60L, totalSeconds % 60L);
    }

    public static String formatSeconds(long seconds) {
        seconds = Math.max(0L, seconds);
        return String.format("%02d:%02d", seconds / 60L, seconds % 60L);
    }

    public static String stripColor(String s) {
        return s == null ? "" : s.replaceAll("\u00a7[0-9a-fk-orx]", "").replaceAll("\u00a7x(\u00a7[0-9a-f]){6}", "");
    }

    public static String sbLine(String s) {
        String colored = TextUtil.colorize(s);
        StringBuilder out = new StringBuilder();
        int visible = 0;
        for (int i = 0; i < colored.length(); ++i) {
            char c = colored.charAt(i);
            if (c == '\u00a7') {
                out.append(c);
                if (i + 1 >= colored.length()) continue;
                out.append(colored.charAt(++i));
                continue;
            }
            if (visible >= 38) break;
            out.append(c);
            ++visible;
        }
        return out.toString();
    }

    public static Formatting parseFormatting(String name, Formatting def) {
        try {
            return Formatting.valueOf((String)name.toUpperCase());
        }
        catch (IllegalArgumentException var3) {
            return def;
        }
    }

    public static Formatting lastColorCode(String s) {
        if (s == null) {
            return null;
        }
        Formatting found = null;
        for (int i = 0; i < s.length() - 1; ++i) {
            Formatting f;
            char c = s.charAt(i);
            if (c != '&' && c != '\u00a7' || (f = TextUtil.colorCodeToFormatting(s.charAt(i + 1))) == null) continue;
            found = f;
        }
        return found;
    }

    private static Formatting colorCodeToFormatting(char code) {
        switch (Character.toLowerCase(code)) {
            case '0': {
                return Formatting.BLACK;
            }
            case '1': {
                return Formatting.DARK_BLUE;
            }
            case '2': {
                return Formatting.DARK_GREEN;
            }
            case '3': {
                return Formatting.DARK_AQUA;
            }
            case '4': {
                return Formatting.DARK_RED;
            }
            case '5': {
                return Formatting.DARK_PURPLE;
            }
            case '6': {
                return Formatting.GOLD;
            }
            case '7': {
                return Formatting.GRAY;
            }
            case '8': {
                return Formatting.DARK_GRAY;
            }
            case '9': {
                return Formatting.BLUE;
            }
            case 'a': {
                return Formatting.GREEN;
            }
            case 'b': {
                return Formatting.AQUA;
            }
            case 'c': {
                return Formatting.RED;
            }
            case 'd': {
                return Formatting.LIGHT_PURPLE;
            }
            case 'e': {
                return Formatting.YELLOW;
            }
            case 'f': {
                return Formatting.WHITE;
            }
        }
        return null;
    }
}

