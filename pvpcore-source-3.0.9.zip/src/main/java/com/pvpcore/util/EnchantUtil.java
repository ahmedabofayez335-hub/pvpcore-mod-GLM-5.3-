/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.enchantment.Enchantment
 *  net.minecraft.registry.Registry
 *  net.minecraft.registry.RegistryKeys
 *  net.minecraft.registry.entry.RegistryEntry
 *  net.minecraft.util.Identifier
 */
package com.pvpcore.util;

import com.pvpcore.PvPCore;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Identifier;

public final class EnchantUtil {
    private EnchantUtil() {
    }

    public static Registry<Enchantment> registry() {
        return PvPCore.get().server().getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT);
    }

    public static RegistryEntry<Enchantment> byId(String id) {
        if (id != null && !id.isBlank()) {
            Identifier identifier;
            Object s = id.trim().toLowerCase();
            if (!((String)s).contains(":")) {
                s = "minecraft:" + (String)s;
            }
            return (identifier = Identifier.tryParse((String)s)) == null ? null : (RegistryEntry)EnchantUtil.registry().getEntry(identifier).orElse(null);
        }
        return null;
    }

    public static List<RegistryEntry<Enchantment>> all() {
        ArrayList<RegistryEntry<Enchantment>> out = new ArrayList<RegistryEntry<Enchantment>>();
        for (Map.Entry e : EnchantUtil.registry().getEntrySet()) {
            RegistryEntry entry = EnchantUtil.registry().getEntry((Enchantment)e.getValue());
            if (entry == null) continue;
            out.add((RegistryEntry<Enchantment>)entry);
        }
        return out;
    }
}

