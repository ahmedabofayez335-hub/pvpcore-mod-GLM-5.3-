/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.text.ClickEvent
 *  net.minecraft.text.ClickEvent$RunCommand
 *  net.minecraft.text.HoverEvent
 *  net.minecraft.text.HoverEvent$ShowText
 *  net.minecraft.text.MutableText
 *  net.minecraft.text.Text
 *  net.minecraft.util.Formatting
 */
package com.pvpcore.util;

import com.pvpcore.util.TextUtil;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.HoverEvent;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public final class ChatButtons {
    private ChatButtons() {
    }

    public static MutableText button(String label, String command, String hover, Formatting color) {
        return Text.literal((String)label).styled(s -> s.withColor(color).withBold(Boolean.valueOf(true)).withClickEvent((ClickEvent)new ClickEvent.RunCommand(command)).withHoverEvent((HoverEvent)new HoverEvent.ShowText(TextUtil.text(hover))));
    }

    public static MutableText line(Text ... parts) {
        MutableText out = Text.literal((String)"");
        for (Text p : parts) {
            out.append(p);
        }
        return out;
    }
}

