/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.registry.RegistryKey
 *  net.minecraft.registry.RegistryKeys
 *  net.minecraft.server.MinecraftServer
 *  net.minecraft.server.network.ServerPlayerEntity
 *  net.minecraft.server.world.ServerWorld
 *  net.minecraft.util.Identifier
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.world.TeleportTarget
 */
package com.pvpcore.util;

import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.TeleportTarget;

public final class TeleportUtil {
    private TeleportUtil() {
    }

    public static void teleport(ServerPlayerEntity player, ServerWorld world, double x, double y, double z, float yaw, float pitch) {
        if (player.getEntityWorld() == world) {
            player.networkHandler.requestTeleport(x, y, z, yaw, pitch);
        } else {
            player.teleportTo(new TeleportTarget(world, new Vec3d(x, y, z), Vec3d.ZERO, yaw, pitch, entity -> {}));
        }
    }

    public static ServerWorld world(MinecraftServer server, String key) {
        try {
            String[] stringArray;
            if (key.contains(":")) {
                stringArray = key.split(":", 2);
            } else {
                String[] stringArray2 = new String[]{"minecraft", null};
                stringArray = stringArray2;
                stringArray2[1] = key;
            }
            RegistryKey worldKey = RegistryKey.of((RegistryKey)RegistryKeys.WORLD, (Identifier)Identifier.of((String)stringArray[0], (String)stringArray[1]));
            return server.getWorld(worldKey);
        }
        catch (Exception var5) {
            return null;
        }
    }

    public static boolean isValidPos(ServerWorld world, double x, double y, double z) {
        return y >= (double)world.getBottomY() && y <= (double)(world.getBottomY() + world.getHeight());
    }
}

