/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.DataResult
 *  com.mojang.serialization.DynamicOps
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemConvertible
 *  net.minecraft.item.ItemStack
 *  net.minecraft.nbt.NbtCompound
 *  net.minecraft.nbt.NbtElement
 *  net.minecraft.nbt.NbtOps
 *  net.minecraft.nbt.StringNbtReader
 *  net.minecraft.registry.DynamicRegistryManager$Immutable
 *  net.minecraft.registry.Registries
 *  net.minecraft.server.MinecraftServer
 *  net.minecraft.util.Identifier
 */
package com.pvpcore.util;

import com.mojang.serialization.DataResult;
import com.mojang.serialization.DynamicOps;
import com.pvpcore.PvPCore;
import com.pvpcore.PvPCoreMod;
import java.util.Optional;
import net.minecraft.item.Item;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.StringNbtReader;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.Identifier;

public final class ItemCodecUtil {
    private ItemCodecUtil() {
    }

    private static DynamicOps<NbtElement> nbtOps() {
        MinecraftServer server;
        PvPCore core = PvPCore.get();
        MinecraftServer minecraftServer = server = core != null ? core.server() : null;
        if (server != null) {
            try {
                DynamicRegistryManager.Immutable registries = server.getRegistryManager();
                return registries.getOps((DynamicOps)NbtOps.INSTANCE);
            }
            catch (Throwable var3) {
                PvPCoreMod.LOGGER.warn("Could not build RegistryOps for item serialization: {}", (Object)var3.getMessage());
            }
        }
        return NbtOps.INSTANCE;
    }

    public static String toSnbt(ItemStack stack) {
        if (stack != null && !stack.isEmpty()) {
            try {
                DataResult<NbtElement> res = ItemStack.CODEC.encodeStart(ItemCodecUtil.nbtOps(), stack);
                Optional<NbtElement> opt = res.result();
                if (opt.isEmpty()) {
                    String item = stack.getItem().getDefaultStack().toString();
                    String reason = res.error().map(e -> e.message()).orElse("?");
                    PvPCoreMod.LOGGER.warn("Could not serialize item {}: {}", (Object)item, (Object)reason);
                    return "";
                }
                NbtElement el = (NbtElement)opt.get();
                return el.toString();
            }
            catch (Throwable var5) {
                PvPCoreMod.LOGGER.warn("Item serialization threw", var5);
                return "";
            }
        }
        return "";
    }

    public static ItemStack fromSnbt(String s) {
        if (s != null && !s.isBlank()) {
            try {
                NbtCompound compound = StringNbtReader.readCompound((String)s);
                DataResult<ItemStack> res = ItemStack.CODEC.parse(ItemCodecUtil.nbtOps(), compound);
                Optional<ItemStack> opt = res.result();
                if (opt.isEmpty()) {
                    return ItemStack.EMPTY;
                }
                ItemStack st = (ItemStack)opt.get();
                if (st.getCount() <= 0) {
                    st.setCount(1);
                }
                return st;
            }
            catch (Exception var51) {
                return ItemStack.EMPTY;
            }
        }
        return ItemStack.EMPTY;
    }

    public static ItemStack copy(ItemStack st) {
        return st == null ? ItemStack.EMPTY : st.copy();
    }

    public static ItemStack parseMaterial(String name) {
        if (name != null && !name.isBlank()) {
            Identifier id;
            String ns = "minecraft";
            String path = name.trim().toLowerCase();
            if (path.contains(":")) {
                String[] parts = path.split(":", 2);
                ns = parts[0];
                path = parts[1];
            }
            if ((id = Identifier.tryParse((String)(ns + ":" + path))) == null) {
                return ItemStack.EMPTY;
            }
            Item item = (Item)Registries.ITEM.get(id);
            return item == null ? ItemStack.EMPTY : new ItemStack((ItemConvertible)item);
        }
        return ItemStack.EMPTY;
    }
}

