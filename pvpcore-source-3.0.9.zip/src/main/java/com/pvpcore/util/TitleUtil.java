/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.packet.Packet
 *  net.minecraft.network.packet.s2c.play.SubtitleS2CPacket
 *  net.minecraft.network.packet.s2c.play.TitleFadeS2CPacket
 *  net.minecraft.network.packet.s2c.play.TitleS2CPacket
 *  net.minecraft.server.network.ServerPlayerEntity
 *  net.minecraft.text.Text
 */
package com.pvpcore.util;

import com.pvpcore.util.TextUtil;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.SubtitleS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleFadeS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleS2CPacket;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

public final class TitleUtil {
    private TitleUtil() {
    }

    public static void title(ServerPlayerEntity player, String title, String subtitle, int fadeIn, int stay, int fadeOut) {
        Text t = TextUtil.text(title);
        Text s = TextUtil.text(subtitle);
        player.networkHandler.sendPacket((Packet)new TitleFadeS2CPacket(fadeIn, stay, fadeOut));
        player.networkHandler.sendPacket((Packet)new TitleS2CPacket(t));
        if (!subtitle.isEmpty()) {
            player.networkHandler.sendPacket((Packet)new SubtitleS2CPacket(s));
        }
    }

    public static void title(ServerPlayerEntity player, String title, String subtitle) {
        TitleUtil.title(player, title, subtitle, 5, 25, 5);
    }
}

