/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.scoreboard.AbstractTeam$CollisionRule
 *  net.minecraft.scoreboard.Scoreboard
 *  net.minecraft.scoreboard.Team
 *  net.minecraft.server.MinecraftServer
 *  net.minecraft.server.PlayerManager
 *  net.minecraft.server.network.ServerPlayerEntity
 *  net.minecraft.text.Text
 *  net.minecraft.util.Formatting
 */
package com.pvpcore.util;

import com.pvpcore.PvPCore;
import com.pvpcore.duel.Duel;
import com.pvpcore.duel.DuelState;
import com.pvpcore.party.PartyManager;
import com.pvpcore.util.TextUtil;
import java.util.List;
import java.util.UUID;
import net.minecraft.scoreboard.AbstractTeam;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.Team;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.PlayerManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public final class TeamColorManager {
    public static final String TEAM_PREFIX = "pvp";
    private static final List<Formatting> PARTY_PALETTE = List.of(Formatting.AQUA, Formatting.YELLOW, Formatting.GREEN, Formatting.LIGHT_PURPLE, Formatting.GOLD, Formatting.DARK_AQUA, Formatting.DARK_GREEN, Formatting.DARK_PURPLE, Formatting.BLUE, Formatting.RED, Formatting.DARK_BLUE, Formatting.DARK_RED);
    private int partyColorCursor = 0;

    private Scoreboard scoreboard() {
        try {
            MinecraftServer server = PvPCore.get().server();
            return server == null ? null : server.getScoreboard();
        }
        catch (Throwable var21) {
            return null;
        }
    }

    private boolean enabled() {
        return PvPCore.get().config().duel.teamColors;
    }

    private Team ensureTeam(String name, Formatting color) {
        Scoreboard sb = this.scoreboard();
        if (sb == null) {
            return null;
        }
        Team existing = sb.getTeam(name);
        if (existing != null) {
            return existing;
        }
        try {
            Team team = sb.addTeam(name);
            team.setColor(color);
            team.setFriendlyFireAllowed(false);
            team.setShowFriendlyInvisibles(true);
            team.setCollisionRule(AbstractTeam.CollisionRule.ALWAYS);
            return team;
        }
        catch (Throwable var61) {
            return sb.getTeam(name);
        }
    }

    private void addToTeam(String playerName, Team team) {
        Scoreboard sb = this.scoreboard();
        if (sb != null && team != null && playerName != null && !playerName.isBlank()) {
            try {
                Team current = this.teamOf(playerName);
                if (current == team) {
                    return;
                }
                if (current != null && !TeamColorManager.isOurTeam(current)) {
                    return;
                }
                if (current != null) {
                    sb.removeScoreHolderFromTeam(playerName, current);
                }
                sb.addScoreHolderToTeam(playerName, team);
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
    }

    private void removeFromOurTeams(String playerName) {
        Scoreboard sb = this.scoreboard();
        if (sb != null && playerName != null) {
            try {
                Team current = this.teamOf(playerName);
                if (current != null && TeamColorManager.isOurTeam(current)) {
                    sb.removeScoreHolderFromTeam(playerName, current);
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
    }

    private Team teamOf(String playerName) {
        Scoreboard sb = this.scoreboard();
        if (sb != null && playerName != null) {
            try {
                return sb.getScoreHolderTeam(playerName);
            }
            catch (Throwable var4) {
                return null;
            }
        }
        return null;
    }

    public static boolean isOurTeam(Team team) {
        return team != null && team.getName() != null && team.getName().startsWith(TEAM_PREFIX);
    }

    private String duelTeamName(Duel duel, boolean teamA) {
        String hex = duel.id.toString().replace("-", "").substring(0, 8);
        return TEAM_PREFIX + (teamA ? "a" : "b") + hex;
    }

    public void applyDuelColors(Duel duel) {
        if (this.enabled() && this.scoreboard() != null) {
            ServerPlayerEntity p;
            Formatting colorA = TextUtil.parseFormatting(PvPCore.get().config().duel.teamAColor, Formatting.RED);
            Formatting colorB = TextUtil.parseFormatting(PvPCore.get().config().duel.teamBColor, Formatting.BLUE);
            Team teamA = this.ensureTeam(this.duelTeamName(duel, true), colorA);
            Team teamB = this.ensureTeam(this.duelTeamName(duel, false), colorB);
            PlayerManager pm = PvPCore.get().server().getPlayerManager();
            for (UUID u : duel.teamA) {
                p = pm.getPlayer(u);
                if (p == null) continue;
                this.addToTeam(p.getGameProfile().name(), teamA);
            }
            for (UUID ux : duel.teamB) {
                p = pm.getPlayer(ux);
                if (p == null) continue;
                this.addToTeam(p.getGameProfile().name(), teamB);
            }
            this.updateDuelHealthSuffixes(duel);
        }
    }

    public void updateDuelHealthSuffixes(Duel duel) {
        if (duel == null || !PvPCore.get().config().duel.showHeartsBelowName) {
            return;
        }
        Scoreboard sb = this.scoreboard();
        if (sb == null) {
            return;
        }
        Team teamA = sb.getTeam(this.duelTeamName(duel, true));
        Team teamB = sb.getTeam(this.duelTeamName(duel, false));
        if (teamA == null && teamB == null) {
            return;
        }
        PlayerManager pm = PvPCore.get().server().getPlayerManager();
        this.setHealthSuffixForSide(duel, teamA, duel.teamA, pm);
        this.setHealthSuffixForSide(duel, teamB, duel.teamB, pm);
    }

    private void setHealthSuffixForSide(Duel duel, Team team, List<UUID> side, PlayerManager pm) {
        if (team == null) {
            return;
        }
        ServerPlayerEntity solo = null;
        int alive = 0;
        for (UUID u : side) {
            ServerPlayerEntity p = pm.getPlayer(u);
            if (p == null || duel.isEliminated(u) || duel.isDisconnected(u)) continue;
            ++alive;
            solo = p;
        }
        try {
            if (alive == 1 && solo != null && duel.state != DuelState.ROUND_END) {
                String format = PvPCore.get().config().duel.heartFormat;
                String hp = this.formatHealth(solo.getHealth());
                team.setSuffix(TextUtil.text(" " + format.replace("{health}", hp)));
            } else {
                team.setSuffix((Text)Text.literal((String)""));
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private String formatHealth(float health) {
        float clamped = Math.max(0.0f, health);
        if ((double)clamped == Math.floor(clamped)) {
            return String.valueOf((int)clamped);
        }
        return String.format("%.1f", Float.valueOf(clamped));
    }

    public void clearDuelColors(Duel duel) {
        Scoreboard sb = this.scoreboard();
        if (sb != null) {
            ServerPlayerEntity p;
            String nameA = this.duelTeamName(duel, true);
            String nameB = this.duelTeamName(duel, false);
            Team teamA = sb.getTeam(nameA);
            Team teamB = sb.getTeam(nameB);
            PlayerManager pm = PvPCore.get().server().getPlayerManager();
            for (UUID u : duel.participantUuids()) {
                p = pm.getPlayer(u);
                if (p == null) continue;
                String playerName = p.getGameProfile().name();
                try {
                    Team current = this.teamOf(playerName);
                    if (current != teamA && current != teamB) continue;
                    sb.removeScoreHolderFromTeam(playerName, current);
                }
                catch (Throwable throwable) {}
            }
            try {
                if (teamA != null) {
                    sb.removeTeam(teamA);
                }
                if (teamB != null) {
                    sb.removeTeam(teamB);
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            for (UUID ux : duel.participantUuids()) {
                PartyManager.Party party;
                p = pm.getPlayer(ux);
                if (p == null || (party = PvPCore.get().partyManager().partyOf(p)) == null) continue;
                this.applyPartyColor(party);
            }
        }
    }

    private String partyTeamName(PartyManager.Party party) {
        String hex = party.id.toString().replace("-", "").substring(0, 8);
        return "pvpp" + hex;
    }

    public Formatting nextPartyColor() {
        Formatting color = PARTY_PALETTE.get(Math.floorMod(this.partyColorCursor, PARTY_PALETTE.size()));
        ++this.partyColorCursor;
        return color;
    }

    public void applyPartyColor(PartyManager.Party party) {
        Team team;
        if (PvPCore.get().config().party.partyColors && party != null && (team = this.ensureTeam(this.partyTeamName(party), party.color != null ? party.color : this.nextPartyColor())) != null) {
            for (ServerPlayerEntity member : party.onlineMembers()) {
                if (PvPCore.get().duelManager().duelOf(member) != null) continue;
                this.addToTeam(member.getGameProfile().name(), team);
            }
        }
    }

    public void clearPartyColor(PartyManager.Party party) {
        Team team;
        Scoreboard sb = this.scoreboard();
        if (sb != null && party != null && (team = sb.getTeam(this.partyTeamName(party))) != null) {
            for (ServerPlayerEntity member : party.onlineMembers()) {
                try {
                    Team current = this.teamOf(member.getGameProfile().name());
                    if (current != team) continue;
                    sb.removeScoreHolderFromTeam(member.getGameProfile().name(), team);
                }
                catch (Throwable throwable) {}
            }
            try {
                sb.removeTeam(team);
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
    }

    public void clearMemberColor(ServerPlayerEntity player) {
        Team current;
        if (player != null && (current = this.teamOf(player.getGameProfile().name())) != null && TeamColorManager.isOurTeam(current) && current.getName().startsWith("pvpp")) {
            this.removeFromOurTeams(player.getGameProfile().name());
        }
    }

    private String zoneTeamName(String zoneId, UUID playerUuid) {
        String playerHash;
        String name;
        String zoneHash = Integer.toHexString(zoneId.hashCode()).replace("-", "0");
        if (zoneHash.length() > 6) {
            zoneHash = zoneHash.substring(0, 6);
        }
        return (name = "pvz" + zoneHash + (playerHash = playerUuid.toString().replace("-", "").substring(0, 6))).length() > 16 ? name.substring(0, 16) : name;
    }

    public void applyZoneLayout(ServerPlayerEntity player, String zoneId) {
        if (player == null || zoneId == null || !PvPCore.get().config().zone.showHeartsBelowName) {
            return;
        }
        Scoreboard sb = this.scoreboard();
        if (sb == null) {
            return;
        }
        Formatting color = TextUtil.parseFormatting(PvPCore.get().config().zone.nameTagColor, Formatting.YELLOW);
        Team team = this.ensureTeam(this.zoneTeamName(zoneId, player.getUuid()), color);
        if (team == null) {
            return;
        }
        try {
            team.setFriendlyFireAllowed(true);
            team.setCollisionRule(AbstractTeam.CollisionRule.ALWAYS);
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        this.addToTeam(player.getGameProfile().name(), team);
        this.updateZoneHealthSuffix(player, zoneId);
    }

    public void updateZoneHealthSuffix(ServerPlayerEntity player, String zoneId) {
        if (player == null || zoneId == null || !PvPCore.get().config().zone.showHeartsBelowName) {
            return;
        }
        Scoreboard sb = this.scoreboard();
        if (sb != null) {
            try {
                Team team = sb.getTeam(this.zoneTeamName(zoneId, player.getUuid()));
                if (team != null && team.getPlayerList().contains(player.getGameProfile().name())) {
                    String format = PvPCore.get().config().zone.heartFormat;
                    String hp = this.formatHealth(player.getHealth());
                    team.setSuffix(TextUtil.text(" " + format.replace("{health}", hp)));
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
    }

    public void clearZoneLayout(ServerPlayerEntity player, String zoneId) {
        if (player == null || zoneId == null) {
            return;
        }
        Scoreboard sb = this.scoreboard();
        if (sb != null) {
            String playerName = player.getGameProfile().name();
            try {
                Team team = sb.getTeam(this.zoneTeamName(zoneId, player.getUuid()));
                if (team != null) {
                    sb.removeScoreHolderFromTeam(playerName, team);
                    if (team.getPlayerList().isEmpty()) {
                        sb.removeTeam(team);
                    }
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
    }

    public boolean sameColor(ServerPlayerEntity a, ServerPlayerEntity b) {
        if (a != null && b != null) {
            if (a.getUuid().equals(b.getUuid())) {
                return true;
            }
            Team ta = this.teamOf(a.getGameProfile().name());
            Team tb = this.teamOf(b.getGameProfile().name());
            if (ta == null || tb == null) {
                return false;
            }
            if (ta == tb) {
                return true;
            }
            Formatting ca = ta.getColor();
            Formatting cb = tb.getColor();
            return ca != null && cb != null && ca == cb;
        }
        return false;
    }

    public String colorCodeOf(ServerPlayerEntity player) {
        if (player == null) {
            return "";
        }
        Team team = this.teamOf(player.getGameProfile().name());
        if (team != null && TeamColorManager.isOurTeam(team)) {
            Formatting color = team.getColor();
            return color != null && color.isColor() ? "&" + color.getCode() : "";
        }
        return "";
    }

    public String coloredName(ServerPlayerEntity player) {
        if (player == null) {
            return "?";
        }
        String code = this.colorCodeOf(player);
        return code.isEmpty() ? player.getGameProfile().name() : code + player.getGameProfile().name();
    }

    public void shutdown() {
        Scoreboard sb = this.scoreboard();
        if (sb != null) {
            for (Team team : List.copyOf(sb.getTeams())) {
                if (!TeamColorManager.isOurTeam(team)) continue;
                try {
                    for (String member : List.copyOf(team.getPlayerList())) {
                        try {
                            sb.removeScoreHolderFromTeam(member, team);
                        }
                        catch (Throwable throwable) {}
                    }
                    sb.removeTeam(team);
                }
                catch (Throwable throwable) {}
            }
        }
    }
}

