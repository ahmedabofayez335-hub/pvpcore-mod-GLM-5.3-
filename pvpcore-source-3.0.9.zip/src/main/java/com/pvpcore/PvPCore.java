/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.server.MinecraftServer
 *  net.minecraft.server.network.ServerPlayerEntity
 */
package com.pvpcore;

import com.pvpcore.PvPCoreMod;
import com.pvpcore.arena.ArenaManager;
import com.pvpcore.audit.AuditLog;
import com.pvpcore.chat.ChatRouter;
import com.pvpcore.config.GuiConfig;
import com.pvpcore.config.MainConfig;
import com.pvpcore.config.Messages;
import com.pvpcore.data.Storage;
import com.pvpcore.duel.DuelManager;
import com.pvpcore.ffa.ZoneManager;
import com.pvpcore.gui.GuiManager;
import com.pvpcore.kit.KitManager;
import com.pvpcore.leaderboard.LeaderboardManager;
import com.pvpcore.party.PartyManager;
import com.pvpcore.player.PlayerManager;
import com.pvpcore.player.PlayerState;
import com.pvpcore.player.SnapshotStore;
import com.pvpcore.queue.QueueManager;
import com.pvpcore.scoreboard.LobbyScoreboardManager;
import com.pvpcore.spectate.SpectateManager;
import com.pvpcore.util.ServerStats;
import com.pvpcore.util.TeamColorManager;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.FileAttribute;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

public final class PvPCore {
    private static PvPCore instance;
    private MinecraftServer server;
    private Path configDir;
    private Path dataDir;
    private MainConfig mainConfig;
    private GuiConfig guiConfig;
    private Messages messages;
    private Storage storage;
    private SnapshotStore snapshotStore;
    private GuiManager guiManager;
    private PlayerManager playerManager;
    private KitManager kitManager;
    private ArenaManager arenaManager;
    private DuelManager duelManager;
    private QueueManager queueManager;
    private PartyManager partyManager;
    private LeaderboardManager leaderboardManager;
    private SpectateManager spectateManager;
    private LobbyScoreboardManager lobbyScoreboardManager;
    private ZoneManager zoneManager;
    private ChatRouter chatRouter;
    private TeamColorManager teamColorManager;
    private AuditLog auditLog;

    public static PvPCore init() {
        if (instance == null) {
            instance = new PvPCore();
        }
        return instance;
    }

    public static PvPCore get() {
        return instance != null ? instance : PvPCore.init();
    }

    private PvPCore() {
    }

    public void onServerStarted(MinecraftServer server) {
        this.server = server;
        Path gameDir = server.getRunDirectory().toAbsolutePath();
        this.configDir = gameDir.resolve("config").resolve("pvp");
        this.dataDir = gameDir.resolve("data").resolve("pvp");
        try {
            Files.createDirectories(this.configDir, new FileAttribute[0]);
            Files.createDirectories(this.dataDir, new FileAttribute[0]);
        }
        catch (Exception var4) {
            PvPCoreMod.LOGGER.error("Failed to create pvp directories", (Throwable)var4);
        }
        this.mainConfig = new MainConfig();
        this.mainConfig.load(this.configDir);
        this.guiConfig = new GuiConfig();
        this.guiConfig.load(this.configDir);
        this.messages = new Messages();
        this.messages.load(this.configDir);
        this.auditLog = new AuditLog(this.dataDir);
        this.storage = new Storage(this.dataDir);
        this.snapshotStore = new SnapshotStore(this.dataDir);
        this.kitManager = new KitManager(this.dataDir);
        this.arenaManager = new ArenaManager(this.dataDir);
        this.guiManager = new GuiManager();
        this.leaderboardManager = new LeaderboardManager();
        this.chatRouter = new ChatRouter();
        this.teamColorManager = new TeamColorManager();
        this.playerManager = new PlayerManager();
        this.duelManager = new DuelManager();
        this.queueManager = new QueueManager();
        this.partyManager = new PartyManager();
        this.spectateManager = new SpectateManager();
        this.lobbyScoreboardManager = new LobbyScoreboardManager();
        this.zoneManager = new ZoneManager(this.dataDir);
        this.zoneManager.onServerStarted(server);
        this.storage.loadAll();
        this.leaderboardManager.refresh();
        PvPCoreMod.LOGGER.info("PvP Core started. Kits: {}, Arenas: {}, Players on record: {}", new Object[]{this.kitManager.all().size(), this.arenaManager.all().size(), this.storage.all().size()});
    }

    public void onServerStopping() {
        if (this.duelManager != null) {
            this.duelManager.shutdown();
        }
        if (this.partyManager != null) {
            this.partyManager.shutdown();
        }
        if (this.queueManager != null) {
            this.queueManager.shutdown();
        }
        if (this.spectateManager != null) {
            this.spectateManager.shutdown();
        }
        if (this.teamColorManager != null) {
            this.teamColorManager.shutdown();
        }
        if (this.lobbyScoreboardManager != null) {
            this.lobbyScoreboardManager.shutdown();
        }
        if (this.zoneManager != null) {
            this.zoneManager.shutdown();
        }
        if (this.playerManager != null) {
            this.playerManager.saveAllNow();
        }
        if (this.storage != null) {
            this.storage.saveAll();
        }
        if (this.kitManager != null) {
            this.kitManager.save();
        }
        if (this.arenaManager != null) {
            this.arenaManager.save();
        }
        if (this.auditLog != null) {
            this.auditLog.save();
        }
        PvPCoreMod.LOGGER.info("PvP Core stopped. All data saved.");
    }

    public void tick() {
        // 3.0.8: sample live ping (pong-based) before the scoreboards refresh.
        ServerStats.tick(this.server);
        this.playerManager.tick();
        this.duelManager.tick();
        this.queueManager.tick();
        this.partyManager.tick();
        this.spectateManager.tick();
        this.lobbyScoreboardManager.tick();
        this.zoneManager.tick();
        this.guiManager.tick();
        this.playerManager.autosaveTick();
    }

    public boolean isInventoryLocked(ServerPlayerEntity player) {
        return this.playerManager != null && this.playerManager.isInventoryLocked(player);
    }

    public boolean isItemUseBlocked(ServerPlayerEntity player) {
        boolean active;
        if (this.playerManager == null) {
            return false;
        }
        MainConfig.Lobby cfg = this.config().lobby;
        if (!cfg.blockItemUse) {
            return false;
        }
        if (!this.playerManager.loginSynced(player)) {
            return false;
        }
        PlayerState state = this.playerManager.state(player);
        boolean bl = active = state == PlayerState.LOBBY || state == PlayerState.QUEUEING || state == PlayerState.SPECTATING;
        return !active ? false : !PlayerManager.isAdmin(player) || !cfg.adminBypassLock && !this.playerManager.buildBypass(player);
    }

    public boolean isWorldInteractionBlocked(ServerPlayerEntity player) {
        return this.isBlockBreakBlocked(player) || this.isBlockPlaceBlocked(player);
    }

    public boolean isBlockBreakBlocked(ServerPlayerEntity player) {
        boolean active;
        if (this.playerManager == null) {
            return false;
        }
        MainConfig.Lobby cfg = this.config().lobby;
        if (!cfg.blockWorldInteraction && !this.config().zone.blockWorldInteraction) {
            return false;
        }
        if (!this.playerManager.loginSynced(player)) {
            return false;
        }
        PlayerState state = this.playerManager.state(player);
        if (state == PlayerState.ZONE) {
            return this.config().zone.blockWorldInteraction ? !PlayerManager.isAdmin(player) || !cfg.adminBypassLock && !this.playerManager.buildBreak(player) : false;
        }
        boolean bl = active = state == PlayerState.LOBBY || state == PlayerState.QUEUEING || state == PlayerState.SPECTATING;
        return !active ? false : !PlayerManager.isAdmin(player) || !cfg.adminBypassLock && !this.playerManager.buildBreak(player);
    }

    public boolean isBlockPlaceBlocked(ServerPlayerEntity player) {
        boolean active;
        if (this.playerManager == null) {
            return false;
        }
        MainConfig.Lobby cfg = this.config().lobby;
        if (!cfg.blockWorldInteraction && !this.config().zone.blockWorldInteraction) {
            return false;
        }
        if (!this.playerManager.loginSynced(player)) {
            return false;
        }
        PlayerState state = this.playerManager.state(player);
        if (state == PlayerState.ZONE) {
            return this.config().zone.blockWorldInteraction ? !PlayerManager.isAdmin(player) || !cfg.adminBypassLock && !this.playerManager.buildPlace(player) : false;
        }
        boolean bl = active = state == PlayerState.LOBBY || state == PlayerState.QUEUEING || state == PlayerState.SPECTATING;
        return !active ? false : !PlayerManager.isAdmin(player) || !cfg.adminBypassLock && !this.playerManager.buildPlace(player);
    }

    public MinecraftServer server() {
        return this.server;
    }

    public Path configDir() {
        return this.configDir;
    }

    public Path dataDir() {
        return this.dataDir;
    }

    public MainConfig config() {
        return this.mainConfig;
    }

    public GuiConfig guiConfig() {
        return this.guiConfig;
    }

    public Messages messages() {
        return this.messages;
    }

    public Storage storage() {
        return this.storage;
    }

    public SnapshotStore snapshotStore() {
        return this.snapshotStore;
    }

    public GuiManager guiManager() {
        return this.guiManager;
    }

    public PlayerManager playerManager() {
        return this.playerManager;
    }

    public KitManager kitManager() {
        return this.kitManager;
    }

    public ArenaManager arenaManager() {
        return this.arenaManager;
    }

    public DuelManager duelManager() {
        return this.duelManager;
    }

    public QueueManager queueManager() {
        return this.queueManager;
    }

    public PartyManager partyManager() {
        return this.partyManager;
    }

    public LeaderboardManager leaderboardManager() {
        return this.leaderboardManager;
    }

    public SpectateManager spectateManager() {
        return this.spectateManager;
    }

    public LobbyScoreboardManager lobbyScoreboardManager() {
        return this.lobbyScoreboardManager;
    }

    public ZoneManager zoneManager() {
        return this.zoneManager;
    }

    public ChatRouter chatRouter() {
        return this.chatRouter;
    }

    public TeamColorManager teamColors() {
        return this.teamColorManager;
    }

    public AuditLog auditLog() {
        return this.auditLog;
    }

    public long reloadConfigs() {
        long start = System.currentTimeMillis();
        this.mainConfig.load(this.configDir);
        this.guiConfig.load(this.configDir);
        this.messages.load(this.configDir);
        this.playerManager.refreshAllLobby();
        return System.currentTimeMillis() - start;
    }
}

