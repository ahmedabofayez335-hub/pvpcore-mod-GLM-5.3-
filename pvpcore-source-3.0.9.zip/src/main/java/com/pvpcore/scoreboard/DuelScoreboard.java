/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.packet.Packet
 *  net.minecraft.network.packet.s2c.play.ScoreboardDisplayS2CPacket
 *  net.minecraft.network.packet.s2c.play.ScoreboardObjectiveUpdateS2CPacket
 *  net.minecraft.network.packet.s2c.play.ScoreboardScoreResetS2CPacket
 *  net.minecraft.network.packet.s2c.play.ScoreboardScoreUpdateS2CPacket
 *  net.minecraft.scoreboard.Scoreboard
 *  net.minecraft.scoreboard.ScoreboardCriterion
 *  net.minecraft.scoreboard.ScoreboardCriterion$RenderType
 *  net.minecraft.scoreboard.ScoreboardDisplaySlot
 *  net.minecraft.scoreboard.ScoreboardObjective
 *  net.minecraft.server.network.ServerPlayerEntity
 */
package com.pvpcore.scoreboard;

import com.pvpcore.util.TextUtil;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.ScoreboardDisplayS2CPacket;
import net.minecraft.network.packet.s2c.play.ScoreboardObjectiveUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ScoreboardScoreResetS2CPacket;
import net.minecraft.network.packet.s2c.play.ScoreboardScoreUpdateS2CPacket;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardCriterion;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.server.network.ServerPlayerEntity;

public final class DuelScoreboard {
    private final String objectiveName;
    private final Scoreboard dummyScoreboard;
    private final ScoreboardObjective objective;
    private final List<ServerPlayerEntity> viewers = new ArrayList<ServerPlayerEntity>();
    private final List<String> lineTexts = new ArrayList<String>();
    private boolean created = false;

    public DuelScoreboard(UUID duelId, String title) {
        this("pvpd_" + duelId.toString().substring(0, 8), title);
    }

    public DuelScoreboard(String objectiveName, String title) {
        this.objectiveName = objectiveName.toLowerCase();
        this.dummyScoreboard = new Scoreboard();
        this.objective = new ScoreboardObjective(this.dummyScoreboard, this.objectiveName, ScoreboardCriterion.DUMMY, TextUtil.text(title), ScoreboardCriterion.RenderType.INTEGER, false, null);
    }

    public synchronized void addViewer(ServerPlayerEntity player) {
        if (player != null && !this.viewers.contains(player)) {
            this.viewers.add(player);
            this.send(player, (Packet<?>)new ScoreboardObjectiveUpdateS2CPacket(this.objective, 0));
            this.send(player, (Packet<?>)new ScoreboardDisplayS2CPacket(ScoreboardDisplaySlot.SIDEBAR, this.objective));
            for (int i = 0; i < this.lineTexts.size(); ++i) {
                this.sendScore(player, this.lineTexts.get(i), this.lineTexts.size() - i);
            }
            this.created = true;
        }
    }

    public synchronized void removeViewer(ServerPlayerEntity player) {
        this.viewers.remove(player);
        if (player != null && player.networkHandler != null) {
            this.send(player, (Packet<?>)new ScoreboardObjectiveUpdateS2CPacket(this.objective, 1));
        }
    }

    public synchronized void updateLines(List<String> lines) {
        ArrayList<String> fresh = new ArrayList<String>();
        HashSet<String> seen = new HashSet<String>();
        for (int i = 0; i < lines.size(); ++i) {
            String line = TextUtil.sbLine(lines.get(i));
            String unique = line;
            int suffix = 0;
            while (seen.contains(unique)) {
                unique = line + "\u00a70".repeat(++suffix);
            }
            seen.add(unique);
            fresh.add(unique);
        }
        for (String old : new ArrayList<String>(this.lineTexts)) {
            if (fresh.contains(old)) continue;
            for (ServerPlayerEntity v : this.viewers) {
                this.removeScore(v, old);
            }
        }
        this.lineTexts.clear();
        for (int i = 0; i < fresh.size(); ++i) {
            String unique = (String)fresh.get(i);
            this.lineTexts.add(unique);
            int score = fresh.size() - i;
            for (ServerPlayerEntity v : this.viewers) {
                this.sendScore(v, unique, score);
            }
        }
    }

    public synchronized void removeAll() {
        for (ServerPlayerEntity v : new ArrayList<ServerPlayerEntity>(this.viewers)) {
            if (v == null || v.networkHandler == null) continue;
            this.send(v, (Packet<?>)new ScoreboardObjectiveUpdateS2CPacket(this.objective, 1));
        }
        this.viewers.clear();
        this.lineTexts.clear();
        this.created = false;
    }

    private void sendScore(ServerPlayerEntity player, String holder, int score) {
        player.networkHandler.sendPacket((Packet)new ScoreboardScoreUpdateS2CPacket(holder, this.objectiveName, score, Optional.empty(), Optional.empty()));
    }

    private void removeScore(ServerPlayerEntity player, String holder) {
        player.networkHandler.sendPacket((Packet)new ScoreboardScoreResetS2CPacket(holder, this.objectiveName));
    }

    private void send(ServerPlayerEntity player, Packet<?> packet) {
        if (player != null && player.networkHandler != null) {
            player.networkHandler.sendPacket(packet);
        }
    }
}

