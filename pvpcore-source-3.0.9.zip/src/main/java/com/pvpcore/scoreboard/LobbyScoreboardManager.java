/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.server.PlayerManager
 *  net.minecraft.server.network.ServerPlayerEntity
 */
package com.pvpcore.scoreboard;

import com.pvpcore.PvPCore;
import com.pvpcore.config.MainConfig;
import com.pvpcore.data.PlayerData;
import com.pvpcore.data.PlayerStats;
import com.pvpcore.leaderboard.LeaderboardManager;
import com.pvpcore.party.PartyManager;
import com.pvpcore.player.PlayerManager;
import com.pvpcore.player.PlayerState;
import com.pvpcore.queue.QueueManager;
import com.pvpcore.scoreboard.DuelScoreboard;
import com.pvpcore.util.ServerStats;
import com.pvpcore.util.TextUtil;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.server.network.ServerPlayerEntity;

public final class LobbyScoreboardManager {
    private final Map<UUID, DuelScoreboard> boards = new ConcurrentHashMap<UUID, DuelScoreboard>();
    private long tick = 0L;
    private long lastRefresh = 0L;
    private Map<String, Integer> rankCache = new ConcurrentHashMap<String, Integer>();

    public void show(ServerPlayerEntity player) {
        if (player != null) {
            MainConfig.LobbyScoreboardSection cfg = PvPCore.get().config().lobbyScoreboard;
            if (cfg.enabled) {
                DuelScoreboard board = this.boards.computeIfAbsent(player.getUuid(), u -> new DuelScoreboard("pvl_" + u.toString().substring(0, 8), cfg.title));
                board.addViewer(player);
                this.update(player);
            }
        }
    }

    public void hide(ServerPlayerEntity player) {
        DuelScoreboard board;
        if (player != null && (board = this.boards.remove(player.getUuid())) != null) {
            board.removeViewer(player);
        }
    }

    public boolean isShown(ServerPlayerEntity player) {
        return player != null && this.boards.containsKey(player.getUuid());
    }

    public void onQuit(ServerPlayerEntity player) {
        this.hide(player);
    }

    public void tick() {
        ++this.tick;
        MainConfig.LobbyScoreboardSection cfg = PvPCore.get().config().lobbyScoreboard;
        if (!cfg.enabled) {
            if (!this.boards.isEmpty()) {
                this.hideAll();
            }
        } else {
            int interval = Math.max(5, cfg.updateIntervalTicks);
            if (this.tick - this.lastRefresh >= (long)interval) {
                this.lastRefresh = this.tick;
                this.rebuildRanks();
                net.minecraft.server.PlayerManager pm = PvPCore.get().server().getPlayerManager();
                PlayerManager playerManager = PvPCore.get().playerManager();
                for (ServerPlayerEntity p : pm.getPlayerList()) {
                    boolean inLobby;
                    if (p == null || p.isDisconnected()) continue;
                    PlayerState state = playerManager.state(p);
                    boolean bl = inLobby = (state == PlayerState.LOBBY || state == PlayerState.QUEUEING) && playerManager.loginSynced(p) && PvPCore.get().duelManager().duelOf(p) == null && !PvPCore.get().spectateManager().isSpectating(p);
                    if (inLobby) {
                        this.show(p);
                        continue;
                    }
                    this.hide(p);
                }
                for (UUID u : new ArrayList<UUID>(this.boards.keySet())) {
                    DuelScoreboard b;
                    if (pm.getPlayer(u) != null || (b = this.boards.remove(u)) == null) continue;
                    b.removeAll();
                }
            }
        }
    }

    private void hideAll() {
        net.minecraft.server.PlayerManager pm = PvPCore.get().server().getPlayerManager();
        for (UUID u : new ArrayList<UUID>(this.boards.keySet())) {
            ServerPlayerEntity p = pm.getPlayer(u);
            DuelScoreboard b = this.boards.remove(u);
            if (b == null || p == null) continue;
            b.removeViewer(p);
        }
    }

    private void update(ServerPlayerEntity player) {
        DuelScoreboard board = this.boards.get(player.getUuid());
        if (board != null) {
            ArrayList<String> lines = new ArrayList<String>();
            for (String template : PvPCore.get().config().lobbyScoreboard.lines) {
                lines.add(TextUtil.colorAndPlace(template, this.placeholders(player)));
            }
            board.updateLines(lines);
        }
    }

    private Map<String, String> placeholders(ServerPlayerEntity player) {
        PvPCore core = PvPCore.get();
        MainConfig.LobbyScoreboardSection cfg = core.config().lobbyScoreboard;
        PlayerData data = core.storage().get(player.getUuid(), player.getGameProfile().name());
        PlayerStats stats = data != null ? data.statsFor("global") : new PlayerStats();
        int elo = data != null ? data.ratingFor("global", core.config().elo.startRating) : core.config().elo.startRating;
        int online = core.server().getPlayerManager().getCurrentPlayerCount();
        int max = core.server().getPlayerManager().getMaxPlayerCount();
        // 3.0.8: live pong-based ping (see ServerStats) instead of the stale
        // 15-second keepalive estimate.
        int ping = ServerStats.ping(player);
        PartyManager.Party party = core.partyManager().partyOf(player);
        String partyText = party != null ? party.members.size() + (party.isLeader(player.getUuid()) ? " (leader)" : "") : "-";
        QueueManager queue = core.queueManager();
        String queueText = queue.isQueued(player) ? "In queue" : "-";
        String rank = String.valueOf(this.rankCache.getOrDefault(player.getGameProfile().name(), this.rankCache.size() + 1));
        LocalDateTime now = LocalDateTime.now();
        String date = now.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        String time = now.format(DateTimeFormatter.ofPattern("HH:mm"));
        String world = player.getEntityWorld().getRegistryKey().getValue().getPath();
        world = world.substring(0, 1).toUpperCase(Locale.ROOT) + world.substring(1);
        return Map.ofEntries(Map.entry("player", player.getGameProfile().name()), Map.entry("online", String.valueOf(online)), Map.entry("max", String.valueOf(max)), Map.entry("ip", cfg.serverIp), Map.entry("ping", String.valueOf(ping)), Map.entry("uptime", ServerStats.uptime(core.server())), Map.entry("tps", ServerStats.tps(core.server())), Map.entry("wins", String.valueOf(stats.wins)), Map.entry("losses", String.valueOf(stats.losses)), Map.entry("duels", String.valueOf(stats.duels)), Map.entry("winrate", String.format(Locale.ROOT, "%.0f%%", stats.winRate())), Map.entry("elo", String.valueOf(elo)), Map.entry("rank", rank), Map.entry("streak", String.valueOf(stats.streak)), Map.entry("beststreak", String.valueOf(stats.bestStreak)), Map.entry("party", partyText), Map.entry("queue", queueText), Map.entry("world", world), Map.entry("date", date), Map.entry("time", time));
    }

    private void rebuildRanks() {
        try {
            ConcurrentHashMap<String, Integer> ranks = new ConcurrentHashMap<String, Integer>();
            List<LeaderboardManager.Entry> all = PvPCore.get().leaderboardManager().top("global", "elo", Integer.MAX_VALUE);
            for (int i = 0; i < all.size(); ++i) {
                ranks.putIfAbsent(all.get(i).name(), i + 1);
            }
            this.rankCache = ranks;
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    public void shutdown() {
        net.minecraft.server.PlayerManager pm = PvPCore.get().server().getPlayerManager();
        for (UUID u : new ArrayList<UUID>(this.boards.keySet())) {
            ServerPlayerEntity p = pm.getPlayer(u);
            DuelScoreboard b = this.boards.remove(u);
            if (b == null || p == null) continue;
            b.removeViewer(p);
        }
    }
}

