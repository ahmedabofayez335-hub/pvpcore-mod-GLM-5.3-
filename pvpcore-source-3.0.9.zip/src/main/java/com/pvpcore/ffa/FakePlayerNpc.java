/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  io.netty.buffer.ByteBuf
 *  io.netty.buffer.Unpooled
 *  io.netty.channel.ChannelFutureListener
 *  io.netty.channel.ChannelHandlerContext
 *  net.minecraft.entity.Entity
 *  net.minecraft.network.ClientConnection
 *  net.minecraft.network.DisconnectionInfo
 *  net.minecraft.network.NetworkSide
 *  net.minecraft.network.PacketByteBuf
 *  net.minecraft.network.RegistryByteBuf
 *  net.minecraft.network.listener.PacketListener
 *  net.minecraft.network.packet.Packet
 *  net.minecraft.network.packet.c2s.common.SyncedClientOptions
 *  net.minecraft.network.packet.s2c.play.PlayerListS2CPacket
 *  net.minecraft.network.packet.s2c.play.PlayerListS2CPacket$Action
 *  net.minecraft.network.packet.s2c.play.PlayerListS2CPacket$Entry
 *  net.minecraft.network.packet.s2c.play.PlayerRemoveS2CPacket
 *  net.minecraft.network.state.NetworkState
 *  net.minecraft.registry.DynamicRegistryManager
 *  net.minecraft.scoreboard.AbstractTeam$CollisionRule
 *  net.minecraft.scoreboard.ServerScoreboard
 *  net.minecraft.scoreboard.Team
 *  net.minecraft.server.MinecraftServer
 *  net.minecraft.server.network.ConnectedClientData
 *  net.minecraft.server.network.ServerPlayNetworkHandler
 *  net.minecraft.server.network.ServerPlayerEntity
 *  net.minecraft.server.world.ServerWorld
 *  net.minecraft.text.Text
 *  net.minecraft.util.Formatting
 *  net.minecraft.util.math.ChunkSectionPos
 *  net.minecraft.world.GameMode
 */
package com.pvpcore.ffa;

import com.mojang.authlib.GameProfile;
import com.pvpcore.PvPCoreMod;
import com.pvpcore.mixin.ClientConnectionAccessor;
import com.pvpcore.util.TeleportUtil;
import com.pvpcore.util.TextUtil;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import java.nio.charset.StandardCharsets;
import java.util.EnumSet;
import java.util.List;
import java.util.UUID;
import java.util.function.Consumer;
import javax.crypto.Cipher;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.decoration.DisplayEntity;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.DisconnectionInfo;
import net.minecraft.network.NetworkSide;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.listener.PacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.common.SyncedClientOptions;
import net.minecraft.network.packet.s2c.play.PlayerListS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerRemoveS2CPacket;
import net.minecraft.network.state.NetworkState;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.scoreboard.AbstractTeam;
import net.minecraft.scoreboard.ServerScoreboard;
import net.minecraft.scoreboard.Team;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ConnectedClientData;
import net.minecraft.server.network.ServerPlayNetworkHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.ChunkSectionPos;
import net.minecraft.world.GameMode;

public final class FakePlayerNpc {
    public final String npcId;
    public final String displayName;
    public final String zoneId;
    public final UUID entityUuid;
    public final String profileName;
    public final String world;
    public final double x;
    public final double y;
    public final double z;
    public final float yaw;
    public final float pitch;
    private ServerPlayerEntity entity;
    private String teamName;
    private boolean chunkForced = false;
    // 3.0.8: hologram line under the NPC name showing the live zone player count.
    private DisplayEntity.TextDisplayEntity countDisplay;

    private FakePlayerNpc(String npcId, String zoneId, String displayName, String world, double x, double y, double z, float yaw, float pitch, UUID entityUuid) {
        this.npcId = npcId;
        this.zoneId = zoneId;
        this.displayName = displayName;
        this.world = world;
        this.x = x;
        this.y = y;
        this.z = z;
        this.yaw = yaw;
        this.pitch = pitch;
        this.entityUuid = entityUuid != null ? entityUuid : UUID.randomUUID();
        this.profileName = FakePlayerNpc.deriveProfileName(displayName);
    }

    public static FakePlayerNpc of(String npcId, String zoneId, String displayName, String world, double x, double y, double z, float yaw, float pitch, UUID entityUuid) {
        return new FakePlayerNpc(npcId, zoneId, displayName, world, x, y, z, yaw, pitch, entityUuid);
    }

    public boolean isSpawned() {
        return this.entity != null && this.entity.isAlive();
    }

    public ServerPlayerEntity entity() {
        return this.entity;
    }

    public boolean matches(Entity candidate) {
        return candidate != null && candidate.getUuid().equals(this.entityUuid);
    }

    /**
     * 3.0.9: shows the NPC display name plus the live zone player count as ONE
     * two-line hologram. The vanilla player nametag used to collide with the old
     * separate count line (nametag text sits at y+2.075..2.3 above the feet, the
     * 3.0.8 count line rendered y+2.02..2.245 and covered most of the name), so
     * while the hologram is up we hide the vanilla nametag via the team rule and
     * render the name ourselves as the hologram's first line.
     * Pass a blank/null line to hide the count line again (the vanilla nametag
     * is restored).
     */
    public void updateCountLine(MinecraftServer server, String line) {
        try {
            if (!this.isSpawned() || line == null || line.isBlank()) {
                this.removeCountDisplay(server);
                this.setVanillaNameTagHidden(server, false);
                return;
            }
            ServerWorld w = TeleportUtil.world(server, this.world);
            if (w == null) {
                return;
            }
            this.setVanillaNameTagHidden(server, true);
            DisplayEntity.TextDisplayEntity display = this.countDisplay;
            if (display != null && (!display.isAlive() || display.getEntityWorld() != w)) {
                this.discardCountDisplay(display);
                display = null;
            }
            if (display == null) {
                display = this.spawnCountDisplay(w);
            }
            if (display != null) {
                display.setText(TextUtil.text(this.displayName + "\n" + line));
            }
        }
        catch (Throwable t) {
            PvPCoreMod.LOGGER.warn("Could not update NPC count line: {}", (Object)t.getMessage());
        }
    }

    /**
     * Hides (or restores) the vanilla overhead nametag of the NPC player via its
     * scoreboard team while our two-line hologram is showing the name.
     */
    private void setVanillaNameTagHidden(MinecraftServer server, boolean hidden) {
        if (this.teamName == null) {
            return;
        }
        try {
            ServerScoreboard sb = server.getScoreboard();
            Team team = sb.getTeam(this.teamName);
            if (team != null) {
                team.setNameTagVisibilityRule(hidden ? AbstractTeam.VisibilityRule.NEVER : AbstractTeam.VisibilityRule.ALWAYS);
            }
        }
        catch (Throwable t) {
            PvPCoreMod.LOGGER.warn("Could not toggle NPC nametag visibility: {}", (Object)t.getMessage());
        }
    }

    private DisplayEntity.TextDisplayEntity spawnCountDisplay(ServerWorld w) {
        try {
            // Deterministic UUID: if a leftover display survived a crash in the
            // chunk data it gets replaced instead of stacking a duplicate.
            UUID countUuid = this.countEntityUuid();
            for (Entity e : w.iterateEntities()) {
                if (e == null || !e.getUuid().equals(countUuid)) continue;
                e.discard();
            }
            DisplayEntity.TextDisplayEntity display = new DisplayEntity.TextDisplayEntity(EntityType.TEXT_DISPLAY, w);
            // Two 9px lines + 1px gap = 19px * 0.025 = 0.475 blocks of text. The
            // vanilla nametag text sits with its top edge at feet+2.3 (NAME_TAG
            // attachment = entity height, +0.5 label anchor), so lifting the top
            // of this block to exactly 2.3 puts the name line where the nametag
            // used to be and the count line right under it, clear of the head
            // (top at feet+1.8).
            display.refreshPositionAndAngles(this.x, this.y + 1.825, this.z, 0.0f, 0.0f);
            display.setBillboardMode(DisplayEntity.BillboardMode.CENTER);
            display.setBackground(0x40000000);
            display.setInvulnerable(true);
            display.setNoGravity(true);
            if (w.spawnEntity(display)) {
                this.countDisplay = display;
                return display;
            }
        }
        catch (Throwable t) {
            PvPCoreMod.LOGGER.warn("Could not spawn NPC count line: {}", (Object)t.getMessage());
        }
        return null;
    }

    private void removeCountDisplay(MinecraftServer server) {
        if (this.countDisplay == null) {
            return;
        }
        this.discardCountDisplay(this.countDisplay);
    }

    private void discardCountDisplay(DisplayEntity.TextDisplayEntity display) {
        try {
            if (display.isAlive()) {
                display.discard();
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        if (this.countDisplay == display) {
            this.countDisplay = null;
        }
    }

    private UUID countEntityUuid() {
        return UUID.nameUUIDFromBytes(("pvpcore:npc-count:" + this.npcId).getBytes(StandardCharsets.UTF_8));
    }

    public boolean spawn(MinecraftServer server) {
        try {
            ServerWorld w = TeleportUtil.world(server, this.world);
            if (w == null) {
                PvPCoreMod.LOGGER.warn("NPC {} could not spawn: world {} missing", (Object)this.npcId, (Object)this.world);
                return false;
            }
            this.despawn(server, false);
            Object name = this.profileName;
            while (server.getPlayerManager().isAlreadyConnected((String)name) != null && ((String)name).length() < 14) {
                name = (String)name + "_";
            }
            this.chunkForced = this.setForce(w, true);
            GameProfile profile = new GameProfile(this.entityUuid, (String)name);
            ServerPlayerEntity npc = new ServerPlayerEntity(server, w, profile, SyncedClientOptions.createDefault());
            npc.refreshPositionAndAngles(this.x, this.y, this.z, this.yaw, this.pitch);
            FakeConnection conn = new FakeConnection();
            ConnectedClientData clientData = ConnectedClientData.createDefault((GameProfile)profile, (boolean)false);
            npc.networkHandler = new ServerPlayNetworkHandler(server, (ClientConnection)conn, npc, clientData);
            server.getPlayerManager().onPlayerConnect((ClientConnection)conn, npc, clientData);
            npc.changeGameMode(GameMode.ADVENTURE);
            npc.setInvulnerable(true);
            npc.setNoGravity(true);
            npc.refreshPositionAndAngles(this.x, this.y, this.z, this.yaw, this.pitch);
            npc.networkHandler.requestTeleport(this.x, this.y, this.z, this.yaw, this.pitch);
            this.entity = npc;
            this.applyNameTeam(server);
            this.hideFromTabList(server);
            return true;
        }
        catch (Throwable t) {
            PvPCoreMod.LOGGER.error("Failed to spawn NPC {}", (Object)this.npcId, (Object)t);
            return false;
        }
    }

    private void applyNameTeam(MinecraftServer server) {
        try {
            String tail;
            String stripped;
            ServerScoreboard sb = server.getScoreboard();
            this.teamName = "pvpnpc" + Math.floorMod(this.entityUuid.hashCode(), 100000);
            Team team = sb.getTeam(this.teamName);
            if (team == null) {
                team = sb.addTeam(this.teamName);
            }
            String head = (stripped = TextUtil.stripColor(TextUtil.colorize(this.displayName))).endsWith(tail = this.profileName) ? stripped.substring(0, stripped.length() - tail.length()) : "";
            String coloredHead = head.isEmpty() ? FakePlayerNpc.leadingCodes(this.displayName) : FakePlayerNpc.keepColorCodesUpTo(this.displayName, head.length());
            team.setPrefix(TextUtil.text(coloredHead));
            Formatting color = TextUtil.lastColorCode(this.displayName);
            team.setColor(color != null ? color : Formatting.WHITE);
            team.setCollisionRule(AbstractTeam.CollisionRule.NEVER);
            team.setFriendlyFireAllowed(false);
            // 3.0.9: always start with the vanilla nametag visible; if a leftover
            // NEVER rule from a previous session survived in scoreboard.dat the
            // name would stay hidden forever. updateCountLine re-hides it while
            // the two-line hologram (name + count) is showing.
            team.setNameTagVisibilityRule(AbstractTeam.VisibilityRule.ALWAYS);
            String holder = this.entity.getGameProfile().name();
            if (!team.getPlayerList().contains(holder)) {
                sb.addScoreHolderToTeam(holder, team);
            }
        }
        catch (Throwable t) {
            PvPCoreMod.LOGGER.warn("Could not apply NPC name team: {}", (Object)t.getMessage());
        }
    }

    private static String leadingCodes(String display) {
        char c;
        StringBuilder out = new StringBuilder();
        if (display == null) {
            return "";
        }
        for (int i = 0; i < display.length() && ((c = display.charAt(i)) == '&' || c == '\u00a7') && i + 1 < display.length(); ++i) {
            out.append('\u00a7').append(Character.toLowerCase(display.charAt(i + 1)));
            ++i;
        }
        return out.toString();
    }

    private static String keepColorCodesUpTo(String display, int plainLength) {
        if (plainLength <= 0 || display == null) {
            return "";
        }
        StringBuilder out = new StringBuilder();
        int plainSeen = 0;
        for (int i = 0; i < display.length(); ++i) {
            char c = display.charAt(i);
            if ((c == '&' || c == '\u00a7') && i + 1 < display.length()) {
                out.append(c).append(display.charAt(i + 1));
                ++i;
                continue;
            }
            if (plainSeen >= plainLength) break;
            ++plainSeen;
        }
        return out.toString();
    }

    public void hideFromTabList(MinecraftServer server) {
        try {
            PlayerListS2CPacket.Entry entry = new PlayerListS2CPacket.Entry(this.entityUuid, this.entity.getGameProfile(), false, 0, GameMode.ADVENTURE, null, true, 0, null);
            PlayerListS2CPacket packet = (PlayerListS2CPacket)PlayerListS2CPacket.CODEC.decode(this.tabBuf(server, entry));
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                if (p == this.entity || p.networkHandler == null) continue;
                p.networkHandler.sendPacket((Packet)packet);
            }
        }
        catch (Throwable t) {
            PvPCoreMod.LOGGER.warn("Could not hide NPC from tab list: {}", (Object)t.getMessage());
        }
    }

    private RegistryByteBuf tabBuf(MinecraftServer server, PlayerListS2CPacket.Entry entry) {
        RegistryByteBuf buf = new RegistryByteBuf((ByteBuf)new PacketByteBuf(Unpooled.buffer()), (DynamicRegistryManager)server.getRegistryManager());
        buf.writeEnumSet(EnumSet.of(PlayerListS2CPacket.Action.UPDATE_LISTED), PlayerListS2CPacket.Action.class);
        buf.writeVarInt(1);
        buf.writeUuid(entry.profileId());
        buf.writeBoolean(entry.listed());
        return buf;
    }

    private boolean setForce(ServerWorld w, boolean force) {
        try {
            return w.setChunkForced(ChunkSectionPos.getSectionCoord((double)this.x), ChunkSectionPos.getSectionCoord((double)this.z), force);
        }
        catch (Throwable t) {
            return false;
        }
    }

    public void despawn(MinecraftServer server, boolean removeTeam) {
        block15: {
            try {
                this.removeCountDisplay(server);
                if (this.chunkForced) {
                    ServerWorld w = TeleportUtil.world(server, this.world);
                    if (w != null) {
                        this.setForce(w, false);
                    }
                    this.chunkForced = false;
                }
                if (this.teamName != null && removeTeam) {
                    ServerScoreboard sb = server.getScoreboard();
                    Team team = sb.getTeam(this.teamName);
                    if (team != null) {
                        for (String member : List.copyOf(team.getPlayerList())) {
                            sb.removeScoreHolderFromTeam(member, team);
                        }
                        sb.removeTeam(team);
                    }
                    this.teamName = null;
                }
                if (this.entity == null) break block15;
                try {
                    PlayerRemoveS2CPacket packet = new PlayerRemoveS2CPacket(List.of(this.entityUuid));
                    for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                        if (p.networkHandler == null) continue;
                        p.networkHandler.sendPacket((Packet)packet);
                    }
                }
                catch (Throwable packet) {
                    // empty catch block
                }
                try {
                    this.entity.networkHandler.disconnect((Text)Text.literal((String)"NPC removed"));
                }
                catch (Throwable packet) {
                    // empty catch block
                }
                try {
                    if (this.entity.getEntityWorld() != null) {
                        this.entity.discard();
                    }
                }
                catch (Throwable packet) {
                    // empty catch block
                }
                this.entity = null;
            }
            catch (Throwable t) {
                PvPCoreMod.LOGGER.warn("Error despawning NPC {}: {}", (Object)this.npcId, (Object)t.getMessage());
            }
        }
    }

    public void resetPosition() {
        try {
            if (this.isSpawned()) {
                this.entity.setVelocity(0.0, 0.0, 0.0);
                this.entity.networkHandler.requestTeleport(this.x, this.y, this.z, this.yaw, this.pitch);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private static String deriveProfileName(String displayName) {
        String plain = TextUtil.stripColor(TextUtil.colorize(displayName == null ? "" : displayName));
        String cleaned = plain.replaceAll("[^A-Za-z0-9_]", "").trim();
        if (cleaned.isEmpty()) {
            cleaned = "NPC";
        }
        if (cleaned.length() > 16) {
            cleaned = cleaned.substring(0, 16);
        }
        return cleaned;
    }

    public String toString() {
        return this.npcId + " -> " + this.zoneId + " @ " + this.world + " " + this.x + "," + this.y + "," + this.z;
    }

    static final class FakeConnection
    extends ClientConnection {
        FakeConnection() {
            super(NetworkSide.SERVERBOUND);
        }

        public void channelActive(ChannelHandlerContext ctx) {
        }

        public void channelInactive(ChannelHandlerContext ctx) {
        }

        public void exceptionCaught(ChannelHandlerContext ctx, Throwable t) {
        }

        public void send(Packet<?> packet) {
        }

        public void send(Packet<?> packet, ChannelFutureListener listener) {
            try {
                if (listener != null) {
                    listener.operationComplete(null);
                }
            }
            catch (Exception exception) {
                // empty catch block
            }
        }

        public void send(Packet<?> packet, ChannelFutureListener listener, boolean flush) {
            try {
                if (listener != null) {
                    listener.operationComplete(null);
                }
            }
            catch (Exception exception) {
                // empty catch block
            }
        }

        public void flush() {
        }

        public void tick() {
        }

        public <T extends PacketListener> void transitionInbound(NetworkState<T> state, T packetListener) {
            try {
                ((ClientConnectionAccessor)((Object)this)).pvpcore$setPacketListener(packetListener);
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }

        public void transitionOutbound(NetworkState<?> newState) {
        }

        public void submit(Consumer<ClientConnection> task) {
            try {
                task.accept(this);
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }

        public void tryDisableAutoRead() {
        }

        public void setCompressionThreshold(int compressionThreshold, boolean rejectsBadPackets) {
        }

        public void setupEncryption(Cipher decryptionCipher, Cipher encryptionCipher) {
        }

        public void disconnect(Text disconnectReason) {
        }

        public void disconnect(DisconnectionInfo disconnectionInfo) {
        }

        public void handleDisconnection() {
        }

        public boolean isOpen() {
            return true;
        }
    }
}

