/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 *  com.google.gson.GsonBuilder
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.damage.DamageSource
 *  net.minecraft.entity.player.PlayerInventory
 *  net.minecraft.item.ItemStack
 *  net.minecraft.server.MinecraftServer
 *  net.minecraft.server.network.ServerPlayerEntity
 *  net.minecraft.server.world.ServerWorld
 *  net.minecraft.text.Text
 *  net.minecraft.world.GameMode
 */
package com.pvpcore.ffa;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.pvpcore.PvPCore;
import com.pvpcore.PvPCoreMod;
import com.pvpcore.ffa.FakePlayerNpc;
import com.pvpcore.ffa.FightZone;
import com.pvpcore.gui.guis.ZoneKitGui;
import com.pvpcore.kit.Kit;
import com.pvpcore.player.InventorySnapshot;
import com.pvpcore.player.PlayerManager;
import com.pvpcore.player.PlayerState;
import com.pvpcore.scoreboard.DuelScoreboard;
import com.pvpcore.util.ServerStats;
import com.pvpcore.util.TeleportUtil;
import com.pvpcore.util.TextUtil;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.FileAttribute;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.entity.Entity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.world.GameMode;

public final class ZoneManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private final Path file;
    private final Map<String, FightZone> zones = new LinkedHashMap<String, FightZone>();
    private final List<FakePlayerNpc> npcs = new ArrayList<FakePlayerNpc>();
    private final Map<UUID, String> memberZone = new ConcurrentHashMap<UUID, String>();
    private final Map<UUID, String> kitChoice = new ConcurrentHashMap<UUID, String>();
    private final Map<String, DuelScoreboard> scoreboards = new LinkedHashMap<String, DuelScoreboard>();
    private long tick = 0L;

    public ZoneManager(Path dataDir) {
        this.file = dataDir.resolve("zones.json");
        try {
            Files.createDirectories(dataDir, new FileAttribute[0]);
        }
        catch (IOException var3) {
            PvPCoreMod.LOGGER.error("Could not create pvp data directory", (Throwable)var3);
        }
    }

    public FightZone get(String id) {
        return id == null ? null : this.zones.get(id.toLowerCase());
    }

    public List<FightZone> all() {
        return new ArrayList<FightZone>(this.zones.values());
    }

    public FightZone create(String id, String displayName) {
        String key = id.toLowerCase();
        FightZone zone = new FightZone(key, (String)(displayName == null || displayName.isBlank() ? "&f" + key : displayName));
        zone.world = "minecraft:overworld";
        this.zones.put(key, zone);
        this.save();
        return zone;
    }

    public boolean delete(String id) {
        FightZone zone = this.get(id);
        if (zone == null) {
            return false;
        }
        MinecraftServer server = PvPCore.get().server();
        for (UUID u : new ArrayList<UUID>(this.memberZone.keySet())) {
            ServerPlayerEntity p;
            if (!zone.id.equals(this.memberZone.get(u)) || (p = server.getPlayerManager().getPlayer(u)) == null) continue;
            this.leaveToLobby(p, true);
        }
        zone.members.clear();
        this.zones.remove(zone.id);
        this.npcs.removeIf(n -> {
            if (n.zoneId.equals(zone.id)) {
                n.despawn(server, true);
                return true;
            }
            return false;
        });
        DuelScoreboard sb = this.scoreboards.remove(zone.id);
        if (sb != null) {
            sb.removeAll();
        }
        this.save();
        return true;
    }

    public boolean rename(String id, String displayName) {
        FightZone zone = this.get(id);
        if (zone != null) {
            zone.displayName = displayName;
            this.save();
            return true;
        }
        return false;
    }

    public List<FakePlayerNpc> npcs() {
        return new ArrayList<FakePlayerNpc>(this.npcs);
    }

    public FakePlayerNpc createNpc(String zoneId, String displayName, ServerPlayerEntity at, String worldKey, double x, double y, double z, float yaw, float pitch) {
        String id = "npc" + (this.npcs.size() + 1) + "_" + Long.toHexString(System.currentTimeMillis() & 0xFFFFL);
        FightZone zone = this.get(zoneId);
        FakePlayerNpc npc = FakePlayerNpc.of(id, zone != null ? zone.id : zoneId, displayName, worldKey, x, y, z, yaw, pitch, null);
        this.npcs.add(npc);
        npc.spawn(PvPCore.get().server());
        // 3.0.8: show the live player count under the new NPC immediately.
        this.updateNpcCounts();
        this.save();
        return npc;
    }

    public boolean removeNpc(String idOrName) {
        MinecraftServer server = PvPCore.get().server();
        for (FakePlayerNpc npc : this.npcs) {
            if (!npc.npcId.equalsIgnoreCase(idOrName) && !TextUtil.stripColor(npc.displayName).equalsIgnoreCase(idOrName)) continue;
            npc.despawn(server, true);
            this.npcs.remove(npc);
            this.save();
            return true;
        }
        return false;
    }

    public FakePlayerNpc nearestNpc(ServerPlayerEntity player, double maxDistance) {
        FakePlayerNpc nearest = null;
        double best = maxDistance * maxDistance;
        for (FakePlayerNpc npc : this.npcs) {
            double d;
            if (!npc.isSpawned() || !((d = npc.entity().squaredDistanceTo((Entity)player)) <= best)) continue;
            best = d;
            nearest = npc;
        }
        return nearest;
    }

    public boolean isNpc(Entity entity) {
        if (!(entity instanceof ServerPlayerEntity)) {
            return false;
        }
        for (FakePlayerNpc npc : this.npcs) {
            if (!npc.matches(entity)) continue;
            return true;
        }
        return false;
    }

    public boolean onNpcInteract(ServerPlayerEntity clicker, Entity clicked) {
        for (FakePlayerNpc npc : this.npcs) {
            if (!npc.matches(clicked)) continue;
            FightZone zone = this.get(npc.zoneId);
            if (zone == null || !zone.enabled) {
                clicker.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("zone.npc-unavailable")), false);
                return true;
            }
            PvPCore.get().server().execute(() -> this.join(clicker, zone));
            return true;
        }
        return false;
    }

    public void onPlayerJoin(ServerPlayerEntity player) {
        MinecraftServer server = PvPCore.get().server();
        for (FakePlayerNpc npc : this.npcs) {
            if (!npc.isSpawned()) continue;
            npc.hideFromTabList(server);
        }
    }

    public boolean isInZone(ServerPlayerEntity player) {
        return player != null && this.memberZone.containsKey(player.getUuid());
    }

    public FightZone zoneOf(ServerPlayerEntity player) {
        if (player == null) {
            return null;
        }
        String id = this.memberZone.get(player.getUuid());
        return id == null ? null : this.zones.get(id);
    }

    public List<ServerPlayerEntity> membersOf(FightZone zone) {
        ArrayList<ServerPlayerEntity> out = new ArrayList<ServerPlayerEntity>();
        if (zone != null && PvPCore.get().server() != null) {
            for (Map.Entry<UUID, String> e : this.memberZone.entrySet()) {
                ServerPlayerEntity p;
                if (!e.getValue().equals(zone.id) || (p = PvPCore.get().server().getPlayerManager().getPlayer(e.getKey())) == null) continue;
                out.add(p);
            }
        }
        return out;
    }

    public boolean join(ServerPlayerEntity player, FightZone zone) {
        if (player == null || zone == null || !zone.enabled) {
            return false;
        }
        PvPCore core = PvPCore.get();
        if (core.duelManager().duelOf(player) != null) {
            player.sendMessage((Text)Text.literal((String)core.messages().get("zone.join-in-duel")), false);
            return false;
        }
        if (core.spectateManager().isSpectating(player)) {
            core.spectateManager().returnPlayer(player);
        } else {
            PlayerState st = core.playerManager().state(player);
            if (st == PlayerState.DUELING) {
                player.sendMessage((Text)Text.literal((String)core.messages().get("zone.join-in-duel")), false);
                return false;
            }
        }
        core.queueManager().remove(player);
        ServerWorld world = TeleportUtil.world(core.server(), zone.world);
        if (world == null) {
            player.sendMessage((Text)Text.literal((String)core.messages().get("zone.world-missing", Map.of("zone", zone.id))), false);
            return false;
        }
        FightZone oldZone = this.zoneOf(player);
        if (oldZone != null && oldZone.id.equals(zone.id)) {
            this.respawnInZone(player, zone, false);
            return true;
        }
        if (oldZone != null) {
            this.detachMember(player, oldZone, false);
        } else {
            core.playerManager().snapshotAndClear(player);
        }
        FightZone.ZoneMember rec = zone.members.computeIfAbsent(player.getUuid().toString(), u -> new FightZone.ZoneMember());
        rec.name = player.getGameProfile().name();
        this.memberZone.put(player.getUuid(), zone.id);
        this.attachMember(player, zone);
        this.save();
        return true;
    }

    private void attachMember(ServerPlayerEntity player, FightZone zone) {
        PvPCore core = PvPCore.get();
        core.playerManager().setState(player, PlayerState.ZONE);
        if (player.interactionManager.getGameMode() != GameMode.SURVIVAL) {
            player.changeGameMode(GameMode.SURVIVAL);
        }
        try {
            core.teamColors().applyZoneLayout(player, zone.id);
        }
        catch (Throwable t) {
            PvPCoreMod.LOGGER.warn("Could not apply zone nametag layout: {}", (Object)t.getMessage());
        }
        this.respawnInZone(player, zone, true);
        player.sendMessage((Text)Text.literal((String)core.messages().get("zone.joined", Map.of("zone", TextUtil.stripColor(zone.displayName)))), false);
        player.sendMessage((Text)Text.literal((String)core.messages().get("zone.leave-hint")), false);
        DuelScoreboard sb = this.ensureScoreboard(zone);
        sb.addViewer(player);
    }

    private void respawnInZone(ServerPlayerEntity player, FightZone zone, boolean announceJoin) {
        // Guard: only respawn a player who is STILL a member of this zone.
        // Prevents a scheduled respawn (e.g. after a death) from firing after the
        // player already typed /spawn or /leave - that race used to overwrite the
        // freshly restored lobby inventory with the zone kit.
        String currentZoneId = this.memberZone.get(player.getUuid());
        if (currentZoneId == null || !currentZoneId.equals(zone.id)) {
            return;
        }
        PvPCore core = PvPCore.get();
        ServerWorld world = TeleportUtil.world(core.server(), zone.world);
        if (world != null) {
            TeleportUtil.teleport(player, world, zone.x, zone.y, zone.z, zone.yaw, zone.pitch);
        }
        player.clearStatusEffects();
        player.setHealth(player.getMaxHealth());
        player.getHungerManager().setFoodLevel(20);
        // 3.0.9 fastheal fix: saturation 0 - saturation > 0 with full food arms
        // vanilla's fast saturated regeneration (up to 1 HP per 10 ticks), which
        // made sword FFA fights heal far too fast. Normal slow regen only.
        player.getHungerManager().setSaturationLevel(0.0f);
        player.setFireTicks(0);
        player.setFrozenTicks(0);
        player.fallDistance = 0.0;
        player.deathTime = 0;
        player.hurtTime = 0;
        try {
            core.guiManager().close(player);
            if (player.currentScreenHandler != player.playerScreenHandler) {
                player.closeHandledScreen();
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        boolean kitted = this.giveZoneKit(player, zone);
        if (!kitted && announceJoin && !zone.mode.equalsIgnoreCase("fixed")) {
            player.sendMessage((Text)Text.literal((String)core.messages().get("zone.kit-pick-hint")), false);
            try {
                player.sendMessage((Text)Text.literal((String)core.messages().get("zone.layout-hint")), false);
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            try {
                new ZoneKitGui(player, zone).open(player);
            }
            catch (Throwable t) {
                PvPCoreMod.LOGGER.warn("Could not open zone kit picker: {}", (Object)t.getMessage());
            }
        }
        if (kitted) {
            try {
                player.playerScreenHandler.updateToClient();
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
    }

    public boolean giveZoneKit(ServerPlayerEntity player, FightZone zone) {
        Kit kit;
        String kitId = null;
        FightZone.ZoneMember rec;
        if (zone.mode.equalsIgnoreCase("fixed")) {
            kitId = zone.fixedKit;
            if (kitId == null || PvPCore.get().kitManager().get(kitId) == null) {
                if (zone.kits != null && !zone.kits.isEmpty()) {
                    for (String cand : zone.kits) {
                        if (PvPCore.get().kitManager().get(cand) == null) continue;
                        kitId = cand;
                        break;
                    }
                }
                if ((kitId == null || PvPCore.get().kitManager().get(kitId) == null) && (rec = zone.members.get(player.getUuid().toString())) != null && rec.kitChoice != null && PvPCore.get().kitManager().get(rec.kitChoice) != null) {
                    kitId = rec.kitChoice;
                }
            }
        } else {
            kitId = this.kitChoice.get(player.getUuid());
            if ((kitId == null || PvPCore.get().kitManager().get(kitId) == null) && (rec = zone.members.get(player.getUuid().toString())) != null && rec.kitChoice != null && PvPCore.get().kitManager().get(rec.kitChoice) != null) {
                kitId = rec.kitChoice;
            }
            if ((kitId == null || PvPCore.get().kitManager().get(kitId) == null) && zone.kits != null && zone.kits.size() == 1) {
                Kit only = PvPCore.get().kitManager().get(zone.kits.get(0));
                String string = kitId = only != null ? only.id : null;
            }
        }
        if (kitId != null && PvPCore.get().kitManager().get(kitId) == null) {
            kitId = null;
        }
        Kit kit2 = kit = kitId == null ? null : PvPCore.get().kitManager().get(kitId);
        if (kit != null) {
            this.applyKit(player, kit);
            return true;
        }
        return false;
    }

    public void setKitChoice(ServerPlayerEntity player, String kitId) {
        this.kitChoice.put(player.getUuid(), kitId);
        FightZone zone = this.zoneOf(player);
        if (zone != null) {
            FightZone.ZoneMember rec = zone.members.get(player.getUuid().toString());
            if (rec != null) {
                rec.kitChoice = kitId;
            }
            this.save();
        }
    }

    private void applyKit(ServerPlayerEntity player, Kit kit) {
        ItemStack st;
        int i;
        // FFA kits use the player's SEPARATE FFA layout (edited via the zone kit picker,
        // right-click), falling back to their regular kit layout, then the kit template.
        List<ItemStack> layout = null;
        com.pvpcore.data.PlayerData data = PvPCore.get().storage().get(player.getUuid(), player.getGameProfile().name());
        if (data != null) {
            // 3.0.7: the player's explicit FFA layout (right-click editor) wins, but when
            // they have none we now fall back to their REGULAR kit layout (the one saved
            // from the lobby kit editor) so it applies on FFA kits too. The kit template
            // is only used when the player has neither layout.
            layout = data.ffaLoadoutFor(kit.id);
            if (layout == null || layout.isEmpty()) {
                layout = data.loadoutFor(kit.id);
            }
        }
        if (layout != null && !layout.isEmpty()) {
            layout = Kit.padLayout(layout);
        }
        if (layout == null || layout.size() < 41) {
            layout = kit.layoutStacks();
        }
        PlayerInventory inv = player.getInventory();
        for (int i2 = 0; i2 < 36; ++i2) {
            inv.setStack(i2, ItemStack.EMPTY);
        }
        for (int i2 = 36; i2 < 41; ++i2) {
            inv.setStack(i2, ItemStack.EMPTY);
        }
        for (int i2 = 0; i2 < 4; ++i2) {
            ItemStack st2 = layout.get(i2);
            if (st2 == null || st2.isEmpty()) continue;
            inv.setStack(36 + i2, st2.copy());
        }
        ItemStack off = layout.get(40);
        if (off != null && !off.isEmpty()) {
            inv.setStack(40, off.copy());
        }
        for (i = 0; i < 9; ++i) {
            st = layout.get(4 + i);
            if (st == null || st.isEmpty()) continue;
            inv.setStack(i, st.copy());
        }
        for (i = 0; i < 27; ++i) {
            st = layout.get(13 + i);
            if (st == null || st.isEmpty()) continue;
            inv.setStack(9 + i, st.copy());
        }
        inv.setSelectedSlot(0);
        inv.markDirty();
        // FULL resync (updateToClient) - diff-based sendContentUpdates can leave the
        // client showing a stale kit/inventory, which looked like "kit not applied".
        player.playerScreenHandler.updateToClient();
        player.currentScreenHandler.updateToClient();
    }

    public void chooseKit(ServerPlayerEntity player, String kitId) {
        FightZone zone = this.zoneOf(player);
        Kit kit = PvPCore.get().kitManager().get(kitId);
        if (zone != null && kit != null) {
            this.setKitChoice(player, kit.id);
            this.applyKit(player, kit);
            player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("zone.kit-given", Map.of("kit", kit.displayName))), false);
        }
    }

    public void leaveToLobby(ServerPlayerEntity player) {
        this.leaveToLobby(player, false);
    }

    private void leaveToLobby(ServerPlayerEntity player, boolean zoneDeleted) {
        PvPCore core = PvPCore.get();
        FightZone zone = this.zoneOf(player);
        try {
            core.guiManager().close(player);
            if (player.currentScreenHandler != player.playerScreenHandler) {
                player.closeHandledScreen();
            }
        }
        catch (Throwable t) {
            PvPCoreMod.LOGGER.warn("Could not close open GUI on zone exit: {}", (Object)t.getMessage());
        }
        try {
            if (zone != null) {
                this.detachMember(player, zone, true);
            } else {
                this.memberZone.remove(player.getUuid());
            }
        }
        catch (Throwable t) {
            PvPCoreMod.LOGGER.warn("Error detaching zone member: {}", (Object)t.getMessage());
        }
        this.kitChoice.remove(player.getUuid());
        PlayerManager pm = core.playerManager();
        // Restore the pre-zone (lobby) inventory. Order matters: session snapshot
        // first, then the on-disk pending snapshot. If neither exists (edge case,
        // e.g. server restart while in a zone), wipe the zone kit so it can never
        // leak into the lobby.
        boolean restored = false;
        try {
            InventorySnapshot snap = pm.preDuelSnapshot(player);
            if (snap != null) {
                pm.restoreSnapshot(player, snap);
                restored = true;
            } else if (core.snapshotStore().has(player.getUuid())) {
                core.snapshotStore().restore(player);
                restored = true;
            }
        }
        catch (Throwable t) {
            PvPCoreMod.LOGGER.warn("Could not restore pre-zone inventory: {}", (Object)t.getMessage());
        }
        if (!restored) {
            try {
                PlayerInventory inv = player.getInventory();
                for (int i = 0; i < 36; ++i) {
                    inv.setStack(i, ItemStack.EMPTY);
                }
                for (int i = 36; i < 41; ++i) {
                    inv.setStack(i, ItemStack.EMPTY);
                }
                inv.markDirty();
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
        pm.backToLobby(player);
        pm.forceLobbyGameMode(player);
        pm.teleportToLobby(player);
        try {
            // FULL resync - the client must see the restored lobby items immediately.
            player.playerScreenHandler.updateToClient();
            player.currentScreenHandler.updateToClient();
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        player.sendMessage((Text)Text.literal((String)core.messages().get("zone.left")), false);
        this.save();
    }

    public void handleMemberRespawn(ServerPlayerEntity player) {
        FightZone zone = this.zoneOf(player);
        if (zone == null) {
            return;
        }
        try {
            PvPCore.get().playerManager().setState(player, PlayerState.ZONE);
            if (player.interactionManager.getGameMode() != GameMode.SURVIVAL) {
                player.changeGameMode(GameMode.SURVIVAL);
            }
            this.respawnInZone(player, zone, false);
        }
        catch (Throwable t) {
            PvPCoreMod.LOGGER.warn("Could not respawn zone member in zone: {}", (Object)t.getMessage());
        }
    }

    private void detachMember(ServerPlayerEntity player, FightZone zone, boolean removeRecord) {
        DuelScoreboard personal;
        DuelScoreboard sb;
        this.memberZone.remove(player.getUuid());
        if (removeRecord) {
            zone.members.remove(player.getUuid().toString());
        }
        if ((sb = this.scoreboards.get(zone.id)) != null) {
            sb.removeViewer(player);
        }
        if ((personal = this.scoreboards.remove(zone.id + ":" + String.valueOf(player.getUuid()))) != null) {
            personal.removeAll();
        }
        try {
            PvPCore.get().teamColors().clearZoneLayout(player, zone.id);
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    public boolean hasZoneMembership(ServerPlayerEntity player) {
        // 3.0.6: true when ANY enabled zone still lists this player as a member -
        // i.e. they disconnected from an FFA zone in a previous session.
        if (player == null || PvPCore.get().server() == null) {
            return false;
        }
        String uuid = player.getUuid().toString();
        for (FightZone zone : this.zones.values()) {
            if (!zone.enabled || !zone.members.containsKey(uuid)) continue;
            return true;
        }
        return false;
    }

    public void removeMembership(ServerPlayerEntity player) {
        // 3.0.6: fully removes the player's zone membership (runtime + persisted
        // record). Used by the login cleanup so a reconnecting player is cleanly
        // out of the zone instead of being thrown back into the fight.
        if (player == null) {
            return;
        }
        FightZone zone = this.zoneOf(player);
        if (zone != null) {
            this.detachMember(player, zone, true);
        } else {
            String uuid = player.getUuid().toString();
            for (FightZone z : this.zones.values()) {
                z.members.remove(uuid);
            }
        }
        this.kitChoice.remove(player.getUuid());
        this.save();
    }

    public void onQuit(ServerPlayerEntity player) {
        FightZone zone = this.zoneOf(player);
        if (zone != null) {
            this.detachMember(player, zone, false);
            this.save();
        }
        this.kitChoice.remove(player.getUuid());
    }

    public Boolean allowDamage(ServerPlayerEntity victim, DamageSource source) {
        if (!this.isInZone(victim)) {
            return null;
        }
        Entity entity = source.getAttacker();
        if (entity instanceof ServerPlayerEntity) {
            ServerPlayerEntity attacker = (ServerPlayerEntity)entity;
            return this.isInZone(attacker) && this.memberZone.get(attacker.getUuid()).equals(this.memberZone.get(victim.getUuid()));
        }
        return true;
    }

    public boolean allowDeath(ServerPlayerEntity victim, DamageSource source) {
        ServerPlayerEntity attacker;
        if (!this.isInZone(victim)) {
            return false;
        }
        FightZone zone = this.zoneOf(victim);
        if (zone == null) {
            return false;
        }
        try {
            if (victim.getHealth() <= 0.0f) {
                victim.setHealth(victim.getMaxHealth());
            }
            victim.deathTime = 0;
            victim.hurtTime = 0;
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        try {
            PvPCore.get().guiManager().close(victim);
            if (victim.currentScreenHandler != victim.playerScreenHandler) {
                victim.closeHandledScreen();
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        String killerName = "";
        Entity entity = source.getAttacker();
        if (entity instanceof ServerPlayerEntity && this.isInZone(attacker = (ServerPlayerEntity)entity) && !attacker.getUuid().equals(victim.getUuid())) {
            killerName = attacker.getGameProfile().name();
            FightZone.ZoneStats ks = zone.stats.computeIfAbsent(attacker.getUuid().toString(), u -> new FightZone.ZoneStats(attacker.getGameProfile().name()));
            ks.name = attacker.getGameProfile().name();
            ++ks.kills;
            ++ks.streak;
        }
        FightZone.ZoneStats vs = zone.stats.computeIfAbsent(victim.getUuid().toString(), u -> new FightZone.ZoneStats(victim.getGameProfile().name()));
        vs.name = victim.getGameProfile().name();
        ++vs.deaths;
        vs.streak = 0;
        String message = killerName.isEmpty() ? PvPCore.get().messages().get("zone.death-message", Map.of("player", victim.getGameProfile().name(), "zone", zone.displayName)) : PvPCore.get().messages().get("zone.kill-message", Map.of("player", victim.getGameProfile().name(), "killer", killerName, "zone", zone.displayName));
        for (ServerPlayerEntity member : this.membersOf(zone)) {
            if (member == null) continue;
            member.sendMessage((Text)Text.literal((String)message), false);
        }
        this.save();
        PvPCore.get().server().execute(() -> this.respawnInZone(victim, zone, false));
        return true;
    }

    private DuelScoreboard ensureScoreboard(FightZone zone) {
        return this.scoreboards.computeIfAbsent(zone.id, id -> {
            String obj = ("pvpz_" + id).toLowerCase();
            if (obj.length() > 16) {
                obj = obj.substring(0, 16);
            }
            return new DuelScoreboard(obj, zone.sbTitle);
        });
    }

    public void rebuildScoreboards() {
        for (DuelScoreboard sb : new ArrayList<DuelScoreboard>(this.scoreboards.values())) {
            sb.removeAll();
        }
        this.scoreboards.clear();
        for (FightZone zone : this.zones.values()) {
            DuelScoreboard sb = this.ensureScoreboard(zone);
            for (ServerPlayerEntity member : this.membersOf(zone)) {
                sb.addViewer(member);
            }
        }
    }

    private void updateScoreboards() {
        for (FightZone zone : this.zones.values()) {
            List<ServerPlayerEntity> members = this.membersOf(zone);
            if (members.isEmpty()) continue;
            DuelScoreboard sb = this.ensureScoreboard(zone);
            List<Map.Entry<FightZone.ZoneStats, String>> top = this.top10(zone);
            for (ServerPlayerEntity member : members) {
                FightZone.ZoneStats stats = zone.stats.get(member.getUuid().toString());
                if (stats == null) {
                    stats = new FightZone.ZoneStats(member.getGameProfile().name());
                }
                this.sendMemberLines(sb, zone, member, stats, members.size(), top);
            }
        }
    }

    private void sendMemberLines(DuelScoreboard shared, FightZone zone, ServerPlayerEntity member, FightZone.ZoneStats stats, int online, List<Map.Entry<FightZone.ZoneStats, String>> top) {
        String plainZone = TextUtil.stripColor(zone.displayName);
        ArrayList<String> lines = new ArrayList<String>();
        int shown = 0;
        for (String line : zone.sbLines) {
            String out = line;
            if (out.contains("{top_")) {
                String value = shown < top.size() ? "&e#" + (shown + 1) + " &f" + top.get(shown).getValue() + " &7- &a" + top.get((int)shown).getKey().kills : "&8#" + (shown + 1) + " &7-";
                out = out.replace("{top_" + (shown + 1) + "}", value);
                ++shown;
            }
            out = out.replace("{player}", member.getGameProfile().name());
            out = out.replace("{zone}", plainZone);
            out = out.replace("{online}", String.valueOf(online));
            out = out.replace("{kills}", String.valueOf(stats.kills));
            out = out.replace("{deaths}", String.valueOf(stats.deaths));
            out = out.replace("{streak}", String.valueOf(stats.streak));
            // 3.0.7/3.0.8: {ping} is the viewer's live latency, {uptime}/{tps} are server stats.
            out = out.replace("{ping}", String.valueOf(ServerStats.ping(member)));
            out = out.replace("{uptime}", ServerStats.uptime(PvPCore.get().server()));
            out = out.replace("{tps}", ServerStats.tps(PvPCore.get().server()));
            lines.add(out);
        }
        String key = zone.id + ":" + String.valueOf(member.getUuid());
        DuelScoreboard target = this.scoreboards.get(key);
        if (target == null) {
            String obj = ("pvzm" + member.getUuid().toString().replace("-", "").substring(0, 10)).toLowerCase();
            target = new DuelScoreboard(obj, zone.sbTitle);
            target.addViewer(member);
            this.scoreboards.put(key, target);
            shared.removeViewer(member);
        }
        target.updateLines(lines);
    }

    public List<Map.Entry<FightZone.ZoneStats, String>> top10(FightZone zone) {
        ArrayList<Map.Entry<FightZone.ZoneStats, String>> out = new ArrayList<Map.Entry<FightZone.ZoneStats, String>>();
        for (Map.Entry<String, FightZone.ZoneStats> e2 : zone.stats.entrySet()) {
            out.add(Map.entry(e2.getValue(), e2.getValue().name));
        }
        out.sort(Comparator.comparing((Map.Entry<FightZone.ZoneStats, String> e) -> ((FightZone.ZoneStats)e.getKey()).kills).reversed());
        while (out.size() > 10) {
            out.remove(out.size() - 1);
        }
        return out;
    }

    /**
     * 3.0.8: keeps the "<count> playing" line under every zone NPC in sync
     * (runs once a second together with the scoreboard refresh).
     */
    private void updateNpcCounts() {
        MinecraftServer server = PvPCore.get().server();
        if (server == null || this.npcs.isEmpty()) {
            return;
        }
        HashMap<String, Integer> counts = new HashMap<String, Integer>();
        for (FakePlayerNpc npc : this.npcs) {
            if (!npc.isSpawned()) continue;
            FightZone zone = this.get(npc.zoneId);
            String line = "";
            if (zone != null && zone.enabled) {
                int count = counts.computeIfAbsent(zone.id, id -> this.membersOf(this.zones.get(id)).size());
                line = PvPCore.get().messages().plain("zone.npc-count", Map.of("count", String.valueOf(count), "zone", TextUtil.stripColor(zone.displayName)));
            }
            npc.updateCountLine(server, line);
        }
    }

    public void tick() {
        ++this.tick;
        MinecraftServer server = PvPCore.get().server();
        if (server != null) {
            ServerPlayerEntity p;
            if (this.tick % 10L == 0L) {
                for (Map.Entry<UUID, String> e : Map.copyOf(this.memberZone).entrySet()) {
                    ServerWorld world;
                    p = server.getPlayerManager().getPlayer(e.getKey());
                    FightZone zone = this.zones.get(e.getValue());
                    if (p == null || zone == null || (world = TeleportUtil.world(server, zone.world)) == null || p.getEntityWorld() != world || !(p.getY() < (double)world.getBottomY() - 8.0)) continue;
                    this.allowDeath(p, p.getEntityWorld().getDamageSources().outOfWorld());
                }
            }
            if (this.tick % 5L == 0L && PvPCore.get().config().zone.showHeartsBelowName) {
                for (Map.Entry<UUID, String> e : Map.copyOf(this.memberZone).entrySet()) {
                    p = server.getPlayerManager().getPlayer(e.getKey());
                    if (p == null || !this.zones.containsKey(e.getValue())) continue;
                    try {
                        PvPCore.get().teamColors().updateZoneHealthSuffix(p, e.getValue());
                    }
                    catch (Throwable throwable) {}
                }
            }
            if (this.tick % 20L == 0L) {
                this.updateScoreboards();
                this.updateNpcCounts();
            }
            if (this.tick % 40L == 0L) {
                for (FakePlayerNpc npc : this.npcs) {
                    if (npc.isSpawned()) {
                        npc.resetPosition();
                        continue;
                    }
                    npc.spawn(server);
                }
            }
        }
    }

    public void onServerStarted(MinecraftServer server) {
        this.load();
        for (FakePlayerNpc npc : this.npcs) {
            npc.spawn(server);
        }
        this.updateNpcCounts();
    }

    public void shutdown() {
        MinecraftServer server = PvPCore.get().server();
        for (FakePlayerNpc npc : this.npcs) {
            npc.despawn(server, true);
        }
        for (DuelScoreboard sb : this.scoreboards.values()) {
            sb.removeAll();
        }
        this.scoreboards.clear();
        this.memberZone.clear();
        this.kitChoice.clear();
        this.save();
    }

    public void save() {
        try {
            JsonObject root = new JsonObject();
            JsonArray zoneArr = new JsonArray();
            for (FightZone fightZone : this.zones.values()) {
                fightZone.normalize();
                zoneArr.add(GSON.toJsonTree((Object)fightZone));
            }
            root.add("zones", (JsonElement)zoneArr);
            JsonArray npcArr = new JsonArray();
            for (FakePlayerNpc npc : this.npcs) {
                JsonObject o = new JsonObject();
                o.addProperty("id", npc.npcId);
                o.addProperty("zone", npc.zoneId);
                o.addProperty("name", npc.displayName);
                o.addProperty("world", npc.world);
                o.addProperty("x", (Number)npc.x);
                o.addProperty("y", (Number)npc.y);
                o.addProperty("z", (Number)npc.z);
                o.addProperty("yaw", (Number)Float.valueOf(npc.yaw));
                o.addProperty("pitch", (Number)Float.valueOf(npc.pitch));
                o.addProperty("uuid", npc.entityUuid.toString());
                npcArr.add((JsonElement)o);
            }
            root.add("npcs", (JsonElement)npcArr);
            Files.createDirectories(this.file.getParent(), new FileAttribute[0]);
            Path path = this.file.resolveSibling(String.valueOf(this.file.getFileName()) + ".tmp");
            Files.writeString(path, (CharSequence)GSON.toJson((JsonElement)root), StandardCharsets.UTF_8, new OpenOption[0]);
            Files.move(path, this.file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        }
        catch (Exception var5) {
            PvPCoreMod.LOGGER.error("Could not save zones.json", (Throwable)var5);
        }
    }

    private void load() {
        try {
            JsonObject root;
            this.zones.clear();
            this.npcs.clear();
            if (Files.exists(this.file, new LinkOption[0]) && (root = (JsonObject)GSON.fromJson(Files.readString(this.file, StandardCharsets.UTF_8), JsonObject.class)) != null) {
                if (root.has("zones") && root.get("zones").isJsonArray()) {
                    for (JsonElement el : root.getAsJsonArray("zones")) {
                        FightZone zone = (FightZone)GSON.fromJson(el, FightZone.class);
                        if (zone == null || zone.id == null) continue;
                        zone.normalize();
                        // 3.0.7: one-time migration so existing zones show the new ping line.
                        zone.migrateSbPingLine();
                        // 3.0.8: one-time migration so existing zones show the uptime line.
                        zone.migrateSbUptimeLine();
                        this.zones.put(zone.id, zone);
                    }
                }
                if (root.has("npcs") && root.get("npcs").isJsonArray()) {
                    for (JsonElement elx : root.getAsJsonArray("npcs")) {
                        JsonObject o = elx.getAsJsonObject();
                        UUID uuid = null;
                        try {
                            uuid = UUID.fromString(o.get("uuid").getAsString());
                        }
                        catch (Exception exception) {
                            // empty catch block
                        }
                        FakePlayerNpc npc = FakePlayerNpc.of(o.get("id").getAsString(), o.get("zone").getAsString(), o.get("name").getAsString(), o.get("world").getAsString(), o.get("x").getAsDouble(), o.get("y").getAsDouble(), o.get("z").getAsDouble(), o.get("yaw").getAsFloat(), o.get("pitch").getAsFloat(), uuid);
                        this.npcs.add(npc);
                    }
                }
            }
            PvPCoreMod.LOGGER.info("Loaded zones.json ({} zones, {} npcs)", (Object)this.zones.size(), (Object)this.npcs.size());
        }
        catch (Exception var5) {
            PvPCoreMod.LOGGER.error("Could not load zones.json", (Throwable)var5);
        }
    }

    public List<Kit> zoneKits(FightZone zone) {
        List<Kit> all = PvPCore.get().kitManager().all().stream().filter(k -> k.enabled).toList();
        if (zone.kits == null || zone.kits.isEmpty()) {
            return all;
        }
        ArrayList<Kit> out = new ArrayList<Kit>();
        for (String id : zone.kits) {
            Kit k2 = PvPCore.get().kitManager().get(id);
            if (k2 == null || !k2.enabled) continue;
            out.add(k2);
        }
        return out;
    }
}

