/*
 * Decompiled with CFR 0.152.
 */
package com.pvpcore.ffa;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class FightZone {
    public String id = "zone";
    public String displayName = "&fZone";
    public String world = "minecraft:overworld";
    public double x = 0.0;
    public double y = 64.0;
    public double z = 0.0;
    public float yaw = 0.0f;
    public float pitch = 0.0f;
    public boolean enabled = true;
    public String mode = "picker";
    public String fixedKit = "";
    public List<String> kits = new ArrayList<String>();
    public String sbTitle = "&6&lFFA";
    public List<String> sbLines = new ArrayList<String>();
    // 3.0.7: scoreboard-config version. 0 = saved before the {ping} line existed
    // (migrateSbPingLine() upgrades it to 1 exactly once per zone).
    // 3.0.8: 1 = saved before the {uptime} line existed (migrateSbUptimeLine()
    // upgrades it to 2 exactly once per zone).
    public int sbVer = 0;
    public Map<String, ZoneStats> stats = new LinkedHashMap<String, ZoneStats>();
    public Map<String, ZoneMember> members = new LinkedHashMap<String, ZoneMember>();

    public FightZone() {
    }

    public FightZone(String id, String displayName) {
        this.id = id;
        this.displayName = displayName;
        this.sbTitle = "&6&l" + displayName.replace("&", "");
        this.sbLines = FightZone.defaultLines();
        this.sbVer = 2;
    }

    public static List<String> defaultLines() {
        ArrayList<String> lines = new ArrayList<String>();
        lines.add("&8&m--------------");
        lines.add("&7Zone: &f{zone}");
        lines.add("&7Players: &f{online}");
        lines.add("");
        lines.add("&7Kills: &a{kills} &7Deaths: &c{deaths}");
        lines.add("&7Streak: &f{streak}");
        lines.add("&7Ping: &f{ping}ms");
        lines.add("&7Uptime: &f{uptime}");
        lines.add("&8&m--------------");
        return lines;
    }

    public static List<String> defaultTop10Lines() {
        ArrayList<String> lines = new ArrayList<String>();
        lines.add("&8&m--------------");
        lines.add("&7Top killers");
        lines.add("{top_1}");
        lines.add("{top_2}");
        lines.add("{top_3}");
        lines.add("&8&m--------------");
        return lines;
    }

    public void normalize() {
        if (this.id == null || this.id.isBlank()) {
            this.id = "zone";
        }
        if (this.displayName == null || this.displayName.isBlank()) {
            this.displayName = "&f" + this.id;
        }
        if (this.sbTitle == null || this.sbTitle.isBlank()) {
            this.sbTitle = "&6&lFFA";
        }
        if (this.sbLines == null || this.sbLines.isEmpty()) {
            this.sbLines = FightZone.defaultLines();
        }
        if (this.mode == null || this.mode.isBlank()) {
            this.mode = "picker";
        }
        if (this.kits == null) {
            this.kits = new ArrayList<String>();
        }
        if (this.stats == null) {
            this.stats = new LinkedHashMap<String, ZoneStats>();
        }
        if (this.members == null) {
            this.members = new LinkedHashMap<String, ZoneMember>();
        }
    }

    /**
     * 3.0.7: one-time migration for zones saved before the {ping} scoreboard line
     * existed. Inserts "&7Ping: &f{ping}ms" into the existing lines (after the streak
     * line, or before the closing separator). Tracked via sbVer, so admins can freely
     * remove the line afterwards without it coming back on the next boot.
     */
    public void migrateSbPingLine() {
        if (this.sbVer >= 1) {
            return;
        }
        if (this.sbLines != null && !this.sbLines.isEmpty() && this.sbLines.stream().noneMatch(l -> l != null && l.contains("{ping}"))) {
            int insertAt = -1;
            for (int i = 0; i < this.sbLines.size(); ++i) {
                String l = this.sbLines.get(i);
                if (l == null || !l.contains("{streak}")) continue;
                insertAt = i + 1;
                break;
            }
            if (insertAt < 0) {
                for (int i = this.sbLines.size() - 1; i >= 0; --i) {
                    String l = this.sbLines.get(i);
                    if (l == null || !l.contains("&m")) continue;
                    insertAt = i;
                    break;
                }
            }
            if (insertAt < 0) {
                insertAt = this.sbLines.size();
            }
            this.sbLines.add(insertAt, "&7Ping: &f{ping}ms");
        }
        this.sbVer = 1;
    }

    /**
     * 3.0.8: one-time migration for zones saved before the {uptime} scoreboard
     * line existed. Inserts "&7Uptime: &f{uptime}" below the ping line (or before
     * the closing separator). Tracked via sbVer, so admins can freely remove or
     * move the line afterwards without it coming back on the next boot.
     */
    public void migrateSbUptimeLine() {
        if (this.sbVer >= 2) {
            return;
        }
        if (this.sbLines != null && !this.sbLines.isEmpty() && this.sbLines.stream().noneMatch(l -> l != null && l.contains("{uptime}"))) {
            int insertAt = -1;
            for (int i = 0; i < this.sbLines.size(); ++i) {
                String l = this.sbLines.get(i);
                if (l == null || !l.contains("{ping}")) continue;
                insertAt = i + 1;
                break;
            }
            if (insertAt < 0) {
                for (int i = this.sbLines.size() - 1; i >= 0; --i) {
                    String l = this.sbLines.get(i);
                    if (l == null || !l.contains("&m")) continue;
                    insertAt = i;
                    break;
                }
            }
            if (insertAt < 0) {
                insertAt = this.sbLines.size();
            }
            this.sbLines.add(insertAt, "&7Uptime: &f{uptime}");
        }
        this.sbVer = 2;
    }

    public static class ZoneMember {
        public String name = "?";
        public String kitChoice = "";
    }

    public static class ZoneStats {
        public String name = "?";
        public int kills = 0;
        public int deaths = 0;
        public int streak = 0;

        public ZoneStats() {
        }

        public ZoneStats(String name) {
            this.name = name;
        }
    }
}

