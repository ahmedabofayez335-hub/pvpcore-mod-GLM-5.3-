/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.effect.StatusEffectInstance
 *  net.minecraft.entity.effect.StatusEffects
 *  net.minecraft.server.PlayerManager
 *  net.minecraft.server.network.ServerPlayerEntity
 *  net.minecraft.server.world.ServerWorld
 *  net.minecraft.text.Text
 *  net.minecraft.util.Formatting
 *  net.minecraft.world.GameMode
 */
package com.pvpcore.spectate;

import com.pvpcore.PvPCore;
import com.pvpcore.arena.Arena;
import com.pvpcore.config.Messages;
import com.pvpcore.duel.Duel;
import com.pvpcore.duel.DuelState;
import com.pvpcore.player.PlayerManager;
import com.pvpcore.player.PlayerState;
import com.pvpcore.util.ChatButtons;
import com.pvpcore.util.TeleportUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.GameMode;

public final class SpectateManager {
    private final Map<UUID, Spectating> spectating = new ConcurrentHashMap<UUID, Spectating>();

    public boolean isSpectating(ServerPlayerEntity player) {
        return player != null && this.spectating.containsKey(player.getUuid());
    }

    public Duel spectatedDuel(ServerPlayerEntity player) {
        Spectating s;
        Spectating spectating = s = player == null ? null : this.spectating.get(player.getUuid());
        if (s == null) {
            return null;
        }
        for (Duel d : PvPCore.get().duelManager().allDuels()) {
            if (!d.id.equals(s.duelId)) continue;
            return d;
        }
        return null;
    }

    public List<ServerPlayerEntity> spectatorsOf(Duel duel) {
        ArrayList<ServerPlayerEntity> out = new ArrayList<ServerPlayerEntity>();
        net.minecraft.server.PlayerManager pm = PvPCore.get().server().getPlayerManager();
        for (Map.Entry<UUID, Spectating> e : this.spectating.entrySet()) {
            ServerPlayerEntity p;
            if (!e.getValue().duelId.equals(duel.id) || (p = pm.getPlayer(e.getKey())) == null) continue;
            out.add(p);
        }
        return out;
    }

    public boolean join(ServerPlayerEntity player, Duel duel) {
        if (!PvPCore.get().config().spectate.enabled) {
            return false;
        }
        if (duel != null && (duel.state == DuelState.FIGHTING || duel.state == DuelState.COUNTDOWN)) {
            if (duel.isParticipant(player.getUuid())) {
                return false;
            }
            PlayerManager pm = PvPCore.get().playerManager();
            if (pm.state(player) == PlayerState.DUELING) {
                return false;
            }
            Spectating s = new Spectating(duel.id);
            s.world = player.getEntityWorld().getRegistryKey().getValue().toString();
            s.x = player.getX();
            s.y = player.getY();
            s.z = player.getZ();
            s.yaw = player.getYaw();
            s.pitch = player.getPitch();
            s.prevGameMode = player.interactionManager.getGameMode() == GameMode.SPECTATOR ? GameMode.byId((String)PvPCore.get().config().lobby.gameMode, (GameMode)GameMode.ADVENTURE) : player.interactionManager.getGameMode();
            this.spectating.put(player.getUuid(), s);
            PvPCore.get().queueManager().remove(player);
            pm.setState(player, PlayerState.SPECTATING);
            pm.markModSpectator(player, true);
            Arena arena = duel.arena;
            ServerWorld world = TeleportUtil.world(PvPCore.get().server(), arena.world);
            if (world == null) {
                world = player.getEntityWorld();
            }
            double sx = arena.spectatorSet ? arena.spectatorX : (arena.spawn1X + arena.spawn2X) / 2.0;
            double sy = arena.spectatorSet ? arena.spectatorY : Math.max(arena.spawn1Y, arena.spawn2Y) + 6.0;
            double sz = arena.spectatorSet ? arena.spectatorZ : (arena.spawn1Z + arena.spawn2Z) / 2.0;
            float syaw = arena.spectatorSet ? arena.spectatorYaw : 0.0f;
            float spitch = arena.spectatorSet ? arena.spectatorPitch : 25.0f;
            TeleportUtil.teleport(player, world, sx, sy, sz, syaw, spitch);
            player.clearStatusEffects();
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, -1, 0, true, false));
            if (player.interactionManager.getGameMode() != GameMode.SPECTATOR) {
                player.changeGameMode(GameMode.SPECTATOR);
            }
            if (duel.scoreboard != null) {
                duel.scoreboard.addViewer(player);
            }
            Messages mm = PvPCore.get().messages();
            player.sendMessage((Text)Text.literal((String)mm.get("spectate.started", Map.of("player1", duel.firstAName(), "player2", duel.firstBName()))), false);
            player.sendMessage((Text)Text.literal((String)mm.get("spectate.return")), false);
            PvPCore.get().playerManager().refreshLobby(player);
            return true;
        }
        return false;
    }

    public void returnPlayer(ServerPlayerEntity player) {
        Spectating s = this.spectating.remove(player.getUuid());
        if (s != null) {
            player.clearStatusEffects();
            PvPCore.get().playerManager().revivePlayer(player);
            if (s.prevGameMode != null && s.prevGameMode != GameMode.SPECTATOR && player.interactionManager.getGameMode() != s.prevGameMode) {
                player.changeGameMode(s.prevGameMode);
                PvPCore.get().playerManager().markModSpectator(player, false);
            } else {
                PvPCore.get().playerManager().forceLobbyGameMode(player);
            }
            PvPCore.get().playerManager().teleportToLobby(player);
            Duel duel = PvPCore.get().duelManager().duelOf(s.duelId);
            if (duel != null && duel.scoreboard != null) {
                duel.scoreboard.removeViewer(player);
            }
            PvPCore.get().playerManager().setState(player, PlayerState.LOBBY);
            player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("spectate.ended")), false);
            PvPCore.get().playerManager().refreshLobby(player);
        }
    }

    public void forceSpectate(ServerPlayerEntity player, Duel duel) {
        if (player != null && duel != null) {
            Spectating s = new Spectating(duel.id);
            s.autoReturn = false;
            s.returnToLobby = true;
            s.prevGameMode = player.interactionManager.getGameMode() == GameMode.SPECTATOR ? GameMode.byId((String)PvPCore.get().config().lobby.gameMode, (GameMode)GameMode.ADVENTURE) : player.interactionManager.getGameMode();
            this.spectating.put(player.getUuid(), s);
            PvPCore.get().queueManager().remove(player);
            PvPCore.get().playerManager().setState(player, PlayerState.SPECTATING);
            PvPCore.get().playerManager().markModSpectator(player, true);
            Arena arena = duel.arena;
            ServerWorld world = TeleportUtil.world(PvPCore.get().server(), arena.world);
            if (world == null) {
                world = player.getEntityWorld();
            }
            double sx = arena.spectatorSet ? arena.spectatorX : (arena.spawn1X + arena.spawn2X) / 2.0;
            double sy = arena.spectatorSet ? arena.spectatorY : Math.max(arena.spawn1Y, arena.spawn2Y) + 6.0;
            double sz = arena.spectatorSet ? arena.spectatorZ : (arena.spawn1Z + arena.spawn2Z) / 2.0;
            float syaw = arena.spectatorSet ? arena.spectatorYaw : 0.0f;
            float spitch = arena.spectatorSet ? arena.spectatorPitch : 25.0f;
            TeleportUtil.teleport(player, world, sx, sy, sz, syaw, spitch);
            player.clearStatusEffects();
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, -1, 0, true, false));
            if (player.interactionManager.getGameMode() != GameMode.SPECTATOR) {
                player.changeGameMode(GameMode.SPECTATOR);
            }
            Messages mm = PvPCore.get().messages();
            player.sendMessage((Text)Text.literal((String)mm.get("spectate.loser-started")), false);
            player.sendMessage((Text)ChatButtons.line(new Text[]{ChatButtons.button(mm.get("spectate.loser-return-button"), "/leave", mm.get("spectate.loser-return-hover"), Formatting.GREEN)}), false);
            PvPCore.get().playerManager().refreshLobby(player);
        }
    }

    public void duelEnded(Duel duel) {
        ArrayList<UUID> toReturn = new ArrayList<UUID>();
        for (Map.Entry<UUID, Spectating> e : this.spectating.entrySet()) {
            if (!e.getValue().duelId.equals(duel.id)) continue;
            toReturn.add(e.getKey());
        }
        net.minecraft.server.PlayerManager pm = PvPCore.get().server().getPlayerManager();
        for (UUID u : toReturn) {
            ServerPlayerEntity p = pm.getPlayer(u);
            if (p == null) continue;
            this.returnPlayer(p);
        }
    }

    public void tick() {
        net.minecraft.server.PlayerManager pm = PvPCore.get().server().getPlayerManager();
        for (Map.Entry<UUID, Spectating> e : Map.copyOf(this.spectating).entrySet()) {
            ServerPlayerEntity p = pm.getPlayer(e.getKey());
            if (p == null) continue;
            if (p.getHungerManager().getFoodLevel() < 20) {
                p.getHungerManager().setFoodLevel(20);
            }
            if (PvPCore.get().duelManager().allDuels().stream().anyMatch(d -> d.id.equals(((Spectating)e.getValue()).duelId) && d.state != DuelState.FINISHED) || !e.getValue().autoReturn) continue;
            this.returnPlayer(p);
        }
    }

    public void clearStale(ServerPlayerEntity player) {
        Spectating s = this.spectating.get(player.getUuid());
        if (s != null && this.spectatedDuel(player) == null) {
            this.spectating.remove(player.getUuid());
            if (player != null && player.interactionManager.getGameMode() == GameMode.SPECTATOR) {
                PvPCore.get().playerManager().forceLobbyGameMode(player);
            }
        }
    }

    public void onQuit(ServerPlayerEntity player) {
        Spectating s = this.spectating.remove(player.getUuid());
        if (s != null && player != null && player.interactionManager.getGameMode() == GameMode.SPECTATOR) {
            PvPCore.get().playerManager().forceLobbyGameMode(player);
        }
    }

    public boolean isolateSpectatorChat() {
        return true;
    }

    public void shutdown() {
        this.spectating.clear();
    }

    public static class Spectating {
        public final UUID duelId;
        public String world;
        public double x;
        public double y;
        public double z;
        public float yaw;
        public float pitch;
        public boolean autoReturn = true;
        public boolean returnToLobby = false;
        public GameMode prevGameMode = GameMode.SURVIVAL;

        public Spectating(UUID duelId) {
            this.duelId = duelId;
        }
    }
}

