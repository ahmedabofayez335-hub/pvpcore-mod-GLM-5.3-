/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.CommandDispatcher
 *  com.mojang.brigadier.arguments.ArgumentType
 *  com.mojang.brigadier.arguments.BoolArgumentType
 *  com.mojang.brigadier.arguments.IntegerArgumentType
 *  com.mojang.brigadier.arguments.StringArgumentType
 *  com.mojang.brigadier.builder.ArgumentBuilder
 *  com.mojang.brigadier.builder.LiteralArgumentBuilder
 *  com.mojang.brigadier.builder.RequiredArgumentBuilder
 *  com.mojang.brigadier.context.CommandContext
 *  com.mojang.brigadier.exceptions.CommandSyntaxException
 *  com.mojang.brigadier.suggestion.SuggestionProvider
 *  com.mojang.brigadier.suggestion.SuggestionsBuilder
 *  net.minecraft.command.CommandSource
 *  net.minecraft.command.argument.EntityArgumentType
 *  net.minecraft.server.PlayerManager
 *  net.minecraft.server.command.CommandManager
 *  net.minecraft.server.command.ServerCommandSource
 *  net.minecraft.server.network.ServerPlayerEntity
 *  net.minecraft.server.world.ServerWorld
 *  net.minecraft.text.Text
 */
package com.pvpcore.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import com.pvpcore.PvPCore;
import com.pvpcore.arena.Arena;
import com.pvpcore.audit.AuditLog;
import com.pvpcore.config.MainConfig;
import com.pvpcore.config.Messages;
import com.pvpcore.data.PlayerData;
import com.pvpcore.duel.Duel;
import com.pvpcore.ffa.FakePlayerNpc;
import com.pvpcore.ffa.FightZone;
import com.pvpcore.gui.guis.AdminGui;
import com.pvpcore.gui.guis.ArenaListGui;
import com.pvpcore.gui.guis.KitPickerGui;
import com.pvpcore.gui.guis.LeaderboardGui;
import com.pvpcore.gui.guis.PartySplitGui;
import com.pvpcore.gui.guis.PlayerPickerGui;
import com.pvpcore.gui.guis.ProfileGui;
import com.pvpcore.gui.guis.ScoreboardSettingsGui;
import com.pvpcore.gui.guis.SpectateGui;
import com.pvpcore.gui.guis.StatsGui;
import com.pvpcore.gui.guis.ZoneKitGui;
import com.pvpcore.kit.Kit;
import com.pvpcore.kit.KitManager;
import com.pvpcore.leaderboard.LeaderboardManager;
import com.pvpcore.party.PartyManager;
import com.pvpcore.player.PlayerManager;
import com.pvpcore.player.PlayerState;
import com.pvpcore.queue.QueueManager;
import com.pvpcore.util.ItemCodecUtil;
import com.pvpcore.util.TeleportUtil;
import com.pvpcore.util.TextUtil;
import java.time.Instant;
import java.util.Collection;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Stream;
import net.minecraft.command.CommandSource;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.registry.Registries;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public final class PvPCommands {
    private static final SuggestionProvider<ServerCommandSource> KITS = (ctx, builder) -> CommandSource.suggestMatching(PvPCore.get().kitManager().all().stream().map(k -> k.id), (SuggestionsBuilder)builder);
    private static final SuggestionProvider<ServerCommandSource> ARENAS = (ctx, builder) -> CommandSource.suggestMatching(PvPCore.get().arenaManager().all().stream().map(a -> a.id), (SuggestionsBuilder)builder);
    private static final SuggestionProvider<ServerCommandSource> PLAYERS = (ctx, builder) -> CommandSource.suggestMatching(((ServerCommandSource)ctx.getSource()).getServer().getPlayerManager().getPlayerList().stream().map(p -> p.getGameProfile().name()), (SuggestionsBuilder)builder);
    private static final SuggestionProvider<ServerCommandSource> LEADERBOARD_TYPES = (ctx, builder) -> CommandSource.suggestMatching(List.of("wins", "elo"), (SuggestionsBuilder)builder);
    private static final SuggestionProvider<ServerCommandSource> ARENA_KITS = (ctx, builder) -> CommandSource.suggestMatching(Stream.concat(Stream.of("any"), PvPCore.get().kitManager().all().stream().map(k -> k.id)).map(String::toLowerCase), (SuggestionsBuilder)builder);
    private static final SuggestionProvider<ServerCommandSource> ZONES = (ctx, builder) -> CommandSource.suggestMatching(PvPCore.get().zoneManager().all().stream().map(z -> z.id), (SuggestionsBuilder)builder);
    private static final SuggestionProvider<ServerCommandSource> NPCS = (ctx, builder) -> CommandSource.suggestMatching(PvPCore.get().zoneManager().npcs().stream().map(n -> n.npcId), (SuggestionsBuilder)builder);
    private static final SuggestionProvider<ServerCommandSource> EFFECTS = (ctx, builder) -> CommandSource.suggestMatching(Registries.STATUS_EFFECT.getIds().stream().map(id -> id.getNamespace().equals("minecraft") ? id.getPath() : id.toString()), (SuggestionsBuilder)builder);

    private PvPCommands() {
    }

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        LiteralArgumentBuilder duelCmd = (LiteralArgumentBuilder)CommandManager.literal((String)"duel").requires(src -> true);
        duelCmd.executes(PvPCommands::duelPicker);
        RequiredArgumentBuilder duelPlayer = CommandManager.argument((String)"player", (ArgumentType)EntityArgumentType.player());
        duelPlayer.executes(ctx -> PvPCommands.duel((CommandContext<ServerCommandSource>)ctx, null, 0));
        RequiredArgumentBuilder duelKit = CommandManager.argument((String)"kit", (ArgumentType)StringArgumentType.word());
        duelKit.suggests(KITS).executes(ctx -> PvPCommands.duel((CommandContext<ServerCommandSource>)ctx, StringArgumentType.getString((CommandContext)ctx, (String)"kit"), 0));
        RequiredArgumentBuilder duelRounds = CommandManager.argument((String)"rounds", (ArgumentType)IntegerArgumentType.integer((int)1));
        duelRounds.executes(ctx -> PvPCommands.duel((CommandContext<ServerCommandSource>)ctx, StringArgumentType.getString((CommandContext)ctx, (String)"kit"), IntegerArgumentType.getInteger((CommandContext)ctx, (String)"rounds")));
        duelKit.then((ArgumentBuilder)duelRounds);
        duelPlayer.then((ArgumentBuilder)duelKit);
        duelCmd.then((ArgumentBuilder)duelPlayer);
        dispatcher.register(duelCmd);
        LiteralArgumentBuilder queueCmd = (LiteralArgumentBuilder)CommandManager.literal((String)"queue").requires(src -> true);
        queueCmd.executes(ctx -> PvPCommands.openQueue((CommandContext<ServerCommandSource>)ctx, false));
        RequiredArgumentBuilder queueKit = CommandManager.argument((String)"kit", (ArgumentType)StringArgumentType.word());
        queueKit.suggests(KITS).executes(ctx -> PvPCommands.queue((CommandContext<ServerCommandSource>)ctx, StringArgumentType.getString((CommandContext)ctx, (String)"kit"), false, 0));
        RequiredArgumentBuilder queueRanked = CommandManager.argument((String)"ranked", (ArgumentType)BoolArgumentType.bool());
        queueRanked.executes(ctx -> PvPCommands.queue((CommandContext<ServerCommandSource>)ctx, StringArgumentType.getString((CommandContext)ctx, (String)"kit"), BoolArgumentType.getBool((CommandContext)ctx, (String)"ranked"), 0));
        RequiredArgumentBuilder queueRounds = CommandManager.argument((String)"rounds", (ArgumentType)IntegerArgumentType.integer((int)1));
        queueRounds.executes(ctx -> PvPCommands.queue((CommandContext<ServerCommandSource>)ctx, StringArgumentType.getString((CommandContext)ctx, (String)"kit"), BoolArgumentType.getBool((CommandContext)ctx, (String)"ranked"), IntegerArgumentType.getInteger((CommandContext)ctx, (String)"rounds")));
        queueRanked.then((ArgumentBuilder)queueRounds);
        queueKit.then((ArgumentBuilder)queueRanked);
        queueCmd.then((ArgumentBuilder)queueKit);
        dispatcher.register(queueCmd);
        LiteralArgumentBuilder rankedCmd = (LiteralArgumentBuilder)CommandManager.literal((String)"ranked").requires(src -> true);
        rankedCmd.executes(ctx -> PvPCommands.openQueue((CommandContext<ServerCommandSource>)ctx, true));
        RequiredArgumentBuilder rankedKit = CommandManager.argument((String)"kit", (ArgumentType)StringArgumentType.word());
        rankedKit.suggests(KITS).executes(ctx -> PvPCommands.queue((CommandContext<ServerCommandSource>)ctx, StringArgumentType.getString((CommandContext)ctx, (String)"kit"), true, 0));
        RequiredArgumentBuilder rankedRounds = CommandManager.argument((String)"rounds", (ArgumentType)IntegerArgumentType.integer((int)1));
        rankedRounds.executes(ctx -> PvPCommands.queue((CommandContext<ServerCommandSource>)ctx, StringArgumentType.getString((CommandContext)ctx, (String)"kit"), true, IntegerArgumentType.getInteger((CommandContext)ctx, (String)"rounds")));
        rankedKit.then((ArgumentBuilder)rankedRounds);
        rankedCmd.then((ArgumentBuilder)rankedKit);
        dispatcher.register(rankedCmd);
        dispatcher.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)CommandManager.literal((String)"leavequeue").requires(src -> true)).executes(PvPCommands::leaveQueue));
        dispatcher.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)CommandManager.literal((String)"leave").requires(src -> true)).executes(PvPCommands::leave));
        dispatcher.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)CommandManager.literal((String)"duelaccept").requires(src -> true)).executes(PvPCommands::duelAccept));
        dispatcher.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)CommandManager.literal((String)"dueldeny").requires(src -> true)).executes(PvPCommands::duelDeny));
        dispatcher.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)CommandManager.literal((String)"profile").requires(src -> true)).executes(ctx -> {
            ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
            if (p != null) {
                new ProfileGui(p, p).open(p);
            }
            return 1;
        }));
        dispatcher.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)CommandManager.literal((String)"stats").requires(src -> true)).executes(ctx -> {
            ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
            if (p != null) {
                new PlayerPickerGui(p, "&8View Stats - Pick a Player", target -> new StatsGui(p, (ServerPlayerEntity)target).open(p)).open(p);
            }
            return 1;
        })).then(CommandManager.argument((String)"player", (ArgumentType)EntityArgumentType.player()).executes(PvPCommands::statsOf)));
        dispatcher.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)CommandManager.literal((String)"leaderboard").requires(src -> true)).executes(ctx -> {
            ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
            if (p != null) {
                new LeaderboardGui(p).open(p);
            }
            return 1;
        })).then(((RequiredArgumentBuilder)CommandManager.argument((String)"type", (ArgumentType)StringArgumentType.word()).suggests(LEADERBOARD_TYPES).executes(ctx -> PvPCommands.leaderboard((CommandContext<ServerCommandSource>)ctx, StringArgumentType.getString((CommandContext)ctx, (String)"type"), "global"))).then(CommandManager.argument((String)"kit", (ArgumentType)StringArgumentType.word()).suggests(KITS).executes(ctx -> PvPCommands.leaderboard((CommandContext<ServerCommandSource>)ctx, StringArgumentType.getString((CommandContext)ctx, (String)"type"), StringArgumentType.getString((CommandContext)ctx, (String)"kit"))))));
        dispatcher.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)CommandManager.literal((String)"spectate").requires(src -> true)).executes(ctx -> {
            ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
            if (p != null) {
                new SpectateGui(p).open(p);
            }
            return 1;
        })).then(CommandManager.argument((String)"player", (ArgumentType)EntityArgumentType.player()).executes(PvPCommands::spectatePlayer)));
        dispatcher.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)CommandManager.literal((String)"lobby").requires(src -> true)).executes(PvPCommands::lobbyTeleport));
        dispatcher.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)CommandManager.literal((String)"spawn").requires(src -> true)).executes(PvPCommands::lobbyTeleport));
        dispatcher.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)CommandManager.literal((String)"party").requires(src -> true)).executes(ctx -> {
            ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
            if (p != null) {
                if (PvPCore.get().partyManager().partyOf(p) == null && PvPCore.get().config().party.autoCreateOnItemClick) {
                    PvPCore.get().partyManager().createParty(p);
                }
                PvPCore.get().partyManager().sendPartyMenu(p);
            }
            return 1;
        })).then(CommandManager.literal((String)"create").executes(PvPCommands::partyCreate))).then(CommandManager.literal((String)"invite").then(CommandManager.argument((String)"player", (ArgumentType)EntityArgumentType.player()).executes(PvPCommands::partyInvite)))).then(CommandManager.literal((String)"accept").executes(PvPCommands::partyAccept))).then(CommandManager.literal((String)"deny").executes(PvPCommands::partyDeny))).then(CommandManager.literal((String)"leave").executes(PvPCommands::partyLeave))).then(CommandManager.literal((String)"kick").then(CommandManager.argument((String)"player", (ArgumentType)EntityArgumentType.player()).executes(PvPCommands::partyKick)))).then(CommandManager.literal((String)"promote").then(CommandManager.argument((String)"player", (ArgumentType)EntityArgumentType.player()).executes(PvPCommands::partyPromote)))).then(CommandManager.literal((String)"disband").executes(PvPCommands::partyDisband))).then(CommandManager.literal((String)"list").executes(PvPCommands::partyList))).then(CommandManager.literal((String)"chat").executes(PvPCommands::partyChat))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)CommandManager.literal((String)"menu").executes(ctx -> {
            ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
            if (p != null) {
                PvPCore.get().partyManager().sendPartyMenu(p);
            }
            return 1;
        })).then(CommandManager.literal((String)"invite").executes(ctx -> {
            ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
            if (p != null) {
                PvPCore.get().partyManager().openInvitePicker(p);
            }
            return 1;
        }))).then(CommandManager.literal((String)"duel").executes(ctx -> {
            ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
            if (p != null) {
                PvPCore.get().partyManager().openDuelPicker(p);
            }
            return 1;
        }))).then(CommandManager.literal((String)"manage").executes(ctx -> {
            ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
            if (p != null) {
                PvPCore.get().partyManager().sendPartyMenu(p);
            }
            return 1;
        }))).then(CommandManager.literal((String)"close").executes(ctx -> {
            ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
            if (p != null) {
                p.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("party.menu-close-hint")), false);
            }
            return 1;
        })))).then(CommandManager.literal((String)"split").executes(ctx -> {
            ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
            if (p != null) {
                PartyManager.Party party = PvPCore.get().partyManager().partyOf(p);
                if (party == null) {
                    p.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("party.not-in-party")), false);
                    return 0;
                }
                if (!party.isLeader(p.getUuid())) {
                    p.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("party.not-leader")), false);
                    return 0;
                }
                new PartySplitGui(p).open(p);
            }
            return 1;
        }))).then(CommandManager.literal((String)"duel").then(CommandManager.argument((String)"player", (ArgumentType)EntityArgumentType.player()).executes(PvPCommands::partyDuel))));
        dispatcher.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)CommandManager.literal((String)"arena").requires(src -> PlayerManager.isAdminSource(src))).executes(ctx -> {
            ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
            if (p != null) {
                new ArenaListGui(p).open(p);
            }
            return 1;
        })).then(CommandManager.literal((String)"list").executes(PvPCommands::arenaList))).then(CommandManager.literal((String)"create").then(CommandManager.argument((String)"id", (ArgumentType)StringArgumentType.word()).executes(PvPCommands::arenaCreate)))).then(CommandManager.literal((String)"setspawn1").then(CommandManager.argument((String)"id", (ArgumentType)StringArgumentType.word()).suggests(ARENAS).executes(ctx -> PvPCommands.arenaSpawnId((CommandContext<ServerCommandSource>)ctx, 1))))).then(CommandManager.literal((String)"setspawn2").then(CommandManager.argument((String)"id", (ArgumentType)StringArgumentType.word()).suggests(ARENAS).executes(ctx -> PvPCommands.arenaSpawnId((CommandContext<ServerCommandSource>)ctx, 2))))).then(CommandManager.literal((String)"setspectator").then(CommandManager.argument((String)"id", (ArgumentType)StringArgumentType.word()).suggests(ARENAS).executes(ctx -> PvPCommands.arenaSpawnId((CommandContext<ServerCommandSource>)ctx, 3))))).then(((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)CommandManager.argument((String)"id", (ArgumentType)StringArgumentType.word()).suggests(ARENAS).then(CommandManager.literal((String)"enable").executes(ctx -> PvPCommands.arenaToggle((CommandContext<ServerCommandSource>)ctx, true)))).then(CommandManager.literal((String)"disable").executes(ctx -> PvPCommands.arenaToggle((CommandContext<ServerCommandSource>)ctx, false)))).then(CommandManager.literal((String)"validate").executes(PvPCommands::arenaValidate))).then(CommandManager.literal((String)"teleport").executes(PvPCommands::arenaTeleport))).then(CommandManager.literal((String)"delete").executes(PvPCommands::arenaDelete)).then(CommandManager.literal((String)"assign").then(CommandManager.argument((String)"kit", (ArgumentType)StringArgumentType.word()).suggests(ARENA_KITS).executes(PvPCommands::arenaAssign)))).then(CommandManager.literal((String)"assign").then(CommandManager.argument((String)"id", (ArgumentType)StringArgumentType.word()).suggests(ARENAS).then(CommandManager.argument((String)"kit", (ArgumentType)StringArgumentType.word()).suggests(ARENA_KITS).executes(PvPCommands::arenaAssign)))));
        dispatcher.register(PvPCommands.pvpAdminCommand());
        dispatcher.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)CommandManager.literal((String)"pvpdebug").requires(src -> PlayerManager.isAdminSource(src))).executes(PvPCommands::debugSummary)).then(CommandManager.literal((String)"state").then(CommandManager.argument((String)"player", (ArgumentType)EntityArgumentType.player()).executes(PvPCommands::debugState)))).then(CommandManager.literal((String)"duels").executes(PvPCommands::debugDuels))).then(CommandManager.literal((String)"arenas").executes(PvPCommands::debugArenas))).then(CommandManager.literal((String)"queues").executes(PvPCommands::debugQueues)));
        PvPCommands.registerZoneCommands(dispatcher);
        PvPCommands.registerNpcCommands(dispatcher);
        PvPCommands.registerZoneKitCommand(dispatcher);
    }

    private static void registerZoneCommands(CommandDispatcher<ServerCommandSource> dispatcher) {
        LiteralArgumentBuilder zoneCmd = (LiteralArgumentBuilder)CommandManager.literal((String)"pvpzone").requires(src -> PlayerManager.isAdminSource(src));
        zoneCmd.executes(PvPCommands::zoneList);
        zoneCmd.then(CommandManager.literal((String)"list").executes(PvPCommands::zoneList));
        zoneCmd.then(CommandManager.literal((String)"join").then(CommandManager.argument((String)"id", (ArgumentType)StringArgumentType.word()).suggests(ZONES).executes(PvPCommands::zoneJoin)));
        zoneCmd.then(CommandManager.literal((String)"create").then(CommandManager.argument((String)"id", (ArgumentType)StringArgumentType.word()).executes(PvPCommands::zoneCreate)));
        zoneCmd.then(CommandManager.literal((String)"delete").then(CommandManager.argument((String)"id", (ArgumentType)StringArgumentType.word()).suggests(ZONES).executes(PvPCommands::zoneDelete)));
        zoneCmd.then(CommandManager.literal((String)"enable").then(CommandManager.argument((String)"id", (ArgumentType)StringArgumentType.word()).suggests(ZONES).executes(ctx -> PvPCommands.zoneToggle((CommandContext<ServerCommandSource>)ctx, true))));
        zoneCmd.then(CommandManager.literal((String)"disable").then(CommandManager.argument((String)"id", (ArgumentType)StringArgumentType.word()).suggests(ZONES).executes(ctx -> PvPCommands.zoneToggle((CommandContext<ServerCommandSource>)ctx, false))));
        zoneCmd.then(CommandManager.literal((String)"setspawn").then(CommandManager.argument((String)"id", (ArgumentType)StringArgumentType.word()).suggests(ZONES).executes(PvPCommands::zoneSetSpawn)));
        zoneCmd.then(CommandManager.literal((String)"name").then(CommandManager.argument((String)"id", (ArgumentType)StringArgumentType.word()).suggests(ZONES).then(CommandManager.argument((String)"name", (ArgumentType)StringArgumentType.greedyString()).executes(PvPCommands::zoneName))));
        zoneCmd.then(CommandManager.literal((String)"mode").then(((RequiredArgumentBuilder)CommandManager.argument((String)"id", (ArgumentType)StringArgumentType.word()).suggests(ZONES).then(CommandManager.literal((String)"fixed").executes(ctx -> PvPCommands.zoneMode((CommandContext<ServerCommandSource>)ctx, "fixed")))).then(CommandManager.literal((String)"picker").executes(ctx -> PvPCommands.zoneMode((CommandContext<ServerCommandSource>)ctx, "picker")))));
        zoneCmd.then(CommandManager.literal((String)"setkit").then(CommandManager.argument((String)"id", (ArgumentType)StringArgumentType.word()).suggests(ZONES).then(CommandManager.argument((String)"kit", (ArgumentType)StringArgumentType.word()).suggests(KITS).executes(PvPCommands::zoneSetKit))));
        zoneCmd.then(CommandManager.literal((String)"kits").then(((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)CommandManager.argument((String)"id", (ArgumentType)StringArgumentType.word()).suggests(ZONES).executes(PvPCommands::zoneKitsList)).then(CommandManager.literal((String)"add").then(CommandManager.argument((String)"kit", (ArgumentType)StringArgumentType.word()).suggests(KITS).executes(ctx -> PvPCommands.zoneKitAddRemove((CommandContext<ServerCommandSource>)ctx, true))))).then(CommandManager.literal((String)"remove").then(CommandManager.argument((String)"kit", (ArgumentType)StringArgumentType.word()).suggests(KITS).executes(ctx -> PvPCommands.zoneKitAddRemove((CommandContext<ServerCommandSource>)ctx, false))))).then(CommandManager.literal((String)"clear").executes(ctx -> PvPCommands.zoneKitClear((CommandContext<ServerCommandSource>)ctx)))));
        zoneCmd.then(CommandManager.literal((String)"sb").then(((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)CommandManager.argument((String)"id", (ArgumentType)StringArgumentType.word()).suggests(ZONES).then(CommandManager.literal((String)"title").then(CommandManager.argument((String)"value", (ArgumentType)StringArgumentType.greedyString()).executes(PvPCommands::zoneSbTitle)))).then(CommandManager.literal((String)"addline").then(CommandManager.argument((String)"value", (ArgumentType)StringArgumentType.greedyString()).executes(PvPCommands::zoneSbAddLine)))).then(CommandManager.literal((String)"setline").then(CommandManager.argument((String)"index", (ArgumentType)IntegerArgumentType.integer((int)1)).then(CommandManager.argument((String)"value", (ArgumentType)StringArgumentType.greedyString()).executes(PvPCommands::zoneSbSetLine))))).then(CommandManager.literal((String)"removeline").then(CommandManager.argument((String)"index", (ArgumentType)IntegerArgumentType.integer((int)1)).executes(PvPCommands::zoneSbRemoveLine)))).then(CommandManager.literal((String)"clearlines").executes(PvPCommands::zoneSbClearLines))).then(CommandManager.literal((String)"reset").executes(PvPCommands::zoneSbReset))));
        dispatcher.register(zoneCmd);
    }

    private static void registerNpcCommands(CommandDispatcher<ServerCommandSource> dispatcher) {
        LiteralArgumentBuilder npcCmd = (LiteralArgumentBuilder)CommandManager.literal((String)"pvpnpc").requires(src -> PlayerManager.isAdminSource(src));
        npcCmd.executes(PvPCommands::npcList);
        npcCmd.then(CommandManager.literal((String)"list").executes(PvPCommands::npcList));
        npcCmd.then(CommandManager.literal((String)"create").then(CommandManager.argument((String)"zone", (ArgumentType)StringArgumentType.word()).suggests(ZONES).then(CommandManager.argument((String)"name", (ArgumentType)StringArgumentType.greedyString()).executes(PvPCommands::npcCreate))));
        npcCmd.then(CommandManager.literal((String)"remove").then(CommandManager.argument((String)"id", (ArgumentType)StringArgumentType.string()).suggests(NPCS).executes(PvPCommands::npcRemove)));
        npcCmd.then(CommandManager.literal((String)"respawn").executes(PvPCommands::npcRespawn));
        dispatcher.register(npcCmd);
    }

    private static void registerZoneKitCommand(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)CommandManager.literal((String)"kit").requires(src -> true)).executes(ctx -> {
            ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
            if (p == null) {
                return 0;
            }
            FightZone zone = PvPCore.get().zoneManager().zoneOf(p);
            if (zone == null) {
                p.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("zone.not-in-zone")), false);
                return 0;
            }
            if (zone.mode.equalsIgnoreCase("fixed")) {
                Kit kit = PvPCore.get().kitManager().get(zone.fixedKit);
                String name = kit != null ? kit.displayName : zone.fixedKit;
                p.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("zone.kit-fixed", Map.of("kit", name))), false);
                PvPCore.get().zoneManager().giveZoneKit(p, zone);
                return 1;
            }
            new ZoneKitGui(p, zone).open(p);
            return 1;
        }));
    }

    private static int duelPicker(CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        if (p == null) {
            return 0;
        }
        Messages mm = PvPCore.get().messages();
        if (PvPCore.get().duelManager().duelOf(p) != null) {
            p.sendMessage((Text)Text.literal((String)mm.get("duel.already-in-duel")), false);
            return 0;
        }
        if (!PvPCore.get().duelManager().isEligibleDuelTarget(p)) {
            p.sendMessage((Text)Text.literal((String)mm.get("duel.not-ready")), false);
            return 0;
        }
        new PlayerPickerGui(p, "&8Duel - Pick an Opponent", target -> new KitPickerGui(p, false, (ServerPlayerEntity)target).open(p), t -> PvPCore.get().duelManager().isEligibleDuelTarget((ServerPlayerEntity)t)).open(p);
        return 1;
    }

    private static int duel(CommandContext<ServerCommandSource> ctx, String kitId, int rounds) throws CommandSyntaxException {
        ServerPlayerEntity sender = ((ServerCommandSource)ctx.getSource()).getPlayer();
        ServerPlayerEntity target = EntityArgumentType.getPlayer(ctx, (String)"player");
        if (sender == null) {
            return 0;
        }
        if (kitId == null) {
            new KitPickerGui(sender, false, target).open(sender);
            return 1;
        }
        if (rounds > 0) {
            PvPCore.get().duelManager().sendChallenge(sender, target, kitId, rounds);
        } else {
            PvPCore.get().duelManager().sendChallenge(sender, target, kitId);
        }
        return 1;
    }

    private static int openQueue(CommandContext<ServerCommandSource> ctx, boolean ranked) {
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        if (p != null) {
            new KitPickerGui(p, ranked, null).open(p);
        }
        return 1;
    }

    private static int queue(CommandContext<ServerCommandSource> ctx, String kitId, boolean ranked, int rounds) {
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        if (p == null) {
            return 0;
        }
        if (rounds > 0) {
            PvPCore.get().queueManager().join(p, kitId, ranked, rounds);
        } else {
            PvPCore.get().queueManager().join(p, kitId, ranked);
        }
        return 1;
    }

    private static int leaveQueue(CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        if (p == null) {
            return 0;
        }
        PvPCore.get().queueManager().leave(p);
        return 1;
    }

    private static int leave(CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        if (p == null) {
            return 0;
        }
        Messages mm = PvPCore.get().messages();
        if (PvPCore.get().zoneManager().isInZone(p)) {
            PvPCore.get().zoneManager().leaveToLobby(p);
            return 1;
        }
        if (PvPCore.get().duelManager().leaveDuel(p)) {
            return 1;
        }
        if (PvPCore.get().queueManager().isQueued(p)) {
            PvPCore.get().queueManager().leave(p);
            p.sendMessage((Text)Text.literal((String)mm.get("leave.queue-left")), false);
            return 1;
        }
        if (PvPCore.get().spectateManager().isSpectating(p)) {
            PvPCore.get().spectateManager().returnPlayer(p);
            return 1;
        }
        PvPCommands.lobbyReturn(p);
        return 1;
    }

    private static int duelAccept(CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        if (p == null) {
            return 0;
        }
        if (PvPCore.get().duelManager().requestFor(p.getUuid()) == null) {
            p.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("duel.no-request")), false);
            return 0;
        }
        PvPCore.get().duelManager().acceptRequest(p);
        return 1;
    }

    private static int duelDeny(CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        if (p == null) {
            return 0;
        }
        if (PvPCore.get().duelManager().requestFor(p.getUuid()) == null) {
            p.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("duel.no-request")), false);
            return 0;
        }
        PvPCore.get().duelManager().denyRequest(p);
        return 1;
    }

    private static int statsOf(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity viewer = ((ServerCommandSource)ctx.getSource()).getPlayer();
        ServerPlayerEntity target = EntityArgumentType.getPlayer(ctx, (String)"player");
        if (viewer != null) {
            new StatsGui(viewer, target).open(viewer);
        }
        return 1;
    }

    private static int leaderboard(CommandContext<ServerCommandSource> ctx, String type, String kitId) {
        Messages mm = PvPCore.get().messages();
        List<LeaderboardManager.Entry> top = PvPCore.get().leaderboardManager().top(kitId, type, 10);
        ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)mm.get("leaderboard.header", Map.of("type", type.toUpperCase(), "kit", kitId))), false);
        if (top.isEmpty()) {
            ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)mm.get("leaderboard.empty")), false);
            return 1;
        }
        for (int i = 0; i < top.size(); ++i) {
            int pos = i + 1;
            LeaderboardManager.Entry entry = top.get(i);
            ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)mm.get("leaderboard.entry", Map.of("position", String.valueOf(pos), "player", entry.name(), "value", String.valueOf(entry.value())))), false);
        }
        return 1;
    }

    private static int spectatePlayer(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        ServerPlayerEntity target = EntityArgumentType.getPlayer(ctx, (String)"player");
        if (p == null) {
            return 0;
        }
        Duel duel = PvPCore.get().duelManager().duelOf(target);
        if (duel == null) {
            p.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("spectate.no-duels")), false);
            return 0;
        }
        PvPCore.get().spectateManager().join(p, duel);
        return 1;
    }

    private static int lobbyTeleport(CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        if (p == null) {
            return 0;
        }
        Messages mm = PvPCore.get().messages();
        // 3.0.6: /spawn and /lobby are completely DISABLED while fighting -
        // in a duel or inside an FFA/fight zone. The only way out is /leave.
        // This guarantees no zone kit can ever leak into the lobby through
        // these commands.
        if (PvPCore.get().duelManager().duelOf(p) != null) {
            p.sendMessage((Text)Text.literal((String)mm.get("spawn.blocked-duel")), false);
            return 0;
        }
        if (PvPCore.get().zoneManager().isInZone(p)) {
            p.sendMessage((Text)Text.literal((String)mm.get("spawn.blocked-zone")), false);
            return 0;
        }
        if (PvPCore.get().spectateManager().isSpectating(p)) {
            PvPCore.get().spectateManager().returnPlayer(p);
            return 1;
        }
        PvPCommands.lobbyReturn(p);
        return 1;
    }

    private static void lobbyReturn(ServerPlayerEntity p) {
        PvPCore core = PvPCore.get();
        PlayerManager pm = core.playerManager();
        pm.clearAfterDuel(p, pm.preDuelSnapshot(p));
        pm.backToLobby(p);
        pm.teleportToLobby(p);
        p.sendMessage((Text)Text.literal((String)core.messages().get("lobby.teleported")), false);
    }

    private static int partyCreate(CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        if (p == null) {
            return 0;
        }
        PvPCore.get().partyManager().createParty(p);
        return 1;
    }

    private static int partyInvite(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        ServerPlayerEntity target = EntityArgumentType.getPlayer(ctx, (String)"player");
        if (p == null) {
            return 0;
        }
        PvPCore.get().partyManager().invite(p, target);
        return 1;
    }

    private static int partyAccept(CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        if (p == null) {
            return 0;
        }
        PvPCore.get().partyManager().acceptInvite(p);
        return 1;
    }

    private static int partyDeny(CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        if (p == null) {
            return 0;
        }
        PvPCore.get().partyManager().denyInvite(p);
        return 1;
    }

    private static int partyLeave(CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        if (p == null) {
            return 0;
        }
        PvPCore.get().partyManager().leave(p);
        return 1;
    }

    private static int partyKick(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        ServerPlayerEntity target = EntityArgumentType.getPlayer(ctx, (String)"player");
        if (p == null) {
            return 0;
        }
        PvPCore.get().partyManager().kick(p, target);
        return 1;
    }

    private static int partyPromote(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        ServerPlayerEntity target = EntityArgumentType.getPlayer(ctx, (String)"player");
        if (p == null) {
            return 0;
        }
        PvPCore.get().partyManager().promote(p, target);
        return 1;
    }

    private static int partyDisband(CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        if (p == null) {
            return 0;
        }
        PvPCore.get().partyManager().disband(p);
        return 1;
    }

    private static int partyList(CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        if (p == null) {
            return 0;
        }
        PartyManager.Party party = PvPCore.get().partyManager().partyOf(p);
        if (party == null) {
            p.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("party.not-in-party")), false);
            return 0;
        }
        net.minecraft.server.PlayerManager pm = PvPCore.get().server().getPlayerManager();
        StringBuilder sb = new StringBuilder("&dParty (&f" + party.members.size() + "&d): ");
        boolean first = true;
        for (UUID u : party.members) {
            if (!first) {
                sb.append("&7, ");
            }
            sb.append(party.leader.equals(u) ? "&6" : "&e").append(PvPCommands.name(pm, u));
            first = false;
        }
        p.sendMessage(TextUtil.text(sb.toString()), false);
        return 1;
    }

    private static String name(net.minecraft.server.PlayerManager pm, UUID uuid) {
        ServerPlayerEntity p = pm.getPlayer(uuid);
        return p != null ? p.getGameProfile().name() : "?";
    }

    private static int partyChat(CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        if (p == null) {
            return 0;
        }
        PlayerData data = PvPCore.get().storage().get(p.getUuid(), p.getGameProfile().name());
        data.partyChat = !data.partyChat;
        PvPCore.get().storage().markDirty(p.getUuid());
        Messages mm = PvPCore.get().messages();
        p.sendMessage((Text)Text.literal((String)mm.get(data.partyChat ? "party.chat-on" : "party.chat-off")), false);
        return 1;
    }

    private static int partyDuel(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        ServerPlayerEntity target = EntityArgumentType.getPlayer(ctx, (String)"player");
        if (p == null) {
            return 0;
        }
        Messages mm = PvPCore.get().messages();
        PartyManager.Party party = PvPCore.get().partyManager().partyOf(p);
        if (party == null) {
            p.sendMessage((Text)Text.literal((String)mm.get("party.not-in-party")), false);
            return 0;
        }
        if (!party.isLeader(p.getUuid())) {
            p.sendMessage((Text)Text.literal((String)mm.get("party.not-leader")), false);
            return 0;
        }
        if (PvPCore.get().partyManager().partyOf(target) == null) {
            p.sendMessage((Text)Text.literal((String)mm.get("party.target-no-party", Map.of("player", target.getGameProfile().name()))), false);
            return 0;
        }
        new KitPickerGui(p, false, target, true).open(p);
        return 1;
    }

    private static int arenaList(CommandContext<ServerCommandSource> ctx) {
        Collection<Arena> arenas = PvPCore.get().arenaManager().all();
        if (arenas.isEmpty()) {
            ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)PvPCore.get().messages().get("arena.none")), false);
            return 1;
        }
        for (Arena arena : arenas) {
            ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)TextUtil.colorize("&e" + arena.id + " &8- " + arena.statusColored() + " &8- &7mode: " + arena.kitDisplayName() + " &8- " + arena.displayName)), false);
        }
        return 1;
    }

    private static int arenaCreate(CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        String id = StringArgumentType.getString(ctx, (String)"id");
        if (PvPCore.get().arenaManager().get(id) != null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)"Arena already exists"));
            return 0;
        }
        Arena arena = PvPCore.get().arenaManager().create(id);
        if (p != null) {
            arena.world = p.getEntityWorld().getRegistryKey().getValue().toString();
        }
        PvPCore.get().arenaManager().save();
        PvPCore.get().auditLog().log(((ServerCommandSource)ctx.getSource()).getName(), "Created arena " + id);
        ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)PvPCore.get().messages().get("arena.created", Map.of("arena", id))), false);
        return 1;
    }

    private static int arenaSpawn(CommandContext<ServerCommandSource> ctx, int which) {
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        if (p == null) {
            return 0;
        }
        ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)"Usage: /arena setspawn1 <id> (stand where the spawn should be)"));
        return 0;
    }

    private static int arenaSpawnId(CommandContext<ServerCommandSource> ctx, int which) {
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        if (p == null) {
            return 0;
        }
        String id = StringArgumentType.getString(ctx, (String)"id");
        Arena arena = PvPCore.get().arenaManager().get(id);
        if (arena == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)"Unknown arena"));
            return 0;
        }
        arena.world = p.getEntityWorld().getRegistryKey().getValue().toString();
        String label = switch (which) {
            case 1 -> {
                arena.spawn1X = p.getX();
                arena.spawn1Y = p.getY();
                arena.spawn1Z = p.getZ();
                arena.spawn1Yaw = p.getYaw();
                arena.spawn1Pitch = p.getPitch();
                arena.spawn1Set = true;
                yield "Spawn 1";
            }
            case 2 -> {
                arena.spawn2X = p.getX();
                arena.spawn2Y = p.getY();
                arena.spawn2Z = p.getZ();
                arena.spawn2Yaw = p.getYaw();
                arena.spawn2Pitch = p.getPitch();
                arena.spawn2Set = true;
                yield "Spawn 2";
            }
            default -> {
                arena.spectatorX = p.getX();
                arena.spectatorY = p.getY();
                arena.spectatorZ = p.getZ();
                arena.spectatorYaw = p.getYaw();
                arena.spectatorPitch = p.getPitch();
                arena.spectatorSet = true;
                yield "Spectator spawn";
            }
        };
        PvPCore.get().arenaManager().save();
        PvPCore.get().auditLog().log(((ServerCommandSource)ctx.getSource()).getName(), "Set " + label + " of arena " + id);
        ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)PvPCore.get().messages().get("arena.spawn-set", Map.of("arena", id, "spawn", label))), false);
        return 1;
    }

    private static int arenaToggle(CommandContext<ServerCommandSource> ctx, boolean enable) {
        String id = StringArgumentType.getString(ctx, (String)"id");
        Arena arena = PvPCore.get().arenaManager().get(id);
        if (arena == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)"Unknown arena"));
            return 0;
        }
        arena.enabled = enable;
        PvPCore.get().arenaManager().save();
        PvPCore.get().auditLog().log(((ServerCommandSource)ctx.getSource()).getName(), (enable ? "Enabled " : "Disabled ") + "arena " + id);
        ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)PvPCore.get().messages().get(enable ? "arena.enabled" : "arena.disabled", Map.of("arena", id))), false);
        return 1;
    }

    private static int arenaValidate(CommandContext<ServerCommandSource> ctx) {
        String id = StringArgumentType.getString(ctx, (String)"id");
        Arena arena = PvPCore.get().arenaManager().get(id);
        if (arena == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)"Unknown arena"));
            return 0;
        }
        Messages mm = PvPCore.get().messages();
        if (arena.isValid()) {
            ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)mm.get("arena.valid", Map.of("arena", id))), false);
        } else {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)mm.get("arena.invalid", Map.of("arena", id, "reason", arena.invalidReason()))));
        }
        return arena.isValid() ? 1 : 0;
    }

    private static int arenaTeleport(CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        if (p == null) {
            return 0;
        }
        String id = StringArgumentType.getString(ctx, (String)"id");
        Arena arena = PvPCore.get().arenaManager().get(id);
        if (arena == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)"Unknown arena"));
            return 0;
        }
        ServerWorld world = TeleportUtil.world(PvPCore.get().server(), arena.world);
        if (world == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)"Arena world not found"));
            return 0;
        }
        double x = arena.spawn1Set ? arena.spawn1X : arena.spectatorX;
        double y = arena.spawn1Set ? arena.spawn1Y : arena.spectatorY;
        double z = arena.spawn1Set ? arena.spawn1Z : arena.spectatorZ;
        TeleportUtil.teleport(p, world, x, y, z, 0.0f, 0.0f);
        ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)PvPCore.get().messages().get("arena.teleported", Map.of("arena", id))), false);
        return 1;
    }

    private static int arenaDelete(CommandContext<ServerCommandSource> ctx) {
        String id = StringArgumentType.getString(ctx, (String)"id");
        Arena arena = PvPCore.get().arenaManager().get(id);
        if (arena == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)"Unknown arena"));
            return 0;
        }
        if (arena.status != Arena.Status.FREE) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)PvPCore.get().messages().get("arena.in-use")));
            return 0;
        }
        PvPCore.get().arenaManager().delete(id);
        PvPCore.get().auditLog().log(((ServerCommandSource)ctx.getSource()).getName(), "Deleted arena " + id);
        ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)PvPCore.get().messages().get("arena.deleted", Map.of("arena", id))), false);
        return 1;
    }

    private static int arenaAssign(CommandContext<ServerCommandSource> ctx) {
        String id = StringArgumentType.getString(ctx, (String)"id");
        String rawKit = StringArgumentType.getString(ctx, (String)"kit");
        Arena arena = PvPCore.get().arenaManager().get(id);
        if (arena == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)"Unknown arena"));
            return 0;
        }
        Messages mm = PvPCore.get().messages();
        String actor = ((ServerCommandSource)ctx.getSource()).getName();
        if (!(rawKit.equalsIgnoreCase("any") || rawKit.equalsIgnoreCase("*") || rawKit.equalsIgnoreCase("global"))) {
            if (!rawKit.equalsIgnoreCase("none") && !rawKit.equalsIgnoreCase("clear")) {
                String[] parts = rawKit.split(",");
                int added = 0;
                int removed = 0;
                StringBuilder addedNames = new StringBuilder();
                for (String part : parts) {
                    String kitId = part.trim().toLowerCase();
                    if (kitId.isEmpty()) continue;
                    if (PvPCore.get().kitManager().get(kitId) == null) {
                        ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)mm.get("kit.not-found", Map.of("kit", kitId))));
                        return 0;
                    }
                    if (arena.hasKit(kitId)) {
                        PvPCore.get().arenaManager().unassign(arena.id, kitId);
                        ++removed;
                        PvPCore.get().auditLog().log(actor, "Removed kit " + kitId + " from arena " + id);
                        continue;
                    }
                    PvPCore.get().arenaManager().assign(arena.id, kitId);
                    ++added;
                    if (addedNames.length() > 0) {
                        addedNames.append(", ");
                    }
                    addedNames.append(PvPCore.get().duelManager().kitDisplayName(kitId));
                    PvPCore.get().auditLog().log(actor, "Assigned arena " + id + " to gamemode " + kitId);
                }
                if (added > 0) {
                    String kitNames = addedNames.toString();
                    ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)mm.get("arena.assigned", Map.of("arena", id, "kit", kitNames))), false);
                } else if (removed > 0) {
                    ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)mm.get("arena.unassigned", Map.of("arena", id, "kit", arena.kitDisplayName()))), false);
                } else {
                    ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)TextUtil.colorize("&7Arena &e" + id + "&7 gamemodes: " + arena.kitDisplayName())), false);
                }
                return 1;
            }
            PvPCore.get().arenaManager().clearAssignment(arena.id);
            PvPCore.get().auditLog().log(actor, "Cleared kit assignments of arena " + id);
            ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)mm.get("arena.assigned-any", Map.of("arena", id))), false);
            return 1;
        }
        PvPCore.get().arenaManager().clearAssignment(arena.id);
        PvPCore.get().auditLog().log(actor, "Set arena " + id + " gamemode to any");
        ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)mm.get("arena.assigned-any", Map.of("arena", id))), false);
        return 1;
    }

    private static LiteralArgumentBuilder<ServerCommandSource> buildCommand() {
        return (LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)CommandManager.literal((String)"build").executes(PvPCommands::buildStatus)).then(CommandManager.literal((String)"on").executes(ctx -> PvPCommands.buildSet((CommandContext<ServerCommandSource>)ctx, true, true)))).then(CommandManager.literal((String)"off").executes(ctx -> PvPCommands.buildSet((CommandContext<ServerCommandSource>)ctx, false, false)))).then(CommandManager.literal((String)"toggle").executes(PvPCommands::buildToggle))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)CommandManager.literal((String)"break").executes(ctx -> PvPCommands.buildBreakSet((CommandContext<ServerCommandSource>)ctx, !PvPCommands.buildFlag((CommandContext<ServerCommandSource>)ctx, true)))).then(CommandManager.literal((String)"on").executes(ctx -> PvPCommands.buildBreakSet((CommandContext<ServerCommandSource>)ctx, true)))).then(CommandManager.literal((String)"off").executes(ctx -> PvPCommands.buildBreakSet((CommandContext<ServerCommandSource>)ctx, false))))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)CommandManager.literal((String)"place").executes(ctx -> PvPCommands.buildPlaceSet((CommandContext<ServerCommandSource>)ctx, !PvPCommands.buildFlag((CommandContext<ServerCommandSource>)ctx, false)))).then(CommandManager.literal((String)"on").executes(ctx -> PvPCommands.buildPlaceSet((CommandContext<ServerCommandSource>)ctx, true)))).then(CommandManager.literal((String)"off").executes(ctx -> PvPCommands.buildPlaceSet((CommandContext<ServerCommandSource>)ctx, false))))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)CommandManager.literal((String)"protection").executes(PvPCommands::buildProtectionToggle)).then(CommandManager.literal((String)"on").executes(ctx -> PvPCommands.buildProtectionSet((CommandContext<ServerCommandSource>)ctx, true)))).then(CommandManager.literal((String)"off").executes(ctx -> PvPCommands.buildProtectionSet((CommandContext<ServerCommandSource>)ctx, false))));
    }

    private static boolean buildFlag(CommandContext<ServerCommandSource> ctx, boolean breakFlag) {
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        return p != null && (breakFlag ? PvPCore.get().playerManager().buildBreak(p) : PvPCore.get().playerManager().buildPlace(p));
    }

    private static int buildStatus(CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        Messages mm = PvPCore.get().messages();
        if (p == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)mm.get("build.no-player")));
            return 0;
        }
        boolean brk = PvPCore.get().playerManager().buildBreak(p);
        boolean plc = PvPCore.get().playerManager().buildPlace(p);
        boolean protection = PvPCore.get().config().lobby.blockWorldInteraction;
        ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)mm.get("build.status", Map.of("break", brk ? "&abreaking" : "&cbreaking", "place", plc ? "&aplacing" : "&cplacing", "protection", protection ? "&aon" : "&coff"))), false);
        return 1;
    }

    private static int buildSet(CommandContext<ServerCommandSource> ctx, boolean brk, boolean plc) {
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        Messages mm = PvPCore.get().messages();
        if (p == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)mm.get("build.no-player")));
            return 0;
        }
        PvPCore.get().playerManager().setBuildBreak(p, brk);
        PvPCore.get().playerManager().setBuildPlace(p, plc);
        PvPCore.get().playerManager().refreshLobby(p);
        PvPCore.get().auditLog().log(p.getGameProfile().name(), "Build mode " + (!brk && !plc ? "OFF" : "ON") + " (break=" + brk + ", place=" + plc + ")");
        ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)mm.get(!brk && !plc ? "build.off" : "build.on")), false);
        return 1;
    }

    private static int buildToggle(CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        if (p == null) {
            return PvPCommands.buildSet(ctx, false, false);
        }
        boolean active = PvPCore.get().playerManager().buildBypass(p);
        return PvPCommands.buildSet(ctx, !active, !active);
    }

    private static int buildBreakSet(CommandContext<ServerCommandSource> ctx, boolean value) {
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        Messages mm = PvPCore.get().messages();
        if (p == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)mm.get("build.no-player")));
            return 0;
        }
        PvPCore.get().playerManager().setBuildBreak(p, value);
        PvPCore.get().playerManager().refreshLobby(p);
        PvPCore.get().auditLog().log(p.getGameProfile().name(), "Build breaking " + (value ? "enabled" : "disabled"));
        ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)mm.get(value ? "build.break-on" : "build.break-off")), false);
        return 1;
    }

    private static int buildPlaceSet(CommandContext<ServerCommandSource> ctx, boolean value) {
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        Messages mm = PvPCore.get().messages();
        if (p == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)mm.get("build.no-player")));
            return 0;
        }
        PvPCore.get().playerManager().setBuildPlace(p, value);
        PvPCore.get().playerManager().refreshLobby(p);
        PvPCore.get().auditLog().log(p.getGameProfile().name(), "Build placing " + (value ? "enabled" : "disabled"));
        ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)mm.get(value ? "build.place-on" : "build.place-off")), false);
        return 1;
    }

    private static int buildProtectionSet(CommandContext<ServerCommandSource> ctx, boolean value) {
        PvPCore.get().config().lobby.blockWorldInteraction = value;
        PvPCore.get().config().save();
        PvPCore.get().auditLog().log(((ServerCommandSource)ctx.getSource()).getName(), "World interaction protection " + (value ? "enabled" : "disabled"));
        ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)PvPCore.get().messages().get(value ? "build.protection-on" : "build.protection-off")), false);
        return 1;
    }

    private static int buildProtectionToggle(CommandContext<ServerCommandSource> ctx) {
        return PvPCommands.buildProtectionSet(ctx, !PvPCore.get().config().lobby.blockWorldInteraction);
    }

    private static int adminReload(CommandContext<ServerCommandSource> ctx) {
        long ms = PvPCore.get().reloadConfigs();
        PvPCore.get().auditLog().log(((ServerCommandSource)ctx.getSource()).getName(), "Reloaded configs");
        ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)PvPCore.get().messages().get("reload-done", Map.of("ms", String.valueOf(ms)))), false);
        return 1;
    }

    private static int adminSave(CommandContext<ServerCommandSource> ctx) {
        PvPCore.get().storage().saveAll();
        PvPCore.get().kitManager().save();
        PvPCore.get().arenaManager().save();
        PvPCore.get().auditLog().save();
        ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)PvPCore.get().messages().get("data-saved")), false);
        return 1;
    }

    private static int adminSetLobby(CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        if (p == null) {
            return 0;
        }
        MainConfig.Lobby cfg = PvPCore.get().config().lobby;
        cfg.lobbyWorld = p.getEntityWorld().getRegistryKey().getValue().toString();
        cfg.lobbyX = p.getX();
        cfg.lobbyY = p.getY();
        cfg.lobbyZ = p.getZ();
        cfg.lobbyYaw = p.getYaw();
        cfg.lobbyPitch = p.getPitch();
        PvPCore.get().config().save();
        PvPCore.get().auditLog().log(((ServerCommandSource)ctx.getSource()).getName(), "Set lobby spawn");
        ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)PvPCore.get().messages().get("admin.lobby-set")), false);
        return 1;
    }

    private static int adminAudit(CommandContext<ServerCommandSource> ctx) {
        List<AuditLog.Entry> entries = PvPCore.get().auditLog().entries();
        for (int i = Math.max(0, entries.size() - 15); i < entries.size(); ++i) {
            AuditLog.Entry e = entries.get(i);
            ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)TextUtil.colorize("&7[" + String.valueOf(Instant.ofEpochMilli(e.timestamp())) + "] &e" + e.actor() + "&8: &f" + e.action())), false);
        }
        return 1;
    }

    private static int kitCreate(CommandContext<ServerCommandSource> ctx, String displayName) {
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        Messages mm = PvPCore.get().messages();
        if (p == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)"Only players can create kits from their inventory."));
            return 0;
        }
        String rawId = StringArgumentType.getString(ctx, (String)"id");
        String id = rawId.toLowerCase();
        if (!KitManager.validId(id)) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)mm.get("kit.invalid-name")));
            return 0;
        }
        if (PvPCore.get().kitManager().get(id) != null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)mm.get("kit.already-exists", Map.of("kit", id))));
            return 0;
        }
        Kit kit = PvPCore.get().kitManager().createFromInventory(id, displayName, p.getInventory());
        PvPCore.get().kitManager().put(kit);
        PvPCore.get().auditLog().log(((ServerCommandSource)ctx.getSource()).getName(), "Created kit " + id + " from inventory");
        ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)mm.get("kit.created-from-inventory", Map.of("kit", id))), false);
        return 1;
    }

    private static int kitDelete(CommandContext<ServerCommandSource> ctx) {
        String id = StringArgumentType.getString(ctx, (String)"id");
        PvPCore.get().kitManager().delete(id);
        PvPCore.get().auditLog().log(((ServerCommandSource)ctx.getSource()).getName(), "Deleted kit " + id);
        ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)PvPCore.get().messages().get("kit.deleted", Map.of("kit", id))), false);
        return 1;
    }

    private static int kitRename(CommandContext<ServerCommandSource> ctx) {
        String id = StringArgumentType.getString(ctx, (String)"id");
        String name = StringArgumentType.getString(ctx, (String)"name");
        Kit kit = PvPCore.get().kitManager().rename(id, null, name);
        if (kit == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)PvPCore.get().messages().get("kit.not-found", Map.of("kit", id))));
            return 0;
        }
        PvPCore.get().auditLog().log(((ServerCommandSource)ctx.getSource()).getName(), "Renamed kit " + id + " to " + name);
        ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)PvPCore.get().messages().get("kit.renamed", Map.of("name", name))), false);
        return 1;
    }

    private static int kitReid(CommandContext<ServerCommandSource> ctx) {
        String oldId = StringArgumentType.getString(ctx, (String)"id");
        String newId = StringArgumentType.getString(ctx, (String)"newid");
        Messages mm = PvPCore.get().messages();
        if (PvPCore.get().kitManager().get(oldId) == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)mm.get("kit.not-found", Map.of("kit", oldId))));
            return 0;
        }
        if (!KitManager.validId(newId.toLowerCase())) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)mm.get("kit.invalid-name")));
            return 0;
        }
        Kit kit = PvPCore.get().kitManager().rename(oldId, newId, null);
        if (kit == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)mm.get("kit.already-exists", Map.of("kit", newId))));
            return 0;
        }
        PvPCore.get().auditLog().log(((ServerCommandSource)ctx.getSource()).getName(), "Changed kit id " + oldId + " -> " + kit.id + " (references synced)");
        ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)TextUtil.colorize("&7Kit id changed: &e" + oldId + " &7-> &a" + kit.id + "&7. Arena assignments, stats, ratings and loadouts were synced.")), false);
        return 1;
    }

    private static int kitReset(CommandContext<ServerCommandSource> ctx) {
        String id = StringArgumentType.getString(ctx, (String)"id");
        Kit kit = PvPCore.get().kitManager().resetToDefault(id);
        if (kit == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)PvPCore.get().messages().get("kit.not-found", Map.of("kit", id))));
            return 0;
        }
        PvPCore.get().auditLog().log(((ServerCommandSource)ctx.getSource()).getName(), "Reset kit " + kit.id + " to the default template");
        ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)TextUtil.colorize("&7Kit &e" + kit.id + " &7was reset to the default template (personal layouts cleared).")), false);
        return 1;
    }

    /**
     * 3.0.9: clean rebuild of the /pvpadmin tree. The old decompiled one-liner
     * (reconstructed from 3.0.4 bytecode) accidentally placed the kit 'reset'
     * subcommand at /pvpadmin level because of cast-paren mangling; this version
     * attaches every kit operation under /pvpadmin kit and keeps /pvpadmin reset
     * working as a back-compat alias.
     */
    private static LiteralArgumentBuilder<ServerCommandSource> pvpAdminCommand() {
        LiteralArgumentBuilder<ServerCommandSource> admin = CommandManager.literal((String)"pvpadmin").requires(src -> PlayerManager.isAdminSource(src));
        admin.executes(ctx -> {
            ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
            if (p != null) {
                new AdminGui(p).open(p);
            }
            return 1;
        });
        admin.then(CommandManager.literal((String)"reload").executes(PvPCommands::adminReload));
        admin.then(CommandManager.literal((String)"save").executes(PvPCommands::adminSave));
        admin.then(CommandManager.literal((String)"setlobby").executes(PvPCommands::adminSetLobby));
        admin.then(CommandManager.literal((String)"scoreboard").executes(ctx -> {
            ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
            if (p != null) {
                new ScoreboardSettingsGui(p).open(p);
            }
            return 1;
        }));
        admin.then(CommandManager.literal((String)"audit").executes(PvPCommands::adminAudit));
        admin.then(PvPCommands.buildCommand());
        admin.then(PvPCommands.kitCommand());
        // back-compat alias: /pvpadmin reset <id> worked in 3.0.4-3.0.8
        admin.then(PvPCommands.kitResetCommand());
        return admin;
    }

    /**
     * 3.0.9: the /pvpadmin kit subtree, rebuilt without the decompiler's cast
     * chains so every subcommand verifiably attaches to the kit literal.
     */
    private static LiteralArgumentBuilder<ServerCommandSource> kitCommand() {
        LiteralArgumentBuilder<ServerCommandSource> kit = CommandManager.literal((String)"kit");
        kit.then(CommandManager.literal((String)"create").then(CommandManager.argument((String)"id", (ArgumentType)StringArgumentType.word()).executes(ctx -> PvPCommands.kitCreate((CommandContext<ServerCommandSource>)ctx, null))).then(CommandManager.argument((String)"name", (ArgumentType)StringArgumentType.greedyString()).executes(ctx -> PvPCommands.kitCreate((CommandContext<ServerCommandSource>)ctx, StringArgumentType.getString((CommandContext<ServerCommandSource>)ctx, (String)"name")))));
        kit.then(CommandManager.literal((String)"delete").then(CommandManager.argument((String)"id", (ArgumentType)StringArgumentType.word()).suggests(KITS).executes(PvPCommands::kitDelete)));
        kit.then(CommandManager.literal((String)"rename").then(CommandManager.argument((String)"id", (ArgumentType)StringArgumentType.word()).suggests(KITS).then(CommandManager.argument((String)"name", (ArgumentType)StringArgumentType.greedyString()).executes(PvPCommands::kitRename))));
        kit.then(CommandManager.literal((String)"reid").then(CommandManager.argument((String)"id", (ArgumentType)StringArgumentType.word()).suggests(KITS).then(CommandManager.argument((String)"newid", (ArgumentType)StringArgumentType.word()).executes(PvPCommands::kitReid))));
        kit.then(CommandManager.literal((String)"icon").then(CommandManager.argument((String)"id", (ArgumentType)StringArgumentType.word()).suggests(KITS).then(CommandManager.argument((String)"material", (ArgumentType)StringArgumentType.word()).executes(PvPCommands::kitIcon))));
        kit.then(CommandManager.literal((String)"slot").then(CommandManager.argument((String)"id", (ArgumentType)StringArgumentType.word()).suggests(KITS).then(CommandManager.argument((String)"position", (ArgumentType)IntegerArgumentType.integer((int)0)).executes(PvPCommands::kitSlot))));
        kit.then(CommandManager.literal((String)"enable").then(CommandManager.argument((String)"id", (ArgumentType)StringArgumentType.word()).suggests(KITS).executes(ctx -> PvPCommands.kitToggle((CommandContext<ServerCommandSource>)ctx, true))));
        kit.then(CommandManager.literal((String)"disable").then(CommandManager.argument((String)"id", (ArgumentType)StringArgumentType.word()).suggests(KITS).executes(ctx -> PvPCommands.kitToggle((CommandContext<ServerCommandSource>)ctx, false))));
        kit.then(CommandManager.literal((String)"list").executes(PvPCommands::kitList));
        kit.then(PvPCommands.kitAutoPotionsCommand());
        kit.then(PvPCommands.kitResetCommand());
        return kit;
    }

    private static LiteralArgumentBuilder<ServerCommandSource> kitResetCommand() {
        return CommandManager.literal((String)"reset").then(CommandManager.argument((String)"id", (ArgumentType)StringArgumentType.word()).suggests(KITS).executes(PvPCommands::kitReset));
    }

    /**
     * 3.0.9: /pvpadmin kit autopotions <id> [addeffect <effect> <seconds> [amplifier]
     * | additem | remove <index> | clear] - per-kit auto potions applied to every
     * fighter at the start of each duel round.
     */
    private static LiteralArgumentBuilder<ServerCommandSource> kitAutoPotionsCommand() {
        RequiredArgumentBuilder<ServerCommandSource, String> idArg = CommandManager.argument((String)"id", (ArgumentType)StringArgumentType.word());
        idArg.suggests(KITS).executes(PvPCommands::kitAutoPotList).then(CommandManager.literal((String)"list").executes(PvPCommands::kitAutoPotList)).then(CommandManager.literal((String)"addeffect").then(CommandManager.argument((String)"effect", (ArgumentType)StringArgumentType.word()).suggests(EFFECTS).then(CommandManager.argument((String)"seconds", (ArgumentType)IntegerArgumentType.integer((int)-1)).executes(ctx -> PvPCommands.kitAutoPotAddEffect((CommandContext<ServerCommandSource>)ctx, 0)).then(CommandManager.argument((String)"amplifier", (ArgumentType)IntegerArgumentType.integer((int)0)).executes(ctx -> PvPCommands.kitAutoPotAddEffect((CommandContext<ServerCommandSource>)ctx, 1)))))).then(CommandManager.literal((String)"additem").executes(PvPCommands::kitAutoPotAddItem)).then(CommandManager.literal((String)"remove").then(CommandManager.argument((String)"index", (ArgumentType)IntegerArgumentType.integer((int)1)).executes(PvPCommands::kitAutoPotRemove))).then(CommandManager.literal((String)"clear").executes(PvPCommands::kitAutoPotClear));
        return (LiteralArgumentBuilder)CommandManager.literal((String)"autopotions").then(idArg);
    }

    private static int kitAutoPotList(CommandContext<ServerCommandSource> ctx) {
        String id = StringArgumentType.getString(ctx, (String)"id");
        Kit kit = PvPCore.get().kitManager().get(id);
        if (kit == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)PvPCore.get().messages().get("kit.not-found", Map.of("kit", id))));
            return 0;
        }
        Messages mm = PvPCore.get().messages();
        ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)mm.get("kit.autopot-header", Map.of("kit", kit.displayName))), false);
        int index = 1;
        boolean any = false;
        if (kit.autoEffects != null) {
            for (String spec : kit.autoEffects) {
                Object[] parsed = KitManager.parseAutoEffect(spec);
                String out = parsed == null ? TextUtil.colorize("&7 #" + index + " &8- &cinvalid: &f" + spec) : mm.get("kit.autopot-effect-entry", Map.of("index", String.valueOf(index), "effect", Registries.STATUS_EFFECT.getId(((RegistryEntry<StatusEffect>)parsed[0]).value()).getPath(), "duration", KitManager.formatAutoSeconds((Integer)parsed[1]), "level", String.valueOf((Integer)parsed[2] + 1)));
                ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)out), false);
                any = true;
                ++index;
            }
        }
        if (kit.autoItems != null) {
            for (String snbt : kit.autoItems) {
                net.minecraft.item.ItemStack st = ItemCodecUtil.fromSnbt(snbt);
                String name = st.isEmpty() ? "?" : st.getName().getString();
                String out = mm.get("kit.autopot-item-entry", Map.of("index", String.valueOf(index), "item", name, "count", String.valueOf(st.getCount())));
                ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)out), false);
                any = true;
                ++index;
            }
        }
        if (!any) {
            ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)mm.get("kit.autopot-empty", Map.of("kit", kit.id))), false);
        }
        return 1;
    }

    private static int kitAutoPotAddEffect(CommandContext<ServerCommandSource> ctx, int withAmplifier) {
        String id = StringArgumentType.getString(ctx, (String)"id");
        Kit kit = PvPCore.get().kitManager().get(id);
        if (kit == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)PvPCore.get().messages().get("kit.not-found", Map.of("kit", id))));
            return 0;
        }
        Messages mm = PvPCore.get().messages();
        String effect = StringArgumentType.getString(ctx, (String)"effect");
        RegistryEntry<StatusEffect> entry = KitManager.effectById(effect);
        if (entry == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)mm.get("kit.autopot-invalid-effect", Map.of("effect", effect))));
            return 0;
        }
        int seconds = IntegerArgumentType.getInteger(ctx, (String)"seconds");
        int amplifier = withAmplifier == 0 ? 0 : IntegerArgumentType.getInteger(ctx, (String)"amplifier");
        String canonical = Registries.STATUS_EFFECT.getId(entry.value()).toString();
        if (kit.autoEffects == null) {
            kit.autoEffects = new ArrayList<String>();
        }
        kit.autoEffects.add(canonical + ":" + seconds + ":" + amplifier);
        PvPCore.get().kitManager().put(kit);
        PvPCore.get().auditLog().log(((ServerCommandSource)ctx.getSource()).getName(), "Kit " + kit.id + " auto effect " + canonical + " " + seconds + "s amp " + amplifier);
        String out = mm.get("kit.autopot-effect-added", Map.of("kit", kit.displayName, "effect", canonical, "duration", KitManager.formatAutoSeconds(seconds), "level", String.valueOf(amplifier + 1)));
        ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)out), false);
        return 1;
    }

    private static int kitAutoPotAddItem(CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        if (p == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)"Only players can add a held item as an auto potion."));
            return 0;
        }
        String id = StringArgumentType.getString(ctx, (String)"id");
        Kit kit = PvPCore.get().kitManager().get(id);
        if (kit == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)PvPCore.get().messages().get("kit.not-found", Map.of("kit", id))));
            return 0;
        }
        Messages mm = PvPCore.get().messages();
        net.minecraft.item.ItemStack held = p.getMainHandStack();
        if (held.isEmpty()) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)mm.get("kit.autopot-held-empty")));
            return 0;
        }
        String snbt = ItemCodecUtil.toSnbt(held);
        if (snbt == null || snbt.isBlank()) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)"Could not serialize the held item."));
            return 0;
        }
        if (kit.autoItems == null) {
            kit.autoItems = new ArrayList<String>();
        }
        kit.autoItems.add(snbt);
        PvPCore.get().kitManager().put(kit);
        PvPCore.get().auditLog().log(((ServerCommandSource)ctx.getSource()).getName(), "Kit " + kit.id + " auto item " + held.getItem().toString() + " x" + held.getCount());
        String out = mm.get("kit.autopot-item-added", Map.of("kit", kit.displayName, "item", held.getName().getString(), "count", String.valueOf(held.getCount())));
        ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)out), false);
        return 1;
    }

    private static int kitAutoPotRemove(CommandContext<ServerCommandSource> ctx) {
        String id = StringArgumentType.getString(ctx, (String)"id");
        Kit kit = PvPCore.get().kitManager().get(id);
        if (kit == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)PvPCore.get().messages().get("kit.not-found", Map.of("kit", id))));
            return 0;
        }
        Messages mm = PvPCore.get().messages();
        int index = IntegerArgumentType.getInteger(ctx, (String)"index");
        int effects = kit.autoEffects == null ? 0 : kit.autoEffects.size();
        int items = kit.autoItems == null ? 0 : kit.autoItems.size();
        if (index < 1 || index > effects + items) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)mm.get("kit.autopot-bad-index", Map.of("index", String.valueOf(index)))));
            return 0;
        }
        if (index <= effects) {
            kit.autoEffects.remove(index - 1);
        } else {
            kit.autoItems.remove(index - effects - 1);
        }
        PvPCore.get().kitManager().put(kit);
        PvPCore.get().auditLog().log(((ServerCommandSource)ctx.getSource()).getName(), "Kit " + kit.id + " auto potion #" + index + " removed");
        String out = mm.get("kit.autopot-removed", Map.of("kit", kit.displayName, "index", String.valueOf(index)));
        ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)out), false);
        return 1;
    }

    private static int kitAutoPotClear(CommandContext<ServerCommandSource> ctx) {
        String id = StringArgumentType.getString(ctx, (String)"id");
        Kit kit = PvPCore.get().kitManager().get(id);
        if (kit == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)PvPCore.get().messages().get("kit.not-found", Map.of("kit", id))));
            return 0;
        }
        if (kit.autoEffects != null) {
            kit.autoEffects.clear();
        }
        if (kit.autoItems != null) {
            kit.autoItems.clear();
        }
        PvPCore.get().kitManager().put(kit);
        PvPCore.get().auditLog().log(((ServerCommandSource)ctx.getSource()).getName(), "Kit " + kit.id + " auto potions cleared");
        String out = PvPCore.get().messages().get("kit.autopot-cleared", Map.of("kit", kit.displayName));
        ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)out), false);
        return 1;
    }

    private static int kitIcon(CommandContext<ServerCommandSource> ctx) {
        String id = StringArgumentType.getString(ctx, (String)"id");
        Kit kit = PvPCore.get().kitManager().get(id);
        if (kit == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)PvPCore.get().messages().get("kit.not-found", Map.of("kit", id))));
            return 0;
        }
        String material = StringArgumentType.getString(ctx, (String)"material").toUpperCase();
        if (ItemCodecUtil.parseMaterial(material).isEmpty()) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)("Unknown item: " + material)));
            return 0;
        }
        kit.displayItem = material;
        PvPCore.get().kitManager().put(kit);
        PvPCore.get().auditLog().log(((ServerCommandSource)ctx.getSource()).getName(), "Changed icon of kit " + id + " to " + material);
        ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)PvPCore.get().messages().get("kit.icon-changed", Map.of("kit", kit.displayName))), false);
        return 1;
    }

    private static int kitSlot(CommandContext<ServerCommandSource> ctx) {
        int position;
        String id = StringArgumentType.getString(ctx, (String)"id");
        Kit kit = PvPCore.get().kitManager().get(id);
        if (kit == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)PvPCore.get().messages().get("kit.not-found", Map.of("kit", id))));
            return 0;
        }
        kit.slot = position = IntegerArgumentType.getInteger(ctx, (String)"position");
        PvPCore.get().kitManager().put(kit);
        PvPCore.get().auditLog().log(((ServerCommandSource)ctx.getSource()).getName(), "Set position of kit " + id + " to " + position);
        ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)PvPCore.get().messages().get("kit.slot-changed", Map.of("kit", kit.displayName, "slot", String.valueOf(position)))), false);
        return 1;
    }

    private static int kitToggle(CommandContext<ServerCommandSource> ctx, boolean enable) {
        String id = StringArgumentType.getString(ctx, (String)"id");
        Kit kit = PvPCore.get().kitManager().get(id);
        if (kit == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)PvPCore.get().messages().get("kit.not-found", Map.of("kit", id))));
            return 0;
        }
        kit.enabled = enable;
        PvPCore.get().kitManager().put(kit);
        PvPCore.get().auditLog().log(((ServerCommandSource)ctx.getSource()).getName(), (enable ? "Enabled " : "Disabled ") + "kit " + id);
        ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)PvPCore.get().messages().get(enable ? "kit.enabled" : "kit.disabled", Map.of("kit", kit.displayName))), false);
        return 1;
    }

    private static int kitList(CommandContext<ServerCommandSource> ctx) {
        for (Kit kit : PvPCore.get().kitManager().all()) {
            ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)TextUtil.colorize("&e" + kit.id + " &8- &f" + kit.displayName)), false);
        }
        return 1;
    }

    private static int debugSummary(CommandContext<ServerCommandSource> ctx) {
        PvPCore core = PvPCore.get();
        ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)TextUtil.colorize("&6PvP Core&7: duels=&f" + core.duelManager().allDuels().size() + "&7 queues=&f" + core.queueManager().totalQueued() + "&7 parties=&f" + core.partyManager().allParties().size() + "&7 arenas=&f" + core.arenaManager().all().size() + " &7(&f" + core.arenaManager().countUsable() + "&7 usable)")), false);
        return 1;
    }

    private static int debugState(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity target = EntityArgumentType.getPlayer(ctx, (String)"player");
        PvPCore core = PvPCore.get();
        PlayerState state = core.playerManager().state(target);
        Duel duel = core.duelManager().duelOf(target);
        PartyManager.Party party = core.partyManager().partyOf(target);
        ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)TextUtil.colorize("&e" + target.getGameProfile().name() + "&7: state=&f" + String.valueOf((Object)state) + "&7 loginSynced=&f" + core.playerManager().loginSynced(target) + "&7 duel=&f" + (String)(duel != null ? duel.kitId + " (" + String.valueOf((Object)duel.state) + ")" : "none") + "&7 party=&f" + (String)(party != null ? party.members.size() + " members" : "none") + "&7 queued=&f" + core.queueManager().isQueued(target))), false);
        return 1;
    }

    private static int debugDuels(CommandContext<ServerCommandSource> ctx) {
        for (Duel duel : PvPCore.get().duelManager().allDuels()) {
            ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)TextUtil.colorize("&e" + duel.firstAName() + " vs " + duel.firstBName() + " &7kit=&f" + duel.kitId + "&7 state=&f" + String.valueOf((Object)duel.state) + "&7 arena=&f" + (duel.arena != null ? duel.arena.id : "?"))), false);
        }
        return 1;
    }

    private static int debugArenas(CommandContext<ServerCommandSource> ctx) {
        for (Arena arena : PvPCore.get().arenaManager().all()) {
            ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)TextUtil.colorize("&e" + arena.id + " &7status=&f" + String.valueOf((Object)arena.status) + "&7 enabled=&f" + arena.enabled + "&7 kits=&f" + (arena.kitIds != null && !arena.kitIds.isEmpty() ? String.join((CharSequence)",", arena.kitIds) : "any") + "&7 spawns=&f" + arena.spawn1Set + "/" + arena.spawn2Set)), false);
        }
        return 1;
    }

    private static int debugQueues(CommandContext<ServerCommandSource> ctx) {
        QueueManager entry = PvPCore.get().queueManager();
        ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)TextUtil.colorize("&7Total queued: &f" + entry.totalQueued())), false);
        return 1;
    }

    private static void adminFeedback(CommandContext<ServerCommandSource> ctx, String message) {
        ((ServerCommandSource)ctx.getSource()).sendFeedback(() -> Text.literal((String)message), false);
    }

    private static int zoneList(CommandContext<ServerCommandSource> ctx) {
        Messages mm = PvPCore.get().messages();
        PvPCommands.adminFeedback(ctx, mm.get("zone.list-header"));
        for (FightZone zone : PvPCore.get().zoneManager().all()) {
            int online = PvPCore.get().zoneManager().membersOf(zone).size();
            String state = zone.enabled ? "&aenabled" : "&cdisabled";
            PvPCommands.adminFeedback(ctx, mm.get("zone.list-entry", Map.of("zone", zone.id, "online", String.valueOf(online), "state", state)));
        }
        return 1;
    }

    private static int zoneJoin(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        String id = StringArgumentType.getString(ctx, (String)"id");
        FightZone zone = PvPCore.get().zoneManager().get(id);
        if (p == null || zone == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)PvPCore.get().messages().get("zone.not-found", Map.of("zone", id))));
            return 0;
        }
        PvPCore.get().zoneManager().join(p, zone);
        return 1;
    }

    private static int zoneCreate(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        if (p == null) {
            return 0;
        }
        String id = StringArgumentType.getString(ctx, (String)"id").toLowerCase();
        if (!KitManager.validId(id)) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)PvPCore.get().messages().get("kit.invalid-name")));
            return 0;
        }
        if (PvPCore.get().zoneManager().get(id) != null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)PvPCore.get().messages().get("zone.already-exists", Map.of("zone", id))));
            return 0;
        }
        FightZone zone = PvPCore.get().zoneManager().create(id, "&f" + id);
        zone.world = p.getEntityWorld().getRegistryKey().getValue().toString();
        zone.x = p.getX();
        zone.y = p.getY();
        zone.z = p.getZ();
        zone.yaw = p.getYaw();
        zone.pitch = p.getPitch();
        PvPCore.get().zoneManager().save();
        PvPCore.get().auditLog().log(((ServerCommandSource)ctx.getSource()).getName(), "Created zone " + id);
        PvPCommands.adminFeedback(ctx, PvPCore.get().messages().get("zone.created", Map.of("zone", id)));
        return 1;
    }

    private static int zoneDelete(CommandContext<ServerCommandSource> ctx) {
        String id = StringArgumentType.getString(ctx, (String)"id");
        if (PvPCore.get().zoneManager().delete(id)) {
            PvPCore.get().auditLog().log(((ServerCommandSource)ctx.getSource()).getName(), "Deleted zone " + id);
            PvPCommands.adminFeedback(ctx, PvPCore.get().messages().get("zone.deleted", Map.of("zone", id)));
            PvPCommands.adminFeedback(ctx, PvPCore.get().messages().get("zone.deleted-members"));
            return 1;
        }
        ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)PvPCore.get().messages().get("zone.not-found", Map.of("zone", id))));
        return 0;
    }

    private static int zoneToggle(CommandContext<ServerCommandSource> ctx, boolean enabled) {
        String id = StringArgumentType.getString(ctx, (String)"id");
        FightZone zone = PvPCore.get().zoneManager().get(id);
        if (zone == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)PvPCore.get().messages().get("zone.not-found", Map.of("zone", id))));
            return 0;
        }
        zone.enabled = enabled;
        PvPCore.get().zoneManager().save();
        PvPCommands.adminFeedback(ctx, TextUtil.colorize("&7Zone &e" + id + "&7 is now " + (enabled ? "&aenabled" : "&cdisabled") + "&7."));
        return 1;
    }

    private static int zoneSetSpawn(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        if (p == null) {
            return 0;
        }
        String id = StringArgumentType.getString(ctx, (String)"id");
        FightZone zone = PvPCore.get().zoneManager().get(id);
        if (zone == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)PvPCore.get().messages().get("zone.not-found", Map.of("zone", id))));
            return 0;
        }
        zone.world = p.getEntityWorld().getRegistryKey().getValue().toString();
        zone.x = p.getX();
        zone.y = p.getY();
        zone.z = p.getZ();
        zone.yaw = p.getYaw();
        zone.pitch = p.getPitch();
        PvPCore.get().zoneManager().save();
        PvPCommands.adminFeedback(ctx, PvPCore.get().messages().get("zone.spawn-set", Map.of("zone", id)));
        return 1;
    }

    private static int zoneName(CommandContext<ServerCommandSource> ctx) {
        String id = StringArgumentType.getString(ctx, (String)"id");
        String name = StringArgumentType.getString(ctx, (String)"name");
        if (PvPCore.get().zoneManager().rename(id, name)) {
            PvPCommands.adminFeedback(ctx, PvPCore.get().messages().get("zone.name-set"));
            return 1;
        }
        ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)PvPCore.get().messages().get("zone.not-found", Map.of("zone", id))));
        return 0;
    }

    private static int zoneMode(CommandContext<ServerCommandSource> ctx, String mode) {
        String id = StringArgumentType.getString(ctx, (String)"id");
        FightZone zone = PvPCore.get().zoneManager().get(id);
        if (zone == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)PvPCore.get().messages().get("zone.not-found", Map.of("zone", id))));
            return 0;
        }
        zone.mode = mode;
        PvPCore.get().zoneManager().save();
        PvPCommands.adminFeedback(ctx, PvPCore.get().messages().get("zone.mode-set", Map.of("mode", mode)));
        return 1;
    }

    private static int zoneSetKit(CommandContext<ServerCommandSource> ctx) {
        String id = StringArgumentType.getString(ctx, (String)"id");
        String kitId = StringArgumentType.getString(ctx, (String)"kit").toLowerCase();
        FightZone zone = PvPCore.get().zoneManager().get(id);
        Kit kit = PvPCore.get().kitManager().get(kitId);
        if (zone == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)PvPCore.get().messages().get("zone.not-found", Map.of("zone", id))));
            return 0;
        }
        if (kit == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)PvPCore.get().messages().get("kit.not-found", Map.of("kit", kitId))));
            return 0;
        }
        zone.fixedKit = kit.id;
        zone.mode = "fixed";
        PvPCore.get().zoneManager().save();
        PvPCommands.adminFeedback(ctx, PvPCore.get().messages().get("zone.kit-set", Map.of("kit", kit.id)));
        return 1;
    }

    private static int zoneKitsList(CommandContext<ServerCommandSource> ctx) {
        String id = StringArgumentType.getString(ctx, (String)"id");
        FightZone zone = PvPCore.get().zoneManager().get(id);
        if (zone == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)PvPCore.get().messages().get("zone.not-found", Map.of("zone", id))));
            return 0;
        }
        String kits = String.join((CharSequence)", ", zone.kits.isEmpty() ? List.of("(all enabled kits)") : zone.kits);
        PvPCommands.adminFeedback(ctx, PvPCore.get().messages().get("zone.kits-list", Map.of("zone", id, "kits", kits)));
        return 1;
    }

    private static int zoneKitAddRemove(CommandContext<ServerCommandSource> ctx, boolean add) {
        String id = StringArgumentType.getString(ctx, (String)"id");
        String kitId = StringArgumentType.getString(ctx, (String)"kit").toLowerCase();
        FightZone zone = PvPCore.get().zoneManager().get(id);
        Kit kit = PvPCore.get().kitManager().get(kitId);
        Messages mm = PvPCore.get().messages();
        if (zone == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)mm.get("zone.not-found", Map.of("zone", id))));
            return 0;
        }
        if (kit == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)mm.get("kit.not-found", Map.of("kit", kitId))));
            return 0;
        }
        if (add) {
            if (zone.kits.contains(kit.id)) {
                ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)mm.get("zone.kit-already", Map.of("kit", kit.id, "zone", id))));
                return 0;
            }
            zone.kits.add(kit.id);
            PvPCore.get().zoneManager().save();
            PvPCommands.adminFeedback(ctx, mm.get("zone.kit-added", Map.of("kit", kit.id, "zone", id)));
            return 1;
        }
        if (!zone.kits.remove(kit.id)) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)mm.get("zone.kit-not-in-zone", Map.of("kit", kit.id, "zone", id))));
            return 0;
        }
        PvPCore.get().zoneManager().save();
        PvPCommands.adminFeedback(ctx, mm.get("zone.kit-removed", Map.of("kit", kit.id, "zone", id)));
        return 1;
    }

    private static int zoneKitClear(CommandContext<ServerCommandSource> ctx) {
        String id = StringArgumentType.getString(ctx, (String)"id");
        FightZone zone = PvPCore.get().zoneManager().get(id);
        if (zone == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)PvPCore.get().messages().get("zone.not-found", Map.of("zone", id))));
            return 0;
        }
        zone.kits.clear();
        PvPCore.get().zoneManager().save();
        PvPCommands.adminFeedback(ctx, PvPCore.get().messages().get("zone.kits-list", Map.of("zone", id, "kits", "(all enabled kits)")));
        return 1;
    }

    private static int zoneSbTitle(CommandContext<ServerCommandSource> ctx) {
        String id = StringArgumentType.getString(ctx, (String)"id");
        FightZone zone = PvPCore.get().zoneManager().get(id);
        if (zone == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)PvPCore.get().messages().get("zone.not-found", Map.of("zone", id))));
            return 0;
        }
        zone.sbTitle = StringArgumentType.getString(ctx, (String)"value");
        PvPCore.get().zoneManager().save();
        PvPCore.get().zoneManager().rebuildScoreboards();
        PvPCommands.adminFeedback(ctx, PvPCore.get().messages().get("zone.sb-title-set"));
        return 1;
    }

    private static int zoneSbAddLine(CommandContext<ServerCommandSource> ctx) {
        String id = StringArgumentType.getString(ctx, (String)"id");
        FightZone zone = PvPCore.get().zoneManager().get(id);
        if (zone == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)PvPCore.get().messages().get("zone.not-found", Map.of("zone", id))));
            return 0;
        }
        String line = StringArgumentType.getString(ctx, (String)"value");
        zone.sbLines.add(line);
        PvPCore.get().zoneManager().save();
        PvPCommands.adminFeedback(ctx, PvPCore.get().messages().get("zone.sb-line-added", Map.of("line", line)));
        return 1;
    }

    private static int zoneSbSetLine(CommandContext<ServerCommandSource> ctx) {
        String id = StringArgumentType.getString(ctx, (String)"id");
        FightZone zone = PvPCore.get().zoneManager().get(id);
        if (zone == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)PvPCore.get().messages().get("zone.not-found", Map.of("zone", id))));
            return 0;
        }
        int index = IntegerArgumentType.getInteger(ctx, (String)"index");
        if (index < 1 || index > zone.sbLines.size()) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)("Line index out of range (1-" + zone.sbLines.size() + ")")));
            return 0;
        }
        String line = StringArgumentType.getString(ctx, (String)"value");
        zone.sbLines.set(index - 1, line);
        PvPCore.get().zoneManager().save();
        PvPCommands.adminFeedback(ctx, PvPCore.get().messages().get("zone.sb-line-set", Map.of("index", String.valueOf(index), "line", line)));
        return 1;
    }

    private static int zoneSbRemoveLine(CommandContext<ServerCommandSource> ctx) {
        String id = StringArgumentType.getString(ctx, (String)"id");
        FightZone zone = PvPCore.get().zoneManager().get(id);
        if (zone == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)PvPCore.get().messages().get("zone.not-found", Map.of("zone", id))));
            return 0;
        }
        int index = IntegerArgumentType.getInteger(ctx, (String)"index");
        if (index < 1 || index > zone.sbLines.size()) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)("Line index out of range (1-" + zone.sbLines.size() + ")")));
            return 0;
        }
        zone.sbLines.remove(index - 1);
        PvPCore.get().zoneManager().save();
        PvPCommands.adminFeedback(ctx, PvPCore.get().messages().get("zone.sb-line-removed", Map.of("index", String.valueOf(index))));
        return 1;
    }

    private static int zoneSbClearLines(CommandContext<ServerCommandSource> ctx) {
        String id = StringArgumentType.getString(ctx, (String)"id");
        FightZone zone = PvPCore.get().zoneManager().get(id);
        if (zone == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)PvPCore.get().messages().get("zone.not-found", Map.of("zone", id))));
            return 0;
        }
        zone.sbLines.clear();
        PvPCore.get().zoneManager().save();
        PvPCommands.adminFeedback(ctx, PvPCore.get().messages().get("zone.sb-lines-cleared"));
        return 1;
    }

    private static int zoneSbReset(CommandContext<ServerCommandSource> ctx) {
        String id = StringArgumentType.getString(ctx, (String)"id");
        FightZone zone = PvPCore.get().zoneManager().get(id);
        if (zone == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)PvPCore.get().messages().get("zone.not-found", Map.of("zone", id))));
            return 0;
        }
        zone.sbLines = FightZone.defaultLines();
        PvPCore.get().zoneManager().save();
        PvPCore.get().zoneManager().rebuildScoreboards();
        PvPCommands.adminFeedback(ctx, PvPCore.get().messages().get("zone.sb-reset"));
        return 1;
    }

    private static int npcCreate(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        String zoneId = StringArgumentType.getString(ctx, (String)"zone").toLowerCase();
        String name = StringArgumentType.getString(ctx, (String)"name");
        FightZone zone = PvPCore.get().zoneManager().get(zoneId);
        if (zone == null) {
            ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)PvPCore.get().messages().get("zone.not-found", Map.of("zone", zoneId))));
            return 0;
        }
        ServerPlayerEntity p = ((ServerCommandSource)ctx.getSource()).getPlayer();
        if (p != null) {
            String world = p.getEntityWorld().getRegistryKey().getValue().toString();
            PvPCore.get().zoneManager().createNpc(zoneId, name, p, world, p.getX(), p.getY(), p.getZ(), p.getYaw(), p.getPitch());
        } else {
            PvPCore.get().zoneManager().createNpc(zoneId, name, null, zone.world, zone.x, zone.y, zone.z, zone.yaw, zone.pitch);
        }
        PvPCore.get().auditLog().log(((ServerCommandSource)ctx.getSource()).getName(), "Created zone NPC " + name);
        PvPCommands.adminFeedback(ctx, PvPCore.get().messages().get("npc.created", Map.of("name", name, "zone", zoneId)));
        PvPCommands.adminFeedback(ctx, PvPCore.get().messages().get("npc.hint"));
        return 1;
    }

    private static int npcRemove(CommandContext<ServerCommandSource> ctx) {
        String id = StringArgumentType.getString(ctx, (String)"id");
        if (PvPCore.get().zoneManager().removeNpc(id)) {
            PvPCommands.adminFeedback(ctx, PvPCore.get().messages().get("npc.removed", Map.of("name", id)));
            return 1;
        }
        ((ServerCommandSource)ctx.getSource()).sendError((Text)Text.literal((String)PvPCore.get().messages().get("npc.not-found", Map.of("id", id))));
        return 0;
    }

    private static int npcRespawn(CommandContext<ServerCommandSource> ctx) {
        int spawned = 0;
        for (FakePlayerNpc npc : PvPCore.get().zoneManager().npcs()) {
            if (!npc.spawn(PvPCore.get().server())) continue;
            ++spawned;
        }
        PvPCommands.adminFeedback(ctx, TextUtil.colorize("&aRespawned &f" + spawned + "&a NPC(s)."));
        return 1;
    }

    private static int npcList(CommandContext<ServerCommandSource> ctx) {
        Messages mm = PvPCore.get().messages();
        PvPCommands.adminFeedback(ctx, mm.get("npc.list-header"));
        for (FakePlayerNpc npc : PvPCore.get().zoneManager().npcs()) {
            PvPCommands.adminFeedback(ctx, mm.get("npc.list-entry", Map.of("name", npc.displayName, "zone", npc.zoneId)));
        }
        return 1;
    }
}

