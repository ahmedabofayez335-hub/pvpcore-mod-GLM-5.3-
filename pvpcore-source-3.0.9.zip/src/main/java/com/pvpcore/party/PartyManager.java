/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.server.PlayerManager
 *  net.minecraft.server.network.ServerPlayerEntity
 *  net.minecraft.text.Text
 *  net.minecraft.util.Formatting
 */
package com.pvpcore.party;

import com.pvpcore.PvPCore;
import com.pvpcore.config.MainConfig;
import com.pvpcore.config.Messages;
import com.pvpcore.gui.guis.KitPickerGui;
import com.pvpcore.gui.guis.PartyGui;
import com.pvpcore.gui.guis.PlayerPickerGui;
import com.pvpcore.util.ChatButtons;
import com.pvpcore.util.TitleUtil;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.server.PlayerManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public final class PartyManager {
    private final Map<UUID, Party> parties = new ConcurrentHashMap<UUID, Party>();
    private final Map<UUID, UUID> memberIndex = new ConcurrentHashMap<UUID, UUID>();
    private final Map<UUID, PartyInvite> invites = new ConcurrentHashMap<UUID, PartyInvite>();
    private long tick = 0L;

    public Party partyOf(ServerPlayerEntity player) {
        return player == null ? null : this.partyOf(player.getUuid());
    }

    public Party partyOf(UUID uuid) {
        UUID partyId = this.memberIndex.get(uuid);
        if (partyId == null) {
            return null;
        }
        Party party = this.parties.get(partyId);
        if (party == null || !party.members.contains(uuid)) {
            this.memberIndex.remove(uuid);
            return null;
        }
        return party;
    }

    public Party partyById(UUID id) {
        return this.parties.get(id);
    }

    public List<Party> allParties() {
        return new ArrayList<Party>(this.parties.values());
    }

    public PartyInvite inviteFor(UUID target) {
        return this.invites.get(target);
    }

    public Party createParty(ServerPlayerEntity player) {
        Party existing = this.partyOf(player);
        if (existing != null) {
            return existing;
        }
        Party party = new Party(player.getUuid());
        party.color = PvPCore.get().teamColors().nextPartyColor();
        this.parties.put(party.id, party);
        this.memberIndex.put(player.getUuid(), party.id);
        player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("party.created")), false);
        PvPCore.get().teamColors().applyPartyColor(party);
        this.refreshMembers(party);
        return party;
    }

    public void disband(ServerPlayerEntity player) {
        Party party = this.partyOf(player);
        if (party != null && party.isLeader(player.getUuid())) {
            Messages mm = PvPCore.get().messages();
            for (ServerPlayerEntity member : party.onlineMembers()) {
                member.sendMessage((Text)Text.literal((String)mm.get("party.disbanded")), false);
            }
            for (UUID u : party.members) {
                this.memberIndex.remove(u);
            }
            this.parties.remove(party.id);
            PvPCore.get().teamColors().clearPartyColor(party);
            this.refreshMembers(party);
        }
    }

    public void leave(ServerPlayerEntity player) {
        Party party = this.partyOf(player);
        if (party != null) {
            Messages mm = PvPCore.get().messages();
            if (party.isLeader(player.getUuid())) {
                if (party.members.size() <= 1) {
                    this.disband(player);
                    return;
                }
                UUID next = party.members.stream().filter(u -> !u.equals(player.getUuid())).findFirst().orElse(null);
                party.members.remove(player.getUuid());
                this.memberIndex.remove(player.getUuid());
                PvPCore.get().teamColors().clearMemberColor(player);
                if (next != null) {
                    party.leader = next;
                    ServerPlayerEntity nextP = PvPCore.get().server().getPlayerManager().getPlayer(next);
                    if (nextP != null) {
                        nextP.sendMessage((Text)Text.literal((String)mm.get("party.you-promoted")), false);
                    }
                }
                player.sendMessage((Text)Text.literal((String)mm.get("party.left")), false);
                this.broadcast(party, mm.get("party.player-left", Map.of("player", player.getGameProfile().name())));
            } else {
                party.members.remove(player.getUuid());
                this.memberIndex.remove(player.getUuid());
                PvPCore.get().teamColors().clearMemberColor(player);
                player.sendMessage((Text)Text.literal((String)mm.get("party.left")), false);
                this.broadcast(party, mm.get("party.player-left", Map.of("player", player.getGameProfile().name())));
            }
            this.refreshMembers(party);
        }
    }

    private boolean canJoinParty(ServerPlayerEntity player) {
        Party current = this.partyOf(player);
        if (current == null) {
            return true;
        }
        if (current.members.size() > 1) {
            return false;
        }
        this.memberIndex.remove(player.getUuid());
        current.members.remove(player.getUuid());
        this.parties.remove(current.id);
        PvPCore.get().teamColors().clearPartyColor(current);
        return true;
    }

    public void onPlayerJoin(ServerPlayerEntity player) {
        this.invites.remove(player.getUuid());
        this.partyOf(player.getUuid());
        PvPCore.get().teamColors().clearMemberColor(player);
    }

    public void kick(ServerPlayerEntity leader, ServerPlayerEntity target) {
        Party party = this.partyOf(leader);
        if (party != null && party.isLeader(leader.getUuid()) && !target.getUuid().equals(leader.getUuid()) && party.members.contains(target.getUuid())) {
            party.members.remove(target.getUuid());
            this.memberIndex.remove(target.getUuid());
            PvPCore.get().teamColors().clearMemberColor(target);
            Messages mm = PvPCore.get().messages();
            target.sendMessage((Text)Text.literal((String)mm.get("party.you-kicked")), false);
            this.broadcast(party, mm.get("party.kicked", Map.of("player", target.getGameProfile().name())));
            this.refreshMembers(party);
        }
    }

    public void promote(ServerPlayerEntity leader, ServerPlayerEntity target) {
        Party party = this.partyOf(leader);
        if (party != null && party.isLeader(leader.getUuid()) && party.members.contains(target.getUuid())) {
            party.leader = target.getUuid();
            Messages mm = PvPCore.get().messages();
            this.broadcast(party, mm.get("party.promoted", Map.of("player", target.getGameProfile().name())));
            target.sendMessage((Text)Text.literal((String)mm.get("party.you-promoted")), false);
            this.refreshMembers(party);
        }
    }

    public boolean invite(ServerPlayerEntity inviter, ServerPlayerEntity target) {
        Party party = this.partyOf(inviter);
        if (party == null) {
            return false;
        }
        MainConfig.PartySection cfg = PvPCore.get().config().party;
        Messages mm = PvPCore.get().messages();
        if (!party.isLeader(inviter.getUuid()) && !cfg.membersCanInvite) {
            inviter.sendMessage((Text)Text.literal((String)mm.get("party.not-leader")), false);
            return false;
        }
        if (PvPCore.get().duelManager().duelOf(inviter) != null) {
            inviter.sendMessage((Text)Text.literal((String)mm.get("party.you-in-duel")), false);
            return false;
        }
        if (PvPCore.get().duelManager().duelOf(target) != null) {
            inviter.sendMessage((Text)Text.literal((String)mm.get("party.target-in-duel", Map.of("player", target.getGameProfile().name()))), false);
            return false;
        }
        if (!this.canJoinParty(target)) {
            inviter.sendMessage((Text)Text.literal((String)mm.get("party.already-in-party")), false);
            return false;
        }
        if (party.members.size() >= cfg.maxSize) {
            inviter.sendMessage((Text)Text.literal((String)mm.get("party.full", Map.of("max", String.valueOf(cfg.maxSize)))), false);
            return false;
        }
        this.invites.remove(target.getUuid());
        PartyInvite invite = new PartyInvite(party.id, inviter.getUuid(), target.getUuid(), this.tick + (long)cfg.inviteExpirySeconds * 20L);
        this.invites.put(target.getUuid(), invite);
        inviter.sendMessage((Text)Text.literal((String)mm.get("party.invite-sent", Map.of("player", target.getGameProfile().name()))), false);
        TitleUtil.title(target, mm.get("party.invite-received-title"), mm.get("party.invite-received-subtitle", Map.of("player", inviter.getGameProfile().name())));
        target.sendMessage((Text)ChatButtons.line(new Text[]{Text.literal((String)mm.get("party.invite-chat-header", Map.of("player", inviter.getGameProfile().name())))}), false);
        target.sendMessage((Text)ChatButtons.line(new Text[]{ChatButtons.button(mm.get("party.accept-button"), "/party accept", mm.get("party.accept-hover"), Formatting.GREEN), Text.literal((String)" "), ChatButtons.button(mm.get("party.deny-button"), "/party deny", mm.get("party.deny-hover"), Formatting.RED)}), false);
        target.sendMessage((Text)Text.literal((String)mm.get("duel.challenge-chat-expire", Map.of("seconds", String.valueOf(cfg.inviteExpirySeconds)))), false);
        return true;
    }

    public void acceptInvite(ServerPlayerEntity player) {
        Party party;
        PartyInvite invite = this.invites.remove(player.getUuid());
        if (invite != null && (party = this.parties.get(invite.partyId)) != null) {
            MainConfig.PartySection cfg = PvPCore.get().config().party;
            Messages mm = PvPCore.get().messages();
            if (PvPCore.get().duelManager().duelOf(player) != null) {
                player.sendMessage((Text)Text.literal((String)mm.get("party.cant-while-dueling")), false);
            } else if (party.members.size() < cfg.maxSize && this.canJoinParty(player)) {
                party.members.add(player.getUuid());
                this.memberIndex.put(player.getUuid(), party.id);
                PvPCore.get().teamColors().applyPartyColor(party);
                player.sendMessage((Text)Text.literal((String)mm.get("party.joined", Map.of("player", this.nameOf(party.leader)))), false);
                this.broadcast(party, mm.get("party.player-joined", Map.of("player", player.getGameProfile().name())));
                this.refreshMembers(party);
                new PartyGui(player).open(player);
            }
        }
    }

    public void denyInvite(ServerPlayerEntity player) {
        ServerPlayerEntity inviter;
        PartyInvite invite = this.invites.remove(player.getUuid());
        if (invite != null && (inviter = PvPCore.get().server().getPlayerManager().getPlayer(invite.inviter)) != null) {
            inviter.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("party.invite-denied", Map.of("player", player.getGameProfile().name()))), false);
        }
    }

    public void sendPartyMenu(ServerPlayerEntity player) {
        Party party = this.partyOf(player);
        if (party == null) {
            if (PvPCore.get().config().party.autoCreateOnItemClick) {
                this.createParty(player);
                party = this.partyOf(player);
            }
            if (party == null) {
                player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("party.not-in-party")), false);
                return;
            }
        }
        new PartyGui(player).open(player);
    }

    public boolean isEligibleInviteTarget(ServerPlayerEntity p) {
        if (PvPCore.get().duelManager().duelOf(p) != null) {
            return false;
        }
        Party party = this.partyOf(p);
        return party == null || party.members.size() <= 1;
    }

    public void openInvitePicker(ServerPlayerEntity player) {
        Party party = this.partyOf(player);
        if (party != null) {
            Messages mm = PvPCore.get().messages();
            if (!party.isLeader(player.getUuid()) && !PvPCore.get().config().party.membersCanInvite) {
                player.sendMessage((Text)Text.literal((String)mm.get("party.not-leader")), false);
            } else {
                new PlayerPickerGui(player, mm.get("party.menu-invite-players"), target -> {
                    this.invite(player, (ServerPlayerEntity)target);
                    new PartyGui(player).open(player);
                }, this::isEligibleInviteTarget).open(player);
            }
        }
    }

    public void openDuelPicker(ServerPlayerEntity player) {
        Messages mm = PvPCore.get().messages();
        Party myParty = this.partyOf(player);
        if (myParty != null && myParty.isLeader(player.getUuid())) {
            new PlayerPickerGui(player, mm.get("party.menu-duel-leaders"), target -> new KitPickerGui(player, false, (ServerPlayerEntity)target, true).open(player), p -> {
                Party other = this.partyOf((ServerPlayerEntity)p);
                return other != null && other != myParty && other.isLeader(p.getUuid()) && PvPCore.get().duelManager().duelOf((ServerPlayerEntity)p) == null;
            }).open(player);
        } else {
            player.sendMessage((Text)Text.literal((String)mm.get("party.not-leader")), false);
        }
    }

    private String nameOf(UUID uuid) {
        ServerPlayerEntity p = PvPCore.get().server().getPlayerManager().getPlayer(uuid);
        return p != null ? p.getGameProfile().name() : "?";
    }

    private void broadcast(Party party, String message) {
        for (ServerPlayerEntity member : party.onlineMembers()) {
            member.sendMessage((Text)Text.literal((String)message), false);
        }
    }

    private void refreshMembers(Party party) {
        for (UUID u : party.members) {
            ServerPlayerEntity p = PvPCore.get().server().getPlayerManager().getPlayer(u);
            if (p == null) continue;
            PvPCore.get().playerManager().refreshLobby(p);
        }
    }

    public void onQuit(ServerPlayerEntity player) {
        this.invites.remove(player.getUuid());
        Party party = this.partyOf(player);
        if (party != null) {
            PvPCore.get().teamColors().clearMemberColor(player);
            if (party.isLeader(player.getUuid()) && PvPCore.get().config().party.disbandOnLeaderQuit) {
                this.disbandForLeaderQuit(party, player);
                return;
            }
            if (party.members.size() > 1) {
                if (party.isLeader(player.getUuid())) {
                    UUID next = party.members.stream().filter(u -> !u.equals(player.getUuid())).findFirst().orElse(null);
                    party.members.remove(player.getUuid());
                    this.memberIndex.remove(player.getUuid());
                    if (next != null) {
                        party.leader = next;
                        ServerPlayerEntity nextP = PvPCore.get().server().getPlayerManager().getPlayer(next);
                        if (nextP != null) {
                            nextP.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("party.you-promoted")), false);
                        }
                    }
                } else {
                    party.members.remove(player.getUuid());
                    this.memberIndex.remove(player.getUuid());
                }
                this.broadcast(party, PvPCore.get().messages().get("party.player-left", Map.of("player", player.getGameProfile().name())));
            } else {
                for (UUID u2 : party.members) {
                    this.memberIndex.remove(u2);
                }
                PvPCore.get().teamColors().clearPartyColor(party);
                this.parties.remove(party.id);
            }
        }
    }

    private void disbandForLeaderQuit(Party party, ServerPlayerEntity leader) {
        Messages mm = PvPCore.get().messages();
        PlayerManager pm = PvPCore.get().server().getPlayerManager();
        for (UUID u : List.copyOf(party.members)) {
            ServerPlayerEntity member;
            if (u.equals(leader.getUuid()) || (member = pm.getPlayer(u)) == null) continue;
            member.sendMessage((Text)Text.literal((String)mm.get("party.disbanded-leader-left", Map.of("player", leader.getGameProfile().name()))), false);
        }
        for (UUID ux : party.members) {
            this.memberIndex.remove(ux);
        }
        PvPCore.get().teamColors().clearPartyColor(party);
        this.parties.remove(party.id);
        this.refreshMembers(party);
    }

    public void tick() {
        ++this.tick;
        this.invites.entrySet().removeIf(e -> {
            if (this.tick >= ((PartyInvite)e.getValue()).expiryTick) {
                ServerPlayerEntity target = PvPCore.get().server().getPlayerManager().getPlayer((UUID)e.getKey());
                if (target != null) {
                    target.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("party.invite-expired")), false);
                }
                return true;
            }
            return false;
        });
    }

    public void shutdown() {
        for (Party party : new ArrayList<Party>(this.parties.values())) {
            PvPCore.get().teamColors().clearPartyColor(party);
        }
        this.parties.clear();
        this.memberIndex.clear();
        this.invites.clear();
    }

    public static class Party {
        public final UUID id = UUID.randomUUID();
        public UUID leader;
        public final Set<UUID> members = new HashSet<UUID>();
        public volatile transient Formatting color;

        public Party(UUID leader) {
            this.leader = leader;
            this.members.add(leader);
        }

        public boolean isLeader(UUID player) {
            return this.leader.equals(player);
        }

        public List<ServerPlayerEntity> onlineMembers() {
            ArrayList<ServerPlayerEntity> out = new ArrayList<ServerPlayerEntity>();
            PlayerManager pm = PvPCore.get().server().getPlayerManager();
            for (UUID u : this.members) {
                ServerPlayerEntity p = pm.getPlayer(u);
                if (p == null) continue;
                out.add(p);
            }
            return out;
        }

        public List<UUID> onlineMemberUuids() {
            ArrayList<UUID> out = new ArrayList<UUID>();
            PlayerManager pm = PvPCore.get().server().getPlayerManager();
            for (UUID u : this.members) {
                if (pm.getPlayer(u) == null) continue;
                out.add(u);
            }
            return out;
        }
    }

    public static class PartyInvite {
        public final UUID partyId;
        public final UUID inviter;
        public final UUID target;
        public final long expiryTick;

        public PartyInvite(UUID partyId, UUID inviter, UUID target, long expiryTick) {
            this.partyId = partyId;
            this.inviter = inviter;
            this.target = target;
            this.expiryTick = expiryTick;
        }
    }
}

