/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.packet.c2s.play.ClickSlotC2SPacket
 *  net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket
 *  net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket$Action
 *  net.minecraft.server.network.ServerPlayNetworkHandler
 *  net.minecraft.server.network.ServerPlayerEntity
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package com.pvpcore.mixin;

import com.pvpcore.PvPCore;
import net.minecraft.network.packet.c2s.play.ClickSlotC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.server.network.ServerPlayNetworkHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={ServerPlayNetworkHandler.class})
public abstract class ServerPlayNetworkHandlerMixin {
    @Shadow
    public ServerPlayerEntity field_14140;

    @Inject(method={"onClickSlot"}, at={@At(value="HEAD")}, cancellable=true)
    private void pvpcore$onClickSlot(ClickSlotC2SPacket packet, CallbackInfo ci) {
        ServerPlayerEntity p = this.field_14140;
        if (p != null && PvPCore.get().server() != null && p.currentScreenHandler == p.playerScreenHandler && PvPCore.get().isInventoryLocked(p)) {
            ci.cancel();
            p.currentScreenHandler.updateToClient();
        }
    }

    @Inject(method={"onPlayerAction"}, at={@At(value="HEAD")}, cancellable=true)
    private void pvpcore$onPlayerAction(PlayerActionC2SPacket packet, CallbackInfo ci) {
        PlayerActionC2SPacket.Action action;
        ServerPlayerEntity p = this.field_14140;
        if (p != null && p.currentScreenHandler == p.playerScreenHandler && ((action = packet.getAction()) == PlayerActionC2SPacket.Action.DROP_ITEM || action == PlayerActionC2SPacket.Action.DROP_ALL_ITEMS || action == PlayerActionC2SPacket.Action.SWAP_ITEM_WITH_OFFHAND) && PvPCore.get().isInventoryLocked(p)) {
            ci.cancel();
            p.currentScreenHandler.updateToClient();
        }
    }
}

