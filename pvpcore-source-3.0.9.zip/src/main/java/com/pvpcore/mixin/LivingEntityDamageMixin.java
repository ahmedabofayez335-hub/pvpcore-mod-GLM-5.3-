/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.LivingEntity
 *  net.minecraft.entity.damage.DamageSource
 *  net.minecraft.server.world.ServerWorld
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package com.pvpcore.mixin;

import com.pvpcore.PvPCore;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.server.world.ServerWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={LivingEntity.class})
public abstract class LivingEntityDamageMixin {
    private static final ThreadLocal<Boolean> PVPCORE_SCALING = ThreadLocal.withInitial(() -> false);

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Inject(method={"damage(Lnet/minecraft/server/world/ServerWorld;Lnet/minecraft/entity/damage/DamageSource;F)Z"}, at={@At(value="HEAD")}, cancellable=true)
    private void pvpcore$scaleDamage(ServerWorld world, DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
        block6: {
            if (!PVPCORE_SCALING.get().booleanValue()) {
                try {
                    float scaled = PvPCore.get().duelManager().scaleDamage((LivingEntity)(Object)this, source, amount);
                    if (scaled == amount) break block6;
                    PVPCORE_SCALING.set(true);
                    try {
                        cir.setReturnValue(((LivingEntity)(Object)this).damage(world, source, scaled));
                    }
                    finally {
                        PVPCORE_SCALING.set(false);
                    }
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
            }
        }
    }
}

