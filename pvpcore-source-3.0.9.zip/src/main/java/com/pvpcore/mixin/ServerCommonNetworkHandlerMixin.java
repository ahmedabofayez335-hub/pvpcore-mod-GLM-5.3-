package com.pvpcore.mixin;

import com.pvpcore.util.ServerStats;
import net.minecraft.network.packet.c2s.common.CommonPongC2SPacket;
import net.minecraft.server.network.ServerCommonNetworkHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 3.0.8: vanilla's onPong is an empty no-op (the vanilla server never sends
 * CommonPingS2CPacket during play), so observing it at HEAD is completely safe
 * and nothing needs to be cancelled. PvPCore uses the vanilla ping/pong pair
 * to measure the real round-trip latency once per second for the scoreboard
 * {ping} placeholder (see ServerStats).
 */
@Mixin(ServerCommonNetworkHandler.class)
public abstract class ServerCommonNetworkHandlerMixin {
    @Inject(method = {"onPong"}, at = {@At(value = "HEAD")})
    private void pvpcore$onPong(CommonPongC2SPacket packet, CallbackInfo ci) {
        ServerStats.handlePong((ServerCommonNetworkHandler)(Object)this, packet);
    }
}
