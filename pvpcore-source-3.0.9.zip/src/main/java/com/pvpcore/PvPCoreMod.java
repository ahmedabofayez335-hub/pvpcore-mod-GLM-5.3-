/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.CommandDispatcher
 *  net.fabricmc.api.ModInitializer
 *  net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback
 *  net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents
 *  net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents
 *  net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents
 *  net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents
 *  net.fabricmc.fabric.api.event.player.AttackEntityCallback
 *  net.fabricmc.fabric.api.event.player.UseEntityCallback
 *  net.fabricmc.fabric.api.message.v1.ServerMessageEvents
 *  net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents
 *  net.minecraft.server.command.ServerCommandSource
 *  net.minecraft.server.network.ServerPlayerEntity
 *  net.minecraft.util.ActionResult
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.pvpcore;

import com.mojang.brigadier.CommandDispatcher;
import com.pvpcore.PvPCore;
import com.pvpcore.command.PvPCommands;
import com.pvpcore.lobby.LobbyItemListener;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.ActionResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PvPCoreMod
implements ModInitializer {
    public static final String MOD_ID = "pvpcore";
    public static final Logger LOGGER = LoggerFactory.getLogger((String)"PvP Core");

    public void onInitialize() {
        PvPCore.init();
        ServerLifecycleEvents.SERVER_STARTED.register(server -> PvPCore.get().onServerStarted(server));
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> PvPCore.get().onServerStopping());
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> server.execute(() -> {
            PvPCore.get().playerManager().onJoin(handler.player);
            PvPCore.get().partyManager().onPlayerJoin(handler.player);
            PvPCore.get().zoneManager().onPlayerJoin(handler.player);
        }));
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> server.execute(() -> PvPCore.get().playerManager().onQuit(handler.player)));
        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
            if (!alive && PvPCore.get().server() != null && !newPlayer.isDisconnected()) {
                PvPCore.get().playerManager().scheduleRespawnRecovery(newPlayer);
            }
        });
        ServerTickEvents.END_SERVER_TICK.register(server -> PvPCore.get().tick());
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> PvPCommands.register((CommandDispatcher<ServerCommandSource>)dispatcher));
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> PvPCore.get().duelManager().allowDamage(entity, source, amount));
        ServerLivingEntityEvents.ALLOW_DEATH.register((entity, source, amount) -> {
            if (!(entity instanceof ServerPlayerEntity)) return true;
            ServerPlayerEntity sp = (ServerPlayerEntity)entity;
            if (PvPCore.get().server() == null) return true;
            boolean bl = PvPCore.get().duelManager().allowDeath(sp, source, amount);
            return bl;
        });
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (entity instanceof ServerPlayerEntity) {
                ServerPlayerEntity sp = (ServerPlayerEntity)entity;
                if (PvPCore.get().server() != null) {
                    PvPCore.get().server().execute(() -> PvPCore.get().duelManager().onPlayerDeath(sp));
                }
            }
        });
        ServerMessageEvents.ALLOW_CHAT_MESSAGE.register((message, sender, params) -> {
            if (PvPCore.get().server() == null || PvPCore.get().chatRouter() == null) {
                return true;
            }
            if (!PvPCore.get().config().chat.manageChat) {
                return true;
            }
            String content = message.getContent().getString();
            if (content != null && !content.isBlank()) {
                PvPCore.get().chatRouter().handle(sender, content);
                return false;
            }
            return true;
        });
        UseEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (!world.isClient() && player instanceof ServerPlayerEntity) {
                ServerPlayerEntity sp = (ServerPlayerEntity)player;
                if (PvPCore.get().server() != null && PvPCore.get().zoneManager().onNpcInteract(sp, entity)) {
                    return ActionResult.SUCCESS;
                }
            }
            return ActionResult.PASS;
        });
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (!world.isClient() && player instanceof ServerPlayerEntity) {
                ServerPlayerEntity sp = (ServerPlayerEntity)player;
                if (PvPCore.get().server() != null && PvPCore.get().zoneManager().isNpc(entity)) {
                    PvPCore.get().server().execute(() -> PvPCore.get().zoneManager().onNpcInteract(sp, entity));
                    return ActionResult.SUCCESS;
                }
            }
            return ActionResult.PASS;
        });
        LobbyItemListener.register();
        LOGGER.info("PvP Core initialized (server-side practice core).");
    }
}

