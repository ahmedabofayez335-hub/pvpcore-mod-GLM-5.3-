/*
 * Decompiled with CFR 0.152.
 */
package com.pvpcore.leaderboard;

import com.pvpcore.PvPCore;
import com.pvpcore.data.PlayerData;
import com.pvpcore.data.Storage;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class LeaderboardManager {
    private final Map<String, List<Entry>> byWins = new ConcurrentHashMap<String, List<Entry>>();
    private final Map<String, List<Entry>> byElo = new ConcurrentHashMap<String, List<Entry>>();
    private long lastRefresh = 0L;

    public void refresh() {
        this.byWins.clear();
        this.byElo.clear();
        Storage storage = PvPCore.get().storage();
        int startRating = PvPCore.get().config().elo.startRating;
        for (Map.Entry<UUID, PlayerData> e : storage.loadAll().entrySet()) {
            PlayerData data = e.getValue();
            String name = data.name != null && !data.name.isBlank() ? data.name : e.getKey().toString().substring(0, 8);
            this.addEntry(this.byWins, "global", name, data.statsFor((String)"global").wins);
            this.addEntry(this.byElo, "global", name, data.ratingFor("global", startRating));
            for (String kitId : data.stats.keySet()) {
                if (kitId.equals("global")) continue;
                this.addEntry(this.byWins, kitId, name, data.statsFor((String)kitId).wins);
            }
            for (String kitIdx : data.ratings.keySet()) {
                if (kitIdx.equals("global")) continue;
                this.addEntry(this.byElo, kitIdx, name, data.ratingFor(kitIdx, startRating));
            }
        }
        this.byWins.values().forEach(l -> l.sort(Comparator.comparingInt(Entry::value).reversed()));
        this.byElo.values().forEach(l -> l.sort(Comparator.comparingInt(Entry::value).reversed()));
        this.lastRefresh = System.currentTimeMillis();
    }

    private void addEntry(Map<String, List<Entry>> map, String kitId, String name, int value) {
        map.computeIfAbsent(kitId, k -> new ArrayList()).add(new Entry(name, value));
    }

    public List<Entry> top(String kitId, String type, int n) {
        Map<String, List<Entry>> source = type.equals("elo") ? this.byElo : this.byWins;
        List<Entry> list = source.get(kitId);
        return list == null ? new ArrayList<Entry>() : new ArrayList<Entry>(list.subList(0, Math.min(n, list.size())));
    }

    public int rankOf(String playerName, String kitId, String type) {
        Map<String, List<Entry>> source = type.equals("elo") ? this.byElo : this.byWins;
        List<Entry> list = source.get(kitId);
        if (list != null && playerName != null) {
            for (int i = 0; i < list.size(); ++i) {
                if (!list.get(i).name().equals(playerName)) continue;
                return i + 1;
            }
            return -1;
        }
        return -1;
    }

    public record Entry(String name, int value) {
    }
}

