/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.server.PlayerManager
 *  net.minecraft.server.network.ServerPlayerEntity
 *  net.minecraft.text.Text
 */
package com.pvpcore.queue;

import com.pvpcore.PvPCore;
import com.pvpcore.config.MainConfig;
import com.pvpcore.config.Messages;
import com.pvpcore.data.PlayerData;
import com.pvpcore.duel.Duel;
import com.pvpcore.kit.Kit;
import com.pvpcore.party.PartyManager;
import com.pvpcore.player.PlayerManager;
import com.pvpcore.player.PlayerState;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

public final class QueueManager {
    private final List<Entry> entries = new ArrayList<Entry>();
    private long tick = 0L;
    private long lastStatus = 0L;

    public boolean isQueued(ServerPlayerEntity player) {
        return this.entries.stream().anyMatch(e -> e.player.equals(player.getUuid()));
    }

    public boolean isRankedQueue(ServerPlayerEntity player) {
        return this.entries.stream().anyMatch(e -> e.player.equals(player.getUuid()) && e.ranked);
    }

    public Entry entryOf(UUID player) {
        for (Entry e : this.entries) {
            if (!e.player.equals(player)) continue;
            return e;
        }
        return null;
    }

    public int queueSize(String kitId, boolean ranked) {
        return (int)this.entries.stream().filter(e -> e.kitId.equals(kitId) && e.ranked == ranked).count();
    }

    public int totalQueued() {
        return this.entries.size();
    }

    public void join(ServerPlayerEntity player, String kitId, boolean ranked) {
        this.join(player, kitId, ranked, PvPCore.get().config().duel.defaultRounds);
    }

    public void join(ServerPlayerEntity player, String kitId, boolean ranked, int rounds) {
        Messages mm = PvPCore.get().messages();
        if (PvPCore.get().kitManager().get(kitId) == null) {
            player.sendMessage((Text)Text.literal((String)mm.get("kit.not-found", Map.of("kit", kitId))), false);
        } else {
            PlayerManager pm = PvPCore.get().playerManager();
            PlayerState state = pm.state(player);
            if (state != PlayerState.LOBBY && state != PlayerState.QUEUEING) {
                player.sendMessage((Text)Text.literal((String)mm.get("not-in-lobby")), false);
            } else if (PvPCore.get().duelManager().duelOf(player) == null) {
                if (this.isQueued(player)) {
                    player.sendMessage((Text)Text.literal((String)mm.get("queue.already")), false);
                } else {
                    int roundsClamped = PvPCore.get().duelManager().clampRounds(rounds);
                    this.entries.add(new Entry(player.getUuid(), kitId, ranked, roundsClamped, this.tick));
                    pm.setState(player, PlayerState.QUEUEING);
                    player.sendMessage((Text)Text.literal((String)mm.get("queue.joined", Map.of("type", ranked ? "Ranked" : "Unranked", "kit", PvPCore.get().duelManager().kitDisplayName(kitId), "rounds", String.valueOf(roundsClamped)))), false);
                    player.sendMessage((Text)Text.literal((String)mm.get("queue.rounds-selected", Map.of("rounds", String.valueOf(roundsClamped)))), false);
                    PvPCore.get().playerManager().refreshLobby(player);
                }
            }
        }
    }

    public void remove(ServerPlayerEntity player) {
        boolean removed = this.entries.removeIf(e -> e.player.equals(player.getUuid()));
        if (removed) {
            PlayerManager pm = PvPCore.get().playerManager();
            if (pm.state(player) == PlayerState.QUEUEING) {
                pm.setState(player, PlayerState.LOBBY);
            }
            PvPCore.get().playerManager().refreshLobby(player);
        }
    }

    public void leave(ServerPlayerEntity player) {
        Messages mm = PvPCore.get().messages();
        if (!this.isQueued(player)) {
            player.sendMessage((Text)Text.literal((String)mm.get("queue.not-queued")), false);
        } else {
            this.remove(player);
            player.sendMessage((Text)Text.literal((String)mm.get("queue.left")), false);
        }
    }

    public void tick() {
        ++this.tick;
        int interval = Math.max(2, PvPCore.get().config().queue.matchmakingIntervalTicks);
        if (this.tick % (long)interval == 0L) {
            ArrayList<Entry> pool;
            net.minecraft.server.PlayerManager pm = PvPCore.get().server().getPlayerManager();
            this.entries.removeIf(e -> {
                ServerPlayerEntity px = pm.getPlayer(e.player);
                return px == null || PvPCore.get().playerManager().state(px) != PlayerState.QUEUEING;
            });
            ArrayList<String> kitIds = new ArrayList<String>();
            for (Kit kit : PvPCore.get().kitManager().all()) {
                kitIds.add(kit.id);
            }
            for (String kitId : kitIds) {
                pool = this.pool(kitId, false);
                while (pool.size() >= 2) {
                    Entry a = pool.remove(0);
                    Entry b = this.pickOpponent(a, pool);
                    if (b == null || !this.tryMatch(a, b)) continue;
                    this.entries.remove(a);
                    this.entries.remove(b);
                }
            }
            for (String kitId : kitIds) {
                pool = this.pool(kitId, true);
                pool.sort(Comparator.comparingLong(e -> e.joinTick));
                block4: for (int ix = 0; ix < pool.size(); ++ix) {
                    for (int j = ix + 1; j < pool.size(); ++j) {
                        Entry b;
                        Entry a = pool.get(ix);
                        if (!this.withinEloRange(a, b = pool.get(j), kitId) || this.sameParty(a, b) || this.sameColor(a, b) || !this.tryMatch(a, b)) continue;
                        this.entries.remove(a);
                        this.entries.remove(b);
                        pool.remove(a);
                        pool.remove(b);
                        ix = -1;
                        continue block4;
                    }
                }
            }
            this.crossKitPass(false);
            this.crossKitPass(true);
            int statusInterval = PvPCore.get().config().queue.statusIntervalTicks;
            if (statusInterval > 0 && this.tick - this.lastStatus >= (long)statusInterval) {
                this.lastStatus = this.tick;
                for (Entry exx2 : List.copyOf(this.entries)) {
                    ServerPlayerEntity p = pm.getPlayer(exx2.player);
                    if (p == null) continue;
                    int range = this.currentRange(exx2);
                    p.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("queue.status", Map.of("kit", PvPCore.get().duelManager().kitDisplayName(exx2.kitId), "type", exx2.ranked ? "Ranked" : "Unranked", "position", String.valueOf(this.queueSize(exx2.kitId, exx2.ranked)), "range", exx2.ranked ? "(\u00b1" + range + " ELO)" : ""))), true);
                }
            }
        }
    }

    private ArrayList<Entry> pool(String kitId, boolean ranked) {
        ArrayList<Entry> pool = new ArrayList<Entry>();
        for (Entry e : this.entries) {
            if (!e.kitId.equals(kitId) || e.ranked != ranked) continue;
            pool.add(e);
        }
        return pool;
    }

    private Entry pickOpponent(Entry a, ArrayList<Entry> pool) {
        for (int i = 0; i < pool.size(); ++i) {
            if (this.sameColor(a, pool.get(i)) || this.sameParty(a, pool.get(i))) continue;
            return pool.remove(i);
        }
        return null;
    }

    private void crossKitPass(boolean ranked) {
        int afterSeconds = PvPCore.get().config().queue.crossKitMatchAfterSeconds;
        if (afterSeconds >= 0) {
            net.minecraft.server.PlayerManager pm = PvPCore.get().server().getPlayerManager();
            ArrayList<Entry> pool = new ArrayList<Entry>();
            for (Entry e : this.entries) {
                if (e.ranked != ranked || pm.getPlayer(e.player) == null) continue;
                pool.add(e);
            }
            pool.sort(Comparator.comparingLong(ex -> ex.joinTick));
            long minTicks = (long)afterSeconds * 20L;
            while (pool.size() >= 2) {
                Entry a = (Entry)pool.get(0);
                if (this.tick - a.joinTick < minTicks) break;
                Entry b = null;
                for (int i = 1; i < pool.size(); ++i) {
                    Entry cand = (Entry)pool.get(i);
                    if (this.sameParty(a, cand) || this.sameColor(a, cand) || ranked && !this.withinEloRange(a, cand, a.kitId)) continue;
                    b = cand;
                    break;
                }
                if (b == null) break;
                if (this.tryMatch(a, b)) {
                    this.entries.remove(a);
                    this.entries.remove(b);
                    pool.remove(a);
                    pool.remove(b);
                    continue;
                }
                pool.remove(a);
            }
        }
    }

    private boolean withinEloRange(Entry a, Entry b, String kitId) {
        net.minecraft.server.PlayerManager pm = PvPCore.get().server().getPlayerManager();
        int start = PvPCore.get().config().elo.startRating;
        PlayerData da = PvPCore.get().storage().get(a.player, null);
        PlayerData db = PvPCore.get().storage().get(b.player, null);
        int ra = da != null ? da.ratingFor(kitId, start) : start;
        int rb = db != null ? db.ratingFor(kitId, start) : start;
        int range = Math.min(this.currentRange(a), this.currentRange(b));
        return Math.abs(ra - rb) <= range;
    }

    private int currentRange(Entry e) {
        MainConfig.Elo cfg = PvPCore.get().config().elo;
        long waitedSeconds = (this.tick - e.joinTick) / 20L;
        if (waitedSeconds < 10L) {
            return cfg.range0to10s;
        }
        if (waitedSeconds < 20L) {
            return cfg.range10to20s;
        }
        return waitedSeconds < 30L ? cfg.range20to30s : cfg.range30plus;
    }

    private boolean sameColor(Entry a, Entry b) {
        net.minecraft.server.PlayerManager pm = PvPCore.get().server().getPlayerManager();
        ServerPlayerEntity pa = pm.getPlayer(a.player);
        ServerPlayerEntity pb = pm.getPlayer(b.player);
        return pa != null && pb != null && PvPCore.get().teamColors().sameColor(pa, pb);
    }

    private boolean sameParty(Entry a, Entry b) {
        PartyManager.Party pa = PvPCore.get().partyManager().partyOf(a.player);
        return pa != null && pa == PvPCore.get().partyManager().partyOf(b.player);
    }

    private boolean tryMatch(Entry a, Entry b) {
        net.minecraft.server.PlayerManager pm = PvPCore.get().server().getPlayerManager();
        ServerPlayerEntity pa = pm.getPlayer(a.player);
        ServerPlayerEntity pb = pm.getPlayer(b.player);
        if (pa != null && pb != null) {
            PlayerManager playerManager = PvPCore.get().playerManager();
            if (playerManager.state(pa) != PlayerState.QUEUEING || playerManager.state(pb) != PlayerState.QUEUEING) {
                return false;
            }
            if (PvPCore.get().teamColors().sameColor(pa, pb)) {
                return false;
            }
            Duel duel = PvPCore.get().duelManager().startDuel(a.kitId, a.ranked, List.of(pa), List.of(pb), a.rounds);
            if (duel == null) {
                return false;
            }
            Messages mm = PvPCore.get().messages();
            String msg = mm.get("queue.matched", Map.of("kit", PvPCore.get().duelManager().kitDisplayName(a.kitId), "arena", duel.arena.id, "rounds", String.valueOf(duel.rounds)));
            pa.sendMessage((Text)Text.literal((String)msg), false);
            pb.sendMessage((Text)Text.literal((String)msg), false);
            return true;
        }
        return false;
    }

    public void shutdown() {
        this.entries.clear();
    }

    public static class Entry {
        public final UUID player;
        public final String kitId;
        public final boolean ranked;
        public final int rounds;
        public final long joinTick;

        public Entry(UUID player, String kitId, boolean ranked, int rounds, long joinTick) {
            this.player = player;
            this.kitId = kitId;
            this.ranked = ranked;
            this.rounds = rounds;
            this.joinTick = joinTick;
        }
    }
}

