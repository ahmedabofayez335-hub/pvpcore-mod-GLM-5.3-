/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemStack
 */
package com.pvpcore.data;

import com.pvpcore.data.PlayerStats;
import com.pvpcore.util.ItemCodecUtil;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.item.ItemStack;

public class PlayerData {
    public String uuid = "";
    public String name = "";
    public Map<String, PlayerStats> stats = new HashMap<String, PlayerStats>();
    public Map<String, Integer> ratings = new HashMap<String, Integer>();
    public Map<String, List<String>> loadouts = new HashMap<String, List<String>>();
    public Map<String, List<String>> ffaLoadouts = new HashMap<String, List<String>>();
    public boolean partyChat = false;
    public transient UUID uuidObj;

    public PlayerStats statsFor(String kitId) {
        return this.stats.computeIfAbsent(kitId, k -> new PlayerStats());
    }

    public Integer ratingFor(String kitId, int defaultRating) {
        return this.ratings.getOrDefault(kitId, defaultRating);
    }

    public void setRating(String kitId, int rating) {
        this.ratings.put(kitId, rating);
    }

    public List<ItemStack> loadoutFor(String kitId) {
        List<String> snbt = this.loadouts.get(kitId);
        ArrayList<ItemStack> out = new ArrayList<ItemStack>();
        if (snbt == null) {
            return null;
        }
        for (String s : snbt) {
            out.add(ItemCodecUtil.fromSnbt(s));
        }
        return out;
    }

    public void setLoadout(String kitId, List<ItemStack> items) {
        ArrayList<String> snbt = new ArrayList<String>();
        for (ItemStack st : items) {
            snbt.add(ItemCodecUtil.toSnbt(st));
        }
        this.loadouts.put(kitId, snbt);
    }

    /**
     * Separate per-kit layout used ONLY inside FFA fight zones, so players can
     * arrange their FFA loadout differently from their duel loadout for the same kit.
     */
    public List<ItemStack> ffaLoadoutFor(String kitId) {
        List<String> snbt = this.ffaLoadouts.get(kitId);
        ArrayList<ItemStack> out = new ArrayList<ItemStack>();
        if (snbt == null) {
            return null;
        }
        for (String s : snbt) {
            out.add(ItemCodecUtil.fromSnbt(s));
        }
        return out;
    }

    public void setFfaLoadout(String kitId, List<ItemStack> items) {
        ArrayList<String> snbt = new ArrayList<String>();
        for (ItemStack st : items) {
            snbt.add(ItemCodecUtil.toSnbt(st));
        }
        this.ffaLoadouts.put(kitId, snbt);
    }

    public PlayerStats globalStats() {
        PlayerStats g = new PlayerStats();
        for (Map.Entry<String, PlayerStats> e : this.stats.entrySet()) {
            if (e.getKey().equals("global")) continue;
            g.wins += e.getValue().wins;
            g.losses += e.getValue().losses;
            g.hits += e.getValue().hits;
            g.duels += e.getValue().duels;
            g.bestStreak = Math.max(g.bestStreak, e.getValue().bestStreak);
        }
        return g;
    }
}

