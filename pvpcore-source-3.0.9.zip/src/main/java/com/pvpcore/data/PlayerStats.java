/*
 * Decompiled with CFR 0.152.
 */
package com.pvpcore.data;

public class PlayerStats {
    public int wins = 0;
    public int losses = 0;
    public int hits = 0;
    public int duels = 0;
    public int streak = 0;
    public int bestStreak = 0;

    public void addWin() {
        ++this.wins;
        ++this.duels;
        ++this.streak;
        if (this.streak > this.bestStreak) {
            this.bestStreak = this.streak;
        }
    }

    public void addLoss() {
        ++this.losses;
        ++this.duels;
        this.streak = 0;
    }

    public double winRate() {
        int total = this.wins + this.losses;
        return total == 0 ? 0.0 : (double)this.wins * 100.0 / (double)total;
    }

    public PlayerStats copy() {
        PlayerStats s = new PlayerStats();
        s.wins = this.wins;
        s.losses = this.losses;
        s.hits = this.hits;
        s.duels = this.duels;
        s.streak = this.streak;
        s.bestStreak = this.bestStreak;
        return s;
    }
}

