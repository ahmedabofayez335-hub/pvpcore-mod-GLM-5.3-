/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 *  com.google.gson.GsonBuilder
 */
package com.pvpcore.data;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.pvpcore.PvPCoreMod;
import com.pvpcore.data.PlayerData;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.FileAttribute;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Stream;

public final class Storage {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private final Path playersDir;
    private final Map<UUID, PlayerData> cache = new HashMap<UUID, PlayerData>();
    private final Map<UUID, Boolean> dirty = new HashMap<UUID, Boolean>();

    public Storage(Path dataDir) {
        this.playersDir = dataDir.resolve("players");
        try {
            Files.createDirectories(this.playersDir, new FileAttribute[0]);
        }
        catch (IOException var3) {
            PvPCoreMod.LOGGER.error("Could not create players directory", (Throwable)var3);
        }
    }

    public synchronized PlayerData get(UUID uuid, String name) {
        PlayerData data = this.cache.get(uuid);
        if (data == null) {
            Path file = this.playersDir.resolve(String.valueOf(uuid) + ".json");
            if (Files.exists(file, new LinkOption[0])) {
                try {
                    data = (PlayerData)GSON.fromJson(Files.readString(file, StandardCharsets.UTF_8), PlayerData.class);
                }
                catch (Exception var6) {
                    PvPCoreMod.LOGGER.error("Failed to read player data {}", (Object)file, (Object)var6);
                }
            }
            if (data == null) {
                data = new PlayerData();
            }
            data.uuid = uuid.toString();
            data.uuidObj = uuid;
            if (name != null) {
                data.name = name;
            }
            this.cache.put(uuid, data);
        }
        if (name != null && !name.equals(data.name)) {
            data.name = name;
            this.markDirty(uuid);
        }
        return data;
    }

    public synchronized PlayerData getIfLoaded(UUID uuid) {
        return this.cache.get(uuid);
    }

    public synchronized void markDirty(UUID uuid) {
        this.dirty.put(uuid, true);
    }

    public synchronized void saveNow(UUID uuid) {
        PlayerData data = this.cache.get(uuid);
        if (data != null) {
            Path file = this.playersDir.resolve(String.valueOf(uuid) + ".json");
            try {
                Files.createDirectories(this.playersDir, new FileAttribute[0]);
                Path tmp = file.resolveSibling(String.valueOf(uuid) + ".json.tmp");
                Files.writeString(tmp, (CharSequence)GSON.toJson((Object)data), StandardCharsets.UTF_8, new OpenOption[0]);
                Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
                this.dirty.remove(uuid);
            }
            catch (IOException var51) {
                PvPCoreMod.LOGGER.error("Failed to save player data {}", (Object)file, (Object)var51);
            }
        }
    }

    public synchronized void saveAll() {
        for (UUID uuid : this.cache.keySet()) {
            if (!Boolean.TRUE.equals(this.dirty.get(uuid))) continue;
            this.saveNow(uuid);
        }
    }

    public synchronized Map<UUID, PlayerData> all() {
        return this.cache;
    }

    public synchronized Map<UUID, PlayerData> loadAll() {
        try (Stream<Path> stream = Files.list(this.playersDir);){
            stream.filter(p -> p.getFileName().toString().endsWith(".json")).forEach(p -> {
                try {
                    PlayerData data;
                    String name = p.getFileName().toString();
                    name = name.substring(0, name.length() - 5);
                    UUID uuid = UUID.fromString(name);
                    if (!this.cache.containsKey(uuid) && (data = (PlayerData)GSON.fromJson(Files.readString(p, StandardCharsets.UTF_8), PlayerData.class)) != null) {
                        data.uuid = uuid.toString();
                        data.uuidObj = uuid;
                        this.cache.put(uuid, data);
                    }
                }
                catch (Exception exception) {
                    // empty catch block
                }
            });
        }
        catch (Exception var61) {
            PvPCoreMod.LOGGER.error("Failed to list player files", (Throwable)var61);
        }
        return this.cache;
    }
}

