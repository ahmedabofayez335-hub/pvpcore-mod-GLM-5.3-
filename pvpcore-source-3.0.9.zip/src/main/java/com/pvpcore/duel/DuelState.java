/*
 * Decompiled with CFR 0.152.
 */
package com.pvpcore.duel;

public enum DuelState {
    TELEPORTING,
    COUNTDOWN,
    FIGHTING,
    ROUND_END,
    ENDING,
    FINISHED;

}

