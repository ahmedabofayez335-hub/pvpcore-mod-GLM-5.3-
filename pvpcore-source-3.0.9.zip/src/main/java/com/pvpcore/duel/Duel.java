/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.ItemEntity
 *  net.minecraft.server.PlayerManager
 *  net.minecraft.server.network.ServerPlayerEntity
 */
package com.pvpcore.duel;

import com.pvpcore.PvPCore;
import com.pvpcore.arena.Arena;
import com.pvpcore.arena.ArenaRestorer;
import com.pvpcore.duel.DuelState;
import com.pvpcore.scoreboard.DuelScoreboard;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Stream;
import net.minecraft.entity.ItemEntity;
import net.minecraft.server.PlayerManager;
import net.minecraft.server.network.ServerPlayerEntity;

public class Duel {
    public final UUID id;
    public volatile DuelState state = DuelState.TELEPORTING;
    public final String kitId;
    public final boolean ranked;
    public Arena arena;
    public final List<UUID> teamA = new ArrayList<UUID>();
    public final List<UUID> teamB = new ArrayList<UUID>();
    public final Map<UUID, Integer> hits = new HashMap<UUID, Integer>();
    public final Map<UUID, Long> disconnectedAt = new HashMap<UUID, Long>();
    public final Map<UUID, Long> graceUntil = new HashMap<UUID, Long>();
    public long stateSinceTick;
    public long fightStartTick;
    public int countdownRemainingSeconds;
    public DuelScoreboard scoreboard;
    public String result = "";
    public boolean rematchOffered = false;
    public int rounds = 1;
    public int winsA = 0;
    public int winsB = 0;
    public int round = 1;
    public String lastRoundWinner = "";
    public final Set<UUID> eliminated = new HashSet<UUID>();
    public final Set<UUID> withdrawn = ConcurrentHashMap.newKeySet();
    public final Map<ItemEntity, Long> drops = new LinkedHashMap<ItemEntity, Long>();
    public final Map<UUID, double[]> anchors = new HashMap<UUID, double[]>();
    public transient ArenaRestorer restorer;

    public Duel(UUID id, String kitId, boolean ranked, List<ServerPlayerEntity> a, List<ServerPlayerEntity> b) {
        this.id = id;
        this.kitId = kitId;
        this.ranked = ranked;
        for (ServerPlayerEntity p : a) {
            this.teamA.add(p.getUuid());
        }
        for (ServerPlayerEntity p : b) {
            this.teamB.add(p.getUuid());
        }
        for (UUID u : this.teamA) {
            this.hits.put(u, 0);
        }
        for (UUID u : this.teamB) {
            this.hits.put(u, 0);
        }
    }

    public boolean isParticipant(UUID uuid) {
        return this.teamA.contains(uuid) || this.teamB.contains(uuid);
    }

    public boolean isTeamA(UUID uuid) {
        return this.teamA.contains(uuid);
    }

    public List<UUID> teamOf(UUID uuid) {
        return this.teamA.contains(uuid) ? this.teamA : this.teamB;
    }

    public List<UUID> opponentsOf(UUID uuid) {
        return this.teamA.contains(uuid) ? this.teamB : this.teamA;
    }

    public Stream<ServerPlayerEntity> onlineParticipants(PvPCore core) {
        return Stream.concat(this.teamA.stream(), this.teamB.stream()).map(u -> core.server().getPlayerManager().getPlayer(u)).filter(p -> p != null && !this.disconnectedAt.containsKey(p.getUuid()));
    }

    public List<ServerPlayerEntity> participants() {
        ServerPlayerEntity p;
        ArrayList<ServerPlayerEntity> out = new ArrayList<ServerPlayerEntity>();
        for (UUID u : this.teamA) {
            if (this.withdrawn.contains(u) || (p = PvPCore.get().server().getPlayerManager().getPlayer(u)) == null) continue;
            out.add(p);
        }
        for (UUID ux : this.teamB) {
            if (this.withdrawn.contains(ux) || (p = PvPCore.get().server().getPlayerManager().getPlayer(ux)) == null) continue;
            out.add(p);
        }
        return out;
    }

    public List<ServerPlayerEntity> spectators() {
        return PvPCore.get().spectateManager().spectatorsOf(this);
    }

    public long aliveIn(List<UUID> team) {
        PlayerManager pm = PvPCore.get().server().getPlayerManager();
        return team.stream().filter(u -> !this.disconnectedAt.containsKey(u) && !this.eliminated.contains(u) && !this.withdrawn.contains(u)).map(arg_0 -> pm.getPlayer(arg_0)).filter(p -> p != null && p.isAlive() && !p.isSpectator()).count();
    }

    public boolean isDisconnected(UUID uuid) {
        return this.disconnectedAt.containsKey(uuid);
    }

    public boolean isEliminated(UUID uuid) {
        return this.eliminated.contains(uuid);
    }

    public List<UUID> participantUuids() {
        ArrayList<UUID> out = new ArrayList<UUID>(this.teamA);
        out.addAll(this.teamB);
        return out;
    }

    public int hitsOf(UUID uuid) {
        return this.hits.getOrDefault(uuid, 0);
    }

    public String firstAName() {
        PlayerManager pm = PvPCore.get().server().getPlayerManager();
        ServerPlayerEntity p = pm.getPlayer(this.teamA.get(0));
        return p != null ? p.getGameProfile().name() : "?";
    }

    public String firstBName() {
        PlayerManager pm = PvPCore.get().server().getPlayerManager();
        ServerPlayerEntity p = pm.getPlayer(this.teamB.get(0));
        return p != null ? p.getGameProfile().name() : "?";
    }
}

