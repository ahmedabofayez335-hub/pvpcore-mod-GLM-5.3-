/*
 * Decompiled with CFR 0.152.
 */
package com.pvpcore.duel;

import java.util.List;
import java.util.UUID;

public class DuelRequest {
    public final UUID id = UUID.randomUUID();
    public final Type type;
    public final UUID sender;
    public final UUID target;
    public final String kitId;
    public final boolean ranked;
    public final int rounds;
    public final List<UUID> senderParty;
    public final List<UUID> targetParty;
    public final long expiryTick;

    public DuelRequest(Type type, UUID sender, UUID target, String kitId, boolean ranked, int rounds, List<UUID> senderParty, List<UUID> targetParty, long expiryTick) {
        this.type = type;
        this.sender = sender;
        this.target = target;
        this.kitId = kitId;
        this.ranked = ranked;
        this.rounds = Math.max(1, rounds);
        this.senderParty = senderParty;
        this.targetParty = targetParty;
        this.expiryTick = expiryTick;
    }

    public static enum Type {
        PLAYER_DUEL,
        PARTY_DUEL;

    }
}

