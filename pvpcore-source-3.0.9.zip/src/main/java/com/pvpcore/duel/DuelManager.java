/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.component.DataComponentTypes
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.ItemEntity
 *  net.minecraft.entity.LivingEntity
 *  net.minecraft.entity.damage.DamageSource
 *  net.minecraft.entity.damage.DamageTypes
 *  net.minecraft.entity.effect.StatusEffectInstance
 *  net.minecraft.entity.effect.StatusEffects
 *  net.minecraft.entity.player.PlayerInventory
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.packet.Packet
 *  net.minecraft.network.packet.s2c.play.PlaySoundS2CPacket
 *  net.minecraft.registry.entry.RegistryEntry
 *  net.minecraft.registry.tag.DamageTypeTags
 *  net.minecraft.server.PlayerManager
 *  net.minecraft.server.network.ServerPlayerEntity
 *  net.minecraft.server.world.ServerWorld
 *  net.minecraft.sound.SoundCategory
 *  net.minecraft.sound.SoundEvents
 *  net.minecraft.text.Text
 *  net.minecraft.util.Formatting
 *  net.minecraft.util.Hand
 *  net.minecraft.world.GameMode
 *  net.minecraft.world.World
 */
package com.pvpcore.duel;

import com.pvpcore.PvPCore;
import com.pvpcore.PvPCoreMod;
import com.pvpcore.arena.Arena;
import com.pvpcore.arena.ArenaRestorer;
import com.pvpcore.config.MainConfig;
import com.pvpcore.config.Messages;
import com.pvpcore.data.PlayerData;
import com.pvpcore.data.PlayerStats;
import com.pvpcore.data.Storage;
import com.pvpcore.duel.Duel;
import com.pvpcore.duel.DuelRequest;
import com.pvpcore.duel.DuelState;
import com.pvpcore.gui.guis.ChallengeGui;
import com.pvpcore.kit.Kit;
import com.pvpcore.kit.KitManager;
import com.pvpcore.party.PartyManager;
import com.pvpcore.player.InventorySnapshot;
import com.pvpcore.player.PlayerManager;
import com.pvpcore.player.PlayerState;
import com.pvpcore.scoreboard.DuelScoreboard;
import com.pvpcore.util.ChatButtons;
import com.pvpcore.util.ItemCodecUtil;
import com.pvpcore.util.ServerStats;
import com.pvpcore.util.TeleportUtil;
import com.pvpcore.util.TextUtil;
import com.pvpcore.util.TitleUtil;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.PlaySoundS2CPacket;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.world.GameMode;
import net.minecraft.world.World;

public final class DuelManager {
    private final Map<UUID, Duel> duels = new ConcurrentHashMap<UUID, Duel>();
    private final Map<UUID, Duel> byParticipant = new ConcurrentHashMap<UUID, Duel>();
    private final Map<UUID, DuelRequest> requests = new ConcurrentHashMap<UUID, DuelRequest>();
    private long tick = 0L;

    public Duel duelOf(ServerPlayerEntity player) {
        return player == null ? null : this.byParticipant.get(player.getUuid());
    }

    public Duel duelOf(UUID uuid) {
        return this.byParticipant.get(uuid);
    }

    public List<Duel> activeDuels() {
        ArrayList<Duel> out = new ArrayList<Duel>();
        for (Duel d : this.duels.values()) {
            if (d.state != DuelState.FIGHTING && d.state != DuelState.COUNTDOWN) continue;
            out.add(d);
        }
        return out;
    }

    public List<Duel> allDuels() {
        return new ArrayList<Duel>(this.duels.values());
    }

    public int playingCount(String kitId) {
        return (int)this.duels.values().stream().filter(d -> d.state != DuelState.FINISHED && d.kitId.equals(kitId)).count();
    }

    /** 3.0.8: duels currently running for one kit AND one mode (ranked/unranked). */
    public int playingCount(String kitId, boolean ranked) {
        return (int)this.duels.values().stream().filter(d -> d.state != DuelState.FINISHED && d.kitId.equals(kitId) && d.ranked == ranked).count();
    }

    /** 3.0.8: duels currently running in one mode (ranked/unranked), all kits. */
    public int playingCount(boolean ranked) {
        return (int)this.duels.values().stream().filter(d -> d.state != DuelState.FINISHED && d.ranked == ranked).count();
    }

    public int playersFighting(String kitId) {
        return this.duels.values().stream().filter(d -> d.state != DuelState.FINISHED && d.kitId.equals(kitId)).mapToInt(d -> d.teamA.size() + d.teamB.size()).sum();
    }

    public int playersFighting() {
        return this.duels.values().stream().filter(d -> d.state != DuelState.FINISHED).mapToInt(d -> d.teamA.size() + d.teamB.size()).sum();
    }

    public DuelRequest requestFor(UUID target) {
        return this.requests.get(target);
    }

    public float scaleDamage(LivingEntity victim, DamageSource source, float amount) {
        PvPCore core = PvPCore.get();
        if (core != null && core.server() != null && victim instanceof ServerPlayerEntity) {
            float mult = core.config().duel.damageMultiplier;
            if (!(mult <= 0.0f) && mult != 1.0f) {
                mult = Math.max(0.05f, Math.min(10.0f, mult));
                Duel duel = this.duelOf((ServerPlayerEntity)victim);
                if (duel != null && duel.state == DuelState.FIGHTING) {
                    Entity attacker;
                    if (!(core.config().duel.scaleEnvironmentalDamage || (attacker = source.getAttacker()) instanceof ServerPlayerEntity && duel.isParticipant(((ServerPlayerEntity)attacker).getUuid()))) {
                        return amount;
                    }
                    return amount * mult;
                }
                return amount;
            }
            return amount;
        }
        return amount;
    }

    public String kitDisplayName(String kitId) {
        Kit kit = PvPCore.get().kitManager().get(kitId);
        return kit != null ? TextUtil.stripColor(TextUtil.colorize(kit.displayName)) : kitId;
    }

    public boolean sendChallenge(ServerPlayerEntity sender, ServerPlayerEntity target, String kitId) {
        return this.sendChallenge(sender, target, kitId, PvPCore.get().config().duel.defaultRounds);
    }

    public boolean sendChallenge(ServerPlayerEntity sender, ServerPlayerEntity target, String kitId, int rounds) {
        if (sender == null || target == null || sender.getUuid().equals(target.getUuid())) {
            return false;
        }
        Messages mm = PvPCore.get().messages();
        if (this.duelOf(sender) != null) {
            sender.sendMessage((Text)Text.literal((String)mm.get("duel.already-in-duel")), false);
            return false;
        }
        if (this.duelOf(target) != null) {
            sender.sendMessage((Text)Text.literal((String)mm.get("duel.target-in-duel", Map.of("player", target.getGameProfile().name()))), false);
            return false;
        }
        if (!this.eligibleForDuel(sender)) {
            sender.sendMessage((Text)Text.literal((String)mm.get("duel.not-ready")), false);
            return false;
        }
        if (!this.eligibleForDuel(target)) {
            sender.sendMessage((Text)Text.literal((String)mm.get("duel.target-not-ready", Map.of("player", target.getGameProfile().name()))), false);
            return false;
        }
        if (PvPCore.get().teamColors().sameColor(sender, target)) {
            sender.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("duel.same-color-blocked", Map.of("player", target.getGameProfile().name()))), false);
            return false;
        }
        PartyManager.Party senderParty = PvPCore.get().partyManager().partyOf(sender);
        PartyManager.Party targetParty = PvPCore.get().partyManager().partyOf(target);
        if (senderParty != null && targetParty != null && senderParty == targetParty) {
            sender.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("party.no-friendly-duel", Map.of("player", target.getGameProfile().name()))), false);
            return false;
        }
        this.requests.remove(target.getUuid());
        rounds = this.clampRounds(rounds);
        long expiry = this.tick + 600L;
        DuelRequest req = new DuelRequest(DuelRequest.Type.PLAYER_DUEL, sender.getUuid(), target.getUuid(), kitId, false, rounds, null, null, expiry);
        this.requests.put(target.getUuid(), req);
        sender.sendMessage((Text)Text.literal((String)mm.get("duel.challenge-sent", Map.of("player", target.getGameProfile().name(), "kit", this.kitDisplayName(kitId)))), false);
        TitleUtil.title(target, mm.get("duel.challenge-received-title"), mm.get("duel.challenge-received-subtitle", Map.of("player", sender.getGameProfile().name())));
        if (PvPCore.get().config().duel.challengeViaChat) {
            this.sendChallengeChat(target, sender.getGameProfile().name(), this.kitDisplayName(kitId), 30, rounds);
        } else {
            new ChallengeGui(target, req).open(target);
        }
        return true;
    }

    public boolean sendPartyChallenge(ServerPlayerEntity senderLeader, ServerPlayerEntity targetLeader, String kitId) {
        return this.sendPartyChallenge(senderLeader, targetLeader, kitId, PvPCore.get().config().duel.defaultRounds);
    }

    public boolean sendPartyChallenge(ServerPlayerEntity senderLeader, ServerPlayerEntity targetLeader, String kitId, int rounds) {
        PartyManager parties = PvPCore.get().partyManager();
        PartyManager.Party senderParty = parties.partyOf(senderLeader);
        PartyManager.Party targetParty = parties.partyOf(targetLeader);
        if (senderParty == null || targetParty == null) {
            return false;
        }
        if (senderParty == targetParty) {
            return false;
        }
        if (this.duelOf(targetLeader) == null && this.eligibleForDuel(targetLeader)) {
            if (PvPCore.get().teamColors().sameColor(senderLeader, targetLeader)) {
                senderLeader.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("duel.same-color-blocked", Map.of("player", targetLeader.getGameProfile().name()))), false);
                return false;
            }
            this.requests.remove(targetLeader.getUuid());
            rounds = this.clampRounds(rounds);
            long expiry = this.tick + 900L;
            DuelRequest req = new DuelRequest(DuelRequest.Type.PARTY_DUEL, senderLeader.getUuid(), targetLeader.getUuid(), kitId, false, rounds, new ArrayList<UUID>(senderParty.onlineMemberUuids()), new ArrayList<UUID>(targetParty.onlineMemberUuids()), expiry);
            this.requests.put(targetLeader.getUuid(), req);
            Messages mm = PvPCore.get().messages();
            senderLeader.sendMessage((Text)Text.literal((String)mm.get("party.challenge-sent", Map.of("leader", targetLeader.getGameProfile().name()))), false);
            TitleUtil.title(targetLeader, mm.get("party.challenge-received-title"), mm.get("party.challenge-received-subtitle", Map.of("leader", senderLeader.getGameProfile().name(), "kit", this.kitDisplayName(kitId))));
            if (PvPCore.get().config().duel.challengeViaChat) {
                this.sendChallengeChat(targetLeader, senderLeader.getGameProfile().name() + "'s party", this.kitDisplayName(kitId), 45, rounds);
            } else {
                new ChallengeGui(targetLeader, req).open(targetLeader);
            }
            return true;
        }
        return false;
    }

    public int clampRounds(int rounds) {
        int max = Math.max(1, PvPCore.get().config().duel.maxRounds);
        return Math.max(1, Math.min(max, rounds));
    }

    private void sendChallengeChat(ServerPlayerEntity target, String fromName, String kitName, int seconds, int rounds) {
        Messages mm = PvPCore.get().messages();
        target.sendMessage((Text)ChatButtons.line(new Text[]{Text.literal((String)mm.get("duel.challenge-chat-header", Map.of("player", fromName, "kit", kitName)))}), false);
        if (rounds > 1) {
            target.sendMessage((Text)ChatButtons.line(new Text[]{Text.literal((String)mm.get("duel.best-of-line", Map.of("rounds", String.valueOf(rounds))))}), false);
        }
        target.sendMessage((Text)ChatButtons.line(new Text[]{ChatButtons.button(mm.get("duel.challenge-accept-button"), "/duelaccept", mm.get("duel.challenge-accept-hover"), Formatting.GREEN), Text.literal((String)" "), ChatButtons.button(mm.get("duel.challenge-deny-button"), "/dueldeny", mm.get("duel.challenge-deny-hover"), Formatting.RED)}), false);
        target.sendMessage((Text)ChatButtons.line(new Text[]{Text.literal((String)mm.get("duel.challenge-chat-expire", Map.of("seconds", String.valueOf(seconds))))}), false);
    }

    public void acceptRequest(ServerPlayerEntity target) {
        net.minecraft.server.PlayerManager pm;
        ServerPlayerEntity sender;
        DuelRequest req = this.requests.remove(target.getUuid());
        if (req != null && (sender = (pm = PvPCore.get().server().getPlayerManager()).getPlayer(req.sender)) != null) {
            if (req.type != DuelRequest.Type.PARTY_DUEL) {
                if (!this.eligibleForDuel(sender) || !this.eligibleForDuel(target)) {
                    return;
                }
                this.startDuel(req.kitId, req.ranked, List.of(sender), List.of(target), req.rounds);
            } else {
                ServerPlayerEntity p;
                ArrayList<ServerPlayerEntity> teamA = new ArrayList<ServerPlayerEntity>();
                ArrayList<ServerPlayerEntity> teamB = new ArrayList<ServerPlayerEntity>();
                for (UUID u : req.senderParty) {
                    p = pm.getPlayer(u);
                    if (p == null || !this.eligibleForDuel(p)) continue;
                    teamA.add(p);
                }
                for (UUID ux : req.targetParty) {
                    p = pm.getPlayer(ux);
                    if (p == null || !this.eligibleForDuel(p)) continue;
                    teamB.add(p);
                }
                if (teamA.isEmpty() || teamB.isEmpty()) {
                    return;
                }
                this.startDuel(req.kitId, req.ranked, teamA, teamB, req.rounds);
            }
        }
    }

    public void denyRequest(ServerPlayerEntity target) {
        DuelRequest req = this.requests.remove(target.getUuid());
        if (req != null) {
            Messages mm = PvPCore.get().messages();
            ServerPlayerEntity sender = PvPCore.get().server().getPlayerManager().getPlayer(req.sender);
            if (sender != null) {
                sender.sendMessage((Text)Text.literal((String)mm.get("duel.challenge-denied", Map.of("player", target.getGameProfile().name()))), false);
            }
        }
    }

    public boolean leaveDuel(ServerPlayerEntity player) {
        Duel duel = this.duelOf(player);
        if (duel == null) {
            return false;
        }
        if (duel.state != DuelState.FIGHTING && duel.state != DuelState.COUNTDOWN && duel.state != DuelState.ROUND_END) {
            return false;
        }
        String winner = duel.isTeamA(player.getUuid()) ? "B" : "A";
        player.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("leave.duel-left")), false);
        this.endDuel(duel, winner, "forfeit");
        return true;
    }

    private boolean eligibleForDuel(ServerPlayerEntity player) {
        PlayerManager pm = PvPCore.get().playerManager();
        PlayerState st = pm.state(player);
        if (st != PlayerState.LOBBY && st != PlayerState.QUEUEING) {
            return false;
        }
        return this.duelOf(player) != null ? false : !PvPCore.get().spectateManager().isSpectating(player);
    }

    public boolean isEligibleDuelTarget(ServerPlayerEntity player) {
        return player != null && this.duelOf(player) == null && this.eligibleForDuel(player);
    }

    public Duel startDuel(String kitId, boolean ranked, List<ServerPlayerEntity> teamA, List<ServerPlayerEntity> teamB) {
        return this.startDuel(kitId, ranked, teamA, teamB, PvPCore.get().config().duel.defaultRounds);
    }

    public Duel startDuel(String kitId, boolean ranked, List<ServerPlayerEntity> teamA, List<ServerPlayerEntity> teamB, int rounds) {
        ServerPlayerEntity p;
        Kit kit = PvPCore.get().kitManager().get(kitId);
        if (kit == null) {
            return null;
        }
        Arena arena = PvPCore.get().arenaManager().reserve(kitId);
        if (arena == null) {
            String key = PvPCore.get().arenaManager().countUsable(kitId) == 0 && PvPCore.get().arenaManager().countUsable() > 0 ? "arena.none-for-kit" : "arena.none";
            for (ServerPlayerEntity p2 : teamA) {
                p2.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get(key, Map.of("kit", this.kitDisplayName(kitId)))), false);
            }
            for (ServerPlayerEntity p2 : teamB) {
                p2.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get(key, Map.of("kit", this.kitDisplayName(kitId)))), false);
            }
            return null;
        }
        Duel duel = new Duel(UUID.randomUUID(), kitId, ranked, teamA, teamB);
        duel.arena = arena;
        duel.rounds = this.clampRounds(rounds);
        duel.state = DuelState.TELEPORTING;
        duel.stateSinceTick = this.tick;
        this.duels.put(duel.id, duel);
        for (ServerPlayerEntity p3 : duel.participants()) {
            this.byParticipant.put(p3.getUuid(), duel);
        }
        PlayerManager playerManager = PvPCore.get().playerManager();
        net.minecraft.server.PlayerManager pm = PvPCore.get().server().getPlayerManager();
        for (ServerPlayerEntity p4 : duel.participants()) {
            PvPCore.get().queueManager().remove(p4);
            playerManager.setState(p4, PlayerState.DUELING);
            playerManager.snapshotAndClear(p4);
            playerManager.setDuelGameMode(p4);
        }
        PvPCore.get().teamColors().applyDuelColors(duel);
        duel.restorer = this.snapshotArena(duel);
        ArrayList<ServerPlayerEntity> teamAPlayers = new ArrayList<ServerPlayerEntity>();
        ArrayList<ServerPlayerEntity> teamBPlayers = new ArrayList<ServerPlayerEntity>();
        for (UUID u : duel.teamA) {
            p = pm.getPlayer(u);
            if (p == null) continue;
            teamAPlayers.add(p);
        }
        for (UUID ux : duel.teamB) {
            p = pm.getPlayer(ux);
            if (p == null) continue;
            teamBPlayers.add(p);
        }
        this.teleportTeam(duel, teamAPlayers, true);
        this.teleportTeam(duel, teamBPlayers, false);
        for (ServerPlayerEntity p5 : duel.participants()) {
            this.prepareFighter(p5, kit);
        }
        this.captureAnchors(duel);
        if (PvPCore.get().config().scoreboard.enabled) {
            duel.scoreboard = new DuelScoreboard(duel.id, PvPCore.get().config().scoreboard.title);
            for (ServerPlayerEntity p5 : duel.participants()) {
                duel.scoreboard.addViewer(p5);
            }
            this.updateScoreboard(duel);
        }
        duel.state = DuelState.COUNTDOWN;
        duel.stateSinceTick = this.tick;
        duel.countdownRemainingSeconds = PvPCore.get().config().duel.countdownSeconds;
        Messages mm = PvPCore.get().messages();
        if (PvPCore.get().config().duel.broadcastStarts) {
            String started = mm.get("duel.started", Map.of("kit", this.kitDisplayName(kitId), "player1", this.coloredNameOf(duel.teamA.get(0)), "player2", this.coloredNameOf(duel.teamB.get(0)), "arena", arena.id));
            for (ServerPlayerEntity p6 : PvPCore.get().server().getPlayerManager().getPlayerList()) {
                p6.sendMessage((Text)Text.literal((String)started), false);
            }
        }
        if (duel.rounds > 1) {
            String boLine = mm.get("duel.best-of-line", Map.of("rounds", String.valueOf(duel.rounds)));
            for (ServerPlayerEntity p6 : duel.participants()) {
                p6.sendMessage((Text)Text.literal((String)boLine), false);
            }
        }
        return duel;
    }

    private void captureAnchors(Duel duel) {
        duel.anchors.clear();
        net.minecraft.server.PlayerManager pm = PvPCore.get().server().getPlayerManager();
        for (UUID u : duel.participantUuids()) {
            ServerPlayerEntity p = pm.getPlayer(u);
            if (p == null) continue;
            duel.anchors.put(u, new double[]{p.getX(), p.getY(), p.getZ()});
        }
    }

    private void teleportTeam(Duel duel, List<ServerPlayerEntity> players, boolean teamA) {
        Arena arena = duel.arena;
        ServerWorld world = TeleportUtil.world(PvPCore.get().server(), arena.world);
        if (world != null) {
            for (int i = 0; i < players.size(); ++i) {
                float pitch;
                ServerPlayerEntity p = players.get(i);
                double x = teamA ? arena.spawn1X : arena.spawn2X;
                double y = teamA ? arena.spawn1Y : arena.spawn2Y;
                double z = teamA ? arena.spawn1Z : arena.spawn2Z;
                float yaw = teamA ? arena.spawn1Yaw : arena.spawn2Yaw;
                float f = pitch = teamA ? arena.spawn1Pitch : arena.spawn2Pitch;
                if (players.size() > 1) {
                    double off = ((double)i - (double)(players.size() - 1) / 2.0) * 1.5;
                    x += off;
                }
                TeleportUtil.teleport(p, world, x, y, z, yaw, pitch);
            }
        }
    }

    private void prepareFighter(ServerPlayerEntity player, Kit kit) {
        MainConfig.Duel cfg = PvPCore.get().config().duel;
        player.clearStatusEffects();
        if (cfg.healOnStart) {
            player.setHealth(player.getMaxHealth());
            player.getHungerManager().setFoodLevel(20);
            // 3.0.9 fastheal fix: saturation 0, NOT 5. Vanilla's HungerManager
            // runs a SATURATED fast-regen branch (food == 20 && saturation > 0)
            // that heals up to 1 HP every 10 ticks - that made sword fights heal
            // absurdly fast. With saturation 0 fighters only get the normal slow
            // natural regeneration (1 HP per 4 seconds at food >= 18).
            player.getHungerManager().setSaturationLevel(0.0f);
            player.setFireTicks(0);
        }
        List<ItemStack> layout = null;
        PlayerData data = PvPCore.get().storage().get(player.getUuid(), player.getGameProfile().name());
        if (data != null) {
            layout = data.loadoutFor(kit.id);
        }
        if (layout != null && !layout.isEmpty()) {
            layout = Kit.padLayout(layout);
        }
        if (layout == null || layout.isEmpty()) {
            layout = kit.layoutStacks();
        }
        PlayerInventory inv = player.getInventory();
        for (int i = 0; i < 36; ++i) {
            inv.setStack(i, ItemStack.EMPTY);
        }
        for (int var13 = 36; var13 < 41; ++var13) {
            inv.setStack(var13, ItemStack.EMPTY);
        }
        for (int var14 = 0; var14 < 4; ++var14) {
            ItemStack st = layout.get(var14);
            if (st == null || st.isEmpty()) continue;
            inv.setStack(36 + var14, st.copy());
        }
        ItemStack st = layout.get(40);
        if (st != null && !st.isEmpty()) {
            inv.setStack(40, st.copy());
        }
        for (int ix = 0; ix < 9; ++ix) {
            st = layout.get(4 + ix);
            if (st == null || st.isEmpty()) continue;
            inv.setStack(ix, st.copy());
        }
        for (int ixx = 0; ixx < 27; ++ixx) {
            st = layout.get(13 + ixx);
            if (st == null || st.isEmpty()) continue;
            inv.setStack(9 + ixx, st.copy());
        }
        inv.setSelectedSlot(0);
        inv.markDirty();
        this.applyAutoPotions(player, kit);
        player.currentScreenHandler.sendContentUpdates();
    }

    /**
     * 3.0.9: applies the kit's configured auto potions to a fighter at the start
     * of every duel round - potion effects (kit.autoEffects, spec
     * "effectId:seconds:amplifier", -1 seconds = infinite) and/or items
     * (kit.autoItems, item SNBT - e.g. splash potions or golden apples). Bad
     * entries are logged and skipped so one broken spec can never kill a duel.
     */
    private void applyAutoPotions(ServerPlayerEntity player, Kit kit) {
        if (kit == null) {
            return;
        }
        if (kit.autoEffects != null) {
            for (String spec : kit.autoEffects) {
                Object[] parsed = KitManager.parseAutoEffect(spec);
                if (parsed == null) {
                    PvPCoreMod.LOGGER.warn("Kit {} has an invalid auto potion effect spec '{}'; skipping", (Object)kit.id, (Object)spec);
                    continue;
                }
                RegistryEntry<StatusEffect> effect = (RegistryEntry<StatusEffect>)parsed[0];
                int seconds = (Integer)parsed[1];
                int amplifier = (Integer)parsed[2];
                int duration = seconds < 0 ? -1 : seconds * 20;
                try {
                    player.addStatusEffect(new StatusEffectInstance(effect, duration, amplifier, false, true, true));
                }
                catch (Throwable t) {
                    PvPCoreMod.LOGGER.warn("Could not apply auto potion effect '{}' of kit {}: {}", new Object[]{spec, kit.id, t.getMessage()});
                }
            }
        }
        if (kit.autoItems != null) {
            for (String snbt : kit.autoItems) {
                ItemStack stack;
                if (snbt == null || snbt.isBlank() || (stack = ItemCodecUtil.fromSnbt(snbt)).isEmpty()) continue;
                PlayerInventory inv = player.getInventory();
                int slot = -1;
                for (int i = 0; i < 9 && slot < 0; ++i) {
                    if (!inv.getStack(i).isEmpty()) continue;
                    slot = i;
                }
                for (int i = 9; i < 36 && slot < 0; ++i) {
                    if (!inv.getStack(i).isEmpty()) continue;
                    slot = i;
                }
                if (slot >= 0) {
                    inv.setStack(slot, stack.copy());
                    inv.markDirty();
                    continue;
                }
                player.dropItem(stack.copy(), false);
            }
        }
    }

    public void tick() {
        ++this.tick;
        this.requests.entrySet().removeIf(e -> {
            if (this.tick >= ((DuelRequest)e.getValue()).expiryTick) {
                ServerPlayerEntity target = PvPCore.get().server().getPlayerManager().getPlayer((UUID)e.getKey());
                ServerPlayerEntity sender = PvPCore.get().server().getPlayerManager().getPlayer(((DuelRequest)e.getValue()).sender);
                Messages mm = PvPCore.get().messages();
                if (target != null) {
                    target.sendMessage((Text)Text.literal((String)mm.get("duel.challenge-expired", Map.of("player", sender != null ? sender.getGameProfile().name() : "?"))), false);
                }
                if (sender != null) {
                    sender.sendMessage((Text)Text.literal((String)mm.get("duel.challenge-expired-sender", Map.of("player", target != null ? target.getGameProfile().name() : "?"))), false);
                }
                return true;
            }
            return false;
        });
        for (Duel duel : this.duels.values()) {
            switch (duel.state) {
                case COUNTDOWN: {
                    this.tickCountdown(duel);
                    break;
                }
                case FIGHTING: {
                    this.tickFighting(duel);
                    if (this.tick % 5L != 0L) break;
                    PvPCore.get().teamColors().updateDuelHealthSuffixes(duel);
                    break;
                }
                case ROUND_END: {
                    this.tickRoundEnd(duel);
                    break;
                }
                case ENDING: {
                    this.tickEnding(duel);
                }
            }
            this.expireDrops(duel);
        }
        this.duels.entrySet().removeIf(e -> {
            Duel d = (Duel)e.getValue();
            if (d.state != DuelState.FINISHED) {
                return false;
            }
            for (UUID u : d.teamA) {
                this.byParticipant.remove(u, d);
            }
            for (UUID u : d.teamB) {
                this.byParticipant.remove(u, d);
            }
            return true;
        });
    }

    private void tickCountdown(Duel duel) {
        block8: {
            Messages mm;
            long secondsLeft;
            block9: {
                ServerPlayerEntity p2;
                net.minecraft.server.PlayerManager pm = PvPCore.get().server().getPlayerManager();
                long elapsed = this.tick - duel.stateSinceTick;
                secondsLeft = (long)duel.countdownRemainingSeconds - elapsed / 20L;
                MainConfig.Duel cfg = PvPCore.get().config().duel;
                if (cfg.forceSurvival) {
                    for (UUID u : duel.participantUuids()) {
                        if (duel.isEliminated(u) || duel.isDisconnected(u) || (p2 = pm.getPlayer(u)) == null || PvPCore.get().spectateManager().isSpectating(p2) || p2.interactionManager.getGameMode() == GameMode.SURVIVAL) continue;
                        p2.changeGameMode(GameMode.SURVIVAL);
                    }
                }
                if (cfg.freezeDuringCountdown) {
                    for (UUID ux : duel.participantUuids()) {
                        if (duel.isEliminated(ux) || duel.isDisconnected(ux) || (p2 = pm.getPlayer(ux)) == null || PvPCore.get().spectateManager().isSpectating(p2)) continue;
                        if (elapsed % 20L == 0L) {
                            p2.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 40, 8, true, false));
                            p2.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, 40, -129, true, false));
                        }
                        double[] a = duel.anchors.get(ux);
                        if (a == null) continue;
                        double dx = p2.getX() - a[0];
                        double dy = p2.getY() - a[1];
                        double dz = p2.getZ() - a[2];
                        if (dx * dx + dy * dy + dz * dz > 0.25) {
                            p2.networkHandler.requestTeleport(a[0], a[1], a[2], p2.getYaw(), p2.getPitch());
                        }
                    }
                }
                if (elapsed % 20L != 0L && elapsed != 0L) break block8;
                mm = PvPCore.get().messages();
                if (secondsLeft > 0L) break block9;
                if (secondsLeft != 0L) break block8;
                PvPCore.get().arenaManager().markActive(duel.arena);
                duel.state = DuelState.FIGHTING;
                duel.stateSinceTick = this.tick;
                duel.fightStartTick = this.tick;
                for (ServerPlayerEntity px : duel.participants()) {
                    if (!duel.isEliminated(px.getUuid())) {
                        px.clearStatusEffects();
                    }
                    TitleUtil.title(px, mm.get("duel.fight-title"), "", 0, 15, 5);
                    this.fightSound(px);
                }
                break block8;
            }
            for (ServerPlayerEntity px : duel.participants()) {
                if (duel.isEliminated(px.getUuid()) || duel.isDisconnected(px.getUuid())) continue;
                TitleUtil.title(px, mm.get("duel.countdown-title", Map.of("seconds", String.valueOf(secondsLeft))), "", 0, 20, 0);
                this.countdownSound(px, secondsLeft);
            }
        }
    }

    private void tickFighting(Duel duel) {
        long fightTicks;
        MainConfig.Duel cfg = PvPCore.get().config().duel;
        if (cfg.forceSurvival && this.tick % 20L == 0L) {
            net.minecraft.server.PlayerManager pm = PvPCore.get().server().getPlayerManager();
            for (UUID u : duel.participantUuids()) {
                ServerPlayerEntity p;
                if (duel.isEliminated(u) || duel.isDisconnected(u) || (p = pm.getPlayer(u)) == null || PvPCore.get().spectateManager().isSpectating(p) || p.interactionManager.getGameMode() == GameMode.SURVIVAL) continue;
                p.changeGameMode(GameMode.SURVIVAL);
            }
        }
        if (cfg.disableHunger) {
            for (ServerPlayerEntity serverPlayerEntity : duel.participants()) {
                if (serverPlayerEntity.getHungerManager().getFoodLevel() >= 20) continue;
                // 3.0.9: top the food back up but never re-add saturation -
                // re-adding it re-armed vanilla's fast saturated regeneration
                // roughly every 10 seconds of a long sword fight.
                serverPlayerEntity.getHungerManager().setFoodLevel(20);
            }
        }
        for (ServerPlayerEntity serverPlayerEntity : duel.participants()) {
            if (duel.isEliminated(serverPlayerEntity.getUuid()) || duel.isDisconnected(serverPlayerEntity.getUuid()) || !(serverPlayerEntity.getY() < (double)(serverPlayerEntity.getEntityWorld().getBottomY() - 8))) continue;
            this.endRoundOrDuel(duel, duel.isTeamA(serverPlayerEntity.getUuid()) ? "B" : "A", "void");
            return;
        }
        this.reapplyEliminationSpectator(duel);
        for (Map.Entry entry : duel.disconnectedAt.entrySet()) {
            UUID ux = (UUID)entry.getKey();
            if (this.tick < (Long)entry.getValue() + (long)cfg.disconnectGraceSeconds * 20L) continue;
            String winner = duel.isTeamA(ux) ? "B" : "A";
            ServerPlayerEntity opponent = this.firstAliveOnlineOpponent(duel, ux);
            if (opponent != null) {
                opponent.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("duel.won-by-disconnect")), false);
            }
            this.endRoundOrDuel(duel, winner, "disconnect");
            return;
        }
        if (duel.aliveIn(duel.teamA) == 0L) {
            this.endRoundOrDuel(duel, "B", "wipe");
        } else if (duel.aliveIn(duel.teamB) == 0L) {
            this.endRoundOrDuel(duel, "A", "wipe");
        }
        if (cfg.timeoutMinutes > 0 && (fightTicks = this.tick - duel.fightStartTick) >= (long)cfg.timeoutMinutes * 60L * 20L) {
            this.endDuel(duel, "DRAW", "timeout");
        }
        if (duel.scoreboard != null && this.tick % (long)PvPCore.get().config().scoreboard.updateIntervalTicks == 0L) {
            this.updateScoreboard(duel);
        }
    }

    private ServerPlayerEntity firstAliveOnlineOpponent(Duel duel, UUID of) {
        net.minecraft.server.PlayerManager pm = PvPCore.get().server().getPlayerManager();
        for (UUID u : duel.opponentsOf(of)) {
            ServerPlayerEntity p = pm.getPlayer(u);
            if (p == null || !p.isAlive()) continue;
            return p;
        }
        return null;
    }

    private void tickEnding(Duel duel) {
        long elapsed = this.tick - duel.stateSinceTick;
        if (elapsed >= (long)PvPCore.get().config().duel.endDurationSeconds * 20L) {
            this.finishDuel(duel);
        }
    }

    private void endRoundOrDuel(Duel duel, String winner, String reason) {
        if (duel.rounds <= 1) {
            this.endDuel(duel, winner, reason);
        } else {
            boolean decided;
            int remainingAfterThis = duel.rounds - duel.round;
            int winsAfter = winner.equals("A") ? duel.winsA + 1 : duel.winsB + 1;
            int otherWinsAfter = winner.equals("A") ? duel.winsB : duel.winsA;
            boolean bl = decided = remainingAfterThis == 0 || !PvPCore.get().config().duel.playAllRounds && winsAfter > otherWinsAfter + remainingAfterThis;
            if (decided) {
                duel.lastRoundWinner = winner;
                if (winner.equals("A")) {
                    ++duel.winsA;
                } else {
                    ++duel.winsB;
                }
                Messages mm = PvPCore.get().messages();
                net.minecraft.server.PlayerManager pm = PvPCore.get().server().getPlayerManager();
                UUID winnerFirst = winner.equals("A") ? duel.teamA.get(0) : duel.teamB.get(0);
                int winnerWins = winner.equals("A") ? duel.winsA : duel.winsB;
                int loserWins = winner.equals("A") ? duel.winsB : duel.winsA;
                String roundMsg = mm.get("duel.round-won", Map.of("winner", this.coloredNameOf(winnerFirst), "round", String.valueOf(duel.round), "score1", String.valueOf(winnerWins), "score2", String.valueOf(loserWins)));
                ArrayList<ServerPlayerEntity> audience = new ArrayList<ServerPlayerEntity>(duel.participants());
                audience.addAll(duel.spectators());
                for (ServerPlayerEntity p : audience) {
                    if (p == null) continue;
                    p.sendMessage((Text)Text.literal((String)roundMsg), false);
                }
                String overall = duel.winsA > duel.winsB ? "A" : (duel.winsB > duel.winsA ? "B" : "DRAW");
                this.endDuel(duel, overall, reason);
            } else {
                this.endRound(duel, winner);
            }
        }
    }

    private void endRound(Duel duel, String winner) {
        if (duel.state == DuelState.FIGHTING) {
            duel.lastRoundWinner = winner;
            if (winner.equals("A")) {
                ++duel.winsA;
            } else {
                ++duel.winsB;
            }
            duel.state = DuelState.ROUND_END;
            duel.stateSinceTick = this.tick;
            Messages mm = PvPCore.get().messages();
            net.minecraft.server.PlayerManager pm = PvPCore.get().server().getPlayerManager();
            int inter = Math.max(1, PvPCore.get().config().duel.roundIntermissionSeconds);
            UUID winnerFirst = winner.equals("A") ? duel.teamA.get(0) : duel.teamB.get(0);
            int winnerWins = winner.equals("A") ? duel.winsA : duel.winsB;
            int loserWins = winner.equals("A") ? duel.winsB : duel.winsA;
            String roundMsg = mm.get("duel.round-won", Map.of("winner", this.coloredNameOf(winnerFirst), "round", String.valueOf(duel.round), "score1", String.valueOf(winnerWins), "score2", String.valueOf(loserWins)));
            ArrayList<ServerPlayerEntity> audience = new ArrayList<ServerPlayerEntity>(duel.participants());
            audience.addAll(duel.spectators());
            for (ServerPlayerEntity p : audience) {
                if (p == null) continue;
                p.sendMessage((Text)Text.literal((String)roundMsg), false);
            }
            for (UUID u : winner.equals("A") ? duel.teamB : duel.teamA) {
                ServerPlayerEntity px = pm.getPlayer(u);
                if (px == null || duel.isDisconnected(u)) continue;
                this.makeRoundLoserSpectator(duel, px);
            }
            this.updateScoreboard(duel);
        }
    }

    private void makeRoundLoserSpectator(Duel duel, ServerPlayerEntity p) {
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < 36; ++i) {
            inv.setStack(i, ItemStack.EMPTY);
        }
        for (int var6 = 36; var6 < 40; ++var6) {
            inv.setStack(var6, ItemStack.EMPTY);
        }
        inv.setStack(40, ItemStack.EMPTY);
        inv.markDirty();
        p.currentScreenHandler.updateToClient();
        p.clearStatusEffects();
        PvPCore.get().playerManager().revivePlayer(p);
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, -1, 0, true, false));
        if (p.interactionManager.getGameMode() != GameMode.SPECTATOR) {
            p.changeGameMode(GameMode.SPECTATOR);
        }
        this.teleportToSpectatorSpot(duel, p);
        Messages mm = PvPCore.get().messages();
        TitleUtil.title(p, mm.get("duel.lose-title"), mm.get("duel.round-lost-subtitle"));
    }

    private void tickRoundEnd(Duel duel) {
        long secondsLeft;
        long elapsed = this.tick - duel.stateSinceTick;
        int interTicks = Math.max(1, PvPCore.get().config().duel.roundIntermissionSeconds) * 20;
        if (elapsed % 20L == 0L && (secondsLeft = ((long)interTicks - elapsed) / 20L) > 0L && secondsLeft <= 3L) {
            Messages mm = PvPCore.get().messages();
            for (ServerPlayerEntity p : duel.participants()) {
                TitleUtil.title(p, mm.get("duel.countdown-title", Map.of("seconds", String.valueOf(secondsLeft))), "", 0, 20, 0);
                this.countdownSound(p, secondsLeft);
            }
        }
        if (elapsed >= (long)interTicks) {
            this.startNextRound(duel);
        }
    }

    private void startNextRound(Duel duel) {
        net.minecraft.server.PlayerManager pm = PvPCore.get().server().getPlayerManager();
        Kit kit = PvPCore.get().kitManager().get(duel.kitId);
        if (kit == null) {
            this.endDuel(duel, "DRAW", "kit-missing");
        } else {
            ServerPlayerEntity p3;
            ArrayList<ServerPlayerEntity> teamA = new ArrayList<ServerPlayerEntity>();
            ArrayList<ServerPlayerEntity> teamB = new ArrayList<ServerPlayerEntity>();
            for (UUID u : duel.teamA) {
                p3 = pm.getPlayer(u);
                if (p3 == null || duel.isDisconnected(u)) continue;
                teamA.add(p3);
            }
            for (UUID ux : duel.teamB) {
                p3 = pm.getPlayer(ux);
                if (p3 == null || duel.isDisconnected(ux)) continue;
                teamB.add(p3);
            }
            if (!teamA.isEmpty() && !teamB.isEmpty()) {
                ++duel.round;
                duel.eliminated.clear();
                this.clearDrops(duel);
                for (ServerPlayerEntity p2 : duel.participants()) {
                    p2.clearStatusEffects();
                    if (p2.interactionManager.getGameMode() == GameMode.SPECTATOR) {
                        p2.changeGameMode(GameMode.SURVIVAL);
                    }
                    PvPCore.get().playerManager().revivePlayer(p2);
                }
                this.restoreArena(duel);
                this.teleportTeam(duel, teamA, true);
                this.teleportTeam(duel, teamB, false);
                for (ServerPlayerEntity p2 : duel.participants()) {
                    this.prepareFighter(p2, kit);
                }
                duel.state = DuelState.COUNTDOWN;
                duel.stateSinceTick = this.tick;
                duel.countdownRemainingSeconds = PvPCore.get().config().duel.countdownSeconds;
                this.captureAnchors(duel);
                Messages mm = PvPCore.get().messages();
                for (ServerPlayerEntity pt : duel.participants()) {
                    TitleUtil.title(pt, mm.get("duel.round-countdown-title", Map.of("round", String.valueOf(duel.round))), "", 0, 20, 0);
                }
                this.updateScoreboard(duel);
            } else {
                this.endDuel(duel, teamA.isEmpty() ? "B" : "A", "wipe");
            }
        }
    }

    private void teleportToSpectatorSpot(Duel duel, ServerPlayerEntity p) {
        Arena arena = duel.arena;
        ServerWorld world = TeleportUtil.world(PvPCore.get().server(), arena.world);
        if (world != null) {
            double sx = arena.spectatorSet ? arena.spectatorX : (arena.spawn1X + arena.spawn2X) / 2.0;
            double sy = arena.spectatorSet ? arena.spectatorY : Math.max(arena.spawn1Y, arena.spawn2Y) + 6.0;
            double sz = arena.spectatorSet ? arena.spectatorZ : (arena.spawn1Z + arena.spawn2Z) / 2.0;
            float syaw = arena.spectatorSet ? arena.spectatorYaw : 0.0f;
            float spitch = arena.spectatorSet ? arena.spectatorPitch : 25.0f;
            TeleportUtil.teleport(p, world, sx, sy, sz, syaw, spitch);
        }
    }

    private void countdownSound(ServerPlayerEntity p, long secondsLeft) {
        if (PvPCore.get().config().duel.countdownSounds) {
            try {
                float pitch = secondsLeft >= 3L ? 1.0f : (secondsLeft == 2L ? 1.2f : 1.45f);
                p.networkHandler.sendPacket((Packet)new PlaySoundS2CPacket((RegistryEntry)SoundEvents.BLOCK_NOTE_BLOCK_PLING, SoundCategory.MASTER, p.getX(), p.getY(), p.getZ(), 0.8f, pitch, 0L));
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
    }

    private void fightSound(ServerPlayerEntity p) {
        if (PvPCore.get().config().duel.countdownSounds) {
            try {
                p.networkHandler.sendPacket((Packet)new PlaySoundS2CPacket((RegistryEntry)SoundEvents.BLOCK_NOTE_BLOCK_PLING, SoundCategory.MASTER, p.getX(), p.getY(), p.getZ(), 1.0f, 2.0f, 0L));
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
    }

    private void dropItemsAndClear(Duel duel, ServerPlayerEntity victim) {
        ServerWorld expiry;
        PlayerInventory inv = victim.getInventory();
        boolean drop = PvPCore.get().config().duel.dropItemsOnDeath;
        if (drop && (expiry = victim.getEntityWorld()) instanceof ServerWorld) {
            ServerWorld world = expiry;
            long expiryx = this.tick + (long)Math.max(3, PvPCore.get().config().duel.dropsDespawnSeconds) * 20L;
            Random rand = new Random();
            for (int i = 0; i < inv.size(); ++i) {
                ItemStack st = inv.getStack(i);
                if (st == null || st.isEmpty()) continue;
                ItemEntity entity = new ItemEntity((World)world, victim.getX(), victim.getY() + 0.9, victim.getZ(), st.copy(), (rand.nextDouble() - 0.5) * 0.35, rand.nextDouble() * 0.25 + 0.1, (rand.nextDouble() - 0.5) * 0.35);
                entity.setPickupDelay(15);
                if (!world.spawnEntity((Entity)entity)) continue;
                duel.drops.put(entity, expiryx);
            }
            victim.sendMessage((Text)Text.literal((String)PvPCore.get().messages().get("duel.round-lost-items")), false);
        }
        for (int ix = 0; ix < 36; ++ix) {
            inv.setStack(ix, ItemStack.EMPTY);
        }
        for (int var14 = 36; var14 < 40; ++var14) {
            inv.setStack(var14, ItemStack.EMPTY);
        }
        inv.setStack(40, ItemStack.EMPTY);
        inv.markDirty();
        victim.currentScreenHandler.updateToClient();
    }

    private void expireDrops(Duel duel) {
        if (!duel.drops.isEmpty()) {
            duel.drops.entrySet().removeIf(e -> {
                if (this.tick < (Long)e.getValue() && !((ItemEntity)e.getKey()).isRemoved()) {
                    return false;
                }
                try {
                    if (!((ItemEntity)e.getKey()).isRemoved()) {
                        ((ItemEntity)e.getKey()).discard();
                    }
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
                return true;
            });
        }
    }

    private void clearDrops(Duel duel) {
        if (!duel.drops.isEmpty()) {
            for (ItemEntity e : new ArrayList<ItemEntity>(duel.drops.keySet())) {
                try {
                    if (e.isRemoved()) continue;
                    e.discard();
                }
                catch (Throwable throwable) {}
            }
            duel.drops.clear();
        }
    }

    private void updateScoreboard(Duel duel) {
        if (duel.scoreboard != null) {
            MainConfig.ScoreboardSection cfg = PvPCore.get().config().scoreboard;
            net.minecraft.server.PlayerManager pm = PvPCore.get().server().getPlayerManager();
            ArrayList<String> lines = new ArrayList<String>();
            ServerPlayerEntity p1 = pm.getPlayer(duel.teamA.get(0));
            ServerPlayerEntity p2 = pm.getPlayer(duel.teamB.get(0));
            String kit = this.kitDisplayName(duel.kitId);
            if (duel.teamA.size() == 1 && duel.teamB.size() == 1) {
                long durationTicks = duel.state == DuelState.FIGHTING ? this.tick - duel.fightStartTick : 0L;
                for (String template : cfg.lines) {
                    String line = this.scoreboardPlaceholders(template, duel, kit, durationTicks, p1, p2);
                    lines.add(line);
                }
            } else {
                long durationTicks = duel.state == DuelState.FIGHTING ? this.tick - duel.fightStartTick : 0L;
                for (String template : cfg.teamLines) {
                    if (template.contains("{teamAList}")) {
                        lines.addAll(this.teamPlayerLines(duel, duel.teamA, cfg.teamLineA));
                        continue;
                    }
                    if (template.contains("{teamBList}")) {
                        lines.addAll(this.teamPlayerLines(duel, duel.teamB, cfg.teamLineB));
                        continue;
                    }
                    lines.add(this.scoreboardPlaceholders(template, duel, kit, durationTicks, p1, p2));
                }
            }
            duel.scoreboard.updateLines(lines);
        }
    }

    private int pingOf(ServerPlayerEntity player) {
        // 3.0.8: live pong-based ping (see ServerStats).
        try {
            return ServerStats.ping(player);
        }
        catch (Throwable var3) {
            return 0;
        }
    }

    private String scoreboardPlaceholders(String template, Duel duel, String kit, long durationTicks, ServerPlayerEntity p1, ServerPlayerEntity p2) {
        LocalDateTime now = LocalDateTime.now();
        return template.replace("{kit}", kit).replace("{arena}", duel.arena != null ? duel.arena.id : "?").replace("{ranked}", duel.ranked ? "Ranked" : "Unranked").replace("{duration}", TextUtil.formatDurationTicks(durationTicks)).replace("{round}", String.valueOf(duel.round)).replace("{rounds}", String.valueOf(duel.rounds)).replace("{score1}", String.valueOf(duel.winsA)).replace("{score2}", String.valueOf(duel.winsB)).replace("{player1}", p1 != null ? PvPCore.get().teamColors().coloredName(p1) : "?").replace("{player2}", p2 != null ? PvPCore.get().teamColors().coloredName(p2) : "?").replace("{ping1}", p1 != null ? String.valueOf(this.pingOf(p1)) : "?").replace("{ping2}", p2 != null ? String.valueOf(this.pingOf(p2)) : "?").replace("{hp1}", p1 != null ? String.valueOf((int)Math.ceil(p1.getHealth())) : "?").replace("{hp2}", p2 != null ? String.valueOf((int)Math.ceil(p2.getHealth())) : "?").replace("{hits1}", String.valueOf(duel.hitsOf(duel.teamA.get(0)))).replace("{hits2}", String.valueOf(duel.hitsOf(duel.teamB.get(0)))).replace("{online}", String.valueOf(PvPCore.get().server().getPlayerManager().getCurrentPlayerCount())).replace("{max}", String.valueOf(PvPCore.get().server().getPlayerManager().getMaxPlayerCount())).replace("{uptime}", ServerStats.uptime(PvPCore.get().server())).replace("{tps}", ServerStats.tps(PvPCore.get().server())).replace("{date}", now.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))).replace("{time}", now.format(DateTimeFormatter.ofPattern("HH:mm")));
    }

    private List<String> teamPlayerLines(Duel duel, List<UUID> team, String template) {
        net.minecraft.server.PlayerManager pm = PvPCore.get().server().getPlayerManager();
        ArrayList<String> out = new ArrayList<String>();
        int shown = 0;
        for (UUID u : team) {
            ServerPlayerEntity p = pm.getPlayer(u);
            if (p == null || shown >= 5) continue;
            boolean dead = duel.isEliminated(u) || duel.isDisconnected(u);
            String line = template.replace("{player}", this.nameOf(u)).replace("{hp}", String.valueOf((int)Math.ceil((double)p.getHealth() / 2.0))).replace("{ping}", String.valueOf(this.pingOf(p))).replace("{dead}", dead ? "&7(dead)" : "");
            out.add((String)(dead && !template.contains("{dead}") ? "&8" + line : line));
            ++shown;
        }
        return out;
    }

    public void endDuel(Duel duel, String result, String reason) {
        if (duel.state == DuelState.FIGHTING || duel.state == DuelState.COUNTDOWN || duel.state == DuelState.ROUND_END) {
            if (duel.state == DuelState.ROUND_END) {
                // empty if block
            }
            duel.result = result;
            duel.state = DuelState.ENDING;
            duel.stateSinceTick = this.tick;
            for (ServerPlayerEntity p : duel.participants()) {
                if (PvPCore.get().spectateManager().isSpectating(p)) continue;
                p.clearStatusEffects();
            }
            Messages mm = PvPCore.get().messages();
            net.minecraft.server.PlayerManager pm = PvPCore.get().server().getPlayerManager();
            long durationTicks = this.tick - duel.fightStartTick;
            String duration = TextUtil.formatDurationTicks(durationTicks);
            List<UUID> winners = result.equals("A") ? duel.teamA : (result.equals("B") ? duel.teamB : new ArrayList<UUID>());
            List<UUID> losers = result.equals("A") ? duel.teamB : (result.equals("B") ? duel.teamA : new ArrayList<UUID>());
            this.applyStats(duel, winners, losers);
            if (PvPCore.get().config().duel.broadcastEnds) {
                String announcement;
                if (result.equals("DRAW")) {
                    announcement = mm.get("duel.draw", Map.of("player1", this.coloredNameOf(duel.teamA.get(0)), "player2", this.coloredNameOf(duel.teamB.get(0)), "duration", duration));
                } else {
                    String winnerName = this.coloredNameOf(result.equals("A") ? duel.teamA.get(0) : duel.teamB.get(0));
                    String loserName = this.coloredNameOf(result.equals("A") ? duel.teamB.get(0) : duel.teamA.get(0));
                    announcement = mm.get("duel.ended", Map.of("winner", winnerName, "loser", loserName, "kit", this.kitDisplayName(duel.kitId), "duration", duration));
                }
                for (ServerPlayerEntity px : PvPCore.get().server().getPlayerManager().getPlayerList()) {
                    px.sendMessage((Text)Text.literal((String)announcement), false);
                }
            } else {
                ArrayList<ServerPlayerEntity> audience = new ArrayList<ServerPlayerEntity>(duel.participants());
                audience.addAll(duel.spectators());
                for (ServerPlayerEntity px : audience) {
                    if (px == null || px.isDisconnected()) continue;
                    this.sendEndSummary(duel, px, result, duration, winners, losers);
                }
            }
            if (PvPCore.get().config().duel.showEndTitles) {
                for (ServerPlayerEntity pxx : duel.participants()) {
                    if (duel.isDisconnected(pxx.getUuid())) continue;
                    boolean won = winners.contains(pxx.getUuid());
                    if (result.equals("DRAW")) {
                        TitleUtil.title(pxx, mm.get("duel.draw-title"), "");
                        continue;
                    }
                    if (won) {
                        TitleUtil.title(pxx, mm.get("duel.win-title"), mm.get("duel.win-subtitle", Map.of("loser", this.opponentName(duel, pxx))));
                        continue;
                    }
                    TitleUtil.title(pxx, mm.get("duel.lose-title"), mm.get("duel.lose-subtitle", Map.of("winner", this.opponentName(duel, pxx))));
                }
            }
            if (duel.ranked && duel.teamA.size() == 1 && duel.teamB.size() == 1 && !result.equals("DRAW")) {
                this.applyElo(duel, result);
            }
        }
    }

    private String nameOf(UUID uuid) {
        ServerPlayerEntity p = PvPCore.get().server().getPlayerManager().getPlayer(uuid);
        return p != null ? p.getGameProfile().name() : "?";
    }

    private void sendEndSummary(Duel duel, ServerPlayerEntity p, String result, String duration, List<UUID> winners, List<UUID> losers) {
        String sub;
        String title;
        String opponentDisplay;
        Messages mm = PvPCore.get().messages();
        boolean isTeam = duel.teamA.size() > 1 || duel.teamB.size() > 1;
        List<UUID> opponents = duel.opponentsOf(p.getUuid());
        if (isTeam) {
            StringBuilder sb = new StringBuilder();
            int shown = 0;
            for (UUID u : opponents) {
                if (shown >= 3) {
                    sb.append("&7...");
                    break;
                }
                if (shown > 0) {
                    sb.append("&7, ");
                }
                sb.append(this.coloredNameOf(u));
                ++shown;
            }
            opponentDisplay = sb.toString();
        } else {
            opponentDisplay = opponents.isEmpty() ? "?" : this.coloredNameOf(opponents.get(0));
        }
        boolean won = winners.contains(p.getUuid());
        boolean lost = losers.contains(p.getUuid());
        boolean participant = duel.isParticipant(p.getUuid());
        String line = mm.get("duel.end-line");
        if (!participant) {
            String winnerName = result.equals("A") ? this.coloredNameOf(duel.teamA.get(0)) : (result.equals("B") ? this.coloredNameOf(duel.teamB.get(0)) : opponentDisplay);
            title = mm.get("duel.end-spectator");
            sub = mm.get("duel.end-spectator-sub", Map.of("winner", winnerName));
        } else if (result.equals("DRAW")) {
            title = mm.get("duel.end-draw");
            sub = mm.get("duel.end-draw-sub", Map.of("opponent", opponentDisplay));
        } else if (won) {
            title = mm.get("duel.end-victory");
            sub = mm.get(isTeam ? "duel.end-team-victory-sub" : "duel.end-victory-sub", Map.of("opponent", opponentDisplay));
        } else if (lost) {
            title = mm.get("duel.end-defeat");
            sub = mm.get(isTeam ? "duel.end-team-defeat-sub" : "duel.end-defeat-sub", Map.of("opponent", opponentDisplay));
        } else {
            title = mm.get("duel.end-draw");
            sub = mm.get("duel.end-draw-sub", Map.of("opponent", opponentDisplay));
        }
        p.sendMessage((Text)Text.literal((String)line), false);
        p.sendMessage((Text)Text.literal((String)title), false);
        p.sendMessage((Text)Text.literal((String)sub), false);
        if (duel.rounds > 1) {
            int myWins = duel.isTeamA(p.getUuid()) ? duel.winsA : duel.winsB;
            int theirWins = duel.isTeamA(p.getUuid()) ? duel.winsB : duel.winsA;
            p.sendMessage((Text)Text.literal((String)mm.get("duel.end-rounds", Map.of("wins", String.valueOf(myWins), "losses", String.valueOf(theirWins), "rounds", String.valueOf(duel.rounds)))), false);
        }
        p.sendMessage((Text)Text.literal((String)mm.get("duel.end-duration", Map.of("duration", duration))), false);
        p.sendMessage((Text)Text.literal((String)mm.get("duel.end-hits", Map.of("hits1", String.valueOf(duel.hitsOf(p.getUuid())), "hits2", String.valueOf(opponents.isEmpty() ? 0 : duel.hitsOf(opponents.get(0)))))), false);
        p.sendMessage((Text)Text.literal((String)line), false);
    }

    private String opponentName(Duel duel, ServerPlayerEntity player) {
        List<UUID> opponents = duel.opponentsOf(player.getUuid());
        return opponents.isEmpty() ? "?" : this.nameOf(opponents.get(0));
    }

    private void applyStats(Duel duel, List<UUID> winners, List<UUID> losers) {
        PlayerData data;
        Storage storage = PvPCore.get().storage();
        for (UUID u : winners) {
            data = storage.get(u, this.nameOf(u));
            data.statsFor(duel.kitId).addWin();
            data.statsFor("global").addWin();
            storage.markDirty(u);
        }
        for (UUID u : losers) {
            data = storage.get(u, this.nameOf(u));
            data.statsFor(duel.kitId).addLoss();
            data.statsFor("global").addLoss();
            storage.markDirty(u);
        }
        for (UUID u : duel.hits.keySet()) {
            data = storage.get(u, this.nameOf(u));
            PlayerStats var10000 = data.statsFor(duel.kitId);
            var10000.hits += duel.hitsOf(u);
            var10000 = data.statsFor("global");
            var10000.hits += duel.hitsOf(u);
            storage.markDirty(u);
        }
    }

    private void applyElo(Duel duel, String result) {
        Storage storage = PvPCore.get().storage();
        MainConfig.Elo eloCfg = PvPCore.get().config().elo;
        UUID winnerId = result.equals("A") ? duel.teamA.get(0) : duel.teamB.get(0);
        UUID loserId = result.equals("A") ? duel.teamB.get(0) : duel.teamA.get(0);
        PlayerData winnerData = storage.get(winnerId, this.nameOf(winnerId));
        PlayerData loserData = storage.get(loserId, this.nameOf(loserId));
        int winnerRating = winnerData.ratingFor(duel.kitId, eloCfg.startRating);
        int loserRating = loserData.ratingFor(duel.kitId, eloCfg.startRating);
        double expectedWinner = 1.0 / (1.0 + Math.pow(10.0, (double)(loserRating - winnerRating) / 400.0));
        double expectedLoser = 1.0 - expectedWinner;
        int deltaW = (int)Math.round((double)eloCfg.kFactor * (1.0 - expectedWinner));
        int deltaL = (int)Math.round((double)eloCfg.kFactor * (0.0 - expectedLoser));
        int newWinner = Math.max(0, winnerRating + deltaW);
        int newLoser = Math.max(0, loserRating + deltaL);
        winnerData.setRating(duel.kitId, newWinner);
        loserData.setRating(duel.kitId, newLoser);
        winnerData.setRating("global", Math.max(0, winnerData.ratingFor("global", eloCfg.startRating) + deltaW));
        loserData.setRating("global", Math.max(0, loserData.ratingFor("global", eloCfg.startRating) + deltaL));
        storage.markDirty(winnerId);
        storage.markDirty(loserId);
        Messages mm = PvPCore.get().messages();
        String msg = mm.get("duel.elo-change", Map.of("kit", this.kitDisplayName(duel.kitId), "player1", this.nameOf(winnerId), "player2", this.nameOf(loserId), "delta1", "+" + deltaW, "delta2", String.valueOf(deltaL), "rating1", String.valueOf(newWinner), "rating2", String.valueOf(newLoser)));
        for (ServerPlayerEntity p : duel.participants()) {
            p.sendMessage((Text)Text.literal((String)msg), false);
        }
    }

    private void finishDuel(Duel duel) {
        PlayerManager playerManager = PvPCore.get().playerManager();
        net.minecraft.server.PlayerManager pm = PvPCore.get().server().getPlayerManager();
        this.clearDrops(duel);
        PvPCore.get().spectateManager().duelEnded(duel);
        List<UUID> losers = duel.result.equals("A") ? duel.teamB : (duel.result.equals("B") ? duel.teamA : new ArrayList<>());
        boolean loserSpec = PvPCore.get().config().duel.loserSpectates && !duel.result.isEmpty() && !duel.result.equals("DRAW");
        for (UUID u : duel.teamA) {
            if (duel.withdrawn.contains(u)) continue;
            this.finishPlayer(duel, u, loserSpec && losers.contains(u));
        }
        for (UUID u : duel.teamB) {
            if (duel.withdrawn.contains(u)) continue;
            this.finishPlayer(duel, u, loserSpec && losers.contains(u));
        }
        PvPCore.get().teamColors().clearDuelColors(duel);
        if (duel.scoreboard != null) {
            duel.scoreboard.removeAll();
        }
        this.restoreArena(duel);
        duel.restorer = null;
        PvPCore.get().arenaManager().release(duel.arena);
        duel.state = DuelState.FINISHED;
    }

    private void finishPlayer(Duel duel, UUID uuid, boolean loserSpectate) {
        net.minecraft.server.PlayerManager pm = PvPCore.get().server().getPlayerManager();
        ServerPlayerEntity p = pm.getPlayer(uuid);
        if (p != null) {
            PlayerManager playerManager = PvPCore.get().playerManager();
            MainConfig.Lobby lobbyCfg = PvPCore.get().config().lobby;
            InventorySnapshot snap = playerManager.preDuelSnapshot(p);
            playerManager.revivePlayer(p);
            playerManager.restoreGameMode(p);
            if (loserSpectate) {
                playerManager.clearAfterDuel(p, snap);
                PvPCore.get().spectateManager().forceSpectate(p, duel);
                this.playClick(p, false);
            } else {
                if (lobbyCfg.clearInventoryAfterDuel) {
                    playerManager.clearAfterDuel(p, snap);
                } else {
                    playerManager.restoreSnapshot(p, snap);
                }
                if (lobbyCfg.teleportAfterDuel) {
                    playerManager.teleportToLobby(p);
                } else {
                    playerManager.teleportToSnapshot(p, snap);
                }
                playerManager.backToLobby(p);
                this.playClick(p, false);
            }
        }
    }

    public void ensureBackToLobby(ServerPlayerEntity p) {
        if (p != null && !p.isDisconnected()) {
            if (PvPCore.get().spectateManager().isSpectating(p)) {
                PvPCore.get().spectateManager().returnPlayer(p);
            } else {
                PlayerState st = PvPCore.get().playerManager().state(p);
                if (st == PlayerState.SPECTATING || st == PlayerState.DUELING) {
                    PvPCore.get().playerManager().backToLobby(p);
                    PvPCore.get().playerManager().teleportToLobby(p);
                }
            }
        }
    }

    public void onPlayerDisconnect(ServerPlayerEntity player) {
        Duel duel = this.duelOf(player);
        if (duel != null && (duel.state == DuelState.FIGHTING || duel.state == DuelState.COUNTDOWN || duel.state == DuelState.ROUND_END)) {
            duel.disconnectedAt.put(player.getUuid(), this.tick);
            if (duel.state == DuelState.COUNTDOWN) {
                duel.state = DuelState.FIGHTING;
            }
            Messages mm = PvPCore.get().messages();
            for (ServerPlayerEntity p : duel.participants()) {
                if (p == null || p.getUuid().equals(player.getUuid()) || duel.isDisconnected(p.getUuid())) continue;
                TitleUtil.title(p, "", mm.get("duel.opponent-disconnected", Map.of("player", player.getGameProfile().name(), "seconds", String.valueOf(PvPCore.get().config().duel.disconnectGraceSeconds))));
            }
        }
    }

    public void onPlayerReconnectToLobby(ServerPlayerEntity player) {
        Duel duel = this.duelOf(player);
        UUID uuid = player.getUuid();
        if (duel == null) {
            this.recoverPendingToLobby(player);
            return;
        }
        Messages mm = PvPCore.get().messages();
        duel.disconnectedAt.remove(uuid);
        duel.withdrawn.add(uuid);
        this.byParticipant.remove(uuid, duel);
        if (duel.state == DuelState.COUNTDOWN || duel.state == DuelState.FIGHTING || duel.state == DuelState.ROUND_END) {
            ServerPlayerEntity opponent = this.firstAliveOnlineOpponent(duel, uuid);
            if (opponent != null) {
                opponent.sendMessage((Text)Text.literal((String)mm.get("duel.won-by-disconnect")), false);
            }
            this.endDuel(duel, duel.isTeamA(uuid) ? "B" : "A", "disconnect");
        }
        this.recoverPendingToLobby(player);
        player.sendMessage((Text)Text.literal((String)mm.get("duel.rejoined-lobby")), false);
    }

    private void recoverPendingToLobby(ServerPlayerEntity player) {
        PvPCore core = PvPCore.get();
        if (core.snapshotStore().has(player.getUuid())) {
            core.snapshotStore().restore(player);
        }
        core.playerManager().recoverToLobby(player);
    }

    public boolean allowDamage(LivingEntity entity, DamageSource source, float amount) {
        if (!(entity instanceof ServerPlayerEntity)) {
            return true;
        }
        ServerPlayerEntity victim = (ServerPlayerEntity)entity;
        PvPCore core = PvPCore.get();
        PlayerManager pm = core.playerManager();
        PlayerState state = pm.state(victim);
        if (core.spectateManager().isSpectating(victim)) {
            return false;
        }
        Entity entity2 = source.getAttacker();
        if (entity2 instanceof ServerPlayerEntity) {
            ServerPlayerEntity attackerSpectator = (ServerPlayerEntity)entity2;
            if (core.spectateManager().isSpectating(attackerSpectator)) {
                return false;
            }
        }
        if ((state == PlayerState.LOBBY || state == PlayerState.QUEUEING) && core.config().lobby.invulnerable) {
            if (source.isOf(DamageTypes.GENERIC_KILL)) {
                return true;
            }
            if (source.isOf(DamageTypes.OUT_OF_WORLD)) {
                core.playerManager().teleportToLobby(victim);
                return false;
            }
            return false;
        }
        Boolean zoneResult = core.zoneManager().allowDamage(victim, source);
        if (zoneResult != null) {
            return zoneResult;
        }
        Duel duel = this.duelOf(victim);
        if (duel == null) {
            return true;
        }
        if (duel.state != DuelState.FIGHTING) {
            return false;
        }
        if (duel.state == DuelState.FIGHTING) {
            Entity entity3 = source.getAttacker();
            if (entity3 instanceof ServerPlayerEntity) {
                ServerPlayerEntity attacker = (ServerPlayerEntity)entity3;
                if (!duel.isParticipant(attacker.getUuid())) {
                    return false;
                }
                if (duel.teamOf(attacker.getUuid()).equals(duel.teamOf(victim.getUuid()))) {
                    return false;
                }
                if (PvPCore.get().teamColors().sameColor(attacker, victim)) {
                    return false;
                }
                duel.hits.merge(attacker.getUuid(), 1, Integer::sum);
            }
            return true;
        }
        return true;
    }

    private boolean hasDeathProtection(ServerPlayerEntity victim, DamageSource source) {
        try {
            if (source.isIn(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
                return false;
            }
            for (Hand hand : Hand.values()) {
                ItemStack st = victim.getStackInHand(hand);
                if (st == null || st.isEmpty() || st.get(DataComponentTypes.DEATH_PROTECTION) == null) continue;
                return true;
            }
            return false;
        }
        catch (Throwable var8) {
            return false;
        }
    }

    public boolean allowDeath(ServerPlayerEntity victim, DamageSource source, float amount) {
        // TOTEM SUPPORT: Fabric's ALLOW_DEATH event is injected as a redirect of the
        // isDead() call that GUARDS the totem (death protector) check inside
        // LivingEntity.damage(). If we cancel here, vanilla never runs tryUseDeathProtector
        // and totems silently stop working. So whenever the victim holds a usable
        // totem, allow the death path to continue - vanilla will consume the totem,
        // heal the player and skip the actual death on its own.
        if (this.hasDeathProtection(victim, source)) {
            return true;
        }
        if (PvPCore.get().zoneManager().allowDeath(victim, source)) {
            try {
                if (victim.getHealth() <= 0.0f) {
                    victim.setHealth(1.0f);
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            return false;
        }
        Duel duel = this.duelOf(victim);
        if (duel == null) {
            return true;
        }
        if (duel.state != DuelState.FIGHTING) {
            try {
                if (victim.getHealth() <= 0.0f) {
                    victim.setHealth(1.0f);
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            return false;
        }
        if (this.hasDeathProtection(victim, source)) {
            return true;
        }
        this.dropItemsAndClear(duel, victim);
        List<UUID> victimTeam = duel.teamOf(victim.getUuid());
        long remaining = duel.aliveIn(victimTeam);
        if (victim.isAlive() && !victim.isSpectator() && !duel.isEliminated(victim.getUuid())) {
            --remaining;
        }
        if (remaining > 0L) {
            this.eliminate(duel, victim, source);
        } else {
            ServerPlayerEntity attacker;
            Entity class_12972 = source.getAttacker();
            if (class_12972 instanceof ServerPlayerEntity && duel.isParticipant((attacker = (ServerPlayerEntity)class_12972).getUuid()) && !duel.teamOf(attacker.getUuid()).equals(duel.teamOf(victim.getUuid()))) {
                this.endRoundOrDuel(duel, duel.isTeamA(attacker.getUuid()) ? "A" : "B", "kill");
            } else {
                this.endRoundOrDuel(duel, duel.isTeamA(victim.getUuid()) ? "B" : "A", "environment");
            }
        }
        try {
            if (victim.getHealth() <= 0.0f) {
                victim.setHealth(1.0f);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return false;
    }

    private void eliminate(Duel duel, ServerPlayerEntity victim, DamageSource source) {
        ServerPlayerEntity attacker;
        duel.eliminated.add(victim.getUuid());
        if (PvPCore.get().config().duel.eliminatedSpectates) {
            this.makeEliminatedSpectator(duel, victim);
        } else {
            this.sendEliminatedToLobby(duel, victim);
        }
        String killerName = "";
        Entity class_12972 = source.getAttacker();
        if (class_12972 instanceof ServerPlayerEntity && duel.isParticipant((attacker = (ServerPlayerEntity)class_12972).getUuid())) {
            killerName = PvPCore.get().teamColors().coloredName(attacker);
        }
        Messages mm = PvPCore.get().messages();
        ArrayList<ServerPlayerEntity> audience = new ArrayList<ServerPlayerEntity>(duel.participants());
        audience.addAll(duel.spectators());
        String msg = killerName.isEmpty() ? mm.get("duel.eliminated", Map.of("player", this.coloredNameOf(victim.getUuid()))) : mm.get("duel.eliminated-by", Map.of("player", this.coloredNameOf(victim.getUuid()), "killer", killerName));
        for (ServerPlayerEntity p : audience) {
            if (p == null) continue;
            p.sendMessage((Text)Text.literal((String)msg), false);
        }
        TitleUtil.title(victim, mm.get("duel.eliminated-title"), mm.get("duel.eliminated-subtitle"));
        this.updateScoreboard(duel);
    }

    private void makeEliminatedSpectator(Duel duel, ServerPlayerEntity p) {
        p.clearStatusEffects();
        PvPCore.get().playerManager().revivePlayer(p);
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, -1, 0, true, false));
        if (p.interactionManager.getGameMode() != GameMode.SPECTATOR) {
            p.changeGameMode(GameMode.SPECTATOR);
        }
        PvPCore.get().playerManager().markModSpectator(p, true);
        this.teleportToSpectatorSpot(duel, p);
    }

    private void sendEliminatedToLobby(Duel duel, ServerPlayerEntity p) {
        try {
            p.clearStatusEffects();
            PlayerManager pm = PvPCore.get().playerManager();
            pm.revivePlayer(p);
            if (p.interactionManager.getGameMode() == GameMode.SPECTATOR) {
                p.changeGameMode(GameMode.SURVIVAL);
            }
            InventorySnapshot snap = pm.preDuelSnapshot(p);
            pm.clearAfterDuel(p, snap);
            pm.backToLobby(p);
            pm.teleportToLobby(p);
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private void reapplyEliminationSpectator(Duel duel) {
        if (!PvPCore.get().config().duel.eliminatedSpectates || duel.eliminated.isEmpty()) {
            return;
        }
        net.minecraft.server.PlayerManager pm = PvPCore.get().server().getPlayerManager();
        for (UUID u : duel.eliminated) {
            ServerPlayerEntity p = pm.getPlayer(u);
            if (p == null || duel.isDisconnected(u) || !p.isAlive() || p.isSpectator()) continue;
            try {
                this.makeEliminatedSpectator(duel, p);
            }
            catch (Throwable throwable) {}
        }
    }

    private ArenaRestorer snapshotArena(Duel duel) {
        try {
            MainConfig.Duel cfg = PvPCore.get().config().duel;
            if (!cfg.arenaReset || duel.arena == null) {
                PvPCoreMod.LOGGER.info("[PvPCore] Arena snapshot skipped for duel in '{}' (arenaReset={} arena={})", new Object[]{duel.arena != null ? duel.arena.id : "?", cfg.arenaReset, duel.arena != null});
                return null;
            }
            ServerWorld world = TeleportUtil.world(PvPCore.get().server(), duel.arena.world);
            if (world == null) {
                PvPCoreMod.LOGGER.warn("[PvPCore] Arena snapshot skipped: world '{}' not found for arena '{}'", new Object[]{duel.arena.world, duel.arena.id});
                return null;
            }
            return ArenaRestorer.snapshot(world, duel.arena, cfg.arenaResetRadius);
        }
        catch (Throwable t) {
            PvPCoreMod.LOGGER.warn("Arena snapshot failed: {}", (Object)t.getMessage());
            return null;
        }
    }

    private void restoreArena(Duel duel) {
        try {
            if (duel.restorer != null) {
                PvPCoreMod.LOGGER.info("[PvPCore] Restoring arena '{}' for duel round transition/end", (Object)(duel.arena != null ? duel.arena.id : "?"));
                duel.restorer.restore();
            }
        }
        catch (Throwable t) {
            PvPCoreMod.LOGGER.warn("Arena restore failed: {}", (Object)t.getMessage());
        }
    }

    public void onPlayerDeath(ServerPlayerEntity player) {
        block7: {
            Duel duel = this.duelOf(player);
            if (duel != null && (duel.state == DuelState.FIGHTING || duel.state == DuelState.COUNTDOWN || duel.state == DuelState.ROUND_END)) {
                long survivors = duel.aliveIn(duel.teamOf(player.getUuid()));
                if (survivors > 0L) {
                    if (!duel.isEliminated(player.getUuid())) {
                        duel.eliminated.add(player.getUuid());
                        try {
                            if (PvPCore.get().config().duel.eliminatedSpectates) {
                                this.makeEliminatedSpectator(duel, player);
                                break block7;
                            }
                            this.sendEliminatedToLobby(duel, player);
                        }
                        catch (Throwable throwable) {}
                    }
                } else {
                    this.endDuel(duel, duel.isTeamA(player.getUuid()) ? "B" : "A", "death");
                }
            }
        }
    }

    public String coloredNameOf(UUID uuid) {
        ServerPlayerEntity p = PvPCore.get().server().getPlayerManager().getPlayer(uuid);
        return p != null ? PvPCore.get().teamColors().coloredName(p) : this.nameOf(uuid);
    }

    public void playClick(ServerPlayerEntity player, boolean start) {
        try {
            player.getEntityWorld().playSound(null, player.getX(), player.getY(), player.getZ(), start ? SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP : SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.MASTER, 0.6f, start ? 1.4f : 0.8f);
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    public void shutdown() {
        for (Duel duel : new ArrayList<Duel>(this.duels.values())) {
            // Cover EVERY live state - a duel stopped mid-round-end (intermission)
            // or mid-countdown previously left the arena unrestored forever.
            if (duel.state == DuelState.TELEPORTING || duel.state == DuelState.COUNTDOWN || duel.state == DuelState.FIGHTING || duel.state == DuelState.ROUND_END) {
                this.endDuel(duel, "DRAW", "shutdown");
            }
            if (duel.state != DuelState.ENDING) continue;
            this.finishDuel(duel);
        }
        this.duels.clear();
        this.byParticipant.clear();
    }
}

