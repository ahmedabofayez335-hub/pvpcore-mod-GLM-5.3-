/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 *  com.google.gson.GsonBuilder
 *  com.google.gson.reflect.TypeToken
 */
package com.pvpcore.audit;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.pvpcore.PvPCoreMod;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.FileAttribute;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

public final class AuditLog {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private static final int MAX_ENTRIES = 500;
    private final Path file;
    private List<Entry> entries = new ArrayList<Entry>();

    public AuditLog(Path dataDir) {
        this.file = dataDir.resolve("audit.json");
        this.load();
    }

    private void load() {
        if (Files.exists(this.file, new LinkOption[0])) {
            try {
                this.entries = (List)GSON.fromJson(Files.readString(this.file, StandardCharsets.UTF_8), new TypeToken<List<Entry>>(){}.getType());
                if (this.entries == null) {
                    this.entries = new ArrayList<Entry>();
                }
            }
            catch (Exception var2) {
                PvPCoreMod.LOGGER.error("Failed to load audit.json", (Throwable)var2);
            }
        }
    }

    public void log(String actor, String action) {
        this.entries.add(new Entry(Instant.now().toEpochMilli(), actor, action));
        while (this.entries.size() > 500) {
            this.entries.remove(0);
        }
        PvPCoreMod.LOGGER.info("[Audit] {}: {}", (Object)actor, (Object)action);
    }

    public void save() {
        try {
            Files.createDirectories(this.file.getParent(), new FileAttribute[0]);
            Path tmp = this.file.resolveSibling("audit.json.tmp");
            Files.writeString(tmp, (CharSequence)GSON.toJson(this.entries), StandardCharsets.UTF_8, new OpenOption[0]);
            Files.move(tmp, this.file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        }
        catch (IOException var21) {
            PvPCoreMod.LOGGER.error("Failed to save audit.json", (Throwable)var21);
        }
    }

    public List<Entry> entries() {
        return this.entries;
    }

    public record Entry(long timestamp, String actor, String action) {
    }
}

