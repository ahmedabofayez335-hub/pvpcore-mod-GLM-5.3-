/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  net.minecraft.component.DataComponentTypes
 *  net.minecraft.component.type.LoreComponent
 *  net.minecraft.component.type.NbtComponent
 *  net.minecraft.component.type.PotionContentsComponent
 *  net.minecraft.component.type.ProfileComponent
 *  net.minecraft.component.type.TooltipDisplayComponent
 *  net.minecraft.enchantment.Enchantment
 *  net.minecraft.entity.effect.StatusEffectInstance
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemConvertible
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.Items
 *  net.minecraft.nbt.NbtCompound
 *  net.minecraft.registry.entry.RegistryEntry
 *  net.minecraft.server.network.ServerPlayerEntity
 *  net.minecraft.text.Text
 */
package com.pvpcore.item;

import com.mojang.authlib.GameProfile;
import com.pvpcore.PvPCore;
import com.pvpcore.util.EnchantUtil;
import com.pvpcore.util.ItemCodecUtil;
import com.pvpcore.util.TextUtil;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.component.type.ProfileComponent;
import net.minecraft.component.type.TooltipDisplayComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.Item;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

public final class ItemBuilder {
    private final ItemStack stack;

    private ItemBuilder(ItemStack stack) {
        this.stack = stack;
    }

    public static ItemBuilder of(ItemStack stack) {
        return new ItemBuilder(stack == null ? ItemStack.EMPTY.copy() : stack.copy());
    }

    public static ItemBuilder of(String material) {
        return new ItemBuilder(ItemCodecUtil.parseMaterial(material));
    }

    public static ItemBuilder of(Item item) {
        return new ItemBuilder(new ItemStack((ItemConvertible)item));
    }

    public ItemBuilder amount(int count) {
        this.stack.setCount(Math.max(1, Math.min(99, count)));
        return this;
    }

    public ItemBuilder name(String name) {
        if (name != null) {
            this.stack.set(DataComponentTypes.CUSTOM_NAME, TextUtil.text(name));
        }
        return this;
    }

    public ItemBuilder lore(String ... lines) {
        return this.lore(Arrays.asList(lines));
    }

    public ItemBuilder lore(List<String> lines) {
        ArrayList<Text> lore = new ArrayList<Text>();
        if (lines != null) {
            for (String line : lines) {
                lore.add(TextUtil.text(line));
            }
        }
        this.stack.set(DataComponentTypes.LORE, new LoreComponent(lore));
        return this;
    }

    public ItemBuilder appendLore(String ... lines) {
        ArrayList<Text> existing = new ArrayList<Text>();
        LoreComponent comp = (LoreComponent)this.stack.get(DataComponentTypes.LORE);
        if (comp != null) {
            existing.addAll(comp.lines());
        }
        for (String line : lines) {
            existing.add(TextUtil.text(line));
        }
        this.stack.set(DataComponentTypes.LORE, new LoreComponent(existing));
        return this;
    }

    public ItemBuilder glow(boolean glow) {
        if (glow) {
            RegistryEntry<Enchantment> entry = EnchantUtil.byId("unbreaking");
            if (entry != null) {
                this.stack.addEnchantment(entry, 1);
            }
            this.stack.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
        }
        return this;
    }

    public ItemBuilder hideAll() {
        this.stack.set(DataComponentTypes.TOOLTIP_DISPLAY, new TooltipDisplayComponent(true, new LinkedHashSet()));
        return this;
    }

    public ItemBuilder tag(String action) {
        NbtCompound nbt = new NbtCompound();
        nbt.putString("pvpcore", action);
        this.stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of((NbtCompound)nbt));
        return this;
    }

    public static String actionOf(ItemStack stack) {
        if (stack != null && !stack.isEmpty()) {
            NbtComponent comp = (NbtComponent)stack.get(DataComponentTypes.CUSTOM_DATA);
            if (comp == null) {
                return null;
            }
            try {
                NbtCompound nbt = comp.copyNbt();
                String s = nbt.getString("pvpcore", "");
                return s != null && !s.isEmpty() ? s : null;
            }
            catch (Exception var41) {
                return null;
            }
        }
        return null;
    }

    public ItemBuilder skullOwner(ServerPlayerEntity player) {
        if (this.stack.getItem() != Items.PLAYER_HEAD) {
            return this;
        }
        this.stack.set(DataComponentTypes.PROFILE, ProfileComponent.ofStatic((GameProfile)player.getGameProfile()));
        return this;
    }

    public ItemBuilder skullOwner(GameProfile profile) {
        if (this.stack.getItem() == Items.PLAYER_HEAD && profile != null) {
            try {
                this.stack.set(DataComponentTypes.PROFILE, ProfileComponent.ofStatic((GameProfile)profile));
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            return this;
        }
        return this;
    }

    public ItemBuilder skullOwner(String name) {
        if (this.stack.getItem() == Items.PLAYER_HEAD && name != null && !name.isBlank()) {
            try {
                this.stack.set(DataComponentTypes.PROFILE, ProfileComponent.ofDynamic((String)name));
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            return this;
        }
        return this;
    }

    public ItemBuilder skullOwner(UUID uuid, String name) {
        if (this.stack.getItem() == Items.PLAYER_HEAD && uuid != null) {
            try {
                ServerPlayerEntity online = null;
                try {
                    online = PvPCore.get().server().getPlayerManager().getPlayer(uuid);
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
                if (online != null) {
                    this.stack.set(DataComponentTypes.PROFILE, ProfileComponent.ofStatic((GameProfile)online.getGameProfile()));
                } else {
                    this.stack.set(DataComponentTypes.PROFILE, ProfileComponent.ofDynamic((UUID)uuid));
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            return this;
        }
        return this;
    }

    public ItemBuilder enchant(String enchId, int level) {
        RegistryEntry<Enchantment> entry = EnchantUtil.byId(enchId);
        if (entry != null) {
            this.stack.addEnchantment(entry, level);
        }
        return this;
    }

    public ItemBuilder potionEffects(List<StatusEffectInstance> effects) {
        this.stack.set(DataComponentTypes.POTION_CONTENTS, new PotionContentsComponent(Optional.empty(), Optional.empty(), effects, Optional.empty()));
        return this;
    }

    public ItemStack build() {
        return this.stack.copy();
    }
}

