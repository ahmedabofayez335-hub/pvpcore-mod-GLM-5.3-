/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.fabric.api.event.player.AttackBlockCallback
 *  net.fabricmc.fabric.api.event.player.AttackEntityCallback
 *  net.fabricmc.fabric.api.event.player.UseBlockCallback
 *  net.fabricmc.fabric.api.event.player.UseItemCallback
 *  net.minecraft.server.network.ServerPlayerEntity
 *  net.minecraft.text.Text
 *  net.minecraft.util.ActionResult
 */
package com.pvpcore.lobby;

import com.pvpcore.PvPCore;
import com.pvpcore.gui.guis.AdminGui;
import com.pvpcore.gui.guis.KitListGui;
import com.pvpcore.gui.guis.KitPickerGui;
import com.pvpcore.gui.guis.LeaderboardGui;
import com.pvpcore.gui.guis.PlayerPickerGui;
import com.pvpcore.gui.guis.ProfileGui;
import com.pvpcore.gui.guis.SpectateGui;
import com.pvpcore.item.ItemBuilder;
import com.pvpcore.party.PartyManager;
import com.pvpcore.player.PlayerManager;
import com.pvpcore.player.PlayerState;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;

public final class LobbyItemListener {
    private LobbyItemListener() {
    }

    public static void register() {
        UseItemCallback.EVENT.register((player, world, hand) -> {
            if (!world.isClient() && player instanceof ServerPlayerEntity) {
                ServerPlayerEntity sp = (ServerPlayerEntity)player;
                String action = ItemBuilder.actionOf(sp.getStackInHand(hand));
                if (action != null) {
                    PvPCore.get().server().execute(() -> LobbyItemListener.handle(sp, action));
                    return ActionResult.SUCCESS;
                }
                return (ActionResult)(PvPCore.get().isItemUseBlocked(sp) ? ActionResult.FAIL : ActionResult.PASS);
            }
            return ActionResult.PASS;
        });
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (!world.isClient() && player instanceof ServerPlayerEntity) {
                ServerPlayerEntity sp = (ServerPlayerEntity)player;
                String action = ItemBuilder.actionOf(sp.getStackInHand(hand));
                if (action != null) {
                    PvPCore.get().server().execute(() -> LobbyItemListener.handle(sp, action));
                    return ActionResult.SUCCESS;
                }
                return (ActionResult)(PvPCore.get().isBlockPlaceBlocked(sp) ? ActionResult.FAIL : ActionResult.PASS);
            }
            return ActionResult.PASS;
        });
        AttackBlockCallback.EVENT.register((player, world, hand, pos, direction) -> {
            if (!world.isClient() && player instanceof ServerPlayerEntity) {
                ServerPlayerEntity sp = (ServerPlayerEntity)player;
                String action = ItemBuilder.actionOf(sp.getStackInHand(hand));
                if (action != null) {
                    PvPCore.get().server().execute(() -> LobbyItemListener.handle(sp, action));
                    return ActionResult.SUCCESS;
                }
                return (ActionResult)(PvPCore.get().isBlockBreakBlocked(sp) ? ActionResult.FAIL : ActionResult.PASS);
            }
            return ActionResult.PASS;
        });
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (!world.isClient() && player instanceof ServerPlayerEntity) {
                ServerPlayerEntity sp = (ServerPlayerEntity)player;
                String action = ItemBuilder.actionOf(sp.getStackInHand(hand));
                if (action == null) {
                    return ActionResult.PASS;
                }
                PvPCore.get().server().execute(() -> LobbyItemListener.handle(sp, action));
                return ActionResult.SUCCESS;
            }
            return ActionResult.PASS;
        });
    }

    public static void handle(ServerPlayerEntity player, String action) {
        if (player != null && !player.isDisconnected()) {
            PvPCore core = PvPCore.get();
            PlayerManager pm = core.playerManager();
            PlayerState state = pm.state(player);
            if (core.spectateManager().isSpectating(player)) {
                if (action.equals("spectate")) {
                    core.spectateManager().returnPlayer(player);
                }
            } else if (state != PlayerState.DUELING) {
                switch (action) {
                    case "unranked": {
                        new KitPickerGui(player, false, null).open(player);
                        break;
                    }
                    case "ranked": {
                        new KitPickerGui(player, true, null).open(player);
                        break;
                    }
                    case "queue_leave": {
                        core.queueManager().leave(player);
                        break;
                    }
                    case "duel": {
                        if (PvPCore.get().duelManager().duelOf(player) != null) {
                            player.sendMessage((Text)Text.literal((String)core.messages().get("duel.already-in-duel")), false);
                            break;
                        }
                        if (!core.duelManager().isEligibleDuelTarget(player)) {
                            player.sendMessage((Text)Text.literal((String)core.messages().get("duel.not-ready")), false);
                            break;
                        }
                        new PlayerPickerGui(player, "&8Duel - Pick an Opponent", target -> new KitPickerGui(player, false, (ServerPlayerEntity)target).open(player), t -> core.duelManager().isEligibleDuelTarget((ServerPlayerEntity)t)).open(player);
                        break;
                    }
                    case "kits": {
                        new KitListGui(player).open(player);
                        break;
                    }
                    case "party": {
                        PartyManager.Party party = core.partyManager().partyOf(player);
                        if (party == null && core.config().party.autoCreateOnItemClick) {
                            core.partyManager().createParty(player);
                        }
                        core.partyManager().sendPartyMenu(player);
                        break;
                    }
                    case "leaderboard": {
                        new LeaderboardGui(player).open(player);
                        break;
                    }
                    case "profile": {
                        new ProfileGui(player, player).open(player);
                        break;
                    }
                    case "spectate": {
                        new SpectateGui(player).open(player);
                        break;
                    }
                    case "admin": {
                        if (!PlayerManager.isAdmin(player)) break;
                        new AdminGui(player).open(player);
                    }
                }
            }
        }
    }
}

