package com.pvpcore.chat;

import com.pvpcore.PvPCore;
import com.pvpcore.config.MainConfig;
import com.pvpcore.data.PlayerData;
import com.pvpcore.duel.Duel;
import com.pvpcore.ffa.FightZone;
import com.pvpcore.party.PartyManager;
import com.pvpcore.util.TextUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

public final class ChatRouter {
    public void handle(ServerPlayerEntity sender, String message) {
        block10: {
            if (sender == null || sender.isDisconnected()) break block10;
            MainConfig.Chat cfg = PvPCore.get().config().chat;
            Duel duel = PvPCore.get().duelManager().duelOf(sender);
            if (duel != null && cfg.isolateDuels) {
                String colored = PvPCore.get().teamColors().coloredName(sender);
                Map<String, String> vars = Map.of("player", colored, "message", TextUtil.stripColor(message));
                String formatted = TextUtil.colorAndPlace(cfg.duelFormat, vars);
                ArrayList<ServerPlayerEntity> audience = new ArrayList<ServerPlayerEntity>(duel.participants());
                if (cfg.duelChatIncludesSpectators) {
                    audience.addAll(duel.spectators());
                }
                for (ServerPlayerEntity target : audience) {
                    if (target == null || target.networkHandler == null) continue;
                    target.sendMessage((Text)Text.literal((String)formatted), false);
                }
            } else {
                FightZone zone = PvPCore.get().zoneManager().zoneOf(sender);
                if (zone != null && cfg.isolateZones) {
                    // 3.0.8: FFA chat is fully separated from the rest of the
                    // server - only players inside the SAME fight zone see it.
                    String colored = PvPCore.get().teamColors().coloredName(sender);
                    String formatted = TextUtil.colorAndPlace(cfg.zoneFormat, Map.of("player", colored, "zone", TextUtil.stripColor(zone.displayName), "message", TextUtil.stripColor(message)));
                    List<ServerPlayerEntity> audience = PvPCore.get().zoneManager().membersOf(zone);
                    for (ServerPlayerEntity target : audience) {
                        if (target == null || target.networkHandler == null) continue;
                        target.sendMessage((Text)Text.literal((String)formatted), false);
                    }
                } else {
                    Duel spectating = PvPCore.get().spectateManager().spectatedDuel(sender);
                    if (spectating != null && cfg.isolateDuels && PvPCore.get().spectateManager().isolateSpectatorChat()) {
                        Map<String, String> vars = Map.of("player", sender.getGameProfile().name(), "message", TextUtil.stripColor(message));
                        String formatted = TextUtil.colorAndPlace(cfg.specFormat, vars);
                        ArrayList<ServerPlayerEntity> audience = new ArrayList<ServerPlayerEntity>(spectating.participants());
                        audience.addAll(spectating.spectators());
                        for (ServerPlayerEntity targetx : audience) {
                            if (targetx == null || targetx.networkHandler == null) continue;
                            targetx.sendMessage((Text)Text.literal((String)formatted), false);
                        }
                    } else {
                        PlayerData data;
                        PartyManager.Party party = PvPCore.get().partyManager().partyOf(sender);
                        if (party != null && (data = PvPCore.get().storage().get(sender.getUuid(), sender.getGameProfile().name())) != null && data.partyChat) {
                            Map<String, String> vars = Map.of("player", sender.getGameProfile().name(), "message", TextUtil.stripColor(message));
                            String formatted = TextUtil.colorAndPlace(cfg.partyFormat, vars);
                            for (ServerPlayerEntity member : party.onlineMembers()) {
                                if (member == null || member.networkHandler == null || PvPCore.get().duelManager().duelOf(member) != null && cfg.isolateDuels || cfg.isolateZones && PvPCore.get().zoneManager().isInZone(member)) continue;
                                member.sendMessage((Text)Text.literal((String)formatted), false);
                            }
                            return;
                        }
                        Map<String, String> vars = Map.of("player", sender.getGameProfile().name(), "message", TextUtil.stripColor(message));
                        String formatted = TextUtil.colorAndPlace(cfg.globalFormat, vars);
                        for (ServerPlayerEntity targetxx : PvPCore.get().server().getPlayerManager().getPlayerList()) {
                            if (targetxx == null || targetxx.networkHandler == null) continue;
                            if (cfg.hideGlobalFromDuelists && cfg.isolateDuels && targetxx != sender && PvPCore.get().duelManager().duelOf(targetxx) != null) continue;
                            // 3.0.8: FFA fighters do not receive lobby/global chat.
                            if (cfg.isolateZones && cfg.hideGlobalFromZoneMembers && targetxx != sender && PvPCore.get().zoneManager().isInZone(targetxx)) continue;
                            targetxx.sendMessage((Text)Text.literal((String)formatted), false);
                        }
                    }
                }
            }
        }
    }
}
