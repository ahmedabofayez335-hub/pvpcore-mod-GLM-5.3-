package com.pvpcore.queue;

import com.pvpcore.PvPCore;
import com.pvpcore.data.PlayerData;
import com.pvpcore.player.PlayerState;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Ranked / unranked queues with ELO-range matchmaking that expands
 * with wait time (0-10s +-50, 10-20s +-100, 20-30s +-150, 30s+ +-250).
 */
public final class QueueManager {
    public static class Entry {
        public final UUID player;
        public final String kitId;
        public final boolean ranked;
        public final long joinTick;
        public Entry(UUID player, String kitId, boolean ranked, long joinTick) {
            this.player = player; this.kitId = kitId; this.ranked = ranked; this.joinTick = joinTick;
        }
    }

    private final List<Entry> entries = new ArrayList<>();
    private long tick = 0;
    private long lastStatus = 0;

    public boolean isQueued(ServerPlayerEntity player) {
        return entries.stream().anyMatch(e -> e.player.equals(player.getUuid()));
    }

    public boolean isRankedQueue(ServerPlayerEntity player) {
        return entries.stream().anyMatch(e -> e.player.equals(player.getUuid()) && e.ranked);
    }

    public Entry entryOf(UUID player) {
        for (Entry e : entries) if (e.player.equals(player)) return e;
        return null;
    }

    public int queueSize(String kitId, boolean ranked) {
        return (int) entries.stream().filter(e -> e.kitId.equals(kitId) && e.ranked == ranked).count();
    }

    public int totalQueued() {
        return entries.size();
    }

    public void join(ServerPlayerEntity player, String kitId, boolean ranked) {
        var mm = PvPCore.get().messages();
        if (PvPCore.get().kitManager().get(kitId) == null) {
            player.sendMessage(Text.literal(mm.get("kit.not-found", Map.of("kit", kitId))), false);
            return;
        }
        var pm = PvPCore.get().playerManager();
        var state = pm.state(player);
        if (state != PlayerState.LOBBY && state != PlayerState.QUEUEING) {
            player.sendMessage(Text.literal(mm.get("not-in-lobby")), false);
            return;
        }
        if (PvPCore.get().duelManager().duelOf(player) != null) return;
        if (isQueued(player)) {
            player.sendMessage(Text.literal(mm.get("queue.already")), false);
            return;
        }
        entries.add(new Entry(player.getUuid(), kitId, ranked, tick));
        pm.setState(player, PlayerState.QUEUEING);
        player.sendMessage(Text.literal(mm.get("queue.joined", Map.of(
                "type", ranked ? "Ranked" : "Unranked",
                "kit", PvPCore.get().duelManager().kitDisplayName(kitId)))), false);
        PvPCore.get().playerManager().refreshLobby(player);
    }

    public void remove(ServerPlayerEntity player) {
        boolean removed = entries.removeIf(e -> e.player.equals(player.getUuid()));
        if (removed) {
            var pm = PvPCore.get().playerManager();
            if (pm.state(player) == PlayerState.QUEUEING) pm.setState(player, PlayerState.LOBBY);
            PvPCore.get().playerManager().refreshLobby(player);
        }
    }

    public void leave(ServerPlayerEntity player) {
        var mm = PvPCore.get().messages();
        if (!isQueued(player)) {
            player.sendMessage(Text.literal(mm.get("queue.not-queued")), false);
            return;
        }
        remove(player);
        player.sendMessage(Text.literal(mm.get("queue.left")), false);
    }

    public void tick() {
        tick++;
        int interval = Math.max(2, PvPCore.get().config().queue.matchmakingIntervalTicks);
        if (tick % interval != 0) return;

        var kitIds = new ArrayList<>(List.<String>of());
        for (var kit : PvPCore.get().kitManager().all()) kitIds.add(kit.id);

        // Unranked: FIFO pairing per kit
        for (String kitId : kitIds) {
            List<Entry> pool = new ArrayList<>();
            for (Entry e : entries) if (e.kitId.equals(kitId) && !e.ranked) pool.add(e);
            while (pool.size() >= 2) {
                Entry a = pool.remove(0);
                Entry b = pool.remove(0);
                if (tryMatch(a, b)) {
                    entries.remove(a);
                    entries.remove(b);
                }
            }
        }

        // Ranked: ELO range matchmaking
        for (String kitId : kitIds) {
            List<Entry> pool = new ArrayList<>();
            for (Entry e : entries) if (e.kitId.equals(kitId) && e.ranked) pool.add(e);
            pool.sort(Comparator.comparingLong(e -> e.joinTick));
            outer:
            for (int i = 0; i < pool.size(); i++) {
                for (int j = i + 1; j < pool.size(); j++) {
                    Entry a = pool.get(i);
                    Entry b = pool.get(j);
                    if (withinEloRange(a, b, kitId)) {
                        if (tryMatch(a, b)) {
                            entries.remove(a);
                            entries.remove(b);
                            pool.remove(a);
                            pool.remove(b);
                            i = -1;
                            continue outer;
                        }
                    }
                }
            }
        }

        // Status notifications
        int statusInterval = PvPCore.get().config().queue.statusIntervalTicks;
        if (statusInterval > 0 && tick - lastStatus >= statusInterval) {
            lastStatus = tick;
            var pm = PvPCore.get().server().getPlayerManager();
            for (Entry e : List.copyOf(entries)) {
                ServerPlayerEntity p = pm.getPlayer(e.player);
                if (p == null) continue;
                int range = currentRange(e);
                p.sendMessage(Text.literal(PvPCore.get().messages().get("queue.status", Map.of(
                        "kit", PvPCore.get().duelManager().kitDisplayName(e.kitId),
                        "type", e.ranked ? "Ranked" : "Unranked",
                        "position", String.valueOf(queueSize(e.kitId, e.ranked)),
                        "range", e.ranked ? "(±" + range + " ELO)" : ""))), true);
            }
        }
    }

    private boolean withinEloRange(Entry a, Entry b, String kitId) {
        var pm = PvPCore.get().server().getPlayerManager();
        int start = PvPCore.get().config().elo.startRating;
        PlayerData da = PvPCore.get().storage().get(a.player, null);
        PlayerData db = PvPCore.get().storage().get(b.player, null);
        int ra = da != null ? da.ratingFor(kitId, start) : start;
        int rb = db != null ? db.ratingFor(kitId, start) : start;
        int range = Math.min(currentRange(a), currentRange(b));
        return Math.abs(ra - rb) <= range;
    }

    private int currentRange(Entry e) {
        var cfg = PvPCore.get().config().elo;
        long waitedSeconds = (tick - e.joinTick) / 20;
        if (waitedSeconds < 10) return cfg.range0to10s;
        if (waitedSeconds < 20) return cfg.range10to20s;
        if (waitedSeconds < 30) return cfg.range20to30s;
        return cfg.range30plus;
    }

    private boolean tryMatch(Entry a, Entry b) {
        var pm = PvPCore.get().server().getPlayerManager();
        ServerPlayerEntity pa = pm.getPlayer(a.player);
        ServerPlayerEntity pb = pm.getPlayer(b.player);
        if (pa == null || pb == null) return false;
        var playerManager = PvPCore.get().playerManager();
        if (playerManager.state(pa) != PlayerState.QUEUEING || playerManager.state(pb) != PlayerState.QUEUEING) return false;
        var duel = PvPCore.get().duelManager().startDuel(a.kitId, a.ranked, List.of(pa), List.of(pb));
        if (duel == null) {
            // no arenas -> put both back and stop trying this round
            entries.add(a);
            entries.add(b);
            return false;
        }
        var mm = PvPCore.get().messages();
        String msg = mm.get("queue.matched", Map.of(
                "kit", PvPCore.get().duelManager().kitDisplayName(a.kitId),
                "arena", duel.arena.id));
        pa.sendMessage(Text.literal(msg), false);
        pb.sendMessage(Text.literal(msg), false);
        return true;
    }

    public void shutdown() {
        entries.clear();
    }
}
