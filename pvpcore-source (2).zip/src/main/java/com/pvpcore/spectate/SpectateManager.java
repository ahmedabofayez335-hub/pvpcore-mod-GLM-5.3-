package com.pvpcore.spectate;

import com.pvpcore.PvPCore;
import com.pvpcore.arena.Arena;
import com.pvpcore.duel.Duel;
import com.pvpcore.duel.DuelState;
import com.pvpcore.player.PlayerState;
import com.pvpcore.util.ChatButtons;
import com.pvpcore.util.TeleportUtil;
import com.pvpcore.util.TitleUtil;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Spectate ongoing duels. No gamemode changes (requirement 4): spectators
 * get invisibility + full protection, are hidden from fighters, and are
 * returned to their previous location automatically.
 */
public final class SpectateManager {
    public static class Spectating {
        public final UUID duelId;
        public String world;
        public double x, y, z;
        public float yaw, pitch;
        /** Normal spectators auto-return when their duel disappears. */
        public boolean autoReturn = true;
        /** Issue 5: loser-spectate returns to the LOBBY, not the arena spot. */
        public boolean returnToLobby = false;
        public Spectating(UUID duelId) { this.duelId = duelId; }
    }

    private final Map<UUID, Spectating> spectating = new ConcurrentHashMap<>();

    public boolean isSpectating(ServerPlayerEntity player) {
        return player != null && spectating.containsKey(player.getUuid());
    }

    public Duel spectatedDuel(ServerPlayerEntity player) {
        Spectating s = player == null ? null : spectating.get(player.getUuid());
        if (s == null) return null;
        for (Duel d : PvPCore.get().duelManager().allDuels()) {
            if (d.id.equals(s.duelId)) return d;
        }
        return null;
    }

    public List<ServerPlayerEntity> spectatorsOf(Duel duel) {
        List<ServerPlayerEntity> out = new ArrayList<>();
        var pm = PvPCore.get().server().getPlayerManager();
        for (Map.Entry<UUID, Spectating> e : spectating.entrySet()) {
            if (e.getValue().duelId.equals(duel.id)) {
                ServerPlayerEntity p = pm.getPlayer(e.getKey());
                if (p != null) out.add(p);
            }
        }
        return out;
    }

    /** Start spectating a duel. */
    public boolean join(ServerPlayerEntity player, Duel duel) {
        if (!PvPCore.get().config().spectate.enabled) return false;
        if (duel == null || (duel.state != DuelState.FIGHTING && duel.state != DuelState.COUNTDOWN)) return false;
        if (duel.isParticipant(player.getUuid())) return false;
        var pm = PvPCore.get().playerManager();
        if (pm.state(player) == PlayerState.DUELING) return false;

        // remember current position
        Spectating s = new Spectating(duel.id);
        s.world = player.getEntityWorld().getRegistryKey().getValue().toString();
        s.x = player.getX(); s.y = player.getY(); s.z = player.getZ();
        s.yaw = player.getYaw(); s.pitch = player.getPitch();
        spectating.put(player.getUuid(), s);

        PvPCore.get().queueManager().remove(player);
        pm.setState(player, PlayerState.SPECTATING);

        Arena arena = duel.arena;
        var world = TeleportUtil.world(PvPCore.get().server(), arena.world);
        if (world == null) world = player.getEntityWorld();
        double sx = arena.spectatorSet ? arena.spectatorX : (arena.spawn1X + arena.spawn2X) / 2.0;
        double sy = arena.spectatorSet ? arena.spectatorY : Math.max(arena.spawn1Y, arena.spawn2Y) + 6;
        double sz = arena.spectatorSet ? arena.spectatorZ : (arena.spawn1Z + arena.spawn2Z) / 2.0;
        float syaw = arena.spectatorSet ? arena.spectatorYaw : 0;
        float spitch = arena.spectatorSet ? arena.spectatorPitch : 25;
        TeleportUtil.teleport(player, world, sx, sy, sz, syaw, spitch);

        if (PvPCore.get().config().spectate.hideFromFighters) {
            // invisible + no collision; night vision so they can watch comfortably
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.INVISIBILITY,
                    StatusEffectInstance.INFINITE, 0, true, false));
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION,
                    StatusEffectInstance.INFINITE, 0, true, false));
        }

        if (duel.scoreboard != null) duel.scoreboard.addViewer(player);

        var mm = PvPCore.get().messages();
        player.sendMessage(Text.literal(mm.get("spectate.started", Map.of(
                "player1", duel.firstAName(),
                "player2", duel.firstBName()))), false);
        player.sendMessage(Text.literal(mm.get("spectate.return")), false);
        PvPCore.get().playerManager().refreshLobby(player);
        return true;
    }

    /** Return a spectator to their previous location. */
    public void returnPlayer(ServerPlayerEntity player) {
        Spectating s = spectating.remove(player.getUuid());
        if (s == null) return;
        player.clearStatusEffects();
        if (s.returnToLobby) {
            // Issue 5 + 3: the match loser goes back to the lobby point
            PvPCore.get().playerManager().teleportToLobby(player);
        } else {
            var world = TeleportUtil.world(PvPCore.get().server(), s.world);
            if (world == null) world = player.getEntityWorld();
            TeleportUtil.teleport(player, world, s.x, s.y, s.z, s.yaw, s.pitch);
        }
        Duel duel = PvPCore.get().duelManager().duelOf(s.duelId);
        if (duel != null && duel.scoreboard != null) duel.scoreboard.removeViewer(player);
        PvPCore.get().playerManager().setState(player, PlayerState.LOBBY);
        player.sendMessage(Text.literal(PvPCore.get().messages().get("spectate.ended")), false);
        PvPCore.get().playerManager().refreshLobby(player);
    }

    /**
     * Issue 5 (2.2.0): turn the round/match LOSER into a spectator. Unlike a
     * normal spectator they stay until they click the Return item, use /leave
     * or accept a rematch - and they return to the LOBBY, not the arena.
     */
    public void forceSpectate(ServerPlayerEntity player, Duel duel) {
        if (player == null || duel == null) return;
        Spectating s = new Spectating(duel.id);
        s.autoReturn = false;
        s.returnToLobby = true;
        spectating.put(player.getUuid(), s);

        PvPCore.get().queueManager().remove(player);
        PvPCore.get().playerManager().setState(player, PlayerState.SPECTATING);

        Arena arena = duel.arena;
        var world = TeleportUtil.world(PvPCore.get().server(), arena.world);
        if (world == null) world = player.getEntityWorld();
        double sx = arena.spectatorSet ? arena.spectatorX : (arena.spawn1X + arena.spawn2X) / 2.0;
        double sy = arena.spectatorSet ? arena.spectatorY : Math.max(arena.spawn1Y, arena.spawn2Y) + 6;
        double sz = arena.spectatorSet ? arena.spectatorZ : (arena.spawn1Z + arena.spawn2Z) / 2.0;
        float syaw = arena.spectatorSet ? arena.spectatorYaw : 0;
        float spitch = arena.spectatorSet ? arena.spectatorPitch : 25;
        TeleportUtil.teleport(player, world, sx, sy, sz, syaw, spitch);

        player.addStatusEffect(new StatusEffectInstance(StatusEffects.INVISIBILITY,
                StatusEffectInstance.INFINITE, 0, true, false));
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION,
                StatusEffectInstance.INFINITE, 0, true, false));

        var mm = PvPCore.get().messages();
        player.sendMessage(Text.literal(mm.get("spectate.loser-started")), false);
        player.sendMessage(ChatButtons.line(
                ChatButtons.button(mm.get("spectate.loser-return-button"), "/leave",
                        mm.get("spectate.loser-return-hover"), Formatting.GREEN)), false);
        PvPCore.get().playerManager().refreshLobby(player);
    }

    /** Called when a spectated duel ends: return its spectators. */
    public void duelEnded(Duel duel) {
        List<UUID> toReturn = new ArrayList<>();
        for (Map.Entry<UUID, Spectating> e : spectating.entrySet()) {
            if (e.getValue().duelId.equals(duel.id)) toReturn.add(e.getKey());
        }
        var pm = PvPCore.get().server().getPlayerManager();
        for (UUID u : toReturn) {
            ServerPlayerEntity p = pm.getPlayer(u);
            if (p != null) returnPlayer(p);
        }
    }

    public void tick() {
        // keep spectators fed + verify their duel still exists
        var pm = PvPCore.get().server().getPlayerManager();
        for (Map.Entry<UUID, Spectating> e : Map.copyOf(spectating).entrySet()) {
            ServerPlayerEntity p = pm.getPlayer(e.getKey());
            if (p == null) continue;
            if (p.getHungerManager().getFoodLevel() < 20) {
                p.getHungerManager().setFoodLevel(20);
            }
            boolean duelExists = PvPCore.get().duelManager().allDuels().stream()
                    .anyMatch(d -> d.id.equals(e.getValue().duelId) && d.state != DuelState.FINISHED);
            if (!duelExists && e.getValue().autoReturn) returnPlayer(p);
        }
    }

    public void onQuit(ServerPlayerEntity player) {
        spectating.remove(player.getUuid());
    }

    public boolean isolateSpectatorChat() {
        return true; // spectators chat with the duel audience while watching
    }

    public void shutdown() {
        spectating.clear();
    }
}
