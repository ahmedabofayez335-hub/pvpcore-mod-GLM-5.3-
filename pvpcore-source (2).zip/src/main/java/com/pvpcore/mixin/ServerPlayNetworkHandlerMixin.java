package com.pvpcore.mixin;

import com.pvpcore.PvPCore;
import net.minecraft.network.packet.c2s.play.ClickSlotC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.server.network.ServerPlayNetworkHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Server play network handler hooks:
 * - Requirement 1: lock lobby inventory (clicks, drops, offhand swap).
 * - Requirement 3: never lock anything before login-sync fires, and never
 *   interfere with other mods' GUIs (only the player's own inventory is locked).
 *
 * Chat routing was moved to the Fabric ServerMessageEvents.ALLOW_CHAT_MESSAGE
 * event (see PvPCoreMod) - cancelling the signed chat packet here breaks the
 * chat chain bookkeeping, so this mixin no longer touches chat at all.
 *
 * Cancelled clicks are answered with updateToClient() - a FULL slot resync.
 * sendContentUpdates() is diff-based and would send nothing (the server state
 * never changed), leaving the client's optimistic click applied as a ghost
 * item - that was the item duplication bug (issue 2).
 */
@Mixin(ServerPlayNetworkHandler.class)
public abstract class ServerPlayNetworkHandlerMixin {

    @Shadow public ServerPlayerEntity player;

    /** Requirement 1: block inventory clicks on the player's own inventory while locked. */
    @Inject(method = "onClickSlot", at = @At("HEAD"), cancellable = true)
    private void pvpcore$onClickSlot(ClickSlotC2SPacket packet, CallbackInfo ci) {
        ServerPlayerEntity p = this.player;
        if (p == null) return;
        if (PvPCore.get().server() == null) return; // not ready yet
        // If any screen handler (ours or another mod's) is open, let it handle the click.
        if (p.currentScreenHandler != p.playerScreenHandler) return;
        if (PvPCore.get().isInventoryLocked(p)) {
            ci.cancel();
            // Full resync: wipes the client's optimistic click (issue 2: ghost duplicates)
            p.currentScreenHandler.updateToClient();
        }
    }

    /** Requirement 1: block item dropping / offhand swapping while locked. */
    @Inject(method = "onPlayerAction", at = @At("HEAD"), cancellable = true)
    private void pvpcore$onPlayerAction(PlayerActionC2SPacket packet, CallbackInfo ci) {
        ServerPlayerEntity p = this.player;
        if (p == null) return;
        if (p.currentScreenHandler != p.playerScreenHandler) return;
        PlayerActionC2SPacket.Action action = packet.getAction();
        if (action == PlayerActionC2SPacket.Action.DROP_ITEM
                || action == PlayerActionC2SPacket.Action.DROP_ALL_ITEMS
                || action == PlayerActionC2SPacket.Action.SWAP_ITEM_WITH_OFFHAND) {
            if (PvPCore.get().isInventoryLocked(p)) {
                ci.cancel();
                p.currentScreenHandler.updateToClient();
            }
        }
    }
}
