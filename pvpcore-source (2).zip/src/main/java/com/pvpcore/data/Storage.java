package com.pvpcore.data;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.pvpcore.PvPCoreMod;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Local file storage for player data: data/pvp/players/&lt;uuid&gt;.json.
 * Atomic writes + dirty tracking + periodic save.
 */
public final class Storage {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();

    private final Path playersDir;
    private final Map<UUID, PlayerData> cache = new HashMap<>();
    private final Map<UUID, Boolean> dirty = new HashMap<>();

    public Storage(Path dataDir) {
        this.playersDir = dataDir.resolve("players");
        try {
            Files.createDirectories(playersDir);
        } catch (IOException e) {
            PvPCoreMod.LOGGER.error("Could not create players directory", e);
        }
    }

    /** Load (or create) data for a player. */
    public synchronized PlayerData get(UUID uuid, String name) {
        PlayerData data = cache.get(uuid);
        if (data == null) {
            Path file = playersDir.resolve(uuid + ".json");
            if (Files.exists(file)) {
                try {
                    data = GSON.fromJson(Files.readString(file, StandardCharsets.UTF_8), PlayerData.class);
                } catch (Exception e) {
                    PvPCoreMod.LOGGER.error("Failed to read player data {}", file, e);
                }
            }
            if (data == null) data = new PlayerData();
            data.uuid = uuid.toString();
            data.uuidObj = uuid;
            if (name != null) data.name = name;
            cache.put(uuid, data);
        }
        if (name != null && !name.equals(data.name)) {
            data.name = name;
            markDirty(uuid);
        }
        return data;
    }

    public synchronized PlayerData getIfLoaded(UUID uuid) {
        return cache.get(uuid);
    }

    public synchronized void markDirty(UUID uuid) {
        dirty.put(uuid, true);
    }

    /** Save a single player now. */
    public synchronized void saveNow(UUID uuid) {
        PlayerData data = cache.get(uuid);
        if (data == null) return;
        Path file = playersDir.resolve(uuid + ".json");
        try {
            Files.createDirectories(playersDir);
            Path tmp = file.resolveSibling(uuid + ".json.tmp");
            Files.writeString(tmp, GSON.toJson(data), StandardCharsets.UTF_8);
            Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            dirty.remove(uuid);
        } catch (IOException e) {
            PvPCoreMod.LOGGER.error("Failed to save player data {}", file, e);
        }
    }

    /** Save all dirty player data. */
    public synchronized void saveAll() {
        for (UUID uuid : cache.keySet()) {
            if (Boolean.TRUE.equals(dirty.get(uuid))) saveNow(uuid);
        }
    }

    /** All currently loaded player data (for leaderboards). */
    public synchronized Map<UUID, PlayerData> all() {
        return cache;
    }

    /** Load every stored player file (for leaderboards across offline players). */
    public synchronized Map<UUID, PlayerData> loadAll() {
        try (var stream = Files.list(playersDir)) {
            stream.filter(p -> p.getFileName().toString().endsWith(".json")).forEach(p -> {
                try {
                    String name = p.getFileName().toString();
                    name = name.substring(0, name.length() - 5);
                    UUID uuid = UUID.fromString(name);
                    if (!cache.containsKey(uuid)) {
                        PlayerData data = GSON.fromJson(Files.readString(p, StandardCharsets.UTF_8), PlayerData.class);
                        if (data != null) {
                            data.uuid = uuid.toString();
                            data.uuidObj = uuid;
                            cache.put(uuid, data);
                        }
                    }
                } catch (Exception ignored) {}
            });
        } catch (Exception e) {
            PvPCoreMod.LOGGER.error("Failed to list player files", e);
        }
        return cache;
    }
}
