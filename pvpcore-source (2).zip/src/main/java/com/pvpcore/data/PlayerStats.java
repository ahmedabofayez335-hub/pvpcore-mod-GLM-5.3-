package com.pvpcore.data;

/**
 * Per-kit (or global) statistics for a player.
 */
public class PlayerStats {
    public int wins = 0;
    public int losses = 0;
    public int hits = 0;
    public int duels = 0;
    public int streak = 0;
    public int bestStreak = 0;

    public void addWin() {
        wins++;
        duels++;
        streak++;
        if (streak > bestStreak) bestStreak = streak;
    }

    public void addLoss() {
        losses++;
        duels++;
        streak = 0;
    }

    public double winRate() {
        int total = wins + losses;
        return total == 0 ? 0 : (wins * 100.0) / total;
    }

    public PlayerStats copy() {
        PlayerStats s = new PlayerStats();
        s.wins = wins; s.losses = losses; s.hits = hits; s.duels = duels;
        s.streak = streak; s.bestStreak = bestStreak;
        return s;
    }
}
