package com.pvpcore.data;

import com.pvpcore.util.ItemCodecUtil;
import net.minecraft.item.ItemStack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Per-player data (persisted to data/pvp/players/&lt;uuid&gt;.json).
 */
public class PlayerData {
    public String uuid = "";
    public String name = "";

    /** Per-kit + "global" statistics. */
    public Map<String, PlayerStats> stats = new HashMap<>();
    /** Per-kit ELO ratings. */
    public Map<String, Integer> ratings = new HashMap<>();
    /** Per-kit personal loadouts (SNBT item strings): armor(4), hotbar(9), inv(27) = 40 entries. */
    public Map<String, List<String>> loadouts = new HashMap<>();
    /** Player toggles. */
    public boolean partyChat = false;

    /** Transient runtime fields (not persisted by GSON exclusions happen in Storage). */
    public transient UUID uuidObj;

    public PlayerStats statsFor(String kitId) {
        return stats.computeIfAbsent(kitId, k -> new PlayerStats());
    }

    public Integer ratingFor(String kitId, int defaultRating) {
        return ratings.getOrDefault(kitId, defaultRating);
    }

    public void setRating(String kitId, int rating) {
        ratings.put(kitId, rating);
    }

    public List<ItemStack> loadoutFor(String kitId) {
        List<String> snbt = loadouts.get(kitId);
        List<ItemStack> out = new ArrayList<>();
        if (snbt == null) return null;
        for (String s : snbt) out.add(ItemCodecUtil.fromSnbt(s));
        return out;
    }

    public void setLoadout(String kitId, List<ItemStack> items) {
        List<String> snbt = new ArrayList<>();
        for (ItemStack st : items) snbt.add(ItemCodecUtil.toSnbt(st));
        loadouts.put(kitId, snbt);
    }

    /** Global stats (sum view across kits, computed fresh each call). */
    public PlayerStats globalStats() {
        PlayerStats g = new PlayerStats();
        for (Map.Entry<String, PlayerStats> e : stats.entrySet()) {
            if (e.getKey().equals("global")) continue;
            g.wins += e.getValue().wins;
            g.losses += e.getValue().losses;
            g.hits += e.getValue().hits;
            g.duels += e.getValue().duels;
            g.bestStreak = Math.max(g.bestStreak, e.getValue().bestStreak);
        }
        return g;
    }
}
