package com.pvpcore.duel;

/** Duel lifecycle state machine. */
public enum DuelState {
    /** Arena reserved, teleporting players. */
    TELEPORTING,
    /** Players frozen at spawns, countdown running. */
    COUNTDOWN,
    /** Fight in progress. */
    FIGHTING,
    /**
     * Issue 5/6: a round just ended - the round loser is a spectator and the
     * next round starts after a short intermission (best-of duels only).
     */
    ROUND_END,
    /** Duel decided, showing results before teleport-back. */
    ENDING,
    /** Fully finished. */
    FINISHED
}
