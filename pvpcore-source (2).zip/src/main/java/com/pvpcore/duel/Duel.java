package com.pvpcore.duel;

import com.pvpcore.arena.Arena;
import com.pvpcore.scoreboard.DuelScoreboard;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Stream;

/**
 * A duel instance (1v1 or party vs party teams).
 */
public class Duel {
    public final UUID id;
    public volatile DuelState state = DuelState.TELEPORTING;
    public final String kitId;
    public final boolean ranked;
    public Arena arena;

    /** Team A members (UUIDs). */
    public final List<UUID> teamA = new ArrayList<>();
    /** Team B members (UUIDs). */
    public final List<UUID> teamB = new ArrayList<>();
    /** Hits dealt per player. */
    public final Map<UUID, Integer> hits = new HashMap<>();
    /** Disconnect tracking. */
    public final Map<UUID, Long> disconnectedAt = new HashMap<>();
    /** Reconnect grace deadline (tick) per player. */
    public final Map<UUID, Long> graceUntil = new HashMap<>();

    public long stateSinceTick;
    public long fightStartTick;
    public int countdownRemainingSeconds;
    public DuelScoreboard scoreboard;
    public String result = ""; // "A", "B" or "DRAW"
    public boolean rematchOffered = false;

    /** Issue 6: best-of-N rounds (1 = single round duel). */
    public int bestOf = 1;
    /** Round wins per team. */
    public int winsA = 0, winsB = 0;
    /** Current round number (1-based). */
    public int round = 1;
    /** Winner of the last finished round: "A", "B" or "". */
    public String lastRoundWinner = "";

    public Duel(UUID id, String kitId, boolean ranked, List<ServerPlayerEntity> a, List<ServerPlayerEntity> b) {
        this.id = id;
        this.kitId = kitId;
        this.ranked = ranked;
        for (ServerPlayerEntity p : a) teamA.add(p.getUuid());
        for (ServerPlayerEntity p : b) teamB.add(p.getUuid());
        for (UUID u : teamA) hits.put(u, 0);
        for (UUID u : teamB) hits.put(u, 0);
    }

    public boolean isParticipant(UUID uuid) {
        return teamA.contains(uuid) || teamB.contains(uuid);
    }

    public boolean isTeamA(UUID uuid) {
        return teamA.contains(uuid);
    }

    /** The team this player belongs to. */
    public List<UUID> teamOf(UUID uuid) {
        return teamA.contains(uuid) ? teamA : teamB;
    }

    /** The opposing team of this player. */
    public List<UUID> opponentsOf(UUID uuid) {
        return teamA.contains(uuid) ? teamB : teamA;
    }

    public Stream<ServerPlayerEntity> onlineParticipants(com.pvpcore.PvPCore core) {
        return Stream.concat(teamA.stream(), teamB.stream())
                .map(u -> core.server().getPlayerManager().getPlayer(u))
                .filter(p -> p != null && !disconnectedAt.containsKey(p.getUuid()));
    }

    public List<ServerPlayerEntity> participants() {
        List<ServerPlayerEntity> out = new ArrayList<>();
        for (UUID u : teamA) {
            var p = com.pvpcore.PvPCore.get().server().getPlayerManager().getPlayer(u);
            if (p != null) out.add(p);
        }
        for (UUID u : teamB) {
            var p = com.pvpcore.PvPCore.get().server().getPlayerManager().getPlayer(u);
            if (p != null) out.add(p);
        }
        return out;
    }

    public List<ServerPlayerEntity> spectators() {
        return com.pvpcore.PvPCore.get().spectateManager().spectatorsOf(this);
    }

    /** Alive + online members of a team count. */
    public long aliveIn(List<UUID> team) {
        var pm = com.pvpcore.PvPCore.get().server().getPlayerManager();
        return team.stream()
                .filter(u -> !disconnectedAt.containsKey(u))
                .map(pm::getPlayer)
                .filter(p -> p != null && p.isAlive() && !p.isSpectator())
                .count();
    }

    public boolean isDisconnected(UUID uuid) {
        return disconnectedAt.containsKey(uuid);
    }

    public int hitsOf(UUID uuid) {
        return hits.getOrDefault(uuid, 0);
    }

    public String firstAName() {
        var pm = com.pvpcore.PvPCore.get().server().getPlayerManager();
        var p = pm.getPlayer(teamA.get(0));
        return p != null ? p.getGameProfile().name() : "?";
    }

    public String firstBName() {
        var pm = com.pvpcore.PvPCore.get().server().getPlayerManager();
        var p = pm.getPlayer(teamB.get(0));
        return p != null ? p.getGameProfile().name() : "?";
    }
}
