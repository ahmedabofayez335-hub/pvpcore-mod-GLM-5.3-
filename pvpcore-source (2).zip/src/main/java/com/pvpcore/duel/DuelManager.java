package com.pvpcore.duel;

import com.pvpcore.PvPCore;
import com.pvpcore.arena.Arena;
import com.pvpcore.data.PlayerData;
import com.pvpcore.kit.Kit;
import com.pvpcore.player.InventorySnapshot;
import com.pvpcore.player.PlayerState;
import com.pvpcore.scoreboard.DuelScoreboard;
import com.pvpcore.util.ChatButtons;
import com.pvpcore.util.TextUtil;
import com.pvpcore.util.TitleUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Duel lifecycle manager: challenges, countdowns, fights, endings,
 * rematch offers, disconnect grace periods, damage rules and ELO.
 */
public final class DuelManager {
    private final Map<UUID, Duel> duels = new ConcurrentHashMap<>();
    private final Map<UUID, Duel> byParticipant = new ConcurrentHashMap<>();
    private final Map<UUID, DuelRequest> requests = new ConcurrentHashMap<>(); // target uuid -> request
    private final Map<UUID, RematchOffer> rematchOffers = new ConcurrentHashMap<>();
    private long tick = 0;

    public static class RematchOffer {
        public final UUID playerA;
        public final UUID playerB;
        public final String kitId;
        public final boolean ranked;
        /** Issue 6: the rematch keeps the round format of the original duel. */
        public final int bestOf;
        public final long expiryTick;
        public final List<UUID> accepted = new ArrayList<>();

        public RematchOffer(UUID a, UUID b, String kitId, boolean ranked, int bestOf, long expiryTick) {
            this.playerA = a; this.playerB = b;
            this.kitId = kitId; this.ranked = ranked; this.bestOf = Math.max(1, bestOf);
            this.expiryTick = expiryTick;
        }
    }

    // ------------------------------------------------------------------
    // Lookups
    // ------------------------------------------------------------------

    public Duel duelOf(ServerPlayerEntity player) {
        return player == null ? null : byParticipant.get(player.getUuid());
    }

    public Duel duelOf(UUID uuid) {
        return byParticipant.get(uuid);
    }

    public List<Duel> activeDuels() {
        List<Duel> out = new ArrayList<>();
        for (Duel d : duels.values()) {
            if (d.state == DuelState.FIGHTING || d.state == DuelState.COUNTDOWN) out.add(d);
        }
        return out;
    }

    public List<Duel> allDuels() {
        return new ArrayList<>(duels.values());
    }

    public DuelRequest requestFor(UUID target) {
        return requests.get(target);
    }

    public RematchOffer rematchOfferFor(UUID player) {
        for (RematchOffer offer : rematchOffers.values()) {
            if (offer.playerA.equals(player) || offer.playerB.equals(player)) return offer;
        }
        return null;
    }

    public String kitDisplayName(String kitId) {
        Kit kit = PvPCore.get().kitManager().get(kitId);
        return kit != null ? TextUtil.stripColor(TextUtil.colorize(kit.displayName)) : kitId;
    }

    // ------------------------------------------------------------------
    // Challenges
    // ------------------------------------------------------------------

    /** Send a 1v1 challenge with the configured default round count. */
    public boolean sendChallenge(ServerPlayerEntity sender, ServerPlayerEntity target, String kitId) {
        return sendChallenge(sender, target, kitId, PvPCore.get().config().duel.defaultBestOf);
    }

    /**
     * Send a 1v1 challenge. Issue 9: accept/deny are clickable chat buttons.
     * Issue 6: the challenger picks the round count (best-of-N).
     */
    public boolean sendChallenge(ServerPlayerEntity sender, ServerPlayerEntity target, String kitId, int bestOf) {
        if (sender == null || target == null || sender.getUuid().equals(target.getUuid())) return false;
        if (duelOf(sender) != null || duelOf(target) != null) return false;
        var pm = PvPCore.get().playerManager();
        if (!eligibleForDuel(sender) || !eligibleForDuel(target)) return false;
        requests.remove(target.getUuid());

        bestOf = clampBestOf(bestOf);
        long expiry = tick + 30 * 20;
        DuelRequest req = new DuelRequest(DuelRequest.Type.PLAYER_DUEL, sender.getUuid(), target.getUuid(),
                kitId, false, bestOf, null, null, expiry);
        requests.put(target.getUuid(), req);

        var mm = PvPCore.get().messages();
        sender.sendMessage(net.minecraft.text.Text.literal(mm.get("duel.challenge-sent", Map.of(
                "player", target.getGameProfile().name(),
                "kit", kitDisplayName(kitId)))), false);
        TitleUtil.title(target,
                mm.get("duel.challenge-received-title"),
                mm.get("duel.challenge-received-subtitle", Map.of(
                        "player", sender.getGameProfile().name())));
        if (PvPCore.get().config().duel.challengeViaChat) {
            sendChallengeChat(target, sender.getGameProfile().name(), kitDisplayName(kitId), 30, bestOf);
        } else {
            new com.pvpcore.gui.guis.ChallengeGui(target, req).open(target);
        }
        return true;
    }

    /** Send a party-vs-party challenge with the default round count. */
    public boolean sendPartyChallenge(ServerPlayerEntity senderLeader, ServerPlayerEntity targetLeader, String kitId) {
        return sendPartyChallenge(senderLeader, targetLeader, kitId, PvPCore.get().config().duel.defaultBestOf);
    }

    /** Send a party-vs-party challenge to another party leader (issue 6: best-of-N rounds). */
    public boolean sendPartyChallenge(ServerPlayerEntity senderLeader, ServerPlayerEntity targetLeader, String kitId, int bestOf) {
        var parties = PvPCore.get().partyManager();
        var senderParty = parties.partyOf(senderLeader);
        var targetParty = parties.partyOf(targetLeader);
        if (senderParty == null || targetParty == null) return false;
        if (senderParty == targetParty) return false;
        if (duelOf(targetLeader) != null || !eligibleForDuel(targetLeader)) return false;
        requests.remove(targetLeader.getUuid());

        bestOf = clampBestOf(bestOf);
        long expiry = tick + 45 * 20;
        DuelRequest req = new DuelRequest(DuelRequest.Type.PARTY_DUEL, senderLeader.getUuid(), targetLeader.getUuid(),
                kitId, false, bestOf,
                new ArrayList<>(senderParty.onlineMemberUuids()),
                new ArrayList<>(targetParty.onlineMemberUuids()),
                expiry);
        requests.put(targetLeader.getUuid(), req);

        var mm = PvPCore.get().messages();
        senderLeader.sendMessage(net.minecraft.text.Text.literal(mm.get("party.challenge-sent", Map.of(
                "leader", targetLeader.getGameProfile().name()))), false);
        TitleUtil.title(targetLeader,
                mm.get("party.challenge-received-title"),
                mm.get("party.challenge-received-subtitle", Map.of(
                        "leader", senderLeader.getGameProfile().name(),
                        "kit", kitDisplayName(kitId))));
        if (PvPCore.get().config().duel.challengeViaChat) {
            sendChallengeChat(targetLeader, senderLeader.getGameProfile().name() + "'s party", kitDisplayName(kitId), 45, bestOf);
        } else {
            new com.pvpcore.gui.guis.ChallengeGui(targetLeader, req).open(targetLeader);
        }
        return true;
    }

    /** Issue 6: keep best-of within 1..maxBestOf (and odd, so no ties are possible). */
    private int clampBestOf(int bestOf) {
        int max = Math.max(1, PvPCore.get().config().duel.maxBestOf);
        int v = Math.max(1, Math.min(max, bestOf));
        if (v % 2 == 0) v = Math.max(1, v - 1);
        return v;
    }

    /**
     * Issue 9: duel requests are accepted/denied with clickable chat buttons
     * instead of a chest GUI. The buttons run /duelaccept and /dueldeny.
     */
    private void sendChallengeChat(ServerPlayerEntity target, String fromName, String kitName, int seconds, int bestOf) {
        var mm = PvPCore.get().messages();
        target.sendMessage(ChatButtons.line(
                net.minecraft.text.Text.literal(mm.get("duel.challenge-chat-header", Map.of(
                        "player", fromName, "kit", kitName)))), false);
        if (bestOf > 1) {
            target.sendMessage(ChatButtons.line(
                    net.minecraft.text.Text.literal(mm.get("duel.best-of-line", Map.of(
                            "rounds", String.valueOf(bestOf))))), false);
        }
        target.sendMessage(ChatButtons.line(
                ChatButtons.button(mm.get("duel.challenge-accept-button"), "/duelaccept",
                        mm.get("duel.challenge-accept-hover"), Formatting.GREEN),
                net.minecraft.text.Text.literal(" "),
                ChatButtons.button(mm.get("duel.challenge-deny-button"), "/dueldeny",
                        mm.get("duel.challenge-deny-hover"), Formatting.RED)), false);
        target.sendMessage(ChatButtons.line(
                net.minecraft.text.Text.literal(mm.get("duel.challenge-chat-expire", Map.of(
                        "seconds", String.valueOf(seconds))))), false);
    }

    public void acceptRequest(ServerPlayerEntity target) {
        DuelRequest req = requests.remove(target.getUuid());
        if (req == null) return;
        var pm = PvPCore.get().server().getPlayerManager();
        ServerPlayerEntity sender = pm.getPlayer(req.sender);
        if (sender == null) return;

        if (req.type == DuelRequest.Type.PARTY_DUEL) {
            List<ServerPlayerEntity> teamA = new ArrayList<>();
            List<ServerPlayerEntity> teamB = new ArrayList<>();
            for (UUID u : req.senderParty) {
                ServerPlayerEntity p = pm.getPlayer(u);
                if (p != null && eligibleForDuel(p)) teamA.add(p);
            }
            for (UUID u : req.targetParty) {
                ServerPlayerEntity p = pm.getPlayer(u);
                if (p != null && eligibleForDuel(p)) teamB.add(p);
            }
            if (teamA.isEmpty() || teamB.isEmpty()) return;
            startDuel(req.kitId, req.ranked, teamA, teamB, req.bestOf);
        } else {
            if (!eligibleForDuel(sender) || !eligibleForDuel(target)) return;
            startDuel(req.kitId, req.ranked, List.of(sender), List.of(target), req.bestOf);
        }
    }

    public void denyRequest(ServerPlayerEntity target) {
        DuelRequest req = requests.remove(target.getUuid());
        if (req == null) return;
        var mm = PvPCore.get().messages();
        ServerPlayerEntity sender = PvPCore.get().server().getPlayerManager().getPlayer(req.sender);
        if (sender != null) {
            sender.sendMessage(net.minecraft.text.Text.literal(mm.get("duel.challenge-denied", Map.of(
                    "player", target.getGameProfile().name()))), false);
        }
    }

    /**
     * Issue 3: a participant voluntarily leaves their duel - the opposing
     * team wins. Works during countdown, fighting and the round intermission.
     */
    public boolean leaveDuel(ServerPlayerEntity player) {
        Duel duel = duelOf(player);
        if (duel == null) return false;
        if (duel.state != DuelState.FIGHTING && duel.state != DuelState.COUNTDOWN
                && duel.state != DuelState.ROUND_END) return false;
        String winner = duel.isTeamA(player.getUuid()) ? "B" : "A";
        player.sendMessage(net.minecraft.text.Text.literal(
                PvPCore.get().messages().get("leave.duel-left")), false);
        endDuel(duel, winner, "forfeit");
        return true;
    }

    private boolean eligibleForDuel(ServerPlayerEntity player) {
        var pm = PvPCore.get().playerManager();
        PlayerState st = pm.state(player);
        if (st != PlayerState.LOBBY && st != PlayerState.QUEUEING) return false;
        if (duelOf(player) != null) return false;
        if (PvPCore.get().spectateManager().isSpectating(player)) return false;
        return true;
    }

    // ------------------------------------------------------------------
    // Start
    // ------------------------------------------------------------------

    /** Start a duel with the configured default round count (queue matches). */
    public Duel startDuel(String kitId, boolean ranked, List<ServerPlayerEntity> teamA, List<ServerPlayerEntity> teamB) {
        return startDuel(kitId, ranked, teamA, teamB, PvPCore.get().config().duel.defaultBestOf);
    }

    /**
     * Start a duel between two teams. Issue 6: bestOf = how many rounds the
     * whole match has (1 = single round, 3/5/7 = best-of-N).
     */
    public Duel startDuel(String kitId, boolean ranked, List<ServerPlayerEntity> teamA, List<ServerPlayerEntity> teamB, int bestOf) {
        Kit kit = PvPCore.get().kitManager().get(kitId);
        if (kit == null) return null;
        Arena arena = PvPCore.get().arenaManager().reserve();
        if (arena == null) {
            for (ServerPlayerEntity p : teamA) p.sendMessage(net.minecraft.text.Text.literal(
                    com.pvpcore.PvPCore.get().messages().get("arena.none")), false);
            for (ServerPlayerEntity p : teamB) p.sendMessage(net.minecraft.text.Text.literal(
                    com.pvpcore.PvPCore.get().messages().get("arena.none")), false);
            return null;
        }

        Duel duel = new Duel(UUID.randomUUID(), kitId, ranked, teamA, teamB);
        duel.arena = arena;
        duel.bestOf = clampBestOf(bestOf);
        duel.state = DuelState.TELEPORTING;
        duel.stateSinceTick = tick;
        duels.put(duel.id, duel);
        for (ServerPlayerEntity p : duel.participants()) {
            byParticipant.put(p.getUuid(), duel);
        }

        var playerManager = PvPCore.get().playerManager();
        var pm = PvPCore.get().server().getPlayerManager();

        // Snapshot BEFORE teleporting so the position restore returns to the lobby
        for (ServerPlayerEntity p : duel.participants()) {
            // leave queue if queued
            PvPCore.get().queueManager().remove(p);
            playerManager.setState(p, PlayerState.DUELING);
            playerManager.snapshotAndClear(p);
        }

        // Teleport + kit
        List<ServerPlayerEntity> teamAPlayers = new ArrayList<>();
        List<ServerPlayerEntity> teamBPlayers = new ArrayList<>();
        for (UUID u : duel.teamA) { var p = pm.getPlayer(u); if (p != null) teamAPlayers.add(p); }
        for (UUID u : duel.teamB) { var p = pm.getPlayer(u); if (p != null) teamBPlayers.add(p); }

        teleportTeam(duel, teamAPlayers, true);
        teleportTeam(duel, teamBPlayers, false);

        for (ServerPlayerEntity p : duel.participants()) {
            prepareFighter(p, kit);
        }

        // Scoreboard (requirement 13)
        if (PvPCore.get().config().scoreboard.enabled) {
            duel.scoreboard = new DuelScoreboard(duel.id, PvPCore.get().config().scoreboard.title);
            for (ServerPlayerEntity p : duel.participants()) {
                duel.scoreboard.addViewer(p);
            }
            updateScoreboard(duel);
        }

        duel.state = DuelState.COUNTDOWN;
        duel.stateSinceTick = tick;
        duel.countdownRemainingSeconds = PvPCore.get().config().duel.countdownSeconds;

        var mm = PvPCore.get().messages();
        String started = mm.get("duel.started", Map.of(
                "kit", kitDisplayName(kitId),
                "player1", duel.firstAName(),
                "player2", duel.firstBName(),
                "arena", arena.id));
        for (ServerPlayerEntity p : PvPCore.get().server().getPlayerManager().getPlayerList()) {
            p.sendMessage(net.minecraft.text.Text.literal(started), false);
        }
        // Issue 6: tell the fighters the round format of this match
        if (duel.bestOf > 1) {
            String boLine = mm.get("duel.best-of-line", Map.of("rounds", String.valueOf(duel.bestOf)));
            for (ServerPlayerEntity p : duel.participants()) {
                p.sendMessage(net.minecraft.text.Text.literal(boLine), false);
            }
        }
        return duel;
    }

    private void teleportTeam(Duel duel, List<ServerPlayerEntity> players, boolean teamA) {
        Arena arena = duel.arena;
        var world = com.pvpcore.util.TeleportUtil.world(PvPCore.get().server(), arena.world);
        if (world == null) return;
        for (int i = 0; i < players.size(); i++) {
            ServerPlayerEntity p = players.get(i);
            double x = teamA ? arena.spawn1X : arena.spawn2X;
            double y = teamA ? arena.spawn1Y : arena.spawn2Y;
            double z = teamA ? arena.spawn1Z : arena.spawn2Z;
            float yaw = teamA ? arena.spawn1Yaw : arena.spawn2Yaw;
            float pitch = teamA ? arena.spawn1Pitch : arena.spawn2Pitch;
            // spread team members around the anchor spawn
            if (players.size() > 1) {
                double off = (i - (players.size() - 1) / 2.0) * 1.5;
                x += off;
            }
            com.pvpcore.util.TeleportUtil.teleport(p, world, x, y, z, yaw, pitch);
        }
    }

    private void prepareFighter(ServerPlayerEntity player, Kit kit) {
        var cfg = PvPCore.get().config().duel;
        player.clearStatusEffects();
        if (cfg.healOnStart) {
            player.setHealth(player.getMaxHealth());
            player.getHungerManager().setFoodLevel(20);
            player.getHungerManager().setSaturationLevel(5f);
            player.setFireTicks(0);
        }
        // personal loadout or kit template (requirement: per-player layouts)
        List<ItemStack> layout = null;
        PlayerData data = PvPCore.get().storage().get(player.getUuid(), player.getGameProfile().name());
        if (data != null) layout = data.loadoutFor(kit.id);
        if (layout == null || layout.size() < Kit.TOTAL) layout = kit.layoutStacks();

        var inv = player.getInventory();
        for (int i = 0; i < 36; i++) inv.setStack(i, ItemStack.EMPTY);
        for (int i = 36; i < 41; i++) inv.setStack(i, ItemStack.EMPTY);
        for (int i = 0; i < 4; i++) {
            ItemStack st = layout.get(i);
            if (st != null && !st.isEmpty()) inv.setStack(36 + i, st.copy());
        }
        for (int i = 0; i < 9; i++) {
            ItemStack st = layout.get(4 + i);
            if (st != null && !st.isEmpty()) inv.setStack(i, st.copy());
        }
        for (int i = 0; i < 27; i++) {
            ItemStack st = layout.get(13 + i);
            if (st != null && !st.isEmpty()) inv.setStack(9 + i, st.copy());
        }
        inv.setSelectedSlot(0);
        inv.markDirty();
        player.currentScreenHandler.sendContentUpdates();
    }

    // ------------------------------------------------------------------
    // Tick
    // ------------------------------------------------------------------

    public void tick() {
        tick++;

        // Expire challenges
        requests.entrySet().removeIf(e -> {
            if (tick >= e.getValue().expiryTick) {
                ServerPlayerEntity target = PvPCore.get().server().getPlayerManager().getPlayer(e.getKey());
                ServerPlayerEntity sender = PvPCore.get().server().getPlayerManager().getPlayer(e.getValue().sender);
                var mm = PvPCore.get().messages();
                if (target != null) target.sendMessage(net.minecraft.text.Text.literal(
                        mm.get("duel.challenge-expired", Map.of("player",
                                sender != null ? sender.getGameProfile().name() : "?"))), false);
                if (sender != null) sender.sendMessage(net.minecraft.text.Text.literal(
                        mm.get("duel.challenge-expired-sender", Map.of("player",
                                target != null ? target.getGameProfile().name() : "?"))), false);
                return true;
            }
            return false;
        });

        // Expire rematch offers
        rematchOffers.entrySet().removeIf(e -> {
            if (tick >= e.getValue().expiryTick) {
                var pm = PvPCore.get().server().getPlayerManager();
                for (UUID u : List.of(e.getValue().playerA, e.getValue().playerB)) {
                    ServerPlayerEntity p = pm.getPlayer(u);
                    if (p != null && PvPCore.get().guiManager().openGui(p) instanceof com.pvpcore.gui.guis.RematchGui) {
                        PvPCore.get().guiManager().close(p);
                    }
                }
                return true;
            }
            return false;
        });

        for (Duel duel : duels.values()) {
            switch (duel.state) {
                case COUNTDOWN -> tickCountdown(duel);
                case FIGHTING -> tickFighting(duel);
                case ROUND_END -> tickRoundEnd(duel);
                case ENDING -> tickEnding(duel);
                default -> {}
            }
        }

        // Cleanup finished duels
        duels.entrySet().removeIf(e -> {
            Duel d = e.getValue();
            if (d.state == DuelState.FINISHED) {
                for (UUID u : d.teamA) byParticipant.remove(u, d);
                for (UUID u : d.teamB) byParticipant.remove(u, d);
                return true;
            }
            return false;
        });
    }

    private void tickCountdown(Duel duel) {
        var pm = PvPCore.get().server().getPlayerManager();
        long elapsed = tick - duel.stateSinceTick;
        long secondsLeft = duel.countdownRemainingSeconds - (elapsed / 20);

        // Freeze players at their spawns
        Arena arena = duel.arena;
        var world = com.pvpcore.util.TeleportUtil.world(PvPCore.get().server(), arena.world);
        for (int i = 0; i < duel.teamA.size(); i++) {
            ServerPlayerEntity p = pm.getPlayer(duel.teamA.get(i));
            if (p != null) {
                p.networkHandler.requestTeleport(arena.spawn1X, arena.spawn1Y, arena.spawn1Z, arena.spawn1Yaw, arena.spawn1Pitch);
            }
        }
        for (int i = 0; i < duel.teamB.size(); i++) {
            ServerPlayerEntity p = pm.getPlayer(duel.teamB.get(i));
            if (p != null) {
                p.networkHandler.requestTeleport(arena.spawn2X, arena.spawn2Y, arena.spawn2Z, arena.spawn2Yaw, arena.spawn2Pitch);
            }
        }

        long lastShown = secondsLeft + 1;
        if (elapsed % 20 == 0 || elapsed == 0) {
            var mm = PvPCore.get().messages();
            if (secondsLeft > 0) {
                for (ServerPlayerEntity p : duel.participants()) {
                    TitleUtil.title(p, mm.get("duel.countdown-title", Map.of("seconds", String.valueOf(secondsLeft))), "", 0, 20, 0);
                }
            } else if (secondsLeft == 0) {
                PvPCore.get().arenaManager().markActive(duel.arena);
                duel.state = DuelState.FIGHTING;
                duel.stateSinceTick = tick;
                duel.fightStartTick = tick;
                for (ServerPlayerEntity p : duel.participants()) {
                    TitleUtil.title(p, PvPCore.get().messages().get("duel.fight-title"), "", 0, 15, 5);
                    playClick(p, true);
                }
            }
        }
    }

    private void tickFighting(Duel duel) {
        var cfg = PvPCore.get().config().duel;

        // Hunger disabled
        if (cfg.disableHunger) {
            for (ServerPlayerEntity p : duel.participants()) {
                if (p.getHungerManager().getFoodLevel() < 20) {
                    p.getHungerManager().setFoodLevel(20);
                    p.getHungerManager().setSaturationLevel(5f);
                }
            }
        }

        // Void check
        for (ServerPlayerEntity p : duel.participants()) {
            if (p.getY() < p.getEntityWorld().getBottomY() - 8) {
                endRoundOrDuel(duel, duel.isTeamA(p.getUuid()) ? "B" : "A", "void");
                return;
            }
        }

        // Disconnect grace (requirement: reconnect window)
        for (Map.Entry<UUID, Long> e : duel.disconnectedAt.entrySet()) {
            UUID u = e.getKey();
            if (tick >= e.getValue() + (long) cfg.disconnectGraceSeconds * 20) {
                // player did not return -> their team loses
                String winner = duel.isTeamA(u) ? "B" : "A";
                ServerPlayerEntity opponent = firstAliveOnlineOpponent(duel, u);
                if (opponent != null) {
                    opponent.sendMessage(net.minecraft.text.Text.literal(
                            PvPCore.get().messages().get("duel.won-by-disconnect")), false);
                }
                endRoundOrDuel(duel, winner, "disconnect");
                return;
            }
        }

        // Team wiped check (deaths handled via damage capture; this catches edge cases)
        if (duel.aliveIn(duel.teamA) == 0) {
            endRoundOrDuel(duel, "B", "wipe");
        } else if (duel.aliveIn(duel.teamB) == 0) {
            endRoundOrDuel(duel, "A", "wipe");
        }

        // Timeout
        if (cfg.timeoutMinutes > 0) {
            long fightTicks = tick - duel.fightStartTick;
            if (fightTicks >= (long) cfg.timeoutMinutes * 60 * 20) {
                endDuel(duel, "DRAW", "timeout");
            }
        }

        // Scoreboard update (requirement 13)
        if (duel.scoreboard != null && tick % PvPCore.get().config().scoreboard.updateIntervalTicks == 0) {
            updateScoreboard(duel);
        }
    }

    private ServerPlayerEntity firstAliveOnlineOpponent(Duel duel, UUID of) {
        var pm = PvPCore.get().server().getPlayerManager();
        for (UUID u : duel.opponentsOf(of)) {
            ServerPlayerEntity p = pm.getPlayer(u);
            if (p != null && p.isAlive()) return p;
        }
        return null;
    }

    private void tickEnding(Duel duel) {
        long elapsed = tick - duel.stateSinceTick;
        if (elapsed >= (long) PvPCore.get().config().duel.endDurationSeconds * 20) {
            finishDuel(duel);
        }
    }

    // ------------------------------------------------------------------
    // Rounds (issue 5 + 6: best-of-N with an intermission between rounds;
    // the round loser spectates until the next round starts)
    // ------------------------------------------------------------------

    /**
     * Route a round win: single-round duels end immediately; in best-of
     * matches the win decides the duel only once a team holds the majority.
     */
    private void endRoundOrDuel(Duel duel, String winner, String reason) {
        if (duel.bestOf <= 1) {
            endDuel(duel, winner, reason);
            return;
        }
        int needed = duel.bestOf / 2 + 1;
        int wins = winner.equals("A") ? duel.winsA + 1 : duel.winsB + 1;
        if (wins >= needed) {
            endDuel(duel, winner, reason);
        } else {
            endRound(duel, winner);
        }
    }

    /** A round of a best-of duel ended - intermission, loser spectates (issue 5). */
    private void endRound(Duel duel, String winner) {
        if (duel.state != DuelState.FIGHTING) return;
        duel.lastRoundWinner = winner;
        if (winner.equals("A")) duel.winsA++; else duel.winsB++;
        duel.state = DuelState.ROUND_END;
        duel.stateSinceTick = tick;

        var mm = PvPCore.get().messages();
        var pm = PvPCore.get().server().getPlayerManager();
        int inter = Math.max(1, PvPCore.get().config().duel.roundIntermissionSeconds);

        UUID winnerFirst = winner.equals("A") ? duel.teamA.get(0) : duel.teamB.get(0);
        int winnerWins = winner.equals("A") ? duel.winsA : duel.winsB;
        int loserWins = winner.equals("A") ? duel.winsB : duel.winsA;
        String roundMsg = mm.get("duel.round-won", Map.of(
                "winner", nameOf(winnerFirst),
                "round", String.valueOf(duel.round),
                "score1", String.valueOf(winnerWins),
                "score2", String.valueOf(loserWins)));
        String nextMsg = mm.get("duel.round-next", Map.of(
                "round", String.valueOf(duel.round + 1),
                "rounds", String.valueOf(duel.bestOf),
                "seconds", String.valueOf(inter)));
        List<ServerPlayerEntity> audience = new ArrayList<>(duel.participants());
        audience.addAll(duel.spectators());
        for (ServerPlayerEntity p : audience) {
            if (p == null) continue;
            p.sendMessage(net.minecraft.text.Text.literal(roundMsg), false);
            p.sendMessage(net.minecraft.text.Text.literal(nextMsg), false);
        }

        // Issue 5: the round losers turn into spectators until the next round
        List<UUID> losers = winner.equals("A") ? duel.teamB : duel.teamA;
        for (UUID u : losers) {
            ServerPlayerEntity p = pm.getPlayer(u);
            if (p == null || duel.isDisconnected(u)) continue;
            makeRoundLoserSpectator(duel, p);
        }
        updateScoreboard(duel);
    }

    /** Issue 5: park the round loser at the spectator spot, invisible + protected. */
    private void makeRoundLoserSpectator(Duel duel, ServerPlayerEntity p) {
        var inv = p.getInventory();
        for (int i = 0; i < 36; i++) inv.setStack(i, ItemStack.EMPTY);
        for (int i = 36; i < 40; i++) inv.setStack(i, ItemStack.EMPTY);
        inv.setStack(40, ItemStack.EMPTY);
        inv.markDirty();
        p.currentScreenHandler.updateToClient();

        p.clearStatusEffects();
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.INVISIBILITY,
                StatusEffectInstance.INFINITE, 0, true, false));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION,
                StatusEffectInstance.INFINITE, 0, true, false));
        p.setHealth(p.getMaxHealth());

        Arena arena = duel.arena;
        var world = com.pvpcore.util.TeleportUtil.world(PvPCore.get().server(), arena.world);
        if (world != null) {
            double sx = arena.spectatorSet ? arena.spectatorX : (arena.spawn1X + arena.spawn2X) / 2.0;
            double sy = arena.spectatorSet ? arena.spectatorY : Math.max(arena.spawn1Y, arena.spawn2Y) + 6;
            double sz = arena.spectatorSet ? arena.spectatorZ : (arena.spawn1Z + arena.spawn2Z) / 2.0;
            float syaw = arena.spectatorSet ? arena.spectatorYaw : 0;
            float spitch = arena.spectatorSet ? arena.spectatorPitch : 25;
            com.pvpcore.util.TeleportUtil.teleport(p, world, sx, sy, sz, syaw, spitch);
        }
        var mm = PvPCore.get().messages();
        TitleUtil.title(p, mm.get("duel.lose-title"), mm.get("duel.round-lost-subtitle"));
    }

    /** Intermission countdown -> start the next round. */
    private void tickRoundEnd(Duel duel) {
        long elapsed = tick - duel.stateSinceTick;
        int interTicks = Math.max(1, PvPCore.get().config().duel.roundIntermissionSeconds) * 20;
        // countdown title during the last 3 seconds
        if (elapsed % 20 == 0) {
            long secondsLeft = (interTicks - elapsed) / 20;
            if (secondsLeft > 0 && secondsLeft <= 3) {
                var mm = PvPCore.get().messages();
                for (ServerPlayerEntity p : duel.participants()) {
                    TitleUtil.title(p, mm.get("duel.countdown-title",
                            Map.of("seconds", String.valueOf(secondsLeft))), "", 0, 20, 0);
                }
            }
        }
        if (elapsed >= interTicks) {
            startNextRound(duel);
        }
    }

    /** Reset both teams and start the next round of a best-of duel. */
    private void startNextRound(Duel duel) {
        var pm = PvPCore.get().server().getPlayerManager();
        Kit kit = PvPCore.get().kitManager().get(duel.kitId);
        if (kit == null) {
            endDuel(duel, "DRAW", "kit-missing");
            return;
        }
        List<ServerPlayerEntity> teamA = new ArrayList<>();
        List<ServerPlayerEntity> teamB = new ArrayList<>();
        for (UUID u : duel.teamA) {
            ServerPlayerEntity p = pm.getPlayer(u);
            if (p != null && !duel.isDisconnected(u)) teamA.add(p);
        }
        for (UUID u : duel.teamB) {
            ServerPlayerEntity p = pm.getPlayer(u);
            if (p != null && !duel.isDisconnected(u)) teamB.add(p);
        }
        if (teamA.isEmpty() || teamB.isEmpty()) {
            endDuel(duel, teamA.isEmpty() ? "B" : "A", "wipe");
            return;
        }

        duel.round++;
        for (ServerPlayerEntity p : duel.participants()) {
            p.clearStatusEffects(); // remove round-loser invisibility
        }
        teleportTeam(duel, teamA, true);
        teleportTeam(duel, teamB, false);
        for (ServerPlayerEntity p : duel.participants()) {
            prepareFighter(p, kit);
        }

        duel.state = DuelState.COUNTDOWN;
        duel.stateSinceTick = tick;
        duel.countdownRemainingSeconds = PvPCore.get().config().duel.countdownSeconds;

        var mm = PvPCore.get().messages();
        for (ServerPlayerEntity p : duel.participants()) {
            TitleUtil.title(p, mm.get("duel.round-countdown-title",
                    Map.of("round", String.valueOf(duel.round))), "", 0, 20, 0);
        }
        updateScoreboard(duel);
    }

    // ------------------------------------------------------------------
    // Scoreboard (requirement 13)
    // ------------------------------------------------------------------

    private void updateScoreboard(Duel duel) {
        if (duel.scoreboard == null) return;
        var cfg = PvPCore.get().config().scoreboard;
        var pm = PvPCore.get().server().getPlayerManager();
        List<String> lines = new ArrayList<>();

        ServerPlayerEntity p1 = pm.getPlayer(duel.teamA.get(0));
        ServerPlayerEntity p2 = pm.getPlayer(duel.teamB.get(0));
        String kit = kitDisplayName(duel.kitId);

        if (duel.teamA.size() == 1 && duel.teamB.size() == 1) {
            long durationTicks = (duel.state == DuelState.FIGHTING) ? tick - duel.fightStartTick : 0;
            for (String template : cfg.lines) {
                String line = template
                        .replace("{kit}", kit)
                        .replace("{arena}", duel.arena != null ? duel.arena.id : "?")
                        .replace("{duration}", TextUtil.formatDurationTicks(durationTicks))
                        .replace("{round}", String.valueOf(duel.round))
                        .replace("{rounds}", String.valueOf(duel.bestOf))
                        .replace("{score1}", String.valueOf(duel.winsA))
                        .replace("{score2}", String.valueOf(duel.winsB))
                        .replace("{player1}", p1 != null ? p1.getGameProfile().name() : "?")
                        .replace("{player2}", p2 != null ? p2.getGameProfile().name() : "?")
                        .replace("{ping1}", p1 != null ? String.valueOf(pingOf(p1)) : "?")
                        .replace("{ping2}", p2 != null ? String.valueOf(pingOf(p2)) : "?")
                        .replace("{hp1}", p1 != null ? String.valueOf((int) Math.ceil(p1.getHealth())) : "?")
                        .replace("{hp2}", p2 != null ? String.valueOf((int) Math.ceil(p2.getHealth())) : "?")
                        .replace("{hits1}", String.valueOf(duel.hitsOf(duel.teamA.get(0))))
                        .replace("{hits2}", String.valueOf(duel.hitsOf(duel.teamB.get(0))));
                lines.add(line);
            }
        } else {
            // Team duels: list all players with ping & health
            lines.add("&7&m----------------");
            int shown = 0;
            for (UUID u : duel.teamA) {
                ServerPlayerEntity p = pm.getPlayer(u);
                if (p == null || shown >= 6) continue;
                lines.add("&e" + p.getGameProfile().name() + " &8- &a" + pingOf(p) + "ms &c" + (int) Math.ceil(p.getHealth()) / 2 + "❤");
                shown++;
            }
            lines.add("&8&m----------------");
            shown = 0;
            for (UUID u : duel.teamB) {
                ServerPlayerEntity p = pm.getPlayer(u);
                if (p == null || shown >= 6) continue;
                lines.add("&e" + p.getGameProfile().name() + " &8- &a" + pingOf(p) + "ms &c" + (int) Math.ceil(p.getHealth()) / 2 + "❤");
                shown++;
            }
        }
        duel.scoreboard.updateLines(lines);
    }

    private int pingOf(ServerPlayerEntity player) {
        try {
            return Math.max(0, player.networkHandler.getLatency());
        } catch (Throwable t) {
            return 0;
        }
    }

    // ------------------------------------------------------------------
    // End
    // ------------------------------------------------------------------

    /** End the duel. result: "A", "B" or "DRAW". */
    public void endDuel(Duel duel, String result, String reason) {
        if (duel.state != DuelState.FIGHTING && duel.state != DuelState.COUNTDOWN
                && duel.state != DuelState.ROUND_END) return;
        // If a round just ended, book it before finishing the match
        if (duel.state == DuelState.ROUND_END) {
            // round was already counted by endRound(); nothing extra to do
        }
        duel.result = result;
        duel.state = DuelState.ENDING;
        duel.stateSinceTick = tick;

        // Clear any leftover round-loser spectator effects
        for (ServerPlayerEntity p : duel.participants()) {
            if (PvPCore.get().spectateManager().isSpectating(p)) continue;
            p.clearStatusEffects();
        }

        var mm = PvPCore.get().messages();
        var pm = PvPCore.get().server().getPlayerManager();
        long durationTicks = tick - duel.fightStartTick;
        String duration = TextUtil.formatDurationTicks(durationTicks);

        // Stats + ELO + announcement
        List<UUID> winners = result.equals("A") ? duel.teamA : result.equals("B") ? duel.teamB : new ArrayList<>();
        List<UUID> losers = result.equals("A") ? duel.teamB : result.equals("B") ? duel.teamA : new ArrayList<>();

        applyStats(duel, winners, losers);

        String announcement;
        if (result.equals("DRAW")) {
            announcement = mm.get("duel.draw", Map.of(
                    "player1", duel.firstAName(),
                    "player2", duel.firstBName(),
                    "duration", duration));
        } else {
            String winnerName = nameOf(result.equals("A") ? duel.teamA.get(0) : duel.teamB.get(0));
            String loserName = nameOf(result.equals("A") ? duel.teamB.get(0) : duel.teamA.get(0));
            announcement = mm.get("duel.ended", Map.of(
                    "winner", winnerName,
                    "loser", loserName,
                    "kit", kitDisplayName(duel.kitId),
                    "duration", duration));
        }
        for (ServerPlayerEntity p : PvPCore.get().server().getPlayerManager().getPlayerList()) {
            p.sendMessage(net.minecraft.text.Text.literal(announcement), false);
        }

        // Titles
        if (PvPCore.get().config().duel.showEndTitles) {
            for (ServerPlayerEntity p : duel.participants()) {
                if (duel.isDisconnected(p.getUuid())) continue;
                boolean won = winners.contains(p.getUuid());
                if (result.equals("DRAW")) {
                    TitleUtil.title(p, mm.get("duel.draw-title"), "");
                } else if (won) {
                    TitleUtil.title(p, mm.get("duel.win-title"),
                            mm.get("duel.win-subtitle", Map.of("loser", opponentName(duel, p))));
                } else {
                    TitleUtil.title(p, mm.get("duel.lose-title"),
                            mm.get("duel.lose-subtitle", Map.of("winner", opponentName(duel, p))));
                }
            }
        }

        // ELO for ranked 1v1
        if (duel.ranked && duel.teamA.size() == 1 && duel.teamB.size() == 1 && !result.equals("DRAW")) {
            applyElo(duel, result);
        }
    }

    private String nameOf(UUID uuid) {
        var p = PvPCore.get().server().getPlayerManager().getPlayer(uuid);
        return p != null ? p.getGameProfile().name() : "?";
    }

    private String opponentName(Duel duel, ServerPlayerEntity player) {
        List<UUID> opponents = duel.opponentsOf(player.getUuid());
        return opponents.isEmpty() ? "?" : nameOf(opponents.get(0));
    }

    private void applyStats(Duel duel, List<UUID> winners, List<UUID> losers) {
        var storage = PvPCore.get().storage();
        for (UUID u : winners) {
            PlayerData data = storage.get(u, nameOf(u));
            data.statsFor(duel.kitId).addWin();
            data.statsFor("global").addWin();
            storage.markDirty(u);
        }
        for (UUID u : losers) {
            PlayerData data = storage.get(u, nameOf(u));
            data.statsFor(duel.kitId).addLoss();
            data.statsFor("global").addLoss();
            storage.markDirty(u);
        }
        for (UUID u : duel.hits.keySet()) {
            PlayerData data = storage.get(u, nameOf(u));
            data.statsFor(duel.kitId).hits += duel.hitsOf(u);
            data.statsFor("global").hits += duel.hitsOf(u);
            storage.markDirty(u);
        }
    }

    private void applyElo(Duel duel, String result) {
        var storage = PvPCore.get().storage();
        var eloCfg = PvPCore.get().config().elo;
        UUID winnerId = result.equals("A") ? duel.teamA.get(0) : duel.teamB.get(0);
        UUID loserId = result.equals("A") ? duel.teamB.get(0) : duel.teamA.get(0);

        PlayerData winnerData = storage.get(winnerId, nameOf(winnerId));
        PlayerData loserData = storage.get(loserId, nameOf(loserId));
        int winnerRating = winnerData.ratingFor(duel.kitId, eloCfg.startRating);
        int loserRating = loserData.ratingFor(duel.kitId, eloCfg.startRating);

        double expectedWinner = 1.0 / (1.0 + Math.pow(10, (loserRating - winnerRating) / 400.0));
        double expectedLoser = 1.0 - expectedWinner;
        int deltaW = (int) Math.round(eloCfg.kFactor * (1.0 - expectedWinner));
        int deltaL = (int) Math.round(eloCfg.kFactor * (0.0 - expectedLoser));

        int newWinner = Math.max(0, winnerRating + deltaW);
        int newLoser = Math.max(0, loserRating + deltaL);
        winnerData.setRating(duel.kitId, newWinner);
        loserData.setRating(duel.kitId, newLoser);
        winnerData.setRating("global", Math.max(0, winnerData.ratingFor("global", eloCfg.startRating) + deltaW));
        loserData.setRating("global", Math.max(0, loserData.ratingFor("global", eloCfg.startRating) + deltaL));
        storage.markDirty(winnerId);
        storage.markDirty(loserId);

        var mm = PvPCore.get().messages();
        String msg = mm.get("duel.elo-change", Map.of(
                "kit", kitDisplayName(duel.kitId),
                "player1", nameOf(winnerId),
                "player2", nameOf(loserId),
                "delta1", "+" + deltaW,
                "delta2", String.valueOf(deltaL),
                "rating1", String.valueOf(newWinner),
                "rating2", String.valueOf(newLoser)));
        for (ServerPlayerEntity p : duel.participants()) {
            p.sendMessage(net.minecraft.text.Text.literal(msg), false);
        }
    }

    /** Teleport everyone back, restore inventories, offer rematch. */
    private void finishDuel(Duel duel) {
        var playerManager = PvPCore.get().playerManager();
        var pm = PvPCore.get().server().getPlayerManager();

        // Spectators return first
        PvPCore.get().spectateManager().duelEnded(duel);

        // Issue 5: the match loser spectates the arena until they return
        List<UUID> losers = duel.result.equals("A") ? duel.teamB
                : duel.result.equals("B") ? duel.teamA : new ArrayList<>();
        boolean loserSpec = PvPCore.get().config().duel.loserSpectates
                && !duel.result.isEmpty() && !duel.result.equals("DRAW");

        for (UUID u : duel.teamA) finishPlayer(duel, u, loserSpec && losers.contains(u));
        for (UUID u : duel.teamB) finishPlayer(duel, u, loserSpec && losers.contains(u));

        if (duel.scoreboard != null) duel.scoreboard.removeAll();

        PvPCore.get().arenaManager().release(duel.arena);
        duel.state = DuelState.FINISHED;

        // Rematch offer for 1v1 (requirement: rematch)
        if (duel.teamA.size() == 1 && duel.teamB.size() == 1) {
            offerRematch(duel);
        }
    }

    private void finishPlayer(Duel duel, UUID uuid, boolean loserSpectate) {
        var pm = PvPCore.get().server().getPlayerManager();
        ServerPlayerEntity p = pm.getPlayer(uuid);
        if (p == null) {
            // offline: keep the snapshot pending; it will be restored on join
            return;
        }
        var playerManager = PvPCore.get().playerManager();
        var lobbyCfg = PvPCore.get().config().lobby;
        InventorySnapshot snap = playerManager.preDuelSnapshot(p);

        if (loserSpectate) {
            // Issue 5 + 4: loser spectates with a clean inventory
            playerManager.clearAfterDuel(p, snap);
            PvPCore.get().spectateManager().forceSpectate(p, duel);
            playClick(p, false);
            return;
        }

        if (lobbyCfg.clearInventoryAfterDuel) {
            // Issue 4: return to the lobby with a clean inventory
            playerManager.clearAfterDuel(p, snap);
        } else {
            playerManager.restoreSnapshot(p, snap);
        }
        if (lobbyCfg.teleportAfterDuel) {
            // Issue 3: send them to the lobby point
            playerManager.teleportToLobby(p);
        } else {
            playerManager.teleportToSnapshot(p, snap);
        }
        playerManager.backToLobby(p);
        playClick(p, false);
    }

    // ------------------------------------------------------------------
    // Rematch
    // ------------------------------------------------------------------

    public void offerRematch(Duel duel) {
        var pm = PvPCore.get().server().getPlayerManager();
        ServerPlayerEntity a = pm.getPlayer(duel.teamA.get(0));
        ServerPlayerEntity b = pm.getPlayer(duel.teamB.get(0));
        if (a == null || b == null) return;
        if (duel.isDisconnected(a.getUuid()) || duel.isDisconnected(b.getUuid())) return;

        int expiry = PvPCore.get().config().duel.rematchExpirySeconds;
        RematchOffer offer = new RematchOffer(a.getUuid(), b.getUuid(), duel.kitId, duel.ranked, duel.bestOf,
                tick + (long) expiry * 20);
        rematchOffers.put(offer.playerA, offer);
        // one offer object for both players
        new com.pvpcore.gui.guis.RematchGui(a, offer).open(a);
        new com.pvpcore.gui.guis.RematchGui(b, offer).open(b);
    }

    /** Player accepted the rematch via GUI/command. */
    public void acceptRematch(ServerPlayerEntity player) {
        RematchOffer offer = rematchOfferFor(player.getUuid());
        if (offer == null) return;
        var pm = PvPCore.get().server().getPlayerManager();
        ServerPlayerEntity a = pm.getPlayer(offer.playerA);
        ServerPlayerEntity b = pm.getPlayer(offer.playerB);
        if (a == null || b == null) {
            rematchOffers.remove(offer.playerA);
            return;
        }
        if (!offer.accepted.contains(player.getUuid())) offer.accepted.add(player.getUuid());
        if (offer.accepted.containsAll(List.of(offer.playerA, offer.playerB))) {
            rematchOffers.remove(offer.playerA);
            a.sendMessage(net.minecraft.text.Text.literal(
                    PvPCore.get().messages().get("duel.rematch-accepted")), false);
            b.sendMessage(net.minecraft.text.Text.literal(
                    PvPCore.get().messages().get("duel.rematch-accepted")), false);
            PvPCore.get().guiManager().close(a);
            PvPCore.get().guiManager().close(b);
            // Issue 5: pull the loser out of loser-spectate before the rematch
            if (PvPCore.get().spectateManager().isSpectating(a)) {
                PvPCore.get().spectateManager().returnPlayer(a);
            }
            if (PvPCore.get().spectateManager().isSpectating(b)) {
                PvPCore.get().spectateManager().returnPlayer(b);
            }
            startDuel(offer.kitId, offer.ranked, List.of(a), List.of(b), offer.bestOf);
        } else {
            ServerPlayerEntity other = player == a ? b : a;
            other.sendMessage(net.minecraft.text.Text.literal(
                    PvPCore.get().messages().get("duel.rematch-sent", Map.of(
                            "player", player.getGameProfile().name()))), false);
        }
    }

    public void declineRematch(ServerPlayerEntity player) {
        RematchOffer offer = rematchOfferFor(player.getUuid());
        if (offer == null) return;
        rematchOffers.remove(offer.playerA);
        var pm = PvPCore.get().server().getPlayerManager();
        for (UUID u : List.of(offer.playerA, offer.playerB)) {
            ServerPlayerEntity p = pm.getPlayer(u);
            if (p != null) {
                p.sendMessage(net.minecraft.text.Text.literal(
                        PvPCore.get().messages().get("duel.rematch-declined")), false);
                if (PvPCore.get().guiManager().openGui(p) instanceof com.pvpcore.gui.guis.RematchGui) {
                    PvPCore.get().guiManager().close(p);
                }
            }
        }
    }

    // ------------------------------------------------------------------
    // Disconnect / reconnect
    // ------------------------------------------------------------------

    public void onPlayerDisconnect(ServerPlayerEntity player) {
        Duel duel = duelOf(player);
        if (duel == null) return;
        if (duel.state != DuelState.FIGHTING && duel.state != DuelState.COUNTDOWN
                && duel.state != DuelState.ROUND_END) return;
        duel.disconnectedAt.put(player.getUuid(), tick);
        // ensure fighting (in case the disconnect happened during the countdown)
        if (duel.state == DuelState.COUNTDOWN) duel.state = DuelState.FIGHTING;
        var mm = PvPCore.get().messages();
        for (ServerPlayerEntity p : duel.participants()) {
            if (p == null || p.getUuid().equals(player.getUuid()) || duel.isDisconnected(p.getUuid())) continue;
            TitleUtil.title(p, "", mm.get("duel.opponent-disconnected", Map.of(
                    "player", player.getGameProfile().name(),
                    "seconds", String.valueOf(PvPCore.get().config().duel.disconnectGraceSeconds))));
        }
    }

    public void onPlayerReconnect(ServerPlayerEntity player) {
        Duel duel = duelOf(player);
        if (duel == null) return;
        duel.disconnectedAt.remove(player.getUuid());
        var mm = PvPCore.get().messages();
        for (ServerPlayerEntity p : duel.participants()) {
            if (p == null || p.getUuid().equals(player.getUuid())) continue;
            p.sendMessage(net.minecraft.text.Text.literal(mm.get("duel.opponent-returned", Map.of(
                    "player", player.getGameProfile().name()))), false);
        }
        // Teleport back to spawn
        Arena arena = duel.arena;
        var world = com.pvpcore.util.TeleportUtil.world(PvPCore.get().server(), arena.world);
        boolean teamA = duel.isTeamA(player.getUuid());
        if (world != null) {
            com.pvpcore.util.TeleportUtil.teleport(player, world,
                    teamA ? arena.spawn1X : arena.spawn2X,
                    teamA ? arena.spawn1Y : arena.spawn2Y,
                    teamA ? arena.spawn1Z : arena.spawn2Z,
                    teamA ? arena.spawn1Yaw : arena.spawn2Yaw,
                    teamA ? arena.spawn1Pitch : arena.spawn2Pitch);
        }
        if (duel.scoreboard != null) duel.scoreboard.addViewer(player);
        PvPCore.get().playerManager().setState(player, PlayerState.DUELING);
    }

    // ------------------------------------------------------------------
    // Damage rules (called from the Fabric ALLOW_DAMAGE event)
    // ------------------------------------------------------------------

    public boolean allowDamage(LivingEntity entity, DamageSource source, float amount) {
        if (!(entity instanceof ServerPlayerEntity victim)) return true; // non-players untouched

        var core = PvPCore.get();
        var pm = core.playerManager();
        var state = pm.state(victim);

        // Spectators never take or deal damage
        if (core.spectateManager().isSpectating(victim)) return false;
        if (source.getAttacker() instanceof ServerPlayerEntity attackerSpectator
                && core.spectateManager().isSpectating(attackerSpectator)) return false;

        // Lobby protection
        if ((state == PlayerState.LOBBY || state == PlayerState.QUEUEING) && core.config().lobby.invulnerable) {
            if (source.isOf(DamageTypes.GENERIC_KILL)) return true; // allow /kill
            if (source.isOf(DamageTypes.OUT_OF_WORLD)) {
                // falling through the world in lobby -> teleport back instead of dying
                core.playerManager().teleportToLobby(victim);
                return false;
            }
            return false;
        }

        Duel duel = duelOf(victim);
        if (duel == null) return true; // not our business (e.g. another plugin's arena)

        if (duel.state == DuelState.COUNTDOWN || duel.state == DuelState.ENDING
                || duel.state == DuelState.ROUND_END) return false;

        if (duel.state == DuelState.FIGHTING) {
            // attacker handling
            if (source.getAttacker() instanceof ServerPlayerEntity attacker) {
                if (!duel.isParticipant(attacker.getUuid())) return false; // outsider
                if (duel.teamOf(attacker.getUuid()).equals(duel.teamOf(victim.getUuid()))) return false; // friendly fire off
                // record the hit
                duel.hits.merge(attacker.getUuid(), 1, Integer::sum);
            }
            // Lethal damage capture: end the round/duel without a death screen
            if (victim.getHealth() - amount <= 0) {
                if (source.getAttacker() instanceof ServerPlayerEntity attacker && duel.isParticipant(attacker.getUuid())) {
                    endRoundOrDuel(duel, duel.isTeamA(attacker.getUuid()) ? "A" : "B", "kill");
                } else {
                    endRoundOrDuel(duel, duel.isTeamA(victim.getUuid()) ? "B" : "A", "environment");
                }
                return false; // cancel the death
            }
            return true;
        }
        return true;
    }

    /** Fallback: a duel participant actually died (e.g. via /kill). */
    public void onPlayerDeath(ServerPlayerEntity player) {
        Duel duel = duelOf(player);
        if (duel == null || (duel.state != DuelState.FIGHTING && duel.state != DuelState.COUNTDOWN)) return;
        endDuel(duel, duel.isTeamA(player.getUuid()) ? "B" : "A", "death");
    }

    // ------------------------------------------------------------------
    // Misc
    // ------------------------------------------------------------------

    public void playClick(ServerPlayerEntity player, boolean start) {
        try {
            player.getEntityWorld().playSound(null, player.getX(), player.getY(), player.getZ(),
                    start ? net.minecraft.sound.SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP
                          : net.minecraft.sound.SoundEvents.ENTITY_PLAYER_LEVELUP,
                    net.minecraft.sound.SoundCategory.MASTER, 0.6f, start ? 1.4f : 0.8f);
        } catch (Throwable ignored) {}
    }

    /** Shutdown: end all duels gracefully. */
    public void shutdown() {
        for (Duel duel : new ArrayList<>(duels.values())) {
            if (duel.state == DuelState.FIGHTING || duel.state == DuelState.COUNTDOWN) {
                endDuel(duel, "DRAW", "shutdown");
            }
            if (duel.state == DuelState.ENDING) {
                finishDuel(duel);
            }
        }
        duels.clear();
        byParticipant.clear();
    }
}
