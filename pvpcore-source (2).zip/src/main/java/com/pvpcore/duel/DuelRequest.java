package com.pvpcore.duel;

import java.util.UUID;

/**
 * A pending duel or party challenge. Issue 9 (2.1.0): accept/deny happen via
 * clickable chat buttons. Issue 6 (2.2.0): challenges carry a best-of-N rounds
 * setting chosen by the challenger.
 */
public class DuelRequest {
    public enum Type { PLAYER_DUEL, PARTY_DUEL }

    public final UUID id;
    public final Type type;
    public final UUID sender;
    public final UUID target;
    public final String kitId;
    public final boolean ranked;
    /** Issue 6: how many rounds the whole duel has (best-of-N, 1 = single). */
    public final int bestOf;
    /** Party duel: sender party members. */
    public final java.util.List<UUID> senderParty;
    /** Party duel: target party members. */
    public final java.util.List<UUID> targetParty;
    public final long expiryTick;

    public DuelRequest(Type type, UUID sender, UUID target, String kitId, boolean ranked, int bestOf,
                       java.util.List<UUID> senderParty, java.util.List<UUID> targetParty, long expiryTick) {
        this.id = UUID.randomUUID();
        this.type = type;
        this.sender = sender;
        this.target = target;
        this.kitId = kitId;
        this.ranked = ranked;
        this.bestOf = Math.max(1, bestOf);
        this.senderParty = senderParty;
        this.targetParty = targetParty;
        this.expiryTick = expiryTick;
    }
}
