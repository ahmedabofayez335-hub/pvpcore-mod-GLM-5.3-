package com.pvpcore.leaderboard;

import com.pvpcore.PvPCore;
import com.pvpcore.data.PlayerData;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Leaderboards: top players by wins or ELO, global or per kit.
 */
public final class LeaderboardManager {
    public record Entry(String name, int value) {}

    private final Map<String, List<Entry>> byWins = new java.util.concurrent.ConcurrentHashMap<>();
    private final Map<String, List<Entry>> byElo = new java.util.concurrent.ConcurrentHashMap<>();
    private long lastRefresh = 0;

    public void refresh() {
        byWins.clear();
        byElo.clear();
        var storage = PvPCore.get().storage();
        int startRating = PvPCore.get().config().elo.startRating;
        for (Map.Entry<UUID, PlayerData> e : storage.loadAll().entrySet()) {
            PlayerData data = e.getValue();
            String name = data.name != null && !data.name.isBlank() ? data.name : e.getKey().toString().substring(0, 8);
            // global
            addEntry(byWins, "global", name, data.statsFor("global").wins);
            addEntry(byElo, "global", name, data.ratingFor("global", startRating));
            // per kit
            for (String kitId : data.stats.keySet()) {
                if (kitId.equals("global")) continue;
                addEntry(byWins, kitId, name, data.statsFor(kitId).wins);
            }
            for (String kitId : data.ratings.keySet()) {
                if (kitId.equals("global")) continue;
                addEntry(byElo, kitId, name, data.ratingFor(kitId, startRating));
            }
        }
        byWins.values().forEach(l -> l.sort(Comparator.comparingInt(Entry::value).reversed()));
        byElo.values().forEach(l -> l.sort(Comparator.comparingInt(Entry::value).reversed()));
        lastRefresh = System.currentTimeMillis();
    }

    private void addEntry(Map<String, List<Entry>> map, String kitId, String name, int value) {
        map.computeIfAbsent(kitId, k -> new ArrayList<>()).add(new Entry(name, value));
    }

    /** Top N entries. type: "wins" or "elo". */
    public List<Entry> top(String kitId, String type, int n) {
        var source = type.equals("elo") ? byElo : byWins;
        List<Entry> list = source.get(kitId);
        if (list == null) return new ArrayList<>();
        return new ArrayList<>(list.subList(0, Math.min(n, list.size())));
    }
}
