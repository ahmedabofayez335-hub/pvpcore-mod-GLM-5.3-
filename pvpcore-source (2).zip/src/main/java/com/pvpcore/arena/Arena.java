package com.pvpcore.arena;

/**
 * A duel arena with two spawn points and a spectator spawn.
 */
public class Arena {
    public enum Status { FREE, RESERVED, ACTIVE, RESETTING }

    public String id = "arena";
    public String displayName = "&fArena";
    public boolean enabled = true;
    public String world = "minecraft:overworld";
    public double spawn1X, spawn1Y, spawn1Z;
    public float spawn1Yaw, spawn1Pitch;
    public double spawn2X, spawn2Y, spawn2Z;
    public float spawn2Yaw, spawn2Pitch;
    public double spectatorX, spectatorY, spectatorZ;
    public float spectatorYaw, spectatorPitch;
    public boolean spawn1Set = false;
    public boolean spawn2Set = false;
    public boolean spectatorSet = false;

    public transient Status status = Status.FREE;

    public boolean isValid() {
        return spawn1Set && spawn2Set;
    }

    public String invalidReason() {
        if (!spawn1Set) return "Spawn 1 is not set";
        if (!spawn2Set) return "Spawn 2 is not set";
        return "valid";
    }

    public String statusColored() {
        if (!enabled) return "&cDisabled";
        return switch (status) {
            case FREE -> "&aFree";
            case RESERVED -> "&eReserved";
            case ACTIVE -> "&cIn Use";
            case RESETTING -> "&dResetting";
        };
    }
}
