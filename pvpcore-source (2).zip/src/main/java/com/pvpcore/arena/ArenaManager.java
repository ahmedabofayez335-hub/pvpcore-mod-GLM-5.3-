package com.pvpcore.arena;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.pvpcore.PvPCoreMod;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Manages arenas: load/save (arenas.json), atomic reservation, round-robin selection.
 */
public final class ArenaManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();

    private final Path file;
    private final Map<String, Arena> arenas = new LinkedHashMap<>();
    private int rrIndex = 0;

    public ArenaManager(Path dataDir) {
        this.file = dataDir.resolve("arenas.json");
        load();
    }

    public void load() {
        arenas.clear();
        if (Files.exists(file)) {
            try {
                String json = Files.readString(file, StandardCharsets.UTF_8);
                List<Arena> list = GSON.fromJson(json, new TypeToken<List<Arena>>() {}.getType());
                if (list != null) {
                    for (Arena a : list) arenas.put(a.id, a);
                }
            } catch (Exception e) {
                PvPCoreMod.LOGGER.error("Failed to load arenas.json", e);
            }
        }
    }

    public synchronized void save() {
        try {
            Files.createDirectories(file.getParent());
            Path tmp = file.resolveSibling("arenas.json.tmp");
            Files.writeString(tmp, GSON.toJson(new ArrayList<>(arenas.values())), StandardCharsets.UTF_8);
            Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException e) {
            PvPCoreMod.LOGGER.error("Failed to save arenas.json", e);
        }
    }

    public Arena create(String id) {
        Arena a = new Arena();
        a.id = id.toLowerCase().replace(" ", "_");
        a.displayName = "&f" + id;
        arenas.put(a.id, a);
        save();
        return a;
    }

    public Arena get(String id) {
        return arenas.get(id.toLowerCase());
    }

    public Collection<Arena> all() {
        return arenas.values();
    }

    public void delete(String id) {
        arenas.remove(id.toLowerCase());
        save();
    }

    /**
     * Atomically reserve a free, enabled, valid arena (round-robin).
     * Returns null when none are available.
     */
    public synchronized Arena reserve() {
        List<Arena> candidates = arenas.values().stream()
                .filter(a -> a.enabled && a.isValid() && a.status == Arena.Status.FREE)
                .toList();
        if (candidates.isEmpty()) return null;
        Arena picked = candidates.get(Math.floorMod(rrIndex++, candidates.size()));
        picked.status = Arena.Status.RESERVED;
        return picked;
    }

    public void markActive(Arena arena) {
        arena.status = Arena.Status.ACTIVE;
    }

    public void release(Arena arena) {
        if (arena != null) arena.status = Arena.Status.FREE;
    }

    public int countUsable() {
        return (int) arenas.values().stream().filter(a -> a.enabled && a.isValid()).count();
    }
}
