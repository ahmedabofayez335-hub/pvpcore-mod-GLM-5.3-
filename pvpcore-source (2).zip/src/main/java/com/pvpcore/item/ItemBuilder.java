package com.pvpcore.item;

import com.pvpcore.util.TextUtil;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ProfileComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.registry.Registries;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Fluent ItemStack builder used everywhere for GUI items.
 */
public final class ItemBuilder {
    private final ItemStack stack;

    private ItemBuilder(ItemStack stack) {
        this.stack = stack;
    }

    public static ItemBuilder of(ItemStack stack) {
        return new ItemBuilder(stack == null ? ItemStack.EMPTY.copy() : stack.copy());
    }

    public static ItemBuilder of(String material) {
        return new ItemBuilder(com.pvpcore.util.ItemCodecUtil.parseMaterial(material));
    }

    public static ItemBuilder of(Item item) {
        return new ItemBuilder(new ItemStack(item));
    }

    public ItemBuilder amount(int count) {
        stack.setCount(Math.max(1, Math.min(99, count)));
        return this;
    }

    public ItemBuilder name(String name) {
        if (name != null) stack.set(DataComponentTypes.CUSTOM_NAME, TextUtil.text(name));
        return this;
    }

    public ItemBuilder lore(String... lines) {
        return lore(Arrays.asList(lines));
    }

    public ItemBuilder lore(List<String> lines) {
        List<Text> lore = new ArrayList<>();
        if (lines != null) {
            for (String line : lines) lore.add(TextUtil.text(line));
        }
        stack.set(DataComponentTypes.LORE, new net.minecraft.component.type.LoreComponent(lore));
        return this;
    }

    public ItemBuilder appendLore(String... lines) {
        List<Text> existing = new ArrayList<>();
        var comp = stack.get(DataComponentTypes.LORE);
        if (comp != null) existing.addAll(comp.lines());
        for (String line : lines) existing.add(TextUtil.text(line));
        stack.set(DataComponentTypes.LORE, new net.minecraft.component.type.LoreComponent(existing));
        return this;
    }

    public ItemBuilder glow(boolean glow) {
        if (glow) {
            var entry = com.pvpcore.util.EnchantUtil.byId("unbreaking");
            if (entry != null) stack.addEnchantment(entry, 1);
            stack.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
        }
        return this;
    }

    public ItemBuilder hideAll() {
        // Hide additional tooltip info (enchants, etc.) for clean GUI buttons
        stack.set(DataComponentTypes.TOOLTIP_DISPLAY,
                new net.minecraft.component.type.TooltipDisplayComponent(true, new java.util.LinkedHashSet<>()));
        return this;
    }

    /**
     * Tag this item as a PvP Core action item (used for lobby hotbar items).
     * The tag survives copies and is how clicks are routed without commands.
     */
    public ItemBuilder tag(String action) {
        NbtCompound nbt = new NbtCompound();
        nbt.putString("pvpcore", action);
        stack.set(DataComponentTypes.CUSTOM_DATA, net.minecraft.component.type.NbtComponent.of(nbt));
        return this;
    }

    /** Read the PvP Core action tag of a stack (null if none). */
    public static String actionOf(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return null;
        var comp = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (comp == null) return null;
        try {
            NbtCompound nbt = comp.copyNbt();
            String s = nbt.getString("pvpcore", "");
            return s == null || s.isEmpty() ? null : s;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Set this item to be a player head showing the given player's skin.
     * Uses the server-side GameProfile (including any textures applied by
     * skin-restorer mods) - requirement 8.
     */
    public ItemBuilder skullOwner(ServerPlayerEntity player) {
        if (stack.getItem() != Items.PLAYER_HEAD) return this;
        stack.set(DataComponentTypes.PROFILE, ProfileComponent.ofStatic(player.getGameProfile()));
        return this;
    }

    public ItemBuilder enchant(String enchId, int level) {
        var entry = com.pvpcore.util.EnchantUtil.byId(enchId);
        if (entry != null) stack.addEnchantment(entry, level);
        return this;
    }

    public ItemBuilder potionEffects(List<StatusEffectInstance> effects) {
        stack.set(DataComponentTypes.POTION_CONTENTS, new net.minecraft.component.type.PotionContentsComponent(
                java.util.Optional.empty(), java.util.Optional.empty(), effects, java.util.Optional.empty()));
        return this;
    }

    public ItemStack build() {
        return stack.copy();
    }
}
