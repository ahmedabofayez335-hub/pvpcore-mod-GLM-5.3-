package com.pvpcore.player;

import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;

/**
 * Full snapshot of a player taken before a duel:
 * inventory, armor, offhand, position, health, food, XP.
 * Restored exactly when the duel ends.
 */
public class InventorySnapshot {
    public final ItemStack[] main = new ItemStack[36];
    public final ItemStack[] armor = new ItemStack[4];
    public ItemStack offhand = ItemStack.EMPTY;
    public int selectedSlot;
    public float health = 20f;
    public int food = 20;
    public float saturation = 5f;
    public int xpLevel;
    public float xpProgress;

    public String world;
    public double x, y, z;
    public float yaw, pitch;

    /** Issue 5 (2.2.0): game mode before the duel, restored when it ends. */
    public String gameMode = "SURVIVAL";
}
