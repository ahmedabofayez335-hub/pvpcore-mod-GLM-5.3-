package com.pvpcore.player;

import com.pvpcore.PvPCore;
import com.pvpcore.config.GuiConfig;
import com.pvpcore.data.PlayerData;
import com.pvpcore.duel.Duel;
import com.pvpcore.util.TeleportUtil;
import com.pvpcore.util.TextUtil;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Per-player session management:
 * - Requirement 1: lobby inventory lock.
 * - Requirement 3: login-sync so third-party login GUIs keep working.
 * - Requirement 8: profile head matching the player skin (skin restorer compatible).
 * - Requirement 10: lobby items placed in their exact configured slots.
 * - Pre-duel snapshots with exact restore.
 */
public final class PlayerManager {
    public static class Session {
        public PlayerState state = PlayerState.LOBBY;
        public boolean loginSynced = false;
        public long joinTick = 0;
        public Vec3d joinPos;
        /** Items stashed from slots occupied by lobby items (slot -> original). */
        public final Map<Integer, ItemStack> lobbyStash = new HashMap<>();
        /** Snapshot taken when a duel starts. */
        public InventorySnapshot preDuel;
        /** Whether the player was healed before the duel (for restore decision). */
        public boolean spectatingReturnPending;
    }

    private final Map<UUID, Session> sessions = new HashMap<>();
    private long tickCounter = 0;
    private long lastAutosave = 0;

    // ------------------------------------------------------------------
    // Join / quit
    // ------------------------------------------------------------------

    public void onJoin(ServerPlayerEntity player) {
        MinecraftServer server = PvPCore.get().server();
        if (server == null) return;
        Session session = new Session();
        session.joinTick = server.getTicks();
        session.joinPos = player.getEntityPos();
        sessions.put(player.getUuid(), session);

        // Load data (also caches it for leaderboards)
        PvPCore.get().storage().get(player.getUuid(), player.getGameProfile().name());

        // Reconnect grace: if this player is in an active duel, resume it instead of lobby setup
        Duel activeDuel = PvPCore.get().duelManager().duelOf(player.getUuid());
        if (activeDuel != null) {
            session.state = PlayerState.DUELING;
            session.loginSynced = true; // no lobby items during a duel
            PvPCore.get().duelManager().onPlayerReconnect(player);
            return;
        }

        // Crash/disconnect safety: restore a pending pre-duel snapshot if one exists
        if (PvPCore.get().snapshotStore().has(player.getUuid())) {
            PvPCore.get().snapshotStore().restore(player);
        }

        String mode = PvPCore.get().config().lobby.loginSyncMode.toUpperCase();
        if (mode.equals("INSTANT")) {
            applyLobby(player);
        }
        // SMART / TIMEOUT: applied in tick() after movement or timeout (requirement 3)
    }

    public void onQuit(ServerPlayerEntity player) {
        Session session = sessions.get(player.getUuid());
        PvPCore.get().guiManager().cleanup(player.getUuid());
        PvPCore.get().queueManager().remove(player);
        PvPCore.get().spectateManager().onQuit(player);
        PvPCore.get().partyManager().onQuit(player);
        PvPCore.get().lobbyScoreboardManager().onQuit(player);

        if (session != null) {
            if (session.state == PlayerState.DUELING) {
                // Duel manager handles the grace period & keeps the snapshot
                Duel duel = PvPCore.get().duelManager().duelOf(player);
                if (duel != null) PvPCore.get().duelManager().onPlayerDisconnect(player);
            } else {
                // Remove our lobby items and restore everything the stash holds
                // so nothing is lost or left behind (issue 2)
                removeLobbyItems(player);
                restoreLobbyStash(player);
                session.preDuel = null;
            }
        }
        PvPCore.get().storage().saveNow(player.getUuid());
        sessions.remove(player.getUuid());
    }

    // ------------------------------------------------------------------
    // Tick: login sync + autosave
    // ------------------------------------------------------------------

    public void tick() {
        tickCounter++;
        MinecraftServer server = PvPCore.get().server();
        if (server == null) return;

        // Requirement 3: apply lobby state once the player is (very likely) done logging in
        var mode = PvPCore.get().config().lobby.loginSyncMode.toUpperCase();
        if (!mode.equals("INSTANT")) {
            int timeout = PvPCore.get().config().lobby.loginTimeoutTicks;
            boolean smart = mode.equals("SMART");
            for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                Session session = sessions.get(player.getUuid());
                if (session == null || session.loginSynced) continue;
                if (session.state != PlayerState.LOBBY) continue;
                long waited = tickCounter - session.joinTick;
                boolean timedOut = waited >= timeout;
                boolean moved = smart && session.joinPos != null
                        && player.squaredDistanceTo(session.joinPos) > 0.25;
                if (timedOut || moved) {
                    applyLobby(player);
                }
            }
        }

        // Keep lobby players fed & safe
        if (PvPCore.get().config().lobby.invulnerable) {
            for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                Session session = sessions.get(player.getUuid());
                if (session == null || session.state != PlayerState.LOBBY && session.state != PlayerState.QUEUEING) continue;
                if (player.getHealth() < player.getMaxHealth()) player.setHealth(player.getMaxHealth());
                if (player.getHungerManager().getFoodLevel() < 20) player.getHungerManager().setFoodLevel(20);
            }
        }
    }

    public void autosaveTick() {
        int interval = Math.max(10, PvPCore.get().config().storage.saveIntervalSeconds) * 20;
        if (tickCounter - lastAutosave >= interval) {
            lastAutosave = tickCounter;
            PvPCore.get().storage().saveAll();
            PvPCore.get().leaderboardManager().refresh();
        }
    }

    public void saveAllNow() {
        PvPCore.get().storage().saveAll();
    }

    // ------------------------------------------------------------------
    // Lobby items (requirement 10: exact slots; requirement 14: no settings item)
    // ------------------------------------------------------------------

    /** Apply lobby state: login-sync complete, give hotbar items. */
    public void applyLobby(ServerPlayerEntity player) {
        Session session = session(player);
        if (session.loginSynced) return;
        session.loginSynced = true;
        session.state = PlayerState.LOBBY;

        var lobby = PvPCore.get().config().lobby;
        if (lobby.teleportOnJoin) {
            teleportToLobby(player);
        }
        if (lobby.giveItems) {
            giveLobbyItems(player);
        }
    }

    /** Force lobby setup (used after duels). Assumes login-sync already done. */
    public void backToLobby(ServerPlayerEntity player) {
        Session session = session(player);
        session.state = PlayerState.LOBBY;
        session.preDuel = null;
        var lobby = PvPCore.get().config().lobby;
        if (PvPCore.get().config().duel.healAfterDuel) {
            player.setHealth(player.getMaxHealth());
            player.getHungerManager().setFoodLevel(20);
            player.getHungerManager().setSaturationLevel(5f);
            player.clearStatusEffects();
            player.experienceLevel = 0;
            player.experienceProgress = 0;
        }
        if (lobby.giveItems) {
            giveLobbyItems(player);
        }
    }

    /** Give (or refresh) lobby hotbar items into their exact configured slots. */
    public void giveLobbyItems(ServerPlayerEntity player) {
        GuiConfig cfg = PvPCore.get().guiConfig();
        var inv = player.getInventory();
        Session session = session(player);

        // Which item set applies right now?
        boolean queued = PvPCore.get().queueManager().isQueued(player);
        boolean inParty = PvPCore.get().partyManager().partyOf(player) != null;
        boolean spectating = PvPCore.get().spectateManager().isSpectating(player);

        // clear previously given lobby items from configured slots & restore stash first
        removeLobbyItems(player);

        // Build the full desired hotbar map (slot -> [action tag, item])
        Map<Integer, Map.Entry<String, ItemStack>> desired = new java.util.TreeMap<>();
        if (spectating) {
            var spec = cfg.lobbyItem("spectate_return");
            if (spec.enabled) desired.put(spec.slot, Map.entry("spectate", cfg.build(spec)));
        } else if (queued) {
            // Issue 4: while queued, the hotbar shows ONLY the Leave Queue item
            var spec = cfg.lobbyItem("queue_leave");
            desired.put(spec.slot, Map.entry("queue_leave", cfg.build(spec)));
        } else {
            // unranked slot
            var unrankedSpec = cfg.lobbyItem("unranked");
            if (unrankedSpec.enabled) {
                desired.put(unrankedSpec.slot, Map.entry("unranked", cfg.build(unrankedSpec)));
            }
            // ranked slot
            var rankedSpec = cfg.lobbyItem("ranked");
            if (rankedSpec.enabled) {
                desired.put(rankedSpec.slot, Map.entry("ranked", cfg.build(rankedSpec)));
            }
            // static items (issue 7: leaderboard item removed from the hotbar;
            // admins can still open it via /leaderboard or the profile GUI)
            for (String key : List.of("duel", "kits", "profile", "spectate")) {
                var spec = cfg.lobbyItem(key);
                if (spec.enabled) desired.put(spec.slot, Map.entry(key, cfg.build(spec)));
            }
            // party item (requirement 15: party members get the party item automatically)
            var partySpec = inParty ? cfg.lobbyItem("party_active") : cfg.lobbyItem("party");
            if (partySpec.enabled) desired.put(partySpec.slot, Map.entry("party", cfg.build(partySpec)));
        }

        for (Map.Entry<Integer, Map.Entry<String, ItemStack>> e : desired.entrySet()) {
            int slot = e.getKey();
            if (slot < 0 || slot > 8) continue;
            ItemStack current = inv.getStack(slot);
            if (!current.isEmpty()) {
                session.lobbyStash.put(slot, current.copy());
            }
            ItemStack toSet = e.getValue().getValue();
            // Requirement 8: profile head shows the player's real skin (skin restorer compatible)
            if (toSet.getItem() == net.minecraft.item.Items.PLAYER_HEAD) {
                toSet = com.pvpcore.item.ItemBuilder.of(toSet).skullOwner(player).build();
            }
            // Tag the item so clicks are routed to GUI actions (no commands needed)
            toSet = com.pvpcore.item.ItemBuilder.of(toSet).tag(e.getValue().getKey()).build();
            inv.setStack(slot, toSet);
        }
        inv.markDirty();
        // Full resync so the hotbar always matches the server exactly (issue 2)
        player.currentScreenHandler.updateToClient();
    }

    /** Remove all lobby items and restore stashed originals. */
    public void removeLobbyItems(ServerPlayerEntity player) {
        Session session = session(player);
        var inv = player.getInventory();
        GuiConfig cfg = PvPCore.get().guiConfig();

        // determine every slot we might occupy
        java.util.Set<Integer> occupied = new java.util.TreeSet<>();
        for (String key : cfg.lobby.items.keySet()) {
            var spec = cfg.lobbyItem(key);
            if (spec.slot >= 0 && spec.slot <= 8) occupied.add(spec.slot);
        }
        for (int slot : occupied) {
            ItemStack current = inv.getStack(slot);
            ItemStack stashed = session.lobbyStash.remove(slot);
            if (stashed != null) {
                inv.setStack(slot, stashed);
            } else {
                // only clear if the item is one of ours (safety)
                if (isLobbyItem(current, cfg)) inv.setStack(slot, ItemStack.EMPTY);
            }
        }
        inv.markDirty();
        player.currentScreenHandler.updateToClient();
    }

    private boolean isLobbyItem(ItemStack stack, GuiConfig cfg) {
        return com.pvpcore.item.ItemBuilder.actionOf(stack) != null;
    }

    private void restoreLobbyStash(ServerPlayerEntity player) {
        Session session = sessions.get(player.getUuid());
        if (session == null) return;
        var inv = player.getInventory();
        for (Map.Entry<Integer, ItemStack> e : session.lobbyStash.entrySet()) {
            int slot = e.getKey();
            if (slot >= 0 && slot < 36) {
                if (inv.getStack(slot).isEmpty()) inv.setStack(slot, e.getValue());
            }
        }
        session.lobbyStash.clear();
        inv.markDirty();
    }

    // ------------------------------------------------------------------
    // Snapshots
    // ------------------------------------------------------------------

    /** Take a full snapshot and clear everything (called at duel start). */
    public InventorySnapshot snapshotAndClear(ServerPlayerEntity player) {
        Session session = session(player);
        InventorySnapshot snap = new InventorySnapshot();
        var inv = player.getInventory();
        for (int i = 0; i < 36; i++) {
            snap.main[i] = inv.getStack(i).copy();
            inv.setStack(i, ItemStack.EMPTY);
        }
        for (int i = 0; i < 4; i++) {
            snap.armor[i] = inv.getStack(36 + i).copy();
        }
        snap.offhand = inv.getStack(40).copy();
        inv.setStack(40, ItemStack.EMPTY); // offhand slot in 1.21 PlayerInventory
        snap.selectedSlot = inv.getSelectedSlot();
        snap.health = player.getHealth();
        snap.food = player.getHungerManager().getFoodLevel();
        snap.saturation = player.getHungerManager().getSaturationLevel();
        snap.xpLevel = player.experienceLevel;
        snap.xpProgress = player.experienceProgress;

        var world = player.getEntityWorld();
        snap.world = world.getRegistryKey().getValue().toString();
        var pos = player.getEntityPos();
        snap.x = pos.x; snap.y = pos.y; snap.z = pos.z;
        snap.yaw = player.getYaw(); snap.pitch = player.getPitch();

        // remove armor slots too
        for (int i = 0; i < 4; i++) inv.setStack(36 + i, ItemStack.EMPTY);

        inv.markDirty();
        player.currentScreenHandler.sendContentUpdates();
        session.preDuel = snap;

        // crash safety: persist the snapshot to disk
        PvPCore.get().snapshotStore().save(player.getUuid(), snap);
        return snap;
    }

    /** Restore a snapshot exactly (called at duel end). */
    public void restoreSnapshot(ServerPlayerEntity player, InventorySnapshot snap) {
        if (snap == null) return;
        Session session = session(player);
        var inv = player.getInventory();
        // clear current (kit leftovers)
        for (int i = 0; i < 36; i++) inv.setStack(i, ItemStack.EMPTY);
        for (int i = 36; i < 40; i++) inv.setStack(i, ItemStack.EMPTY);
        inv.setStack(40, ItemStack.EMPTY);
        for (int i = 0; i < 36; i++) {
            if (snap.main[i] != null) inv.setStack(i, snap.main[i].copy());
        }
        for (int i = 0; i < 4; i++) {
            if (snap.armor[i] != null) inv.setStack(36 + i, snap.armor[i].copy());
        }
        if (snap.offhand != null) inv.setStack(40, snap.offhand.copy());
        inv.setSelectedSlot(snap.selectedSlot);
        player.setHealth(Math.max(1f, snap.health));
        player.getHungerManager().setFoodLevel(snap.food);
        player.getHungerManager().setSaturationLevel(snap.saturation);
        player.experienceLevel = snap.xpLevel;
        player.experienceProgress = snap.xpProgress;
        inv.markDirty();
        player.currentScreenHandler.updateToClient();
        session.preDuel = null;
        // snapshot fully restored: remove the crash-safety copy
        PvPCore.get().snapshotStore().delete(player.getUuid());
    }

    public InventorySnapshot preDuelSnapshot(ServerPlayerEntity player) {
        Session s = sessions.get(player.getUuid());
        return s != null ? s.preDuel : null;
    }

    /**
     * Issue 4 (2.2.0): wipe the inventory after a duel instead of restoring
     * the pre-duel items. The player returns to the lobby with only the
     * lobby hotbar items; the crash-safety snapshot is deleted.
     */
    public void clearAfterDuel(ServerPlayerEntity player, InventorySnapshot snap) {
        var inv = player.getInventory();
        for (int i = 0; i < 36; i++) inv.setStack(i, ItemStack.EMPTY);
        for (int i = 36; i < 40; i++) inv.setStack(i, ItemStack.EMPTY);
        inv.setStack(40, ItemStack.EMPTY);
        inv.markDirty();
        player.currentScreenHandler.updateToClient();
        if (snap != null) {
            // keep vitals consistent with the pre-duel state
            player.setHealth(Math.max(1f, snap.health));
            player.getHungerManager().setFoodLevel(snap.food);
            player.getHungerManager().setSaturationLevel(snap.saturation);
        }
        session(player).preDuel = null;
        PvPCore.get().snapshotStore().delete(player.getUuid());
    }

    /** Teleport back to the snapshot position. */
    public void teleportToSnapshot(ServerPlayerEntity player, InventorySnapshot snap) {
        if (snap == null) return;
        var server = PvPCore.get().server();
        var world = TeleportUtil.world(server, snap.world);
        if (world == null) world = player.getEntityWorld();
        TeleportUtil.teleport(player, world, snap.x, snap.y, snap.z, snap.yaw, snap.pitch);
    }

    // ------------------------------------------------------------------
    // Lock & state
    // ------------------------------------------------------------------

    /** Requirement 1: is the player's own inventory locked? */
    public boolean isInventoryLocked(ServerPlayerEntity player) {
        var cfg = PvPCore.get().config();
        if (!cfg.lobby.lockInventory) return false;
        Session session = sessions.get(player.getUuid());
        if (session == null) return false;
        if (!session.loginSynced) return false; // requirement 3: never during login
        boolean active = session.state == PlayerState.LOBBY || session.state == PlayerState.QUEUEING
                // Issue 8: spectators are locked too (configurable)
                || (session.state == PlayerState.SPECTATING && cfg.lobby.lockSpectators);
        if (!active) return false;
        if (PvPCore.get().guiManager().hasGuiOpen(player)) return false;
        // Issue 8: admins are locked by default; set adminBypassLock=true to free them
        if (isAdmin(player) && cfg.lobby.adminBypassLock) return false;
        return true;
    }

    /** New permission system check: at least gamemaster (level 2). */
    public static boolean isAdmin(ServerPlayerEntity player) {
        try {
            var perms = player.getPermissions();
            if (perms instanceof net.minecraft.command.permission.LeveledPermissionPredicate leveled) {
                return leveled.getLevel().isAtLeast(net.minecraft.command.permission.PermissionLevel.GAMEMASTERS);
            }
            return false;
        } catch (Throwable t) {
            return false;
        }
    }

    /** Command-source variant of the admin check. */
    public static boolean isAdminSource(net.minecraft.server.command.ServerCommandSource source) {
        try {
            var perms = source.getPermissions();
            if (perms instanceof net.minecraft.command.permission.LeveledPermissionPredicate leveled) {
                return leveled.getLevel().isAtLeast(net.minecraft.command.permission.PermissionLevel.GAMEMASTERS);
            }
            return false;
        } catch (Throwable t) {
            return false;
        }
    }

    public Session session(ServerPlayerEntity player) {
        return sessions.computeIfAbsent(player.getUuid(), u -> new Session());
    }

    public PlayerState state(ServerPlayerEntity player) {
        Session s = sessions.get(player.getUuid());
        return s != null ? s.state : PlayerState.LOBBY;
    }

    public void setState(ServerPlayerEntity player, PlayerState state) {
        session(player).state = state;
    }

    public boolean loginSynced(ServerPlayerEntity player) {
        Session s = sessions.get(player.getUuid());
        return s == null || s.loginSynced; // unknown players treated as synced
    }

    public void teleportToLobby(ServerPlayerEntity player) {
        var cfg = PvPCore.get().config().lobby;
        var world = TeleportUtil.world(PvPCore.get().server(), cfg.lobbyWorld);
        if (world == null) world = player.getEntityWorld();
        TeleportUtil.teleport(player, world, cfg.lobbyX, cfg.lobbyY, cfg.lobbyZ, cfg.lobbyYaw, cfg.lobbyPitch);
    }

    /** Refresh lobby items for everyone (config reload / party change). */
    public void refreshAllLobby() {
        var server = PvPCore.get().server();
        if (server == null) return;
        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            Session s = sessions.get(player.getUuid());
            if (s == null || !s.loginSynced) continue;
            if (s.state == PlayerState.LOBBY || s.state == PlayerState.QUEUEING) {
                giveLobbyItems(player);
            }
        }
    }

    /** Refresh a single player's lobby items (party/queue state changed). */
    public void refreshLobby(ServerPlayerEntity player) {
        Session s = sessions.get(player.getUuid());
        if (s == null || !s.loginSynced) return;
        if (s.state == PlayerState.LOBBY || s.state == PlayerState.QUEUEING) {
            giveLobbyItems(player);
        }
    }
}
