package com.pvpcore.player;

/** Player lifecycle states inside PvP Core. */
public enum PlayerState {
    /** In the lobby with locked hotbar items. */
    LOBBY,
    /** Waiting in a matchmaking queue (lobby items still shown). */
    QUEUEING,
    /** Fighting in a duel. */
    DUELING,
    /** Spectating a duel. */
    SPECTATING
}
