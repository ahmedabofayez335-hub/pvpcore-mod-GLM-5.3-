package com.pvpcore.player;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.pvpcore.PvPCoreMod;
import com.pvpcore.util.ItemCodecUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Crash-safe pending inventory restores.
 * A snapshot is written to disk when a duel starts and deleted once restored,
 * so even after a server crash mid-duel players get their items back on join.
 */
public final class SnapshotStore {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();

    public static class Pending {
        public String world;
        public double x, y, z;
        public float yaw, pitch;
        public float health = 20f;
        public int food = 20;
        public float saturation = 5f;
        public int xpLevel;
        public float xpProgress;
        public int selectedSlot;
        public List<String> main = new ArrayList<>();
        public List<String> armor = new ArrayList<>();
        public String offhand = "";
    }

    private final Path dir;

    public SnapshotStore(Path dataDir) {
        this.dir = dataDir.resolve("pending");
        try {
            Files.createDirectories(dir);
        } catch (IOException e) {
            PvPCoreMod.LOGGER.error("Failed to create pending dir", e);
        }
    }

    public void save(UUID uuid, InventorySnapshot snapshot) {
        Pending p = new Pending();
        p.world = snapshot.world;
        p.x = snapshot.x; p.y = snapshot.y; p.z = snapshot.z;
        p.yaw = snapshot.yaw; p.pitch = snapshot.pitch;
        p.health = snapshot.health;
        p.food = snapshot.food;
        p.saturation = snapshot.saturation;
        p.xpLevel = snapshot.xpLevel;
        p.xpProgress = snapshot.xpProgress;
        p.selectedSlot = snapshot.selectedSlot;
        for (int i = 0; i < 36; i++) p.main.add(ItemCodecUtil.toSnbt(snapshot.main[i]));
        for (int i = 0; i < 4; i++) p.armor.add(ItemCodecUtil.toSnbt(snapshot.armor[i]));
        p.offhand = ItemCodecUtil.toSnbt(snapshot.offhand);
        try {
            Path tmp = dir.resolve(uuid + ".json.tmp");
            Path file = dir.resolve(uuid + ".json");
            Files.writeString(tmp, GSON.toJson(p), StandardCharsets.UTF_8);
            Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException e) {
            PvPCoreMod.LOGGER.error("Failed to save pending snapshot for {}", uuid, e);
        }
    }

    public boolean has(UUID uuid) {
        return Files.exists(dir.resolve(uuid + ".json"));
    }

    public Pending load(UUID uuid) {
        try {
            return GSON.fromJson(Files.readString(dir.resolve(uuid + ".json"), StandardCharsets.UTF_8), Pending.class);
        } catch (Exception e) {
            return null;
        }
    }

    public void delete(UUID uuid) {
        try {
            Files.deleteIfExists(dir.resolve(uuid + ".json"));
        } catch (IOException ignored) {}
    }

    /** Restore a pending snapshot to a player (called on join after a crash/disconnect). */
    public void restore(ServerPlayerEntity player) {
        UUID uuid = player.getUuid();
        Pending p = load(uuid);
        if (p == null) return;
        var inv = player.getInventory();
        for (int i = 0; i < 36; i++) inv.setStack(i, ItemStack.EMPTY);
        for (int i = 36; i < 41; i++) inv.setStack(i, ItemStack.EMPTY);
        for (int i = 0; i < Math.min(36, p.main.size()); i++) {
            ItemStack st = ItemCodecUtil.fromSnbt(p.main.get(i));
            if (!st.isEmpty()) inv.setStack(i, st);
        }
        for (int i = 0; i < Math.min(4, p.armor.size()); i++) {
            ItemStack st = ItemCodecUtil.fromSnbt(p.armor.get(i));
            if (!st.isEmpty()) inv.setStack(36 + i, st);
        }
        ItemStack off = ItemCodecUtil.fromSnbt(p.offhand);
        if (!off.isEmpty()) inv.setStack(40, off);
        inv.setSelectedSlot(p.selectedSlot);
        inv.markDirty();
        player.currentScreenHandler.sendContentUpdates();
        delete(uuid);
        PvPCoreMod.LOGGER.info("Restored pending inventory for {}", player.getGameProfile().name());
    }
}
