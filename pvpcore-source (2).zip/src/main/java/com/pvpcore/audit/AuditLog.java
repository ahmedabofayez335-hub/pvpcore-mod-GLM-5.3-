package com.pvpcore.audit;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.pvpcore.PvPCoreMod;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

/**
 * Audit log of admin actions (bounded to the last 500 entries).
 */
public final class AuditLog {
    public record Entry(long timestamp, String actor, String action) {}

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private static final int MAX_ENTRIES = 500;

    private final Path file;
    private List<Entry> entries = new ArrayList<>();

    public AuditLog(Path dataDir) {
        this.file = dataDir.resolve("audit.json");
        load();
    }

    private void load() {
        if (Files.exists(file)) {
            try {
                entries = GSON.fromJson(Files.readString(file, StandardCharsets.UTF_8),
                        new TypeToken<List<Entry>>() {}.getType());
                if (entries == null) entries = new ArrayList<>();
            } catch (Exception e) {
                PvPCoreMod.LOGGER.error("Failed to load audit.json", e);
            }
        }
    }

    public void log(String actor, String action) {
        entries.add(new Entry(Instant.now().toEpochMilli(), actor, action));
        while (entries.size() > MAX_ENTRIES) entries.remove(0);
        PvPCoreMod.LOGGER.info("[Audit] {}: {}", actor, action);
    }

    public void save() {
        try {
            Files.createDirectories(file.getParent());
            Path tmp = file.resolveSibling("audit.json.tmp");
            Files.writeString(tmp, GSON.toJson(entries), StandardCharsets.UTF_8);
            Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException e) {
            PvPCoreMod.LOGGER.error("Failed to save audit.json", e);
        }
    }

    public List<Entry> entries() {
        return entries;
    }
}
