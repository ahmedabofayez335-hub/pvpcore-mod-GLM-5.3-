package com.pvpcore;

import com.pvpcore.arena.ArenaManager;
import com.pvpcore.audit.AuditLog;
import com.pvpcore.chat.ChatRouter;
import com.pvpcore.config.GuiConfig;
import com.pvpcore.config.MainConfig;
import com.pvpcore.config.Messages;
import com.pvpcore.data.Storage;
import com.pvpcore.duel.Duel;
import com.pvpcore.duel.DuelManager;
import com.pvpcore.gui.GuiManager;
import com.pvpcore.kit.KitManager;
import com.pvpcore.leaderboard.LeaderboardManager;
import com.pvpcore.party.PartyManager;
import com.pvpcore.player.PlayerManager;
import com.pvpcore.player.PlayerState;
import com.pvpcore.queue.QueueManager;
import com.pvpcore.scoreboard.LobbyScoreboardManager;
import com.pvpcore.spectate.SpectateManager;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

import java.nio.file.Path;

/**
 * Central hub holding the server reference and all managers.
 */
public final class PvPCore {
    private static PvPCore instance;

    private MinecraftServer server;
    private Path configDir;
    private Path dataDir;

    private MainConfig mainConfig;
    private GuiConfig guiConfig;
    private Messages messages;
    private Storage storage;
    private com.pvpcore.player.SnapshotStore snapshotStore;
    private GuiManager guiManager;
    private PlayerManager playerManager;
    private KitManager kitManager;
    private ArenaManager arenaManager;
    private DuelManager duelManager;
    private QueueManager queueManager;
    private PartyManager partyManager;
    private LeaderboardManager leaderboardManager;
    private SpectateManager spectateManager;
    private LobbyScoreboardManager lobbyScoreboardManager;
    private ChatRouter chatRouter;
    private AuditLog auditLog;

    public static PvPCore init() {
        if (instance == null) instance = new PvPCore();
        return instance;
    }

    public static PvPCore get() {
        return instance != null ? instance : init();
    }

    private PvPCore() {}

    public void onServerStarted(MinecraftServer server) {
        this.server = server;
        Path gameDir = server.getRunDirectory().toAbsolutePath();
        // Fabric servers: use the server's own directory
        this.configDir = gameDir.resolve("config").resolve("pvp");
        this.dataDir = gameDir.resolve("data").resolve("pvp");

        try {
            java.nio.file.Files.createDirectories(configDir);
            java.nio.file.Files.createDirectories(dataDir);
        } catch (Exception e) {
            PvPCoreMod.LOGGER.error("Failed to create pvp directories", e);
        }

        mainConfig = new MainConfig();
        mainConfig.load(configDir);
        guiConfig = new GuiConfig();
        guiConfig.load(configDir);
        messages = new Messages();
        messages.load(configDir);
        auditLog = new AuditLog(dataDir);
        storage = new Storage(dataDir);
        snapshotStore = new com.pvpcore.player.SnapshotStore(dataDir);
        kitManager = new KitManager(dataDir);
        arenaManager = new ArenaManager(dataDir);
        guiManager = new GuiManager();
        leaderboardManager = new LeaderboardManager();
        chatRouter = new ChatRouter();
        playerManager = new PlayerManager();
        duelManager = new DuelManager();
        queueManager = new QueueManager();
        partyManager = new PartyManager();
        spectateManager = new SpectateManager();
        lobbyScoreboardManager = new LobbyScoreboardManager();

        // Load all stored player data so leaderboards include offline players
        storage.loadAll();
        leaderboardManager.refresh();

        PvPCoreMod.LOGGER.info("PvP Core started. Kits: {}, Arenas: {}, Players on record: {}",
                kitManager.all().size(), arenaManager.all().size(), storage.all().size());
    }

    public void onServerStopping() {
        if (duelManager != null) duelManager.shutdown();
        if (partyManager != null) partyManager.shutdown();
        if (queueManager != null) queueManager.shutdown();
        if (spectateManager != null) spectateManager.shutdown();
        if (lobbyScoreboardManager != null) lobbyScoreboardManager.shutdown();
        if (playerManager != null) playerManager.saveAllNow();
        if (storage != null) storage.saveAll();
        if (kitManager != null) kitManager.save();
        if (arenaManager != null) arenaManager.save();
        if (auditLog != null) auditLog.save();
        PvPCoreMod.LOGGER.info("PvP Core stopped. All data saved.");
    }

    public void tick() {
        playerManager.tick();
        duelManager.tick();
        queueManager.tick();
        partyManager.tick();
        spectateManager.tick();
        lobbyScoreboardManager.tick();
        playerManager.autosaveTick();
    }

    // Delegated helpers -------------------------------------------------------------

    /** Is this player's inventory locked (requirement 1)? */
    public boolean isInventoryLocked(ServerPlayerEntity player) {
        return playerManager != null && playerManager.isInventoryLocked(player);
    }

    /**
     * Issue 8 (2.2.0): block USING items (food, pearls, potions, tools)
     * while the player is locked in the lobby / queue / spectating.
     */
    public boolean isItemUseBlocked(ServerPlayerEntity player) {
        if (playerManager == null) return false;
        var cfg = config().lobby;
        if (!cfg.blockItemUse) return false;
        if (!playerManager.loginSynced(player)) return false;
        PlayerState state = playerManager.state(player);
        boolean active = state == PlayerState.LOBBY || state == PlayerState.QUEUEING
                || state == PlayerState.SPECTATING;
        if (!active) return false;
        if (PlayerManager.isAdmin(player) && cfg.adminBypassLock) return false;
        return true;
    }

    /**
     * Issue 8 (2.2.0): block placing / breaking / interacting with blocks
     * while the player is in the lobby / queue / spectating.
     */
    public boolean isWorldInteractionBlocked(ServerPlayerEntity player) {
        if (playerManager == null) return false;
        var cfg = config().lobby;
        if (!cfg.blockWorldInteraction) return false;
        if (!playerManager.loginSynced(player)) return false;
        PlayerState state = playerManager.state(player);
        boolean active = state == PlayerState.LOBBY || state == PlayerState.QUEUEING
                || state == PlayerState.SPECTATING;
        if (!active) return false;
        if (PlayerManager.isAdmin(player) && cfg.adminBypassLock) return false;
        return true;
    }

    public MinecraftServer server() { return server; }
    public Path configDir() { return configDir; }
    public Path dataDir() { return dataDir; }
    public MainConfig config() { return mainConfig; }
    public GuiConfig guiConfig() { return guiConfig; }
    public Messages messages() { return messages; }
    public Storage storage() { return storage; }
    public com.pvpcore.player.SnapshotStore snapshotStore() { return snapshotStore; }
    public GuiManager guiManager() { return guiManager; }
    public PlayerManager playerManager() { return playerManager; }
    public KitManager kitManager() { return kitManager; }
    public ArenaManager arenaManager() { return arenaManager; }
    public DuelManager duelManager() { return duelManager; }
    public QueueManager queueManager() { return queueManager; }
    public PartyManager partyManager() { return partyManager; }
    public LeaderboardManager leaderboardManager() { return leaderboardManager; }
    public SpectateManager spectateManager() { return spectateManager; }
    public LobbyScoreboardManager lobbyScoreboardManager() { return lobbyScoreboardManager; }
    public ChatRouter chatRouter() { return chatRouter; }
    public AuditLog auditLog() { return auditLog; }

    /** Reload all configs (admin). */
    public long reloadConfigs() {
        long start = System.currentTimeMillis();
        mainConfig.load(configDir);
        guiConfig.load(configDir);
        messages.load(configDir);
        playerManager.refreshAllLobby();
        return System.currentTimeMillis() - start;
    }
}
