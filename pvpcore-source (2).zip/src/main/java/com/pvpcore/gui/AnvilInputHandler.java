package com.pvpcore.gui;

import com.pvpcore.PvPCore;
import com.pvpcore.item.ItemBuilder;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.AnvilScreenHandler;
import net.minecraft.screen.ScreenHandlerContext;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.function.Consumer;

/**
 * Server-driven anvil text input: the player types the name inside the GUI
 * (no chat commands needed - requirement 11) and clicks the confirm item.
 */
public class AnvilInputHandler extends AnvilScreenHandler {
    private final ServerPlayerEntity player;
    private final Consumer<String> callback;
    private String currentName = "";

    public AnvilInputHandler(int syncId, PlayerInventory playerInventory, ServerPlayerEntity player,
                             Consumer<String> callback) {
        super(syncId, playerInventory, ScreenHandlerContext.EMPTY);
        this.player = player;
        this.callback = callback;
        // the rename packet is only processed when slot 0 has an item
        this.getSlot(0).setStackNoCallbacks(ItemBuilder.of("PAPER")
                .name("&fType a name...")
                .build());
        this.getSlot(1).setStackNoCallbacks(ItemBuilder.of("LIME_DYE")
                .name("&a&lConfirm")
                .lore("&7Click to confirm the name above.")
                .build());
    }

    @Override
    public boolean setNewItemName(String name) {
        // called by the server when the client types in the anvil text field
        this.currentName = name == null ? "" : name;
        return true;
    }

    @Override
    public boolean canTakeOutput(PlayerEntity player, boolean present) {
        return false;
    }

    @Override
    public void onSlotClick(int slotIndex, int button, SlotActionType actionType, PlayerEntity player) {
        if (slotIndex == 1) {
            // confirm
            String name = currentName == null ? "" : currentName.trim();
            // server side this is always a ServerPlayerEntity (public closeHandledScreen)
            ((ServerPlayerEntity) player).closeHandledScreen();
            if (!name.isEmpty()) {
                callback.accept(name);
            } else {
                player.sendMessage(Text.literal(
                        com.pvpcore.PvPCore.get().messages().get("input.invalid-name")), false);
            }
            return;
        }
        // cancel every other interaction (items can not be taken out)
        this.sendContentUpdates();
        this.syncState();
    }

    @Override
    public void onClosed(PlayerEntity player) {
        // don't drop the anvil contents
        this.setCursorStack(ItemStack.EMPTY);
        super.onClosed(player);
    }
}
