package com.pvpcore.gui;

import net.minecraft.screen.ScreenHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Formatting;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Tracks which GUI each player has open; opens GUIs; validates clicks.
 */
public final class GuiManager {
    private record OpenGui(int syncId, Gui gui) {}

    private final Map<UUID, OpenGui> open = new ConcurrentHashMap<>();

    /** Open a GUI for a player (closes whatever is open). */
    public void open(ServerPlayerEntity player, Gui gui) {
        if (player == null || gui == null) return;
        gui.build();
        var previous = open.get(player.getUuid());
        if (previous != null && previous.syncId == player.currentScreenHandler.syncId) {
            // same sync id -> refresh in place not possible; close first
            player.closeHandledScreen();
        }
        player.openHandledScreen(new net.minecraft.screen.SimpleNamedScreenHandlerFactory(
                (syncId, inv, p) -> new PvPScreenHandler(syncId, inv, gui), gui.title()));
        ScreenHandler handler = player.currentScreenHandler;
        if (handler instanceof PvPScreenHandler pvph) {
            open.put(player.getUuid(), new OpenGui(pvph.syncId, gui));
        }
    }

    /** Called by PvPScreenHandler.onClosed. */
    public void handleClosed(PvPScreenHandler handler, ServerPlayerEntity player) {
        OpenGui current = open.get(player.getUuid());
        if (current != null && current.syncId == handler.syncId) {
            open.remove(player.getUuid());
            current.gui().closed();
        }
    }

    /** GUI currently open for a player (or null). */
    public Gui openGui(ServerPlayerEntity player) {
        OpenGui current = open.get(player.getUuid());
        if (current != null && player.currentScreenHandler instanceof PvPScreenHandler h && h.syncId == current.syncId) {
            return current.gui();
        }
        return null;
    }

    /** Close any open GUI for a player (server side). */
    public void close(ServerPlayerEntity player) {
        if (player.currentScreenHandler instanceof PvPScreenHandler) {
            player.closeHandledScreen();
        } else {
            OpenGui current = open.remove(player.getUuid());
            if (current != null) current.gui().closed();
        }
    }

    /** Player quit - clean up. */
    public void cleanup(UUID playerId) {
        open.remove(playerId);
    }

    /** Open an anvil text-input GUI (requirement 11: no chat typing). */
    public void openAnvil(ServerPlayerEntity player, String title, java.util.function.Consumer<String> callback) {
        player.openHandledScreen(new net.minecraft.screen.SimpleNamedScreenHandlerFactory(
                (syncId, inv, p) -> new AnvilInputHandler(syncId, inv, player, callback),
                com.pvpcore.util.TextUtil.text(title)));
    }

    /** Does the player have our GUI open? */
    public boolean hasGuiOpen(ServerPlayerEntity player) {
        return openGui(player) != null;
    }
}
