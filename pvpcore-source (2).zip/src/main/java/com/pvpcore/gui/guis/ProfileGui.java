package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.data.PlayerData;
import com.pvpcore.data.PlayerStats;
import com.pvpcore.gui.Gui;
import com.pvpcore.item.ItemBuilder;
import com.pvpcore.kit.Kit;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.ArrayList;
import java.util.List;

/**
 * Profile view: the head uses the player's REAL skin (requirement 8),
 * including skins applied by skin-restorer mods.
 */
public class ProfileGui extends Gui {
    private final ServerPlayerEntity target;

    public ProfileGui(ServerPlayerEntity viewer, ServerPlayerEntity target) {
        super(viewer.getUuid(), "profile", 5);
        this.target = target;
    }

    @Override
    public void build() {
        for (int i = 0; i < 45; i++) set(i, ItemStack.EMPTY);
        PlayerData data = PvPCore.get().storage().get(target.getUuid(), target.getGameProfile().name());
        PlayerStats global = data.globalStats();
        int elo = data.ratingFor("global", PvPCore.get().config().elo.startRating);

        // Requirement 8: skin head (works with skin restorers via server GameProfile)
        set(13, ItemBuilder.of(net.minecraft.item.Items.PLAYER_HEAD)
                .skullOwner(target)
                .name("&e" + target.getGameProfile().name())
                .lore("&7Global ELO: &f" + elo)
                .build());

        set(11, ItemBuilder.of("NETHER_STAR")
                .name("&e&lGlobal Stats")
                .lore("&7Wins: &a" + global.wins,
                      "&7Losses: &c" + global.losses,
                      "&7Win rate: &f" + String.format("%.1f", global.winRate()) + "%",
                      "&7Duels: &f" + global.duels,
                      "&7Hits dealt: &f" + global.hits,
                      "&7Best streak: &6" + global.bestStreak)
                .build());

        // kit stats around
        List<Kit> kits = new ArrayList<>(PvPCore.get().kitManager().all());
        int[] slots = {19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34};
        for (int i = 0; i < slots.length && i < kits.size(); i++) {
            Kit kit = kits.get(i);
            PlayerStats stats = data.statsFor(kit.id);
            set(slots[i], ItemBuilder.of(kit.displayStack())
                    .name(kit.displayName)
                    .lore("&7Wins: &a" + stats.wins,
                          "&7Losses: &c" + stats.losses,
                          "&7ELO: &f" + data.ratingFor(kit.id, PvPCore.get().config().elo.startRating))
                    .build());
        }

        button("close");
        for (int i = 0; i < 45; i++) if (inv.getStack(i).isEmpty()) set(i, filler());
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        if (isLeftClick(type, button) && "close".equals(buttonAt(slot))) {
            PvPCore.get().guiManager().close(player);
        }
    }
}
