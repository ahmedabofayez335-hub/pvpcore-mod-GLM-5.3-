package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.gui.Gui;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.Map;

/**
 * Admin panel: reload configs, save data, manage arenas/kits,
 * set the lobby point - all through GUI (requirement 12).
 */
public class AdminGui extends Gui {
    public AdminGui(ServerPlayerEntity player) {
        super(player.getUuid(), "admin", 6);
    }

    @Override
    public void build() {
        fillAll(filler());
        button("reload");
        button("save");
        button("arenas");
        button("kits");
        button("setlobby");
        button("close");
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        if (!isLeftClick(type, button)) return;
        var core = PvPCore.get();
        var mm = core.messages();
        String b = buttonAt(slot);
        switch (b == null ? "" : b) {
            case "reload" -> { // reload configs
                long ms = core.reloadConfigs();
                player.sendMessage(Text.literal(mm.get("reload-done", Map.of("ms", String.valueOf(ms)))), false);
                core.auditLog().log(player.getGameProfile().name(), "Reloaded configs");
                refresh(player);
            }
            case "save" -> { // save data
                core.storage().saveAll();
                core.kitManager().save();
                core.arenaManager().save();
                core.auditLog().save();
                player.sendMessage(Text.literal(mm.get("data-saved")), false);
            }
            case "arenas" -> new ArenaListGui(player).open(player);
            case "kits" -> new KitListGui(player).open(player);
            case "setlobby" -> {
                var cfg = core.config().lobby;
                var world = player.getEntityWorld();
                cfg.lobbyWorld = world.getRegistryKey().getValue().toString();
                cfg.lobbyX = player.getX();
                cfg.lobbyY = player.getY();
                cfg.lobbyZ = player.getZ();
                cfg.lobbyYaw = player.getYaw();
                cfg.lobbyPitch = player.getPitch();
                core.config().save();
                core.auditLog().log(player.getGameProfile().name(), "Set lobby spawn");
                player.sendMessage(Text.literal(mm.get("admin.lobby-set")), false);
            }
            case "close" -> core.guiManager().close(player);
            default -> {}
        }
    }
}
