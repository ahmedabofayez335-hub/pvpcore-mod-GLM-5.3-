package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.gui.Gui;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.function.IntConsumer;

/**
 * Issue 6 (2.2.0): the challenger picks how many rounds the whole duel
 * should have (Best of 1 / 3 / 5 / 7). Shown after picking a kit when
 * challenging a specific player or another party.
 */
public class RoundsGui extends Gui {
    private final IntConsumer onPicked;
    private final String opponentName;

    public RoundsGui(ServerPlayerEntity player, String opponentName, IntConsumer onPicked) {
        super(player.getUuid(), "rounds", 3);
        this.onPicked = onPicked;
        this.opponentName = opponentName;
        titleVar("player", opponentName);
    }

    @Override
    public void build() {
        for (int i = 0; i < inv.size(); i++) set(i, ItemStack.EMPTY);
        button("info");
        button("bo1");
        button("bo3");
        button("bo5");
        button("bo7");
        button("back");
        for (int i = 0; i < inv.size(); i++) if (inv.getStack(i).isEmpty()) set(i, filler());
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        if (!isLeftClick(type, button)) return;
        String b = buttonAt(slot);
        int bestOf = switch (b == null ? "" : b) {
            case "bo1" -> 1;
            case "bo3" -> 3;
            case "bo5" -> 5;
            case "bo7" -> 7;
            default -> 0;
        };
        if (bestOf > 0) {
            int max = Math.max(1, PvPCore.get().config().duel.maxBestOf);
            if (bestOf > max) {
                bestOf = (max % 2 == 0) ? max - 1 : max; // keep it odd
            }
            PvPCore.get().guiManager().close(player);
            if (onPicked != null) onPicked.accept(bestOf);
            return;
        }
        if ("back".equals(b)) {
            PvPCore.get().guiManager().close(player);
        }
    }
}
