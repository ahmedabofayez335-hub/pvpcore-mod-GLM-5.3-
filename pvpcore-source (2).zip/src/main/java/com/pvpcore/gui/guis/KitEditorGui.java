package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.data.PlayerData;
import com.pvpcore.gui.Gui;
import com.pvpcore.item.ItemBuilder;
import com.pvpcore.kit.Kit;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.List;
import java.util.Map;

/**
 * Requirement 2 + 9: the kit editor is a full double chest (54 slots).
 *
 * Layout:
 *  - slots 0-3   : armor (helmet / chest / legs / boots)
 *  - slots 9-17  : hotbar items
 *  - slots 18-44 : main inventory items
 *  - slot 45     : back
 *  - slot 46     : enchant target slot (place an item here, click Enchant)
 *  - slot 49     : save
 *  - slot 50     : clear
 *  - slot 51     : item palette (add any item)
 *  - slot 52     : enchant the item in slot 46
 *  - slot 53     : close (auto-saves)
 *
 * Items can be freely moved between the editable chest slots. A save
 * button exists AND everything auto-saves on close.
 */
public class KitEditorGui extends Gui {
    private final String kitId;
    /** Issue 8: when true, edits the KIT TEMPLATE (all players) instead of the personal layout. */
    private final boolean templateMode;
    private boolean dirty = false;
    private boolean firstBuild = true;

    // slot mapping
    public static final int[] ARMOR_SLOTS = {0, 1, 2, 3};
    public static final int[] HOTBAR_SLOTS = {9, 10, 11, 12, 13, 14, 15, 16, 17};
    public static final int[] INV_SLOTS = buildInvSlots();
    public static final int ENCHANT_SLOT = 46;

    private static int[] buildInvSlots() {
        int[] slots = new int[27];
        for (int i = 0; i < 27; i++) slots[i] = 18 + i;
        return slots;
    }

    /** Chest slot -> kit layout index (armor 0-3, hotbar 4-12, inv 13-39). */
    public static int chestToLayout(int slot) {
        if (slot >= 0 && slot <= 3) return slot;
        if (slot >= 9 && slot <= 17) return 4 + (slot - 9);
        if (slot >= 18 && slot <= 44) return 13 + (slot - 18);
        return -1;
    }

    /** Kit layout index -> chest slot. */
    public static int layoutToChest(int layoutIndex) {
        if (layoutIndex >= 0 && layoutIndex <= 3) return layoutIndex;
        if (layoutIndex >= 4 && layoutIndex <= 12) return 9 + (layoutIndex - 4);
        if (layoutIndex >= 13 && layoutIndex <= 39) return 18 + (layoutIndex - 13);
        return -1;
    }

    public KitEditorGui(ServerPlayerEntity player, String kitId) {
        this(player, kitId, false);
    }

    /** Issue 8: templateMode = admins edit the kit template itself. */
    public KitEditorGui(ServerPlayerEntity player, String kitId, boolean templateMode) {
        super(player.getUuid(), "kit_editor", 6);
        this.kitId = kitId;
        this.templateMode = templateMode;
        if (templateMode) titleVar("mode", " &7(Template)");
    }

    @Override
    public boolean allowItemMoves() {
        return true;
    }

    @Override
    public boolean isEditableSlot(int slot) {
        if (slot == slot("enchant_target")) {
            // the marker glass itself can not be picked up
            ItemStack st = inv.getStack(slot);
            return !st.isEmpty() && !isEnchantTargetMarker(st);
        }
        return chestToLayout(slot) >= 0;
    }

    @Override
    public void build() {
        Kit kit = PvPCore.get().kitManager().get(kitId);
        if (kit == null) return;

        ItemStack enchantItem = inv.getStack(ENCHANT_SLOT); // preserve across rebuilds

        // editable area from current inventory content (already loaded on first open)
        if (firstBuild) {
            List<ItemStack> layout;
            if (templateMode) {
                // Issue 8: admins always edit the kit template itself
                layout = kit.layoutStacks();
            } else {
                // Issue 2 (2.2.0): by default the editor starts from the ORIGINAL
                // kit template (as set the first time) - saving stores the
                // player's personal layout. Set kit.editorBaseOnOriginal=false
                // in settings.json to keep editing the last saved layout instead.
                layout = null;
                if (!PvPCore.get().config().kit.editorBaseOnOriginal) {
                    PlayerData data = PvPCore.get().storage().get(playerId, null);
                    if (data != null) layout = data.loadoutFor(kitId);
                }
                if (layout == null || layout.size() < Kit.TOTAL) layout = kit.layoutStacks();
            }
            for (int i = 0; i < Kit.TOTAL; i++) {
                int chestSlot = layoutToChest(i);
                set(chestSlot, layout.get(i) == null ? ItemStack.EMPTY : layout.get(i).copy());
            }
            firstBuild = false;
        } else {
            // keep whatever is in the editable slots right now
        }

        // static buttons
        ItemStack filler = ItemBuilder.of("GRAY_STAINED_GLASS_PANE").name("&r").build();
        for (int i = 4; i <= 8; i++) set(i, filler);
        button("armor_info");
        for (int i = 45; i <= 53; i++) set(i, filler);
        button("back");
        int enchantSlot = slot("enchant_target");
        set(enchantSlot, enchantItem.isEmpty() || isEnchantTargetMarker(enchantItem) ? item("enchant_target") : enchantItem);
        button("save");
        button("clear");
        button("palette");
        button("enchant");
        button("close");
    }

    @Override
    public void itemMoved(ServerPlayerEntity player) {
        dirty = true; // auto-save on close
    }

    @Override
    public void absorbCursor(ItemStack cursor) {
        // put the cursor item into the first empty editable slot
        for (int i = 0; i < Kit.TOTAL; i++) {
            int chestSlot = layoutToChest(i);
            if (inv.getStack(chestSlot).isEmpty()) {
                inv.setStack(chestSlot, cursor);
                return;
            }
        }
        // no space left: save it to the enchant slot if empty
        int enchantSlot = slot("enchant_target");
        if (inv.getStack(enchantSlot).isEmpty()) {
            inv.setStack(enchantSlot, cursor);
        }
    }

    /** Add an item from the palette into the first free layout slot. */
    public boolean addPaletteItem(ItemStack stack) {
        for (int i = 0; i < Kit.TOTAL; i++) {
            int chestSlot = layoutToChest(i);
            if (inv.getStack(chestSlot).isEmpty()) {
                inv.setStack(chestSlot, stack.copy());
                dirty = true;
                return true;
            }
        }
        return false;
    }

    /** Save the current chest content. Issue 8: template mode saves the kit itself. */
    public void save(ServerPlayerEntity player, boolean notify) {
        Kit kit = PvPCore.get().kitManager().get(kitId);
        if (kit == null) return;
        List<ItemStack> layout = new java.util.ArrayList<>(java.util.Collections.nCopies(Kit.TOTAL, ItemStack.EMPTY));
        for (int i = 0; i < Kit.TOTAL; i++) {
            int chestSlot = layoutToChest(i);
            ItemStack st = inv.getStack(chestSlot);
            if (st != null && !st.isEmpty()) layout.set(i, st.copy());
        }
        // sweep the enchant slot too so nothing is lost
        int enchantSlot = slot("enchant_target");
        ItemStack ench = inv.getStack(enchantSlot);
        if (!ench.isEmpty() && !isEnchantTargetMarker(ench)) {
            for (int i = 0; i < Kit.TOTAL; i++) {
                if (layout.get(i).isEmpty()) {
                    layout.set(i, ench.copy());
                    inv.setStack(enchantSlot, ItemStack.EMPTY);
                    break;
                }
            }
        }
        if (templateMode) {
            // Issue 8: save into the kit template (kits.json) - every player
            // without a personal layout will receive exactly this setup.
            kit.setLayout(layout);
            PvPCore.get().kitManager().put(kit);
            PvPCore.get().auditLog().log(player.getGameProfile().name(), "Edited kit template " + kitId);
        } else {
            PlayerData data = PvPCore.get().storage().get(player.getUuid(), player.getGameProfile().name());
            data.setLoadout(kitId, layout);
            PvPCore.get().storage().markDirty(player.getUuid());
        }
        dirty = false;
        if (notify) {
            player.sendMessage(Text.literal(PvPCore.get().messages().get(
                    templateMode ? "kit.template-saved" : "kit.layout-saved",
                    Map.of("kit", kit.displayName))), false);
        }
    }

    private boolean isEnchantTargetMarker(ItemStack stack) {
        return stack.getItem() == net.minecraft.item.Items.YELLOW_STAINED_GLASS_PANE;
    }

    @Override
    public void closed() {
        // Auto-save (requirement 9: save button OR automatically saved)
        if (dirty) {
            var pm = PvPCore.get().server().getPlayerManager();
            ServerPlayerEntity player = pm.getPlayer(playerId);
            if (player != null) save(player, false);
        }
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        if (!isLeftClick(type, button)) return;
        String b = buttonAt(slot);
        switch (b == null ? "" : b) {
            case "back" -> { // back - save and go back
                save(player, false);
                new KitStatsGui(player, kitId).open(player);
            }
            case "save" -> { // save
                save(player, true);
                refresh(player);
            }
            case "clear" -> { // clear
                for (int i = 0; i < Kit.TOTAL; i++) {
                    inv.setStack(layoutToChest(i), ItemStack.EMPTY);
                }
                dirty = true;
                player.sendMessage(Text.literal(PvPCore.get().messages().get("kit.cleared")), false);
                refresh(player);
            }
            case "palette" -> { // item palette
                new ItemPaletteGui(player, this).open(player);
            }
            case "enchant" -> { // enchant the item in the enchant slot
                ItemStack target = inv.getStack(slot("enchant_target"));
                if (target.isEmpty() || isEnchantTargetMarker(target)) {
                    player.sendMessage(Text.literal(PvPCore.get().messages().get("kit.no-item-to-enchant")), false);
                    return;
                }
                new EnchantGui(player, this, target).open(player);
            }
            case "close" -> { // close (auto-saves via closed())
                PvPCore.get().guiManager().close(player);
            }
            default -> {}
        }
    }
}
