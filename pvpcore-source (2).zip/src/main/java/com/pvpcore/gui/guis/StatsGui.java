package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.data.PlayerData;
import com.pvpcore.data.PlayerStats;
import com.pvpcore.gui.Gui;
import com.pvpcore.item.ItemBuilder;
import com.pvpcore.kit.Kit;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.ArrayList;
import java.util.List;

/**
 * Statistics of any player (picked via the player picker).
 */
public class StatsGui extends Gui {
    private final ServerPlayerEntity target;

    public StatsGui(ServerPlayerEntity viewer, ServerPlayerEntity target) {
        super(viewer.getUuid(), "stats", 6);
        this.target = target;
    }

    @Override
    public void build() {
        for (int i = 0; i < 54; i++) set(i, ItemStack.EMPTY);
        PlayerData data = PvPCore.get().storage().get(target.getUuid(), target.getGameProfile().name());
        PlayerStats global = data.globalStats();

        set(4, ItemBuilder.of(net.minecraft.item.Items.PLAYER_HEAD)
                .skullOwner(target)
                .name("&e" + target.getGameProfile().name())
                .lore("&7Global Wins: &a" + global.wins,
                      "&7Global Losses: &c" + global.losses,
                      "&7Global ELO: &f" + data.ratingFor("global", PvPCore.get().config().elo.startRating))
                .build());

        List<Kit> kits = new ArrayList<>(PvPCore.get().kitManager().all());
        int[] slots = new int[36];
        for (int i = 0; i < 36; i++) slots[i] = 9 + i;
        for (int i = 0; i < slots.length && i < kits.size(); i++) {
            Kit kit = kits.get(i);
            PlayerStats stats = data.statsFor(kit.id);
            set(slots[i], ItemBuilder.of(kit.displayStack())
                    .name(kit.displayName)
                    .lore("&7Wins: &a" + stats.wins,
                          "&7Losses: &c" + stats.losses,
                          "&7Win rate: &f" + String.format("%.1f", stats.winRate()) + "%",
                          "&7Hits: &f" + stats.hits,
                          "&7ELO: &f" + data.ratingFor(kit.id, PvPCore.get().config().elo.startRating),
                          "&7Best streak: &6" + stats.bestStreak)
                    .build());
        }

        button("back");
        button("close");
        for (int i = 0; i < 54; i++) if (inv.getStack(i).isEmpty()) set(i, filler());
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        if (!isLeftClick(type, button)) return;
        String b = buttonAt(slot);
        if ("back".equals(b) || "close".equals(b)) {
            PvPCore.get().guiManager().close(player);
        }
    }
}
