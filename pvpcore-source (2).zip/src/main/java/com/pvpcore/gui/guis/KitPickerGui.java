package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.data.PlayerData;
import com.pvpcore.gui.Gui;
import com.pvpcore.item.ItemBuilder;
import com.pvpcore.kit.Kit;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Kit picker used for the queue (ranked/unranked) and for challenging a
 * specific player. Everything GUI - no typing (requirement 11).
 *
 * Issue 6 (2.2.0): when challenging a player (or another party), the kit
 * pick is followed by a Best-of-1/3/5/7 round picker before the challenge
 * is sent.
 */
public class KitPickerGui extends Gui {
    private final boolean ranked;
    private final ServerPlayerEntity challengeTarget;
    /** Issue 1 (2.2.0): true = the challenge is party-vs-party. */
    private final boolean partyMode;
    private int page = 0;

    public KitPickerGui(ServerPlayerEntity player, boolean ranked, ServerPlayerEntity challengeTarget) {
        this(player, ranked, challengeTarget, false);
    }

    public KitPickerGui(ServerPlayerEntity player, boolean ranked, ServerPlayerEntity challengeTarget, boolean partyMode) {
        super(player.getUuid(), "queue", 5);
        this.ranked = ranked;
        this.challengeTarget = challengeTarget;
        this.partyMode = partyMode;
    }

    private List<Kit> kits() {
        return new ArrayList<>(PvPCore.get().kitManager().all()).stream()
                .filter(k -> k.enabled)
                .toList();
    }

    /** Issue 6: kit icon slots are configurable in guis.json (queue.kitSlots). */
    private List<Integer> kitSlots() {
        return PvPCore.get().guiConfig().kitSlots("queue");
    }

    @Override
    public void build() {
        List<Kit> kits = kits();
        List<Integer> kitSlots = kitSlots();
        int perPage = kitSlots.size();
        int pages = Math.max(1, (kits.size() + perPage - 1) / perPage);
        if (page >= pages) page = pages - 1;

        for (int i = 0; i < inv.size(); i++) set(i, ItemStack.EMPTY);
        for (int i = 0; i < kitSlots.size(); i++) {
            int idx = page * perPage + i;
            if (idx < kits.size()) {
                Kit kit = kits.get(idx);
                PlayerData data = PvPCore.get().storage().get(playerId, null);
                int elo = data != null ? data.ratingFor(kit.id, PvPCore.get().config().elo.startRating) : 1000;
                set(kitSlots.get(i), ItemBuilder.of(kit.displayStack())
                        .name(kit.displayName)
                        .lore("&7Click to " + (challengeTarget != null ? "challenge with" : "queue for") + " this kit.",
                              "&7ELO: &f" + elo,
                              ranked ? "&6Ranked mode" : "&bUnranked mode")
                        .build());
            }
        }

        for (int i = 0; i < inv.size(); i++) {
            ItemStack cur = inv.getStack(i);
            if (cur.isEmpty() && !kitSlots.contains(i)) set(i, filler());
        }
        set(4, ItemBuilder.of(com.pvpcore.util.ItemCodecUtil.parseMaterial(ranked ? "NETHERITE_SWORD" : "IRON_SWORD"))
                .name(ranked ? "&6&lRanked Queue" : "&b&lUnranked Queue")
                .lore(challengeTarget != null
                        ? List.of("&7Opponent: &f" + challengeTarget.getGameProfile().name())
                        : List.of("&7Pick a kit to join the queue."))
                .build());
        button("prev");
        button("next");
        button("back");
    }

    /** Hook: what happens when a kit is picked. */
    protected void onKitPicked(ServerPlayerEntity player, String kitId) {
        if (challengeTarget != null) {
            // Issue 6: challenges ask for the round format before being sent
            String who = challengeTarget.getGameProfile().name()
                    + (partyMode ? "'s party" : "");
            new RoundsGui(player, who, bestOf -> {
                if (partyMode) {
                    PvPCore.get().duelManager().sendPartyChallenge(player, challengeTarget, kitId, bestOf);
                } else {
                    PvPCore.get().duelManager().sendChallenge(player, challengeTarget, kitId, bestOf);
                }
            }).open(player);
        } else {
            PvPCore.get().queueManager().join(player, kitId, ranked);
        }
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        if (isLeftClick(type, button) || type == SlotActionType.PICKUP) {
            List<Kit> kits = kits();
            List<Integer> slots = kitSlots();
            int idx = slots.indexOf(slot);
            if (idx >= 0) {
                int kitIdx = page * slots.size() + idx;
                if (kitIdx < kits.size()) {
                    Kit kit = kits.get(kitIdx);
                    PvPCore.get().guiManager().close(player);
                    onKitPicked(player, kit.id);
                }
                return;
            }
            String b = buttonAt(slot);
            if ("prev".equals(b)) {
                page = Math.max(0, page - 1);
                refresh(player);
            } else if ("next".equals(b)) {
                page++;
                refresh(player);
            } else if ("back".equals(b)) {
                PvPCore.get().guiManager().close(player);
            }
        }
    }
}
