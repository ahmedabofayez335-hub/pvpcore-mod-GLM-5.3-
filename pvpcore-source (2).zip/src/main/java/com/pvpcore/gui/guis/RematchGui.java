package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.duel.DuelManager;
import com.pvpcore.gui.Gui;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.Map;

/**
 * Rematch offer GUI shown after a 1v1 duel ends.
 */
public class RematchGui extends Gui {
    private final DuelManager.RematchOffer offer;

    public RematchGui(ServerPlayerEntity player, DuelManager.RematchOffer offer) {
        super(player.getUuid(), "rematch", 3);
        this.offer = offer;
    }

    @Override
    public void build() {
        fillAll(filler());
        var pm = PvPCore.get().server().getPlayerManager();
        var other = pm.getPlayer(offer.playerA.equals(playerId) ? offer.playerB : offer.playerA);
        String otherName = other != null ? other.getGameProfile().name() : "?";
        buttonVar("info", Map.of(
                "player", otherName,
                "kit", PvPCore.get().duelManager().kitDisplayName(offer.kitId)));
        button("accept");
        button("deny");
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        if (isLeftClick(type, button)) {
            String b = buttonAt(slot);
            if ("accept".equals(b)) {
                PvPCore.get().duelManager().acceptRematch(player);
                // if the other player hasn't accepted yet the GUI stays open
                if (PvPCore.get().duelManager().rematchOfferFor(player.getUuid()) == null) {
                    PvPCore.get().guiManager().close(player);
                } else {
                    refresh(player);
                }
            } else if ("deny".equals(b)) {
                PvPCore.get().guiManager().close(player);
                PvPCore.get().duelManager().declineRematch(player);
            }
        }
    }
}
