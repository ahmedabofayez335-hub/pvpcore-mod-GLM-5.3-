package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.duel.DuelRequest;
import com.pvpcore.gui.Gui;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.Map;

/**
 * Accept/deny GUI shown to the target of a duel or party-duel challenge.
 */
public class ChallengeGui extends Gui {
    private final DuelRequest request;

    public ChallengeGui(ServerPlayerEntity player, DuelRequest request) {
        super(player.getUuid(), "challenge", 3);
        this.request = request;
    }

    @Override
    public void build() {
        fillAll(filler());
        var pm = PvPCore.get().server().getPlayerManager();
        var sender = pm.getPlayer(request.sender);
        String senderName = sender != null ? sender.getGameProfile().name() : "?";
        String kitName = PvPCore.get().duelManager().kitDisplayName(request.kitId);
        boolean party = request.type == DuelRequest.Type.PARTY_DUEL;
        if (party) {
            buttonVar("info", Map.of(
                    "player", senderName + "'s party (" + request.senderParty.size() + " players)",
                    "kit", kitName));
        } else {
            buttonVar("info", Map.of("player", senderName, "kit", kitName));
        }
        button("accept");
        button("deny");
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        if (isLeftClick(type, button)) {
            String b = buttonAt(slot);
            if ("accept".equals(b)) {
                PvPCore.get().guiManager().close(player);
                PvPCore.get().duelManager().acceptRequest(player);
            } else if ("deny".equals(b)) {
                PvPCore.get().guiManager().close(player);
                PvPCore.get().duelManager().denyRequest(player);
            }
        }
    }
}
