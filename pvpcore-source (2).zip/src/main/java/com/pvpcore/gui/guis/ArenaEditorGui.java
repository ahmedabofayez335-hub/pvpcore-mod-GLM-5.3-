package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.arena.Arena;
import com.pvpcore.gui.Gui;
import com.pvpcore.util.TeleportUtil;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.Map;

/**
 * Per-arena editor: set spawns to the admin's current location, toggle,
 * validate, teleport, rename (anvil), delete - all GUI (requirement 12).
 */
public class ArenaEditorGui extends Gui {
    private final String arenaId;

    public ArenaEditorGui(ServerPlayerEntity player, String arenaId) {
        super(player.getUuid(), "arena_editor", 5);
        this.arenaId = arenaId;
    }

    private Arena arena() {
        return PvPCore.get().arenaManager().get(arenaId);
    }

    @Override
    public void build() {
        Arena arena = arena();
        if (arena == null) return;
        fillAll(filler());

        buttonVar("info", Map.of(
                "arena", arena.displayName,
                "status", arena.statusColored(),
                "spawns", (arena.spawn1Set ? "&a1" : "&c-") + "&7/&f" + (arena.spawn2Set ? "&a2" : "&c-")
                        + "&7 spec:" + (arena.spectatorSet ? "&aY" : "&c-")));
        button("setspawn1");
        button("setspawn2");
        button("setspectator");
        button("teleport");
        buttonVar("enable", Map.of("status", arena.enabled ? "&aEnabled" : "&cDisabled"));
        button("validate");
        button("rename");
        button("delete");
        button("back");
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        if (!isLeftClick(type, button)) return;
        Arena arena = arena();
        if (arena == null) return;
        var core = PvPCore.get();
        var mm = core.messages();
        var audit = core.auditLog();
        String actor = player.getGameProfile().name();
        String b = buttonAt(slot);
        switch (b == null ? "" : b) {
            case "setspawn1" -> { // spawn 1 = current location
                var world = player.getEntityWorld();
                arena.world = world.getRegistryKey().getValue().toString();
                arena.spawn1X = player.getX();
                arena.spawn1Y = player.getY();
                arena.spawn1Z = player.getZ();
                arena.spawn1Yaw = player.getYaw();
                arena.spawn1Pitch = player.getPitch();
                arena.spawn1Set = true;
                core.arenaManager().save();
                audit.log(actor, "Set spawn 1 of arena " + arena.id);
                player.sendMessage(Text.literal(mm.get("arena.spawn-set", Map.of(
                        "arena", arena.id, "spawn", "Spawn 1"))), false);
                refresh(player);
            }
            case "setspawn2" -> { // spawn 2 = current location
                var world = player.getEntityWorld();
                arena.world = world.getRegistryKey().getValue().toString();
                arena.spawn2X = player.getX();
                arena.spawn2Y = player.getY();
                arena.spawn2Z = player.getZ();
                arena.spawn2Yaw = player.getYaw();
                arena.spawn2Pitch = player.getPitch();
                arena.spawn2Set = true;
                core.arenaManager().save();
                audit.log(actor, "Set spawn 2 of arena " + arena.id);
                player.sendMessage(Text.literal(mm.get("arena.spawn-set", Map.of(
                        "arena", arena.id, "spawn", "Spawn 2"))), false);
                refresh(player);
            }
            case "setspectator" -> { // spectator spawn = current location
                var world = player.getEntityWorld();
                arena.world = world.getRegistryKey().getValue().toString();
                arena.spectatorX = player.getX();
                arena.spectatorY = player.getY();
                arena.spectatorZ = player.getZ();
                arena.spectatorYaw = player.getYaw();
                arena.spectatorPitch = player.getPitch();
                arena.spectatorSet = true;
                core.arenaManager().save();
                audit.log(actor, "Set spectator spawn of arena " + arena.id);
                player.sendMessage(Text.literal(mm.get("arena.spawn-set", Map.of(
                        "arena", arena.id, "spawn", "Spectator spawn"))), false);
                refresh(player);
            }
            case "teleport" -> { // teleport
                var world = TeleportUtil.world(core.server(), arena.world);
                if (world != null) {
                    double x = arena.spawn1Set ? arena.spawn1X : arena.spectatorX;
                    double y = arena.spawn1Set ? arena.spawn1Y : arena.spectatorY;
                    double z = arena.spawn1Set ? arena.spawn1Z : arena.spectatorZ;
                    TeleportUtil.teleport(player, world, x, y, z, 0, 0);
                    core.guiManager().close(player);
                    player.sendMessage(Text.literal(mm.get("arena.teleported", Map.of("arena", arena.id))), false);
                }
            }
            case "enable" -> { // toggle enabled
                arena.enabled = !arena.enabled;
                core.arenaManager().save();
                audit.log(actor, (arena.enabled ? "Enabled" : "Disabled") + " arena " + arena.id);
                player.sendMessage(Text.literal(mm.get(arena.enabled ? "arena.enabled" : "arena.disabled", Map.of(
                        "arena", arena.id))), false);
                refresh(player);
            }
            case "validate" -> { // validate
                if (arena.isValid()) {
                    player.sendMessage(Text.literal(mm.get("arena.valid", Map.of("arena", arena.id))), false);
                } else {
                    player.sendMessage(Text.literal(mm.get("arena.invalid", Map.of(
                            "arena", arena.id, "reason", arena.invalidReason()))), false);
                }
            }
            case "rename" -> { // rename via anvil
                core.guiManager().openAnvil(player, "&8Rename Arena", name -> {
                    String clean = name.trim();
                    if (clean.isEmpty() || clean.length() > 32) {
                        player.sendMessage(Text.literal(mm.get("input.invalid-name")), false);
                        return;
                    }
                    arena.displayName = "&f" + clean;
                    core.arenaManager().save();
                    audit.log(player.getGameProfile().name(), "Renamed arena " + arena.id + " to " + clean);
                    player.sendMessage(Text.literal(mm.get("arena.renamed", Map.of("name", clean))), false);
                    new ArenaEditorGui(player, arena.id).open(player);
                });
            }
            case "delete" -> { // delete (confirm)
                new ConfirmGui(player, "&cDelete arena " + arena.id + "?", () -> {
                    if (arena.status != Arena.Status.FREE) {
                        player.sendMessage(Text.literal(mm.get("arena.in-use")), false);
                        return;
                    }
                    core.arenaManager().delete(arena.id);
                    audit.log(player.getGameProfile().name(), "Deleted arena " + arena.id);
                    player.sendMessage(Text.literal(mm.get("arena.deleted", Map.of("arena", arena.id))), false);
                }, () -> new ArenaEditorGui(player, arena.id).open(player)).open(player);
            }
            case "back" -> new ArenaListGui(player).open(player);
            default -> {}
        }
    }
}
