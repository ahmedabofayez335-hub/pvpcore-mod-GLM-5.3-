package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.duel.Duel;
import com.pvpcore.duel.DuelState;
import com.pvpcore.gui.Gui;
import com.pvpcore.item.ItemBuilder;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.List;

/**
 * Lists ongoing duels; click one to spectate it.
 */
public class SpectateGui extends Gui {
    private int page = 0;

    public SpectateGui(ServerPlayerEntity player) {
        super(player.getUuid(), "spectate", 6);
    }

    @Override
    public void build() {
        List<Duel> duels = PvPCore.get().duelManager().activeDuels();
        int perPage = 27;
        int pages = Math.max(1, (duels.size() + perPage - 1) / perPage);
        if (page >= pages) page = pages - 1;

        for (int i = 0; i < 54; i++) set(i, ItemStack.EMPTY);

        int[] slots = new int[perPage];
        int s = 0;
        for (int row = 2; row <= 4 && s < perPage; row++) {
            for (int col = 1; col <= 7 && s < perPage; col++) {
                slots[s++] = row * 9 + col;
            }
        }
        for (int i = 0; i < perPage; i++) {
            int idx = page * perPage + i;
            if (idx < duels.size()) {
                Duel duel = duels.get(idx);
                String kitName = PvPCore.get().duelManager().kitDisplayName(duel.kitId);
                set(slots[i], ItemBuilder.of(Items.IRON_SWORD)
                        .name("&e" + duel.firstAName() + " &7vs &e" + duel.firstBName())
                        .lore("&7Kit: &f" + kitName,
                              "&7Ranked: " + (duel.ranked ? "&6Yes" : "&7No"),
                              "&7State: &f" + (duel.state == DuelState.COUNTDOWN ? "Starting" : "Fighting"),
                              "",
                              "&aClick to spectate")
                        .build());
            }
        }

        button("info");
        button("prev");
        button("back");
        button("next");

        for (int i = 0; i < 54; i++) if (inv.getStack(i).isEmpty()) set(i, filler());
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        if (!isLeftClick(type, button)) return;
        List<Duel> duels = PvPCore.get().duelManager().activeDuels();
        int[] slots = new int[27];
        int s = 0;
        for (int row = 2; row <= 4 && s < 27; row++) {
            for (int col = 1; col <= 7 && s < 27; col++) {
                slots[s++] = row * 9 + col;
            }
        }
        for (int i = 0; i < 27; i++) {
            if (slots[i] == slot) {
                int idx = page * 27 + i;
                if (idx < duels.size()) {
                    PvPCore.get().guiManager().close(player);
                    PvPCore.get().spectateManager().join(player, duels.get(idx));
                }
                return;
            }
        }
        String b = buttonAt(slot);
        if ("prev".equals(b)) {
            page = Math.max(0, page - 1);
            refresh(player);
        } else if ("next".equals(b)) {
            page++;
            refresh(player);
        } else if ("back".equals(b)) {
            PvPCore.get().guiManager().close(player);
        }
    }
}
