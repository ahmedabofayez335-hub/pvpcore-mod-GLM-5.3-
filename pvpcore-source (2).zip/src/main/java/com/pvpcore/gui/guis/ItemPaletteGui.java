package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.gui.Gui;
import com.pvpcore.item.ItemBuilder;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Item palette for the kit editor: every obtainable item, paginated.
 * Click an item to add it to your kit layout (requirement 9/11: GUI only).
 */
public class ItemPaletteGui extends Gui {
    private static final Set<String> EXCLUDED = Set.of(
            "command_block", "chain_command_block", "repeating_command_block",
            "barrier", "structure_void", "debug_stick", "jigsaw", "structure_block",
            "light", "spawn_egg" // handled by prefix below too
    );

    private final KitEditorGui editor;
    private int page = 0;

    public ItemPaletteGui(ServerPlayerEntity player, KitEditorGui editor) {
        super(player.getUuid(), "palette", 6);
        this.editor = editor;
    }

    private List<ItemStack> items() {
        List<ItemStack> out = new ArrayList<>();
        for (Item item : Registries.ITEM) {
            String id = Registries.ITEM.getId(item).getPath();
            if (EXCLUDED.contains(id) || id.endsWith("_spawn_egg")) continue;
            out.add(new ItemStack(item));
        }
        out.sort(Comparator.comparing(st -> Registries.ITEM.getId(st.getItem()).toString()));
        return out;
    }

    @Override
    public void build() {
        List<ItemStack> items = items();
        int perPage = 45;
        int pages = Math.max(1, (items.size() + perPage - 1) / perPage);
        if (page >= pages) page = pages - 1;

        for (int i = 0; i < 45; i++) {
            int idx = page * perPage + i;
            set(i, idx < items.size() ? items.get(idx) : ItemStack.EMPTY);
        }
        for (int i = 45; i < 54; i++) set(i, filler());
        button("prev");
        button("back");
        buttonVar("page", Map.of("page", String.valueOf(page + 1), "pages", String.valueOf(pages)));
        button("next");
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        if ((type == SlotActionType.PICKUP || type == SlotActionType.QUICK_MOVE) && slot >= 0 && slot < 45) {
            List<ItemStack> items = items();
            int idx = page * 45 + slot;
            if (idx >= items.size()) return;
            ItemStack picked = items.get(idx).copy();
            if (type == SlotActionType.QUICK_MOVE || button == 1) {
                picked.setCount(picked.getMaxCount()); // right click / shift = full stack
            } else {
                picked.setCount(1);
            }
            if (editor.addPaletteItem(picked)) {
                player.sendMessage(Text.literal(PvPCore.get().messages().get("kit.item-added", Map.of(
                        "item", picked.getName().getString()))), true);
            }
            return;
        }
        String b = buttonAt(slot);
        if (isLeftClick(type, button)) {
            if ("prev".equals(b)) {
                page = Math.max(0, page - 1);
                refresh(player);
            } else if ("next".equals(b)) {
                page++;
                refresh(player);
            } else if ("back".equals(b)) {
                // back to the editor
                editor.open(player);
            }
        }
    }
}
