package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.data.PlayerData;
import com.pvpcore.data.PlayerStats;
import com.pvpcore.gui.Gui;
import com.pvpcore.item.ItemBuilder;
import com.pvpcore.kit.Kit;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Per-kit statistics + entry point to the kit editor.
 */
public class KitStatsGui extends Gui {
    private final String kitId;

    public KitStatsGui(ServerPlayerEntity player, String kitId) {
        super(player.getUuid(), "kit_stats", 5);
        this.kitId = kitId;
    }

    @Override
    public void build() {
        Kit kit = PvPCore.get().kitManager().get(kitId);
        if (kit == null) return;
        for (int i = 0; i < 45; i++) set(i, ItemStack.EMPTY);

        PlayerData data = PvPCore.get().storage().get(playerId, null);
        PlayerStats stats = data.statsFor(kitId);
        int elo = data.ratingFor(kitId, PvPCore.get().config().elo.startRating);

        set(13, ItemBuilder.of(kit.displayStack())
                .name(kit.displayName)
                .lore("&7Your statistics for this kit.",
                      "",
                      "&7Wins: &a" + stats.wins,
                      "&7Losses: &c" + stats.losses,
                      "&7Win rate: &f" + String.format("%.1f", stats.winRate()) + "%",
                      "&7Hits dealt: &f" + stats.hits,
                      "&7Current streak: &f" + stats.streak,
                      "&7Best streak: &6" + stats.bestStreak,
                      "&7ELO: &f" + elo)
                .build());
        button("edit");
        button("back");
        button("close");

        // Issue 8: admins can edit the kit TEMPLATE (the default layout for everyone)
        ServerPlayerEntity viewer = PvPCore.get().server().getPlayerManager().getPlayer(playerId);
        if (viewer != null && com.pvpcore.player.PlayerManager.isAdmin(viewer)) {
            button("edit_template");
        }

        for (int i = 0; i < 45; i++) {
            if (inv.getStack(i).isEmpty()) set(i, filler());
        }
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        if (!isLeftClick(type, button)) return;
        String b = buttonAt(slot);
        if ("edit".equals(b)) {
            // Requirement 2/9: open the double-chest kit editor
            Kit kit = PvPCore.get().kitManager().get(kitId);
            // Issue 2 (2.2.0): the editor starts from the ORIGINAL template
            if (kit != null && PvPCore.get().config().kit.editorBaseOnOriginal) {
                player.sendMessage(Text.literal(PvPCore.get().messages().get(
                        "kit.editor-original", Map.of("kit", kit.displayName))), false);
            }
            new KitEditorGui(player, kitId).open(player);
        } else if ("edit_template".equals(b)) {
            // Issue 8: admin template editor
            new KitEditorGui(player, kitId, true).open(player);
        } else if ("back".equals(b)) {
            new KitListGui(player).open(player);
        } else if ("close".equals(b)) {
            PvPCore.get().guiManager().close(player);
        }
    }
}
