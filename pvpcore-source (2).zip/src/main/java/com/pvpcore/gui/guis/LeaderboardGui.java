package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.gui.Gui;
import com.pvpcore.item.ItemBuilder;
import com.pvpcore.kit.Kit;
import com.pvpcore.leaderboard.LeaderboardManager;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Leaderboards: global or per kit, by wins or ELO. Pure GUI.
 */
public class LeaderboardGui extends Gui {
    private static final int MODE_GLOBAL = -1;
    private int kitIndex = MODE_GLOBAL; // -1 = global
    private String type = "wins"; // or "elo"
    private int page = 0;

    public LeaderboardGui(ServerPlayerEntity player) {
        super(player.getUuid(), "leaderboard", 6);
    }

    private List<Kit> kits() {
        return new ArrayList<>(PvPCore.get().kitManager().all());
    }

    @Override
    public void build() {
        List<Kit> kits = kits();
        if (kitIndex >= kits.size()) kitIndex = MODE_GLOBAL;

        for (int i = 0; i < 54; i++) set(i, ItemStack.EMPTY);

        // kit selector row 1 (slots 9-16): global first
        set(9, ItemBuilder.of(Items.NETHER_STAR)
                .name("&e&lGlobal")
                .lore(kitIndex == MODE_GLOBAL ? List.of("&aCurrently selected") : List.of("&7Click to view global"))
                .glow(kitIndex == MODE_GLOBAL)
                .build());
        for (int i = 0; i < kits.size() && i < 7; i++) {
            Kit kit = kits.get(i);
            set(10 + i, ItemBuilder.of(kit.displayStack())
                    .name(kit.displayName)
                    .lore(kitIndex == i ? List.of("&aCurrently selected") : List.of("&7Click to view this kit"))
                    .glow(kitIndex == i)
                    .build());
        }

        // entries
        String kitId = kitIndex == MODE_GLOBAL ? "global" : kits.get(kitIndex).id;
        List<LeaderboardManager.Entry> top = PvPCore.get().leaderboardManager().top(kitId, type, 50);
        int perPage = 27;
        int pages = Math.max(1, (top.size() + perPage - 1) / perPage);
        if (page >= pages) page = pages - 1;
        int[] slots = new int[perPage];
        for (int i = 0; i < 7; i++) { /* rows 19-25 and 28-34 */ }
        int s = 0;
        for (int row = 2; row <= 4 && s < perPage; row++) {
            for (int col = 1; col <= 7 && s < perPage; col++) {
                slots[s++] = row * 9 + col;
            }
        }
        for (int i = 0; i < perPage; i++) {
            int idx = page * perPage + i;
            if (idx < top.size()) {
                var entry = top.get(idx);
                set(slots[i], ItemBuilder.of(Items.PLAYER_HEAD)
                        .name("&e#" + (idx + 1) + " &f" + entry.name())
                        .lore("&7" + (type.equals("elo") ? "ELO" : "Wins") + ": &f" + entry.value())
                        .build());
            }
        }

        button("global");
        button("prev");
        buttonVar("switch", Map.of("type", type.equals("elo") ? "ELO" : "Wins"));
        button("next");
        button("back");

        for (int i = 0; i < 54; i++) if (inv.getStack(i).isEmpty()) set(i, filler());
    }

    @Override
    public void click(int slot, int button, SlotActionType type2, ServerPlayerEntity player) {
        List<Kit> kits = kits();
        if (!isLeftClick(type2, button)) return;
        String b = buttonAt(slot);
        if (slot == 9) {
            kitIndex = MODE_GLOBAL;
            page = 0;
            refresh(player);
        } else if (slot >= 10 && slot <= 16) {
            int idx = slot - 10;
            if (idx < kits.size()) {
                kitIndex = idx;
                page = 0;
                refresh(player);
            }
        } else if ("prev".equals(b)) {
            page = Math.max(0, page - 1);
            refresh(player);
        } else if ("next".equals(b)) {
            page++;
            refresh(player);
        } else if ("switch".equals(b)) {
            type = type.equals("wins") ? "elo" : "wins";
            page = 0;
            refresh(player);
        } else if ("back".equals(b)) {
            PvPCore.get().guiManager().close(player);
        }
    }
}
