package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.arena.Arena;
import com.pvpcore.gui.Gui;
import com.pvpcore.item.ItemBuilder;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Arena list + creation. Creating an arena asks for the name through an
 * anvil input GUI (typing happens inside the GUI, not chat - requirement 11).
 */
public class ArenaListGui extends Gui {
    private int page = 0;

    public ArenaListGui(ServerPlayerEntity player) {
        super(player.getUuid(), "arenas", 6);
    }

    private List<Arena> arenas() {
        return new ArrayList<>(PvPCore.get().arenaManager().all());
    }

    @Override
    public void build() {
        List<Arena> arenas = arenas();
        int perPage = 27;
        int pages = Math.max(1, (arenas.size() + perPage - 1) / perPage);
        if (page >= pages) page = pages - 1;

        for (int i = 0; i < 54; i++) set(i, ItemStack.EMPTY);
        int[] slots = new int[perPage];
        int s = 0;
        for (int row = 2; row <= 4 && s < perPage; row++) {
            for (int col = 1; col <= 7 && s < perPage; col++) slots[s++] = row * 9 + col;
        }
        for (int i = 0; i < perPage; i++) {
            int idx = page * perPage + i;
            if (idx < arenas.size()) {
                Arena arena = arenas.get(idx);
                set(slots[i], ItemBuilder.of("GRASS_BLOCK")
                        .name("&e" + arena.id)
                        .lore("&7Display name: &f" + arena.displayName,
                              "&7Status: " + arena.statusColored(),
                              "&7Spawns: &f" + (arena.spawn1Set ? "&a1" : "&c-") +
                                      "&7/&f" + (arena.spawn2Set ? "&a2" : "&c-") +
                                      " &7Spec: &f" + (arena.spectatorSet ? "&aY" : "&c-"),
                              "",
                              "&eLeft-Click &7to edit",
                              "&dRight-Click &7to teleport")
                        .build());
            }
        }

        buttonVar("info", Map.of("count", String.valueOf(arenas.size())));
        button("create");
        button("prev");
        button("back");
        button("next");

        for (int i = 0; i < 54; i++) if (inv.getStack(i).isEmpty()) set(i, filler());
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        List<Arena> arenas = arenas();
        int[] slots = new int[27];
        int s = 0;
        for (int row = 2; row <= 4 && s < 27; row++) {
            for (int col = 1; col <= 7 && s < 27; col++) slots[s++] = row * 9 + col;
        }
        for (int i = 0; i < 27; i++) {
            if (slots[i] == slot) {
                int idx = page * 27 + i;
                if (idx < arenas.size()) {
                    Arena arena = arenas.get(idx);
                    if (isLeftClick(type, button)) {
                        new ArenaEditorGui(player, arena.id).open(player);
                    } else if (isRightClick(type, button)) {
                        var world = com.pvpcore.util.TeleportUtil.world(PvPCore.get().server(), arena.world);
                        if (world != null) {
                            com.pvpcore.util.TeleportUtil.teleport(player, world,
                                    arena.spawn1Set ? arena.spawn1X : arena.spectatorX,
                                    arena.spawn1Set ? arena.spawn1Y : arena.spectatorY,
                                    arena.spawn1Set ? arena.spawn1Z : arena.spectatorZ, 0, 0);
                            PvPCore.get().guiManager().close(player);
                            player.sendMessage(Text.literal(PvPCore.get().messages().get("arena.teleported", Map.of(
                                    "arena", arena.id))), false);
                        }
                    }
                }
                return;
            }
        }
        if (!isLeftClick(type, button)) return;
        String b = buttonAt(slot);
        if ("create".equals(b)) {
            // create arena: anvil input for the name
            PvPCore.get().guiManager().openAnvil(player, "&8Enter Arena Name", name -> {
                String clean = name.trim();
                if (clean.isEmpty() || clean.length() > 32) {
                    player.sendMessage(Text.literal(PvPCore.get().messages().get("input.invalid-name")), false);
                    return;
                }
                if (PvPCore.get().arenaManager().get(clean) != null) {
                    player.sendMessage(Text.literal(PvPCore.get().messages().get("input.invalid-name")), false);
                    return;
                }
                Arena arena = PvPCore.get().arenaManager().create(clean);
                arena.world = player.getEntityWorld().getRegistryKey().getValue().toString();
                PvPCore.get().arenaManager().save();
                PvPCore.get().auditLog().log(player.getGameProfile().name(), "Created arena " + clean);
                player.sendMessage(Text.literal(PvPCore.get().messages().get("arena.created", Map.of(
                        "arena", clean))), false);
                new ArenaEditorGui(player, arena.id).open(player);
            });
        } else if ("prev".equals(b)) {
            page = Math.max(0, page - 1);
            refresh(player);
        } else if ("next".equals(b)) {
            page++;
            refresh(player);
        } else if ("back".equals(b)) {
            new AdminGui(player).open(player);
        }
    }
}
