package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.gui.Gui;
import com.pvpcore.item.ItemBuilder;
import com.pvpcore.kit.Kit;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.ArrayList;
import java.util.List;

/**
 * Kit browser: left-click opens the kit stats/editor menu, right-click
 * resets the personal layout to the kit default.
 *
 * Issue 5: admins get a "Create Kit" button that snapshots their current
 * inventory into a brand-new kit (anvil input for the name).
 * Issue 6: the kit icon slots are configurable in guis.json (kitSlots).
 */
public class KitListGui extends Gui {
    private int page = 0;

    public KitListGui(ServerPlayerEntity player) {
        super(player.getUuid(), "kit_list", 5);
    }

    private List<Kit> kits() {
        return new ArrayList<>(PvPCore.get().kitManager().all()).stream().filter(k -> k.enabled).toList();
    }

    /** Issue 6: kit icon slots come from guis.json (kit_list.kitSlots). */
    private List<Integer> kitSlots() {
        return PvPCore.get().guiConfig().kitSlots("kit_list");
    }

    @Override
    public void build() {
        List<Kit> kits = kits();
        List<Integer> slots = kitSlots();
        int perPage = slots.size();
        int pages = Math.max(1, (kits.size() + perPage - 1) / perPage);
        if (page >= pages) page = pages - 1;

        for (int i = 0; i < inv.size(); i++) set(i, ItemStack.EMPTY);
        boolean admin = com.pvpcore.player.PlayerManager.isAdmin(
                PvPCore.get().server().getPlayerManager().getPlayer(playerId));
        for (int i = 0; i < slots.size(); i++) {
            int idx = page * perPage + i;
            if (idx < kits.size()) {
                Kit kit = kits.get(idx);
                boolean custom = PvPCore.get().storage().get(playerId, null).loadouts.containsKey(kit.id);
                List<String> lore = new ArrayList<>(List.of(
                        "&7Your layout: " + (custom ? "&aCustom" : "&7Default"),
                        "",
                        "&eLeft-Click &7to view & edit",
                        "&cRight-Click &7to reset to default"));
                if (admin) lore.addAll(List.of("", "&cDrop-Click &7(admin) to DELETE this kit"));
                set(slots.get(i), ItemBuilder.of(kit.displayStack())
                        .name(kit.displayName)
                        .lore(lore)
                        .build());
            }
        }
        for (int i = 0; i < inv.size(); i++) {
            if (inv.getStack(i).isEmpty()) set(i, filler());
        }
        set(4, item("info"));
        // Issue 5: admins create a new kit from their current inventory
        if (admin) button("create");
        button("prev");
        button("next");
        button("close");
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        List<Kit> kits = kits();
        List<Integer> slots = kitSlots();
        int idx = slots.indexOf(slot);
        if (idx >= 0) {
            int kitIdx = page * slots.size() + idx;
            if (kitIdx >= kits.size()) return;
            Kit kit = kits.get(kitIdx);
            if (isLeftClick(type, button)) {
                new KitStatsGui(player, kit.id).open(player);
            } else if (isRightClick(type, button)) {
                var data = PvPCore.get().storage().get(player.getUuid(), player.getGameProfile().name());
                data.loadouts.remove(kit.id);
                PvPCore.get().storage().markDirty(player.getUuid());
                player.sendMessage(net.minecraft.text.Text.literal(
                        PvPCore.get().messages().get("kit.layout-reset", java.util.Map.of(
                                "kit", kit.displayName))), false);
                refresh(player);
            } else if (type == SlotActionType.SWAP || type == SlotActionType.CLONE) {
                // Issue 5/8: admin quick-delete (middle-click / drop-click on a kit icon)
                if (com.pvpcore.player.PlayerManager.isAdmin(player)) {
                    PvPCore.get().kitManager().delete(kit.id);
                    PvPCore.get().auditLog().log(player.getGameProfile().name(), "Deleted kit " + kit.id);
                    player.sendMessage(net.minecraft.text.Text.literal(
                            PvPCore.get().messages().get("kit.deleted", java.util.Map.of("kit", kit.id))), false);
                    refresh(player);
                }
            }
            return;
        }
        if (isLeftClick(type, button)) {
            String b = buttonAt(slot);
            switch (b == null ? "" : b) {
                case "create" -> {
                    // Issue 5: anvil name input -> snapshot the admin's inventory
                    PvPCore.get().guiManager().close(player);
                    PvPCore.get().guiManager().openAnvil(player, "&8New Kit - enter an id",
                            name -> {
                                Kit created = createKitFromInventory(player, name);
                                if (created != null) new KitListGui(player).open(player);
                            });
                }
                case "prev" -> {
                    page = Math.max(0, page - 1);
                    refresh(player);
                }
                case "next" -> {
                    page++;
                    refresh(player);
                }
                case "close" -> PvPCore.get().guiManager().close(player);
                default -> {}
            }
        }
    }

    /** Shared helper: build a kit from the admin's current inventory (issue 5). */
    public static Kit createKitFromInventory(ServerPlayerEntity player, String rawName) {
        var mm = PvPCore.get().messages();
        String id = rawName == null ? "" : rawName.trim().toLowerCase().replaceAll("[^a-z0-9_-]", "");
        if (!com.pvpcore.kit.KitManager.validId(id)) {
            player.sendMessage(net.minecraft.text.Text.literal(mm.get("kit.invalid-name")), false);
            return null;
        }
        if (PvPCore.get().kitManager().get(id) != null) {
            player.sendMessage(net.minecraft.text.Text.literal(
                    mm.get("kit.already-exists", java.util.Map.of("kit", id))), false);
            return null;
        }
        Kit kit = PvPCore.get().kitManager().createFromInventory(id, "&f" + rawName.trim(), player.getInventory());
        PvPCore.get().kitManager().put(kit);
        PvPCore.get().auditLog().log(player.getGameProfile().name(), "Created kit " + id + " from inventory");
        player.sendMessage(net.minecraft.text.Text.literal(
                mm.get("kit.created-from-inventory", java.util.Map.of("kit", id))), false);
        return kit;
    }
}
