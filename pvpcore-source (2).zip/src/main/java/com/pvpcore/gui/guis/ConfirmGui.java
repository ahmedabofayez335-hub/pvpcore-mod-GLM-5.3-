package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.gui.Gui;
import com.pvpcore.util.TextUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Formatting;

import java.util.Map;
import java.util.UUID;
import java.util.function.BiConsumer;

/**
 * Generic confirmation dialog (Yes / No).
 */
public class ConfirmGui extends Gui {
    private final String titleText;
    private final Runnable onYes;
    private final Runnable onNo;

    public ConfirmGui(ServerPlayerEntity player, String title, Runnable onYes, Runnable onNo) {
        super(player.getUuid(), "confirm", 3);
        this.titleText = title;
        this.onYes = onYes;
        this.onNo = onNo;
    }

    @Override
    public void build() {
        fillAll(filler());
        buttonVar("info", Map.of("title", titleText, "lines", ""));
        button("yes");
        button("no");
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        if (isLeftClick(type, button)) {
            String b = buttonAt(slot);
            if ("yes".equals(b)) {
                PvPCore.get().guiManager().close(player);
                if (onYes != null) onYes.run();
            } else if ("no".equals(b)) {
                PvPCore.get().guiManager().close(player);
                if (onNo != null) onNo.run();
            }
        }
    }
}
