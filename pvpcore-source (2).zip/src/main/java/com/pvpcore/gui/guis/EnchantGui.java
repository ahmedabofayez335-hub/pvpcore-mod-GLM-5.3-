package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.gui.Gui;
import com.pvpcore.item.ItemBuilder;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

/**
 * Enchant selector: click an enchantment to cycle its level
 * (1 -> 2 -> ... -> max -> removed). Pure GUI (requirement 11).
 */
public class EnchantGui extends Gui {
    private final KitEditorGui editor;
    private final ItemStack target;
    private int page = 0;

    public EnchantGui(ServerPlayerEntity player, KitEditorGui editor, ItemStack target) {
        super(player.getUuid(), "enchant", 6);
        this.editor = editor;
        this.target = target;
    }

    private List<RegistryEntry<Enchantment>> enchantments() {
        List<RegistryEntry<Enchantment>> out = new ArrayList<>();
        for (RegistryEntry<Enchantment> entry : com.pvpcore.util.EnchantUtil.all()) {
            Enchantment ench = entry.value();
            if (ench.isSupportedItem(target)) {
                out.add(entry);
            }
        }
        out.sort(Comparator.comparing(e -> e.value().description().getString()));
        return out;
    }

    private static String roman(int level) {
        return switch (level) {
            case 1 -> "I";
            case 2 -> "II";
            case 3 -> "III";
            case 4 -> "IV";
            case 5 -> "V";
            case 6 -> "VI";
            case 7 -> "VII";
            case 8 -> "VIII";
            case 9 -> "IX";
            case 10 -> "X";
            default -> String.valueOf(level);
        };
    }

    private static int levelOf(ItemStack stack, RegistryEntry<Enchantment> ench) {
        var levels = stack.getEnchantments();
        return levels == null ? 0 : levels.getLevel(ench);
    }

    @Override
    public void build() {
        List<RegistryEntry<Enchantment>> enchants = enchantments();
        int perPage = 45;
        int pages = Math.max(1, (enchants.size() + perPage - 1) / perPage);
        if (page >= pages) page = pages - 1;

        for (int i = 0; i < 45; i++) {
            int idx = page * perPage + i;
            if (idx < enchants.size()) {
                RegistryEntry<Enchantment> entry = enchants.get(idx);
                Enchantment ench = entry.value();
                int level = levelOf(target, entry);
                int max = ench.getMaxLevel();
                String displayName = ench.description().getString();
                List<String> lore = new ArrayList<>();
                lore.add("&7Max level: &f" + max);
                lore.add("&7Current: " + (level == 0 ? "&cNone" : "&a" + level));
                lore.add("");
                lore.add("&eClick &7to cycle level");
                set(i, ItemBuilder.of("ENCHANTED_BOOK")
                        .name("&d" + displayName + (level > 0 ? " " + roman(level) : ""))
                        .lore(lore)
                        .glow(true)
                        .build());
            } else {
                set(i, ItemStack.EMPTY);
            }
        }
        for (int i = 45; i < 54; i++) set(i, filler());
        button("back");
        set(slot("target"), ItemBuilder.of(target.copy()).name("&dTarget: &f" + target.getName().getString()).build());
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        if (isLeftClick(type, button) || type == SlotActionType.PICKUP) {
            if (slot >= 0 && slot < 45) {
                List<RegistryEntry<Enchantment>> enchants = enchantments();
                int idx = page * 45 + slot;
                if (idx >= enchants.size()) return;
                RegistryEntry<Enchantment> entry = enchants.get(idx);
                Enchantment ench = entry.value();
                int level = levelOf(target, entry);
                int max = ench.getMaxLevel();
                String displayName = ench.description().getString();
                if (level >= max) {
                    // remove this enchantment
                    var builder = new net.minecraft.component.type.ItemEnchantmentsComponent.Builder(target.getEnchantments());
                    final var toRemove = entry; builder.remove(e -> e.equals(toRemove));
                    target.set(net.minecraft.component.DataComponentTypes.ENCHANTMENTS, builder.build());
                    player.sendMessage(Text.literal(PvPCore.get().messages().get("kit.enchant-removed", Map.of(
                            "enchant", displayName))), false);
                } else {
                    target.addEnchantment(entry, level + 1);
                    player.sendMessage(Text.literal(PvPCore.get().messages().get("kit.enchanted", Map.of(
                            "enchant", displayName, "level", String.valueOf(level + 1)))), false);
                }
                editor.itemMoved(player);
                refresh(player);
                return;
            }
            if ("back".equals(buttonAt(slot))) {
                editor.open(player);
            }
        }
    }
}
