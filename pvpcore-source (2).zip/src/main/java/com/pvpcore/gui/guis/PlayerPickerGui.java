package com.pvpcore.gui.guis;

import com.pvpcore.PvPCore;
import com.pvpcore.gui.Gui;
import com.pvpcore.item.ItemBuilder;
import com.pvpcore.player.PlayerState;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;

/**
 * Generic paginated online-player picker (heads) with a callback.
 * Used for: duel opponent, party invite, kick, promote, stats view...
 */
public class PlayerPickerGui extends Gui {
    private final String title;
    private final Consumer<ServerPlayerEntity> callback;
    private final java.util.function.Predicate<ServerPlayerEntity> filter;
    private int page = 0;

    public PlayerPickerGui(ServerPlayerEntity player, String title, Consumer<ServerPlayerEntity> callback) {
        this(player, title, callback, null);
    }

    public PlayerPickerGui(ServerPlayerEntity player, String title, Consumer<ServerPlayerEntity> callback,
                           java.util.function.Predicate<ServerPlayerEntity> filter) {
        super(player.getUuid(), "player_picker", 6);
        this.title = title;
        this.callback = callback;
        this.filter = filter;
    }

    private List<ServerPlayerEntity> targets() {
        List<ServerPlayerEntity> out = new ArrayList<>();
        for (ServerPlayerEntity p : PvPCore.get().server().getPlayerManager().getPlayerList()) {
            if (p.getUuid().equals(playerId)) continue;
            if (filter != null && !filter.test(p)) continue;
            out.add(p);
        }
        out.sort((a, b) -> a.getGameProfile().name().compareToIgnoreCase(b.getGameProfile().name()));
        return out;
    }

    @Override
    public void build() {
        List<ServerPlayerEntity> players = targets();
        int perPage = 36;
        int pages = Math.max(1, (players.size() + perPage - 1) / perPage);
        if (page >= pages) page = pages - 1;

        for (int i = 0; i < 36; i++) {
            int idx = page * perPage + i;
            if (idx < players.size()) {
                ServerPlayerEntity target = players.get(idx);
                var state = PvPCore.get().playerManager().state(target);
                String stateStr = switch (state) {
                    case LOBBY -> "&aLobby";
                    case QUEUEING -> "&eIn Queue";
                    case DUELING -> "&cDueling";
                    case SPECTATING -> "&5Spectating";
                };
                set(i, ItemBuilder.of(Items.PLAYER_HEAD)
                        .skullOwner(target)
                        .name("&e" + target.getGameProfile().name())
                        .lore("&7Status: " + stateStr,
                              "&7Ping: &f" + ping(target) + "ms",
                              "",
                              "&aClick to select")
                        .build());
            } else {
                set(i, ItemStack.EMPTY);
            }
        }
        // bottom row
        for (int i = 36; i < 54; i++) set(i, filler());
        button("prev");
        button("back");
        buttonVar("page", Map.of("page", String.valueOf(page + 1), "pages", String.valueOf(pages)));
        button("next");
    }

    private int ping(ServerPlayerEntity p) {
        try {
            return Math.max(0, p.networkHandler.getLatency());
        } catch (Throwable t) {
            return 0;
        }
    }

    @Override
    public void click(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        if (slot >= 0 && slot < 36) {
            List<ServerPlayerEntity> players = targets();
            int idx = page * 36 + slot;
            if (idx < players.size()) {
                ServerPlayerEntity target = players.get(idx);
                PvPCore.get().guiManager().close(player);
                callback.accept(target);
            }
            return;
        }
        String b = buttonAt(slot);
        if (isLeftClick(type, button)) {
            if ("prev".equals(b)) {
                page = Math.max(0, page - 1);
                refresh(player);
            } else if ("next".equals(b)) {
                page++;
                refresh(player);
            } else if ("back".equals(b)) {
                PvPCore.get().guiManager().close(player);
            }
        }
    }
}
