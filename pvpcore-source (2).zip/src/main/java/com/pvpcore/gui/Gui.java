package com.pvpcore.gui;

import com.pvpcore.PvPCore;
import com.pvpcore.config.GuiConfig;
import com.pvpcore.item.ItemBuilder;
import com.pvpcore.util.TextUtil;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;

/**
 * Base class for all server-driven GUIs. Every GUI is fully driven
 * server side - vanilla clients can use them (requirement 11).
 */
public abstract class Gui {
    protected final UUID playerId;
    protected final String key;
    protected final int rows;
    protected final SimpleInventory inv;
    private final Map<String, String> titleVars;

    protected Gui(UUID playerId, String key, int rows) {
        this.playerId = playerId;
        this.key = key;
        this.rows = Math.max(1, Math.min(6, rows));
        this.inv = new SimpleInventory(this.rows * 9);
        this.titleVars = new java.util.HashMap<>();
    }

    public String key() { return key; }
    public UUID playerId() { return playerId; }
    public SimpleInventory inventory() { return inv; }
    public int rows() { return rows; }

    protected void titleVar(String k, String v) { titleVars.put(k, v); }

    public Text title() {
        String t = PvPCore.get().guiConfig().title(key);
        return TextUtil.text(t, titleVars);
    }

    /** Fill the inventory. Called before opening and on refresh. */
    public abstract void build();

    /** Handle a cancelled click on slot {@code slot}. */
    public abstract void click(int slot, int button, SlotActionType type, ServerPlayerEntity player);

    /** Called when the GUI is closed (server side). */
    public void closed() {}

    /** Whether real item movement is allowed inside this GUI (kit editor). */
    public boolean allowItemMoves() { return false; }

    /** Which chest slots accept item placement when allowItemMoves (kit editor area). */
    public boolean isEditableSlot(int slot) { return false; }

    /** Called after a real item move happened in an editable slot (kit editor autosave). */
    public void itemMoved(ServerPlayerEntity player) {}

    /** Cursor item on close is returned into editable area (kit editor). */
    public void absorbCursor(ItemStack cursor) {}

    /** Open (or refresh) this GUI for its player. */
    public void open(ServerPlayerEntity player) {
        PvPCore.get().guiManager().open(player, this);
    }

    /** Rebuild + resync while open. */
    public void refresh(ServerPlayerEntity player) {
        build();
        player.currentScreenHandler.sendContentUpdates();
    }

    // -------- helpers --------

    protected void set(int slot, ItemStack stack) {
        if (slot >= 0 && slot < inv.size()) inv.setStack(slot, stack);
    }

    /** Configured slot for a button of this GUI (requirement 7/12). */
    protected int slot(String itemKey) {
        return PvPCore.get().guiConfig().item(key, itemKey).slot;
    }

    /** Which configured button lives at this slot (or null)? */
    protected String buttonAt(int slot) {
        var spec = PvPCore.get().guiConfig().guis.get(key);
        if (spec == null) return null;
        for (var e : spec.items.entrySet()) {
            if (e.getValue().slot == slot && e.getValue().enabled) return e.getKey();
        }
        return null;
    }

    /** Place a configured button at its configured slot. */
    protected void button(String itemKey) {
        set(slot(itemKey), item(itemKey));
    }

    /** Place a configured button (with placeholders) at its configured slot. */
    protected void buttonVar(String itemKey, Map<String, String> vars) {
        set(slot(itemKey), itemVar(itemKey, vars));
    }

    protected ItemStack item(String itemKey) {
        return PvPCore.get().guiConfig().buildItem(key, itemKey);
    }

    protected ItemStack itemVar(String itemKey, Map<String, String> vars) {
        GuiConfig.ItemSpec spec = PvPCore.get().guiConfig().item(key, itemKey);
        String name = spec.name;
        java.util.List<String> lore = new java.util.ArrayList<>();
        for (String line : spec.lore) lore.add(line);
        if (vars != null) {
            for (Map.Entry<String, String> e : vars.entrySet()) {
                name = name.replace("{" + e.getKey() + "}", e.getValue());
                for (int i = 0; i < lore.size(); i++) {
                    lore.set(i, lore.get(i).replace("{" + e.getKey() + "}", e.getValue()));
                }
            }
        }
        return ItemBuilder.of(com.pvpcore.util.ItemCodecUtil.parseMaterial(spec.material))
                .amount(spec.amount)
                .name(name)
                .lore(lore)
                .glow(spec.glow)
                .build();
    }

    protected void fillRow(int row, ItemStack stack) {
        int start = row * 9;
        for (int i = 0; i < 9; i++) set(start + i, stack.copy());
    }

    protected void fillAll(ItemStack stack) {
        for (int i = 0; i < inv.size(); i++) set(i, stack.copy());
    }

    protected ItemStack filler() {
        return PvPCore.get().guiConfig().buildItem(key, "filler");
    }

    /** Player head for a viewer (requirement 8: matches skin incl. skin-restorer). */
    protected ItemStack selfHead(ServerPlayerEntity viewer, String name, java.util.List<String> lore) {
        return ItemBuilder.of(net.minecraft.item.Items.PLAYER_HEAD)
                .skullOwner(viewer)
                .name(name)
                .lore(lore)
                .build();
    }

    protected boolean isLeftClick(SlotActionType type, int button) {
        return (type == SlotActionType.PICKUP || type == SlotActionType.QUICK_MOVE) && button == 0;
    }

    protected boolean isRightClick(SlotActionType type, int button) {
        return type == SlotActionType.PICKUP && button == 1;
    }
}
