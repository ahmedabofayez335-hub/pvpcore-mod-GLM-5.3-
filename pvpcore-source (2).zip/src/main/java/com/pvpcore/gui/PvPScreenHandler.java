package com.pvpcore.gui;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;

/**
 * Screen handler for all PvP Core GUIs.
 *
 * - Button GUIs: every click is cancelled and routed to the Gui.
 * - Kit editor: PICKUP clicks inside editable slots perform real item moves.
 */
public class PvPScreenHandler extends ScreenHandler {
    private final Gui gui;
    private final SimpleInventory inv;
    private final int chestSlots;

    public PvPScreenHandler(int syncId, PlayerInventory playerInventory, Gui gui) {
        super(type(gui.rows()), syncId);
        this.gui = gui;
        this.inv = gui.inventory();
        this.chestSlots = gui.rows() * 9;

        // chest slots (same geometry as vanilla generic containers)
        for (int row = 0; row < gui.rows(); row++) {
            for (int col = 0; col < 9; col++) {
                this.addSlot(new Slot(inv, col + row * 9, 8 + col * 18, 18 + row * 18));
            }
        }
        // player inventory + hotbar
        int offset = (gui.rows() - 4) * 18;
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.addSlot(new Slot(playerInventory, 9 + col + row * 9, 8 + col * 18, 103 + row * 18 + offset));
            }
        }
        for (int col = 0; col < 9; col++) {
            this.addSlot(new Slot(playerInventory, col, 8 + col * 18, 161 + offset));
        }
    }

    public Gui gui() {
        return gui;
    }

    private static ScreenHandlerType<?> type(int rows) {
        return switch (rows) {
            case 1 -> ScreenHandlerType.GENERIC_9X1;
            case 2 -> ScreenHandlerType.GENERIC_9X2;
            case 3 -> ScreenHandlerType.GENERIC_9X3;
            case 4 -> ScreenHandlerType.GENERIC_9X4;
            case 5 -> ScreenHandlerType.GENERIC_9X5;
            default -> ScreenHandlerType.GENERIC_9X6;
        };
    }

    @Override
    public boolean canUse(PlayerEntity player) {
        return true;
    }

    @Override
    public ItemStack quickMove(PlayerEntity player, int slot) {
        return ItemStack.EMPTY; // no shift-move transfers out of button GUIs
    }

    @Override
    public void onSlotClick(int slotIndex, int button, SlotActionType actionType, PlayerEntity player) {
        if (!(player instanceof ServerPlayerEntity sp)) return;

        // Real item movement for editable GUIs (kit editor requirement 9)
        if (gui.allowItemMoves()
                && actionType == SlotActionType.PICKUP
                && slotIndex >= 0 && slotIndex < chestSlots
                && gui.isEditableSlot(slotIndex)) {
            super.onSlotClick(slotIndex, button, actionType, player);
            gui.itemMoved(sp);
            this.updateToClient();
            return;
        }

        // Everything else is a cancelled button click routed to the GUI
        if (slotIndex >= 0 && slotIndex < chestSlots) {
            gui.click(slotIndex, button, actionType, sp);
        }
        // Full resync (issue 2): the client applied its click optimistically;
        // updateToClient() unconditionally re-sends every slot + cursor so no
        // ghost/duplicated items can survive a rejected click.
        this.updateToClient();
    }

    @Override
    public void onClosed(PlayerEntity player) {
        // Return cursor stack into the GUI instead of dropping it (kit editor)
        ItemStack cursor = this.getCursorStack();
        if (!cursor.isEmpty() && gui.allowItemMoves()) {
            gui.absorbCursor(cursor);
            this.setCursorStack(ItemStack.EMPTY);
        }
        super.onClosed(player);
        if (player instanceof ServerPlayerEntity sp) {
            com.pvpcore.PvPCore.get().guiManager().handleClosed(this, sp);
            // Full resync of the player's own inventory after closing
            sp.playerScreenHandler.updateToClient();
        }
    }
}
