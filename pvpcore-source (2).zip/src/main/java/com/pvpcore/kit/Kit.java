package com.pvpcore.kit;

import com.pvpcore.util.ItemCodecUtil;
import net.minecraft.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

/**
 * A duel kit. Layout layout order: 40 slots ->
 * [0..3] armor (helmet, chestplate, leggings, boots)
 * [4..12] hotbar (9)
 * [13..39] main inventory (27)
 */
public class Kit {
    public String id = "kit";
    public String displayName = "&fKit";
    public String displayItem = "STONE";
    public boolean enabled = true;
    /** 40 SNBT item strings ("" = empty). */
    public List<String> layout = new ArrayList<>();

    public static final int ARMOR_COUNT = 4;
    public static final int HOTBAR_COUNT = 9;
    public static final int INV_COUNT = 27;
    public static final int TOTAL = ARMOR_COUNT + HOTBAR_COUNT + INV_COUNT;

    public void initEmptyLayout() {
        while (layout.size() < TOTAL) layout.add("");
    }

    public List<ItemStack> layoutStacks() {
        initEmptyLayout();
        List<ItemStack> out = new ArrayList<>();
        for (String s : layout) out.add(ItemCodecUtil.fromSnbt(s));
        return out;
    }

    public void setLayout(List<ItemStack> stacks) {
        layout = new ArrayList<>();
        for (int i = 0; i < TOTAL; i++) {
            layout.add(i < stacks.size() ? ItemCodecUtil.toSnbt(stacks.get(i)) : "");
        }
    }

    public ItemStack displayStack() {
        ItemStack st = ItemCodecUtil.parseMaterial(displayItem);
        if (st.isEmpty()) st = ItemCodecUtil.parseMaterial("STONE");
        return st;
    }
}
