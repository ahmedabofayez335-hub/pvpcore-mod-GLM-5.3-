package com.pvpcore.kit;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.pvpcore.PvPCoreMod;
import com.pvpcore.util.ItemCodecUtil;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.potion.Potion;
import net.minecraft.registry.Registries;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Identifier;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Manages kits: load/save (kits.json), default kits, personal loadouts.
 */
public final class KitManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();

    private final Path file;
    private final Map<String, Kit> kits = new LinkedHashMap<>();

    public KitManager(Path dataDir) {
        this.file = dataDir.resolve("kits.json");
        load();
        if (kits.isEmpty()) {
            createDefaultKits();
            save();
        }
    }

    public void load() {
        kits.clear();
        if (Files.exists(file)) {
            try {
                String json = Files.readString(file, StandardCharsets.UTF_8);
                Map<String, Kit> map = GSON.fromJson(json, new TypeToken<Map<String, Kit>>() {}.getType());
                if (map != null) kits.putAll(map);
            } catch (Exception e) {
                PvPCoreMod.LOGGER.error("Failed to load kits.json", e);
            }
        }
    }

    public synchronized void save() {
        try {
            Files.createDirectories(file.getParent());
            Path tmp = file.resolveSibling("kits.json.tmp");
            Files.writeString(tmp, GSON.toJson(kits), StandardCharsets.UTF_8);
            Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException e) {
            PvPCoreMod.LOGGER.error("Failed to save kits.json", e);
        }
    }

    public Kit get(String id) {
        return kits.get(id.toLowerCase());
    }

    public Collection<Kit> all() {
        return kits.values();
    }

    public void put(Kit kit) {
        kits.put(kit.id, kit);
        save();
    }

    public void delete(String id) {
        kits.remove(id.toLowerCase());
        save();
    }

    /**
     * Issue 5: create a new kit from an admin's current inventory.
     * Armor slots 36-39 -> kit armor, hotbar 0-8 -> kit hotbar,
     * main inventory 9-35 -> kit inventory. The kit icon is taken from
     * the first non-empty item (preferably the sword in the hotbar).
     */
    public Kit createFromInventory(String id, String displayName, net.minecraft.entity.player.PlayerInventory inv) {
        Kit kit = new Kit();
        kit.id = id.toLowerCase();
        kit.displayName = (displayName == null || displayName.isBlank()) ? "&f" + id : displayName;
        List<ItemStack> layout = new java.util.ArrayList<>(java.util.Collections.nCopies(Kit.TOTAL, ItemStack.EMPTY));
        for (int i = 0; i < 4; i++) layout.set(i, ItemCodecUtil.copy(inv.getStack(36 + i))); // armor
        for (int i = 0; i < 9; i++) layout.set(4 + i, ItemCodecUtil.copy(inv.getStack(i)));   // hotbar
        for (int i = 0; i < 27; i++) layout.set(13 + i, ItemCodecUtil.copy(inv.getStack(9 + i))); // main
        kit.setLayout(layout);

        // pick a display item: first non-empty hotbar item, else any non-empty slot
        String display = null;
        for (int i = 4; i < Kit.TOTAL && display == null; i++) {
            ItemStack st = layout.get(i);
            if (!st.isEmpty()) display = Registries.ITEM.getId(st.getItem()).toString();
        }
        if (display == null) display = "STONE";
        kit.displayItem = display;
        return kit;
    }

    /** Valid kit ids: lowercase letters, numbers, dash, underscore. */
    public static boolean validId(String id) {
        return id != null && id.matches("[a-zA-Z0-9_-]{1,32}");
    }

    // ------------------------------------------------------------------
    // Default kits
    // ------------------------------------------------------------------

    private void createDefaultKits() {
        kits.put("nodebuff", buildNoDebuff());
        kits.put("classic", buildClassic());
        kits.put("gapple", buildGapple());
    }

    private ItemStack ench(String material, String enchId, int level) {
        ItemStack st = com.pvpcore.util.ItemCodecUtil.parseMaterial(material);
        var entry = com.pvpcore.util.EnchantUtil.byId(enchId);
        if (entry != null) st.addEnchantment(entry, level);
        return st;
    }

    private ItemStack healingPotion() {
        ItemStack st = new ItemStack(Items.SPLASH_POTION);
        var potion = Registries.POTION.getEntry(Identifier.of("minecraft", "strong_healing"));
        potion.ifPresent(p -> st.set(DataComponentTypes.POTION_CONTENTS,
                new PotionContentsComponent(p)));
        return st;
    }

    private ItemStack speedPotion() {
        ItemStack st = new ItemStack(Items.POTION);
        StatusEffectInstance speed = new StatusEffectInstance(StatusEffects.SPEED, 20 * 60, 1);
        st.set(DataComponentTypes.POTION_CONTENTS, new PotionContentsComponent(
                java.util.Optional.empty(), java.util.Optional.empty(),
                java.util.List.of(speed), java.util.Optional.empty()));
        return st;
    }

    private Kit buildNoDebuff() {
        Kit kit = new Kit();
        kit.id = "nodebuff";
        kit.displayName = "&bNoDebuff";
        kit.displayItem = "SPLASH_POTION";
        List<ItemStack> layout = new java.util.ArrayList<>(java.util.Collections.nCopies(Kit.TOTAL, ItemStack.EMPTY));
        layout.set(0, ench("DIAMOND_HELMET", "protection", 2));
        layout.set(1, ench("DIAMOND_CHESTPLATE", "protection", 2));
        layout.set(2, ench("DIAMOND_LEGGINGS", "protection", 2));
        layout.set(3, ench("DIAMOND_BOOTS", "protection", 2));
        layout.set(4, ench("DIAMOND_SWORD", "sharpness", 1));
        for (int i = 5; i < 13; i++) layout.set(i, healingPotion());
        kit.setLayout(layout);
        return kit;
    }

    private Kit buildClassic() {
        Kit kit = new Kit();
        kit.id = "classic";
        kit.displayName = "&6Classic";
        kit.displayItem = "IRON_SWORD";
        List<ItemStack> layout = new java.util.ArrayList<>(java.util.Collections.nCopies(Kit.TOTAL, ItemStack.EMPTY));
        layout.set(0, ench("IRON_HELMET", "protection", 1));
        layout.set(1, ench("IRON_CHESTPLATE", "protection", 1));
        layout.set(2, ench("IRON_LEGGINGS", "protection", 1));
        layout.set(3, ench("IRON_BOOTS", "protection", 1));
        layout.set(4, ench("IRON_SWORD", "sharpness", 2));
        ItemStack bow = ench("BOW", "power", 2);
        layout.set(5, bow);
        ItemStack arrows = new ItemStack(Items.ARROW, 32);
        layout.set(6, arrows);
        ItemStack steak = new ItemStack(Items.COOKED_BEEF, 16);
        layout.set(7, steak);
        ItemStack gapple = new ItemStack(Items.GOLDEN_APPLE, 4);
        layout.set(8, gapple);
        layout.set(9, speedPotion());
        kit.setLayout(layout);
        return kit;
    }

    private Kit buildGapple() {
        Kit kit = new Kit();
        kit.id = "gapple";
        kit.displayName = "&eGapple";
        kit.displayItem = "GOLDEN_APPLE";
        List<ItemStack> layout = new java.util.ArrayList<>(java.util.Collections.nCopies(Kit.TOTAL, ItemStack.EMPTY));
        layout.set(0, ench("DIAMOND_HELMET", "protection", 3));
        layout.set(1, ench("DIAMOND_CHESTPLATE", "protection", 3));
        layout.set(2, ench("DIAMOND_LEGGINGS", "protection", 3));
        layout.set(3, ench("DIAMOND_BOOTS", "protection", 3));
        layout.set(4, ench("DIAMOND_SWORD", "sharpness", 3));
        layout.set(5, ench("DIAMOND_AXE", "sharpness", 2));
        ItemStack gaps = new ItemStack(Items.GOLDEN_APPLE, 64);
        layout.set(6, gaps);
        layout.set(7, new ItemStack(Items.GOLDEN_APPLE, 64));
        kit.setLayout(layout);
        return kit;
    }
}
