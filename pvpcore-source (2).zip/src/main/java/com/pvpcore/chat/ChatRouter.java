package com.pvpcore.chat;

import com.pvpcore.PvPCore;
import com.pvpcore.duel.Duel;
import com.pvpcore.party.PartyManager;
import com.pvpcore.util.TextUtil;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Requirement 5 + issue 10: chat routing that actually works.
 *
 * The formats live in settings.json (chat.globalFormat / duelFormat /
 * partyFormat / specFormat) - the old version read them from messages.json
 * where those keys never existed, so every message displayed the literal
 * text "globalFormat" instead of the chat. Now the formats are read from
 * the right place, with colors and {player}/{message} placeholders applied.
 *
 * When a player is in a duel, global chat is hidden from them and their
 * messages go to the duel chat only; when the duel ends, global chat
 * returns automatically. Party chat mode is routed too.
 */
public final class ChatRouter {

    public void handle(ServerPlayerEntity sender, String message) {
        if (sender == null || sender.isDisconnected()) return;
        var cfg = PvPCore.get().config().chat;
        Map<String, String> vars = Map.of(
                "player", sender.getGameProfile().name(),
                "message", TextUtil.stripColor(message)
        );

        // 1) Party chat mode (toggle via the party GUI)
        PartyManager.Party party = PvPCore.get().partyManager().partyOf(sender);
        if (party != null) {
            var data = PvPCore.get().storage().get(sender.getUuid(), sender.getGameProfile().name());
            if (data != null && data.partyChat) {
                String formatted = TextUtil.colorAndPlace(cfg.partyFormat, vars);
                for (ServerPlayerEntity member : party.onlineMembers()) {
                    if (member != null && member.networkHandler != null) {
                        member.sendMessage(Text.literal(formatted), false);
                    }
                }
                return;
            }
        }

        Duel duel = PvPCore.get().duelManager().duelOf(sender);

        // 2) Sender is in a duel -> duel chat only
        if (duel != null && cfg.isolateDuels) {
            String formatted = TextUtil.colorAndPlace(cfg.duelFormat, vars);
            List<ServerPlayerEntity> audience = new ArrayList<>(duel.participants());
            if (cfg.duelChatIncludesSpectators) audience.addAll(duel.spectators());
            for (ServerPlayerEntity target : audience) {
                if (target != null && target.networkHandler != null) {
                    target.sendMessage(Text.literal(formatted), false);
                }
            }
            return;
        }

        // 3) Spectators of a duel (their chat goes to the duel audience)
        Duel spectating = PvPCore.get().spectateManager().spectatedDuel(sender);
        if (spectating != null && cfg.isolateDuels && PvPCore.get().spectateManager().isolateSpectatorChat()) {
            String formatted = TextUtil.colorAndPlace(cfg.specFormat, vars);
            List<ServerPlayerEntity> audience = new ArrayList<>(spectating.participants());
            audience.addAll(spectating.spectators());
            for (ServerPlayerEntity target : audience) {
                if (target != null && target.networkHandler != null) {
                    target.sendMessage(Text.literal(formatted), false);
                }
            }
            return;
        }

        // 4) Global chat - hidden from players inside duels (requirement 5)
        String formatted = TextUtil.colorAndPlace(cfg.globalFormat, vars);
        var players = PvPCore.get().server().getPlayerManager().getPlayerList();
        for (ServerPlayerEntity target : players) {
            if (target == null || target.networkHandler == null) continue;
            if (cfg.hideGlobalFromDuelists && cfg.isolateDuels && target != sender) {
                if (PvPCore.get().duelManager().duelOf(target) != null) continue; // duelist: no global chat
            }
            target.sendMessage(Text.literal(formatted), false);
        }
    }
}
