package com.pvpcore.scoreboard;

import com.pvpcore.PvPCore;
import com.pvpcore.data.PlayerData;
import com.pvpcore.data.PlayerStats;
import com.pvpcore.util.TextUtil;
import net.minecraft.server.network.ServerPlayerEntity;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Issue 10 (2.2.0): a sidebar scoreboard for the LOBBY.
 *
 * Every player in the lobby / queue sees their own sidebar with their
 * statistics, the server IP and whatever else the admin configures in
 * settings.json (lobbyScoreboard section - title, serverIp and every line
 * are fully customizable with placeholders).
 *
 * The board hides automatically when a duel starts (the duel scoreboard
 * takes over the sidebar) and comes back when the player returns to the
 * lobby.
 */
public final class LobbyScoreboardManager {
    private final Map<UUID, DuelScoreboard> boards = new ConcurrentHashMap<>();
    private long tick = 0;
    private long lastRefresh = 0;
    /** Cached global-ELO ranks (name -> rank), rebuilt every few seconds. */
    private Map<String, Integer> rankCache = new ConcurrentHashMap<>();

    /** Show (or create) the lobby scoreboard for a player. */
    public void show(ServerPlayerEntity player) {
        if (player == null) return;
        var cfg = PvPCore.get().config().lobbyScoreboard;
        if (!cfg.enabled) return;
        DuelScoreboard board = boards.computeIfAbsent(player.getUuid(),
                u -> new DuelScoreboard("pvl_" + u.toString().substring(0, 8), cfg.title));
        board.addViewer(player);
        update(player);
    }

    /** Hide the lobby scoreboard for a player (e.g. duel starting). */
    public void hide(ServerPlayerEntity player) {
        if (player == null) return;
        DuelScoreboard board = boards.remove(player.getUuid());
        if (board != null) board.removeViewer(player);
    }

    public boolean isShown(ServerPlayerEntity player) {
        return player != null && boards.containsKey(player.getUuid());
    }

    public void onQuit(ServerPlayerEntity player) {
        hide(player);
    }

    public void tick() {
        tick++;
        var cfg = PvPCore.get().config().lobbyScoreboard;
        if (!cfg.enabled) {
            if (!boards.isEmpty()) hideAll();
            return;
        }
        int interval = Math.max(5, cfg.updateIntervalTicks);
        if (tick - lastRefresh < interval) return;
        lastRefresh = tick;

        rebuildRanks();

        // Self-healing (issue 10): every synced lobby/queue player sees the
        // lobby sidebar; duelers and spectators do not (their scoreboard or
        // the duel scoreboard owns the sidebar instead).
        var pm = PvPCore.get().server().getPlayerManager();
        var playerManager = PvPCore.get().playerManager();
        for (ServerPlayerEntity p : pm.getPlayerList()) {
            if (p == null || p.isDisconnected()) continue;
            var state = playerManager.state(p);
            boolean inLobby = (state == com.pvpcore.player.PlayerState.LOBBY
                    || state == com.pvpcore.player.PlayerState.QUEUEING)
                    && playerManager.loginSynced(p)
                    && PvPCore.get().duelManager().duelOf(p) == null
                    && !PvPCore.get().spectateManager().isSpectating(p);
            if (inLobby) {
                show(p);
            } else {
                hide(p);
            }
        }
        // drop boards of players that went offline
        for (UUID u : new ArrayList<>(boards.keySet())) {
            if (pm.getPlayer(u) == null) {
                DuelScoreboard b = boards.remove(u);
                if (b != null) b.removeAll();
            }
        }
    }

    private void hideAll() {
        var pm = PvPCore.get().server().getPlayerManager();
        for (UUID u : new ArrayList<>(boards.keySet())) {
            ServerPlayerEntity p = pm.getPlayer(u);
            DuelScoreboard b = boards.remove(u);
            if (b != null && p != null) b.removeViewer(p);
        }
    }

    /** Rebuild the scoreboard lines for one player. */
    private void update(ServerPlayerEntity player) {
        DuelScoreboard board = boards.get(player.getUuid());
        if (board == null) return;
        List<String> lines = new ArrayList<>();
        for (String template : PvPCore.get().config().lobbyScoreboard.lines) {
            lines.add(TextUtil.colorAndPlace(template, placeholders(player)));
        }
        board.updateLines(lines);
    }

    private Map<String, String> placeholders(ServerPlayerEntity player) {
        var core = PvPCore.get();
        var cfg = core.config().lobbyScoreboard;
        PlayerData data = core.storage().get(player.getUuid(), player.getGameProfile().name());
        PlayerStats stats = data != null ? data.statsFor("global") : new PlayerStats();
        int elo = data != null ? data.ratingFor("global", core.config().elo.startRating) : core.config().elo.startRating;

        int online = core.server().getPlayerManager().getCurrentPlayerCount();
        int max = core.server().getPlayerManager().getMaxPlayerCount();

        int ping = 0;
        try {
            ping = Math.max(0, player.networkHandler.getLatency());
        } catch (Throwable ignored) {}

        var party = core.partyManager().partyOf(player);
        String partyText = party != null
                ? party.members.size() + (party.isLeader(player.getUuid()) ? " (leader)" : "")
                : "-";

        var queue = core.queueManager();
        String queueText = queue.isQueued(player) ? "In queue" : "-";

        String rank = String.valueOf(rankCache.getOrDefault(player.getGameProfile().name(), rankCache.size() + 1));

        LocalDateTime now = LocalDateTime.now();
        String date = now.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        String time = now.format(DateTimeFormatter.ofPattern("HH:mm"));

        String world = player.getEntityWorld().getRegistryKey().getValue().getPath();
        world = world.substring(0, 1).toUpperCase(Locale.ROOT) + world.substring(1);

        return Map.ofEntries(
                Map.entry("player", player.getGameProfile().name()),
                Map.entry("online", String.valueOf(online)),
                Map.entry("max", String.valueOf(max)),
                Map.entry("ip", cfg.serverIp),
                Map.entry("ping", String.valueOf(ping)),
                Map.entry("wins", String.valueOf(stats.wins)),
                Map.entry("losses", String.valueOf(stats.losses)),
                Map.entry("duels", String.valueOf(stats.duels)),
                Map.entry("winrate", String.format(Locale.ROOT, "%.0f%%", stats.winRate())),
                Map.entry("elo", String.valueOf(elo)),
                Map.entry("rank", rank),
                Map.entry("streak", String.valueOf(stats.streak)),
                Map.entry("beststreak", String.valueOf(stats.bestStreak)),
                Map.entry("party", partyText),
                Map.entry("queue", queueText),
                Map.entry("world", world),
                Map.entry("date", date),
                Map.entry("time", time)
        );
    }

    /** Rebuild name -> rank map from the ELO leaderboard. */
    private void rebuildRanks() {
        try {
            Map<String, Integer> ranks = new ConcurrentHashMap<>();
            List<com.pvpcore.leaderboard.LeaderboardManager.Entry> all =
                    PvPCore.get().leaderboardManager().top("global", "elo", Integer.MAX_VALUE);
            for (int i = 0; i < all.size(); i++) {
                ranks.putIfAbsent(all.get(i).name(), i + 1);
            }
            rankCache = ranks;
        } catch (Throwable ignored) {}
    }

    public void shutdown() {
        var pm = PvPCore.get().server().getPlayerManager();
        for (UUID u : new ArrayList<>(boards.keySet())) {
            ServerPlayerEntity p = pm.getPlayer(u);
            DuelScoreboard b = boards.remove(u);
            if (b != null && p != null) b.removeViewer(p);
        }
    }
}
