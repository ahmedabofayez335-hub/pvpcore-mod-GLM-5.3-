package com.pvpcore.scoreboard;

import com.pvpcore.PvPCore;
import com.pvpcore.util.TextUtil;
import net.minecraft.network.packet.s2c.play.ScoreboardDisplayS2CPacket;
import net.minecraft.network.packet.s2c.play.ScoreboardObjectiveUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ScoreboardScoreResetS2CPacket;
import net.minecraft.network.packet.s2c.play.ScoreboardScoreUpdateS2CPacket;
import net.minecraft.network.packet.Packet;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardCriterion;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Requirement 13: every duel gets its own sidebar scoreboard showing the
 * players, their live ping and duel stats. Sent via packets only to the
 * duel participants and spectators; removed when the duel ends.
 */
public final class DuelScoreboard {
    private final String objectiveName;
    private final Scoreboard dummyScoreboard;
    private final ScoreboardObjective objective;
    private final List<ServerPlayerEntity> viewers = new ArrayList<>();
    private final List<String> lineTexts = new ArrayList<>();
    private boolean created = false;

    public DuelScoreboard(UUID duelId, String title) {
        this("pvpd_" + duelId.toString().substring(0, 8), title);
    }

    /** Issue 10 (2.2.0): custom objective name (lobby scoreboards are per player). */
    public DuelScoreboard(String objectiveName, String title) {
        this.objectiveName = objectiveName.toLowerCase();
        // dummy scoreboard instance just to construct the objective
        this.dummyScoreboard = new Scoreboard();
        this.objective = new ScoreboardObjective(
                dummyScoreboard, this.objectiveName, ScoreboardCriterion.DUMMY,
                TextUtil.text(title), ScoreboardCriterion.RenderType.INTEGER, false, null);
    }

    /** Show this scoreboard to a viewer. */
    public synchronized void addViewer(ServerPlayerEntity player) {
        if (player == null || viewers.contains(player)) return;
        viewers.add(player);
        send(player, new ScoreboardObjectiveUpdateS2CPacket(objective, ScoreboardObjectiveUpdateS2CPacket.ADD_MODE));
        send(player, new ScoreboardDisplayS2CPacket(ScoreboardDisplaySlot.SIDEBAR, objective));
        for (int i = 0; i < lineTexts.size(); i++) {
            sendScore(player, lineTexts.get(i), lineTexts.size() - i);
        }
        created = true;
    }

    public synchronized void removeViewer(ServerPlayerEntity player) {
        viewers.remove(player);
        if (player != null && player.networkHandler != null) {
            send(player, new ScoreboardObjectiveUpdateS2CPacket(objective, ScoreboardObjectiveUpdateS2CPacket.REMOVE_MODE));
        }
    }

    /** Update all lines. */
    public synchronized void updateLines(List<String> lines) {
        // remove old scores that are no longer present
        for (String old : new ArrayList<>(lineTexts)) {
            if (!lines.contains(old)) {
                for (ServerPlayerEntity v : viewers) {
                    removeScore(v, old);
                }
                lineTexts.remove(old);
            }
        }
        lineTexts.clear();
        for (int i = 0; i < lines.size(); i++) {
            String line = TextUtil.sbLine(lines.get(i));
            lineTexts.add(line);
            int score = lines.size() - i;
            for (ServerPlayerEntity v : viewers) {
                sendScore(v, line, score);
            }
        }
    }

    /** Remove the whole scoreboard from everyone. */
    public synchronized void removeAll() {
        for (ServerPlayerEntity v : new ArrayList<>(viewers)) {
            if (v != null && v.networkHandler != null) {
                send(v, new ScoreboardObjectiveUpdateS2CPacket(objective, ScoreboardObjectiveUpdateS2CPacket.REMOVE_MODE));
            }
        }
        viewers.clear();
        lineTexts.clear();
        created = false;
    }

    private void sendScore(ServerPlayerEntity player, String holder, int score) {
        player.networkHandler.sendPacket(new ScoreboardScoreUpdateS2CPacket(
                holder, objectiveName, score, Optional.empty(), Optional.empty()));
    }

    private void removeScore(ServerPlayerEntity player, String holder) {
        player.networkHandler.sendPacket(new ScoreboardScoreResetS2CPacket(holder, objectiveName));
    }

    private void send(ServerPlayerEntity player, Packet<?> packet) {
        if (player != null && player.networkHandler != null) {
            player.networkHandler.sendPacket(packet);
        }
    }
}
