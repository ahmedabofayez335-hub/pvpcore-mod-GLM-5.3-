package com.pvpcore.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.pvpcore.PvPCore;
import com.pvpcore.arena.Arena;
import com.pvpcore.data.PlayerData;
import com.pvpcore.data.PlayerStats;
import com.pvpcore.duel.Duel;
import com.pvpcore.duel.DuelManager;
import com.pvpcore.gui.guis.AdminGui;
import com.pvpcore.gui.guis.KitListGui;
import com.pvpcore.gui.guis.KitPickerGui;
import com.pvpcore.gui.guis.LeaderboardGui;
import com.pvpcore.gui.guis.PlayerPickerGui;
import com.pvpcore.gui.guis.ProfileGui;
import com.pvpcore.gui.guis.SpectateGui;
import com.pvpcore.gui.guis.StatsGui;
import com.pvpcore.item.ItemBuilder;
import com.pvpcore.kit.Kit;
import com.pvpcore.leaderboard.LeaderboardManager;
import com.pvpcore.party.PartyManager;
import com.pvpcore.player.PlayerState;
import com.pvpcore.util.TextUtil;
import com.pvpcore.util.TitleUtil;
import net.minecraft.command.CommandRegistryAccess;
import net.minecraft.command.CommandSource;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.item.ItemStack;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * All commands. NOTE: every feature is also reachable through GUIs;
 * commands exist as a convenience/power-user alternative (requirement 11).
 */
public final class PvPCommands {
    private PvPCommands() {}

    private static final SuggestionProvider<ServerCommandSource> KITS =
            (ctx, builder) -> CommandSource.suggestMatching(
                    PvPCore.get().kitManager().all().stream().map(k -> k.id), builder);

    private static final SuggestionProvider<ServerCommandSource> ARENAS =
            (ctx, builder) -> CommandSource.suggestMatching(
                    PvPCore.get().arenaManager().all().stream().map(a -> a.id), builder);

    private static final SuggestionProvider<ServerCommandSource> PLAYERS =
            (ctx, builder) -> CommandSource.suggestMatching(
                    ctx.getSource().getServer().getPlayerManager().getPlayerList().stream()
                            .map(p -> p.getGameProfile().name()), builder);

    private static final SuggestionProvider<ServerCommandSource> LEADERBOARD_TYPES =
            (ctx, builder) -> CommandSource.suggestMatching(List.of("wins", "elo"), builder);

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        // /duel <player> [kit]
        dispatcher.register(CommandManager.literal("duel")
                .requires(src -> true)
                .then(CommandManager.argument("player", EntityArgumentType.player())
                        .executes(ctx -> duel(ctx, null))
                        .then(CommandManager.argument("kit", StringArgumentType.word())
                                .suggests(KITS)
                                .executes(ctx -> duel(ctx, StringArgumentType.getString(ctx, "kit"))))));

        // /queue [kit] [ranked]
        dispatcher.register(CommandManager.literal("queue")
                .requires(src -> true)
                .executes(ctx -> openQueue(ctx, false))
                .then(CommandManager.argument("kit", StringArgumentType.word())
                        .suggests(KITS)
                        .executes(ctx -> queue(ctx, StringArgumentType.getString(ctx, "kit"), false))
                        .then(CommandManager.argument("ranked", BoolArgumentType.bool())
                                .executes(ctx -> queue(ctx, StringArgumentType.getString(ctx, "kit"),
                                        BoolArgumentType.getBool(ctx, "ranked"))))));

        // /ranked [kit]
        dispatcher.register(CommandManager.literal("ranked")
                .requires(src -> true)
                .executes(ctx -> openQueue(ctx, true))
                .then(CommandManager.argument("kit", StringArgumentType.word())
                        .suggests(KITS)
                        .executes(ctx -> queue(ctx, StringArgumentType.getString(ctx, "kit"), true))));

        // /leavequeue
        dispatcher.register(CommandManager.literal("leavequeue")
                .requires(src -> true)
                .executes(PvPCommands::leaveQueue));

        // /leave - issue 3: leave the current duel (forfeit) or queue
        dispatcher.register(CommandManager.literal("leave")
                .requires(src -> true)
                .executes(PvPCommands::leave));

        // /duelaccept - issue 9: clickable chat button target
        dispatcher.register(CommandManager.literal("duelaccept")
                .requires(src -> true)
                .executes(PvPCommands::duelAccept));

        // /dueldeny - issue 9: clickable chat button target
        dispatcher.register(CommandManager.literal("dueldeny")
                .requires(src -> true)
                .executes(PvPCommands::duelDeny));

        // /profile
        dispatcher.register(CommandManager.literal("profile")
                .requires(src -> true)
                .executes(ctx -> {
                    ServerPlayerEntity p = ctx.getSource().getPlayer();
                    if (p != null) new ProfileGui(p, p).open(p);
                    return 1;
                }));

        // /stats [player]
        dispatcher.register(CommandManager.literal("stats")
                .requires(src -> true)
                .executes(ctx -> {
                    ServerPlayerEntity p = ctx.getSource().getPlayer();
                    if (p != null) new PlayerPickerGui(p, "&8View Stats - Pick a Player",
                            target -> new StatsGui(p, target).open(p)).open(p);
                    return 1;
                })
                .then(CommandManager.argument("player", EntityArgumentType.player())
                        .executes(PvPCommands::statsOf)));

        // /leaderboard [type] [kit]
        dispatcher.register(CommandManager.literal("leaderboard")
                .requires(src -> true)
                .executes(ctx -> {
                    ServerPlayerEntity p = ctx.getSource().getPlayer();
                    if (p != null) new LeaderboardGui(p).open(p);
                    return 1;
                })
                .then(CommandManager.argument("type", StringArgumentType.word())
                        .suggests(LEADERBOARD_TYPES)
                        .executes(ctx -> leaderboard(ctx, StringArgumentType.getString(ctx, "type"), "global"))
                        .then(CommandManager.argument("kit", StringArgumentType.word())
                                .suggests(KITS)
                                .executes(ctx -> leaderboard(ctx,
                                        StringArgumentType.getString(ctx, "type"),
                                        StringArgumentType.getString(ctx, "kit"))))));

        // /spectate [player]
        dispatcher.register(CommandManager.literal("spectate")
                .requires(src -> true)
                .executes(ctx -> {
                    ServerPlayerEntity p = ctx.getSource().getPlayer();
                    if (p != null) new SpectateGui(p).open(p);
                    return 1;
                })
                .then(CommandManager.argument("player", EntityArgumentType.player())
                        .executes(PvPCommands::spectatePlayer)));

        // /rematch
        dispatcher.register(CommandManager.literal("rematch")
                .requires(src -> true)
                .executes(PvPCommands::rematch));

        // /lobby - issue 3: teleport yourself to the lobby point
        dispatcher.register(CommandManager.literal("lobby")
                .requires(src -> true)
                .executes(PvPCommands::lobbyTeleport));

        // /party ...
        dispatcher.register(CommandManager.literal("party")
                .requires(src -> true)
                .executes(ctx -> {
                    ServerPlayerEntity p = ctx.getSource().getPlayer();
                    if (p != null) {
                        // Requirement 6: auto-create on use
                        if (PvPCore.get().partyManager().partyOf(p) == null
                                && PvPCore.get().config().party.autoCreateOnItemClick) {
                            PvPCore.get().partyManager().createParty(p);
                        }
                        PvPCore.get().partyManager().sendPartyMenu(p);
                    }
                    return 1;
                })
                .then(CommandManager.literal("create").executes(PvPCommands::partyCreate))
                .then(CommandManager.literal("invite")
                        .then(CommandManager.argument("player", EntityArgumentType.player()).executes(PvPCommands::partyInvite)))
                .then(CommandManager.literal("accept").executes(PvPCommands::partyAccept))
                .then(CommandManager.literal("deny").executes(PvPCommands::partyDeny))
                .then(CommandManager.literal("leave").executes(PvPCommands::partyLeave))
                .then(CommandManager.literal("kick")
                        .then(CommandManager.argument("player", EntityArgumentType.player()).executes(PvPCommands::partyKick)))
                .then(CommandManager.literal("promote")
                        .then(CommandManager.argument("player", EntityArgumentType.player()).executes(PvPCommands::partyPromote)))
                .then(CommandManager.literal("disband").executes(PvPCommands::partyDisband))
                .then(CommandManager.literal("list").executes(PvPCommands::partyList))
                .then(CommandManager.literal("chat").executes(PvPCommands::partyChat))
                // Issue 1 (2.2.0): the party menu is clickable CHAT; these are
                // the commands the chat buttons run.
                .then(CommandManager.literal("menu")
                        .executes(ctx -> {
                            ServerPlayerEntity p = ctx.getSource().getPlayer();
                            if (p != null) PvPCore.get().partyManager().sendPartyMenu(p);
                            return 1;
                        })
                        .then(CommandManager.literal("invite").executes(ctx -> {
                            ServerPlayerEntity p = ctx.getSource().getPlayer();
                            if (p != null) PvPCore.get().partyManager().sendInviteTargets(p);
                            return 1;
                        }))
                        .then(CommandManager.literal("duel").executes(ctx -> {
                            ServerPlayerEntity p = ctx.getSource().getPlayer();
                            if (p != null) PvPCore.get().partyManager().sendDuelTargets(p);
                            return 1;
                        }))
                        .then(CommandManager.literal("manage").executes(ctx -> {
                            ServerPlayerEntity p = ctx.getSource().getPlayer();
                            if (p != null) PvPCore.get().partyManager().sendManageMembers(p);
                            return 1;
                        }))
                        .then(CommandManager.literal("close").executes(ctx -> {
                            ServerPlayerEntity p = ctx.getSource().getPlayer();
                            if (p != null) p.sendMessage(Text.literal(
                                    PvPCore.get().messages().get("party.menu-close-hint")), false);
                            return 1;
                        })))
                // Issue 1: /party duel <leader> - challenge another party
                .then(CommandManager.literal("duel")
                        .then(CommandManager.argument("player", EntityArgumentType.player()).executes(PvPCommands::partyDuel))));

        // /arena ... (admin)
        dispatcher.register(CommandManager.literal("arena")
                .requires(src -> com.pvpcore.player.PlayerManager.isAdminSource(src))
                .executes(ctx -> {
                    ServerPlayerEntity p = ctx.getSource().getPlayer();
                    if (p != null) new com.pvpcore.gui.guis.ArenaListGui(p).open(p);
                    return 1;
                })
                .then(CommandManager.literal("list").executes(PvPCommands::arenaList))
                .then(CommandManager.literal("create")
                        .then(CommandManager.argument("id", StringArgumentType.word()).executes(PvPCommands::arenaCreate)))
                .then(CommandManager.literal("setspawn1")
                        .then(CommandManager.argument("id", StringArgumentType.word())
                                .suggests(ARENAS).executes(ctx -> arenaSpawnId(ctx, 1))))
                .then(CommandManager.literal("setspawn2")
                        .then(CommandManager.argument("id", StringArgumentType.word())
                                .suggests(ARENAS).executes(ctx -> arenaSpawnId(ctx, 2))))
                .then(CommandManager.literal("setspectator")
                        .then(CommandManager.argument("id", StringArgumentType.word())
                                .suggests(ARENAS).executes(ctx -> arenaSpawnId(ctx, 3))))
                .then(CommandManager.argument("id", StringArgumentType.word())
                        .suggests(ARENAS)
                        .then(CommandManager.literal("enable").executes(ctx -> arenaToggle(ctx, true)))
                        .then(CommandManager.literal("disable").executes(ctx -> arenaToggle(ctx, false)))
                        .then(CommandManager.literal("validate").executes(PvPCommands::arenaValidate))
                        .then(CommandManager.literal("teleport").executes(PvPCommands::arenaTeleport))
                        .then(CommandManager.literal("delete").executes(PvPCommands::arenaDelete))));

        // /pvpadmin ...
        dispatcher.register(CommandManager.literal("pvpadmin")
                .requires(src -> com.pvpcore.player.PlayerManager.isAdminSource(src))
                .executes(ctx -> {
                    ServerPlayerEntity p = ctx.getSource().getPlayer();
                    if (p != null) new AdminGui(p).open(p);
                    return 1;
                })
                .then(CommandManager.literal("reload").executes(PvPCommands::adminReload))
                .then(CommandManager.literal("save").executes(PvPCommands::adminSave))
                .then(CommandManager.literal("setlobby").executes(PvPCommands::adminSetLobby))
                .then(CommandManager.literal("audit").executes(PvPCommands::adminAudit))
                .then(CommandManager.literal("kit")
                        .then(CommandManager.literal("create")
                                .then(CommandManager.argument("id", StringArgumentType.word())
                                        .executes(ctx -> kitCreate(ctx, null))
                                        // Issue 5: optional display name; the kit layout
                                        // is copied from the admin's current inventory
                                        .then(CommandManager.argument("name", StringArgumentType.greedyString())
                                                .executes(ctx -> kitCreate(ctx, StringArgumentType.getString(ctx, "name"))))))
                        .then(CommandManager.literal("delete")
                                .then(CommandManager.argument("id", StringArgumentType.word())
                                        .suggests(KITS).executes(PvPCommands::kitDelete)))
                        .then(CommandManager.literal("list").executes(PvPCommands::kitList))));

        // /pvpdebug ...
        dispatcher.register(CommandManager.literal("pvpdebug")
                .requires(src -> com.pvpcore.player.PlayerManager.isAdminSource(src))
                .executes(PvPCommands::debugSummary)
                .then(CommandManager.literal("state")
                        .then(CommandManager.argument("player", EntityArgumentType.player()).executes(PvPCommands::debugState)))
                .then(CommandManager.literal("duels").executes(PvPCommands::debugDuels))
                .then(CommandManager.literal("arenas").executes(PvPCommands::debugArenas))
                .then(CommandManager.literal("queues").executes(PvPCommands::debugQueues)));
    }

    // ------------------------------------------------------------------
    // Player commands
    // ------------------------------------------------------------------

    private static int duel(CommandContext<ServerCommandSource> ctx, String kitId) throws CommandSyntaxException {
        ServerPlayerEntity sender = ctx.getSource().getPlayer();
        ServerPlayerEntity target = EntityArgumentType.getPlayer(ctx, "player");
        if (sender == null) return 0;
        if (kitId == null) {
            // no kit given: open the kit picker bound to this opponent
            new KitPickerGui(sender, false, target).open(sender);
            return 1;
        }
        PvPCore.get().duelManager().sendChallenge(sender, target, kitId);
        return 1;
    }

    private static int openQueue(CommandContext<ServerCommandSource> ctx, boolean ranked) {
        ServerPlayerEntity p = ctx.getSource().getPlayer();
        if (p != null) new KitPickerGui(p, ranked, null).open(p);
        return 1;
    }

    private static int queue(CommandContext<ServerCommandSource> ctx, String kitId, boolean ranked) {
        ServerPlayerEntity p = ctx.getSource().getPlayer();
        if (p == null) return 0;
        PvPCore.get().queueManager().join(p, kitId, ranked);
        return 1;
    }

    private static int leaveQueue(CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity p = ctx.getSource().getPlayer();
        if (p == null) return 0;
        PvPCore.get().queueManager().leave(p);
        return 1;
    }

    /** Issue 3: /leave - forfeit the duel, or leave the queue. */
    private static int leave(CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity p = ctx.getSource().getPlayer();
        if (p == null) return 0;
        var mm = PvPCore.get().messages();
        // 1) in a duel -> forfeit
        if (PvPCore.get().duelManager().leaveDuel(p)) return 1;
        // 2) in a queue -> leave it
        if (PvPCore.get().queueManager().isQueued(p)) {
            PvPCore.get().queueManager().leave(p);
            p.sendMessage(Text.literal(mm.get("leave.queue-left")), false);
            return 1;
        }
        // 3) spectating -> return to lobby
        if (PvPCore.get().spectateManager().isSpectating(p)) {
            PvPCore.get().spectateManager().returnPlayer(p);
            return 1;
        }
        p.sendMessage(Text.literal(mm.get("leave.nothing")), false);
        return 0;
    }

    /** Issue 9: /duelaccept - target of the clickable chat button. */
    private static int duelAccept(CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity p = ctx.getSource().getPlayer();
        if (p == null) return 0;
        if (PvPCore.get().duelManager().requestFor(p.getUuid()) == null) {
            p.sendMessage(Text.literal(PvPCore.get().messages().get("duel.no-request")), false);
            return 0;
        }
        PvPCore.get().duelManager().acceptRequest(p);
        return 1;
    }

    /** Issue 9: /dueldeny - target of the clickable chat button. */
    private static int duelDeny(CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity p = ctx.getSource().getPlayer();
        if (p == null) return 0;
        if (PvPCore.get().duelManager().requestFor(p.getUuid()) == null) {
            p.sendMessage(Text.literal(PvPCore.get().messages().get("duel.no-request")), false);
            return 0;
        }
        PvPCore.get().duelManager().denyRequest(p);
        return 1;
    }

    private static int statsOf(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity viewer = ctx.getSource().getPlayer();
        ServerPlayerEntity target = EntityArgumentType.getPlayer(ctx, "player");
        if (viewer != null) new StatsGui(viewer, target).open(viewer);
        return 1;
    }

    private static int leaderboard(CommandContext<ServerCommandSource> ctx, String type, String kitId) {
        var mm = PvPCore.get().messages();
        List<LeaderboardManager.Entry> top = PvPCore.get().leaderboardManager().top(kitId, type, 10);
        ctx.getSource().sendFeedback(() -> Text.literal(
                mm.get("leaderboard.header", Map.of("type", type.toUpperCase(),
                        "kit", kitId))), false);
        if (top.isEmpty()) {
            ctx.getSource().sendFeedback(() -> Text.literal(mm.get("leaderboard.empty")), false);
            return 1;
        }
        for (int i = 0; i < top.size(); i++) {
            final int pos = i + 1;
            final var entry = top.get(i);
            ctx.getSource().sendFeedback(() -> Text.literal(
                    mm.get("leaderboard.entry", Map.of(
                            "position", String.valueOf(pos),
                            "player", entry.name(),
                            "value", String.valueOf(entry.value())))), false);
        }
        return 1;
    }

    private static int spectatePlayer(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayer();
        ServerPlayerEntity target = EntityArgumentType.getPlayer(ctx, "player");
        if (p == null) return 0;
        Duel duel = PvPCore.get().duelManager().duelOf(target);
        if (duel == null) {
            p.sendMessage(Text.literal(PvPCore.get().messages().get("spectate.no-duels")), false);
            return 0;
        }
        PvPCore.get().spectateManager().join(p, duel);
        return 1;
    }

    private static int rematch(CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity p = ctx.getSource().getPlayer();
        if (p == null) return 0;
        var offer = PvPCore.get().duelManager().rematchOfferFor(p.getUuid());
        if (offer == null) {
            p.sendMessage(Text.literal(PvPCore.get().messages().get("queue.not-queued")), false);
            return 0;
        }
        PvPCore.get().duelManager().acceptRematch(p);
        return 1;
    }

    // ------------------------------------------------------------------
    // PartyManager.Party commands
    // ------------------------------------------------------------------

    /** Issue 3 (2.2.0): /lobby - teleport to the lobby point. */
    private static int lobbyTeleport(CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity p = ctx.getSource().getPlayer();
        if (p == null) return 0;
        var mm = PvPCore.get().messages();
        if (PvPCore.get().duelManager().duelOf(p) != null) {
            p.sendMessage(Text.literal(mm.get("not-in-lobby")), false);
            return 0;
        }
        PvPCore.get().playerManager().teleportToLobby(p);
        p.sendMessage(Text.literal(mm.get("lobby.teleported")), false);
        return 1;
    }

    private static int partyCreate(CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity p = ctx.getSource().getPlayer();
        if (p == null) return 0;
        PvPCore.get().partyManager().createParty(p);
        return 1;
    }

    private static int partyInvite(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayer();
        ServerPlayerEntity target = EntityArgumentType.getPlayer(ctx, "player");
        if (p == null) return 0;
        PvPCore.get().partyManager().invite(p, target);
        return 1;
    }

    private static int partyAccept(CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity p = ctx.getSource().getPlayer();
        if (p == null) return 0;
        PvPCore.get().partyManager().acceptInvite(p);
        return 1;
    }

    private static int partyDeny(CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity p = ctx.getSource().getPlayer();
        if (p == null) return 0;
        PvPCore.get().partyManager().denyInvite(p);
        return 1;
    }

    private static int partyLeave(CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity p = ctx.getSource().getPlayer();
        if (p == null) return 0;
        PvPCore.get().partyManager().leave(p);
        return 1;
    }

    private static int partyKick(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayer();
        ServerPlayerEntity target = EntityArgumentType.getPlayer(ctx, "player");
        if (p == null) return 0;
        PvPCore.get().partyManager().kick(p, target);
        return 1;
    }

    private static int partyPromote(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayer();
        ServerPlayerEntity target = EntityArgumentType.getPlayer(ctx, "player");
        if (p == null) return 0;
        PvPCore.get().partyManager().promote(p, target);
        return 1;
    }

    private static int partyDisband(CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity p = ctx.getSource().getPlayer();
        if (p == null) return 0;
        PvPCore.get().partyManager().disband(p);
        return 1;
    }

    private static int partyList(CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity p = ctx.getSource().getPlayer();
        if (p == null) return 0;
        PartyManager.Party party = PvPCore.get().partyManager().partyOf(p);
        if (party == null) {
            p.sendMessage(Text.literal(PvPCore.get().messages().get("party.not-in-party")), false);
            return 0;
        }
        var pm = PvPCore.get().server().getPlayerManager();
        StringBuilder sb = new StringBuilder("&dParty (&f" + party.members.size() + "&d): ");
        boolean first = true;
        for (UUID u : party.members) {
            if (!first) sb.append("&7, ");
            sb.append(party.leader.equals(u) ? "&6" : "&e").append(name(pm, u));
            first = false;
        }
        p.sendMessage(TextUtil.text(sb.toString()), false);
        return 1;
    }

    private static String name(net.minecraft.server.PlayerManager pm, UUID uuid) {
        var p = pm.getPlayer(uuid);
        return p != null ? p.getGameProfile().name() : "?";
    }

    private static int partyChat(CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity p = ctx.getSource().getPlayer();
        if (p == null) return 0;
        PlayerData data = PvPCore.get().storage().get(p.getUuid(), p.getGameProfile().name());
        data.partyChat = !data.partyChat;
        PvPCore.get().storage().markDirty(p.getUuid());
        var mm = PvPCore.get().messages();
        p.sendMessage(Text.literal(mm.get(data.partyChat ? "party.chat-on" : "party.chat-off")), false);
        return 1;
    }

    /**
     * Issue 1 (2.2.0): /party duel <leader> - pick a kit (then rounds) and
     * challenge the other party. Only party leaders can start party duels.
     */
    private static int partyDuel(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayer();
        ServerPlayerEntity target = EntityArgumentType.getPlayer(ctx, "player");
        if (p == null) return 0;
        var mm = PvPCore.get().messages();
        PartyManager.Party party = PvPCore.get().partyManager().partyOf(p);
        if (party == null) {
            p.sendMessage(Text.literal(mm.get("party.not-in-party")), false);
            return 0;
        }
        if (!party.isLeader(p.getUuid())) {
            p.sendMessage(Text.literal(mm.get("party.not-leader")), false);
            return 0;
        }
        if (PvPCore.get().partyManager().partyOf(target) == null) {
            p.sendMessage(Text.literal(mm.get("party.target-no-party",
                    Map.of("player", target.getGameProfile().name()))), false);
            return 0;
        }
        // kit picker in party mode -> rounds picker -> party challenge
        new KitPickerGui(p, false, target, true).open(p);
        return 1;
    }

    // ------------------------------------------------------------------
    // Arena commands (admin)
    // ------------------------------------------------------------------

    private static int arenaList(CommandContext<ServerCommandSource> ctx) {
        var arenas = PvPCore.get().arenaManager().all();
        if (arenas.isEmpty()) {
            ctx.getSource().sendFeedback(() -> Text.literal(
                    PvPCore.get().messages().get("arena.none")), false);
            return 1;
        }
        for (Arena arena : arenas) {
            ctx.getSource().sendFeedback(() -> Text.literal(TextUtil.colorize(
                    "&e" + arena.id + " &8- " + arena.statusColored() + " &8- " + arena.displayName)), false);
        }
        return 1;
    }

    private static int arenaCreate(CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity p = ctx.getSource().getPlayer();
        String id = StringArgumentType.getString(ctx, "id");
        if (PvPCore.get().arenaManager().get(id) != null) {
            ctx.getSource().sendError(Text.literal("Arena already exists"));
            return 0;
        }
        Arena arena = PvPCore.get().arenaManager().create(id);
        if (p != null) {
            arena.world = p.getEntityWorld().getRegistryKey().getValue().toString();
        }
        PvPCore.get().arenaManager().save();
        PvPCore.get().auditLog().log(ctx.getSource().getName(), "Created arena " + id);
        ctx.getSource().sendFeedback(() -> Text.literal(
                PvPCore.get().messages().get("arena.created", Map.of("arena", id))), false);
        return 1;
    }

    private static int arenaSpawn(CommandContext<ServerCommandSource> ctx, int which) {
        ServerPlayerEntity p = ctx.getSource().getPlayer();
        if (p == null) return 0;
        // apply to the nearest... we need an id: use "setspawn for arena without id is not supported"
        ctx.getSource().sendError(Text.literal("Usage: /arena setspawn1 <id> (stand where the spawn should be)"));
        return 0;
    }

    private static int arenaSpawnId(CommandContext<ServerCommandSource> ctx, int which) {
        ServerPlayerEntity p = ctx.getSource().getPlayer();
        if (p == null) return 0;
        String id = StringArgumentType.getString(ctx, "id");
        Arena arena = PvPCore.get().arenaManager().get(id);
        if (arena == null) {
            ctx.getSource().sendError(Text.literal("Unknown arena"));
            return 0;
        }
        arena.world = p.getEntityWorld().getRegistryKey().getValue().toString();
        String label;
        switch (which) {
            case 1 -> {
                arena.spawn1X = p.getX(); arena.spawn1Y = p.getY(); arena.spawn1Z = p.getZ();
                arena.spawn1Yaw = p.getYaw(); arena.spawn1Pitch = p.getPitch();
                arena.spawn1Set = true; label = "Spawn 1";
            }
            case 2 -> {
                arena.spawn2X = p.getX(); arena.spawn2Y = p.getY(); arena.spawn2Z = p.getZ();
                arena.spawn2Yaw = p.getYaw(); arena.spawn2Pitch = p.getPitch();
                arena.spawn2Set = true; label = "Spawn 2";
            }
            default -> {
                arena.spectatorX = p.getX(); arena.spectatorY = p.getY(); arena.spectatorZ = p.getZ();
                arena.spectatorYaw = p.getYaw(); arena.spectatorPitch = p.getPitch();
                arena.spectatorSet = true; label = "Spectator spawn";
            }
        }
        PvPCore.get().arenaManager().save();
        PvPCore.get().auditLog().log(ctx.getSource().getName(), "Set " + label + " of arena " + id);
        String finalLabel = label;
        ctx.getSource().sendFeedback(() -> Text.literal(
                PvPCore.get().messages().get("arena.spawn-set", Map.of(
                        "arena", id, "spawn", finalLabel))), false);
        return 1;
    }

    private static int arenaToggle(CommandContext<ServerCommandSource> ctx, boolean enable) {
        String id = StringArgumentType.getString(ctx, "id");
        Arena arena = PvPCore.get().arenaManager().get(id);
        if (arena == null) {
            ctx.getSource().sendError(Text.literal("Unknown arena"));
            return 0;
        }
        arena.enabled = enable;
        PvPCore.get().arenaManager().save();
        PvPCore.get().auditLog().log(ctx.getSource().getName(),
                (enable ? "Enabled " : "Disabled ") + "arena " + id);
        ctx.getSource().sendFeedback(() -> Text.literal(PvPCore.get().messages().get(
                enable ? "arena.enabled" : "arena.disabled", Map.of("arena", id))), false);
        return 1;
    }

    private static int arenaValidate(CommandContext<ServerCommandSource> ctx) {
        String id = StringArgumentType.getString(ctx, "id");
        Arena arena = PvPCore.get().arenaManager().get(id);
        if (arena == null) {
            ctx.getSource().sendError(Text.literal("Unknown arena"));
            return 0;
        }
        var mm = PvPCore.get().messages();
        if (arena.isValid()) {
            ctx.getSource().sendFeedback(() -> Text.literal(mm.get("arena.valid", Map.of("arena", id))), false);
        } else {
            ctx.getSource().sendError(Text.literal(mm.get("arena.invalid", Map.of(
                    "arena", id, "reason", arena.invalidReason()))));
        }
        return arena.isValid() ? 1 : 0;
    }

    private static int arenaTeleport(CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity p = ctx.getSource().getPlayer();
        if (p == null) return 0;
        String id = StringArgumentType.getString(ctx, "id");
        Arena arena = PvPCore.get().arenaManager().get(id);
        if (arena == null) {
            ctx.getSource().sendError(Text.literal("Unknown arena"));
            return 0;
        }
        var world = com.pvpcore.util.TeleportUtil.world(PvPCore.get().server(), arena.world);
        if (world == null) {
            ctx.getSource().sendError(Text.literal("Arena world not found"));
            return 0;
        }
        double x = arena.spawn1Set ? arena.spawn1X : arena.spectatorX;
        double y = arena.spawn1Set ? arena.spawn1Y : arena.spectatorY;
        double z = arena.spawn1Set ? arena.spawn1Z : arena.spectatorZ;
        com.pvpcore.util.TeleportUtil.teleport(p, world, x, y, z, 0, 0);
        ctx.getSource().sendFeedback(() -> Text.literal(
                PvPCore.get().messages().get("arena.teleported", Map.of("arena", id))), false);
        return 1;
    }

    private static int arenaDelete(CommandContext<ServerCommandSource> ctx) {
        String id = StringArgumentType.getString(ctx, "id");
        Arena arena = PvPCore.get().arenaManager().get(id);
        if (arena == null) {
            ctx.getSource().sendError(Text.literal("Unknown arena"));
            return 0;
        }
        if (arena.status != Arena.Status.FREE) {
            ctx.getSource().sendError(Text.literal(
                    PvPCore.get().messages().get("arena.in-use")));
            return 0;
        }
        PvPCore.get().arenaManager().delete(id);
        PvPCore.get().auditLog().log(ctx.getSource().getName(), "Deleted arena " + id);
        ctx.getSource().sendFeedback(() -> Text.literal(
                PvPCore.get().messages().get("arena.deleted", Map.of("arena", id))), false);
        return 1;
    }

    // ------------------------------------------------------------------
    // Admin commands
    // ------------------------------------------------------------------

    private static int adminReload(CommandContext<ServerCommandSource> ctx) {
        long ms = PvPCore.get().reloadConfigs();
        PvPCore.get().auditLog().log(ctx.getSource().getName(), "Reloaded configs");
        ctx.getSource().sendFeedback(() -> Text.literal(
                PvPCore.get().messages().get("reload-done", Map.of("ms", String.valueOf(ms)))), false);
        return 1;
    }

    private static int adminSave(CommandContext<ServerCommandSource> ctx) {
        PvPCore.get().storage().saveAll();
        PvPCore.get().kitManager().save();
        PvPCore.get().arenaManager().save();
        PvPCore.get().auditLog().save();
        ctx.getSource().sendFeedback(() -> Text.literal(
                PvPCore.get().messages().get("data-saved")), false);
        return 1;
    }

    private static int adminSetLobby(CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity p = ctx.getSource().getPlayer();
        if (p == null) return 0;
        var cfg = PvPCore.get().config().lobby;
        cfg.lobbyWorld = p.getEntityWorld().getRegistryKey().getValue().toString();
        cfg.lobbyX = p.getX();
        cfg.lobbyY = p.getY();
        cfg.lobbyZ = p.getZ();
        cfg.lobbyYaw = p.getYaw();
        cfg.lobbyPitch = p.getPitch();
        PvPCore.get().config().save();
        PvPCore.get().auditLog().log(ctx.getSource().getName(), "Set lobby spawn");
        ctx.getSource().sendFeedback(() -> Text.literal(
                PvPCore.get().messages().get("admin.lobby-set")), false);
        return 1;
    }

    private static int adminAudit(CommandContext<ServerCommandSource> ctx) {
        var entries = PvPCore.get().auditLog().entries();
        int from = Math.max(0, entries.size() - 15);
        for (int i = from; i < entries.size(); i++) {
            var e = entries.get(i);
            ctx.getSource().sendFeedback(() -> Text.literal(TextUtil.colorize(
                    "&7[" + java.time.Instant.ofEpochMilli(e.timestamp()) + "] &e" + e.actor() + "&8: &f" + e.action())), false);
        }
        return 1;
    }

    /** Issue 5: create a kit from the admin's CURRENT INVENTORY. */
    private static int kitCreate(CommandContext<ServerCommandSource> ctx, String displayName) {
        ServerPlayerEntity p = ctx.getSource().getPlayer();
        var mm = PvPCore.get().messages();
        if (p == null) {
            ctx.getSource().sendError(Text.literal("Only players can create kits from their inventory."));
            return 0;
        }
        String rawId = StringArgumentType.getString(ctx, "id");
        String id = rawId.toLowerCase();
        if (!com.pvpcore.kit.KitManager.validId(id)) {
            ctx.getSource().sendError(Text.literal(mm.get("kit.invalid-name")));
            return 0;
        }
        if (PvPCore.get().kitManager().get(id) != null) {
            ctx.getSource().sendError(Text.literal(mm.get("kit.already-exists", Map.of("kit", id))));
            return 0;
        }
        Kit kit = PvPCore.get().kitManager().createFromInventory(id, displayName, p.getInventory());
        PvPCore.get().kitManager().put(kit);
        PvPCore.get().auditLog().log(ctx.getSource().getName(), "Created kit " + id + " from inventory");
        ctx.getSource().sendFeedback(() -> Text.literal(
                mm.get("kit.created-from-inventory", Map.of("kit", id))), false);
        return 1;
    }

    private static int kitDelete(CommandContext<ServerCommandSource> ctx) {
        String id = StringArgumentType.getString(ctx, "id");
        PvPCore.get().kitManager().delete(id);
        PvPCore.get().auditLog().log(ctx.getSource().getName(), "Deleted kit " + id);
        ctx.getSource().sendFeedback(() -> Text.literal(
                PvPCore.get().messages().get("kit.deleted", Map.of("kit", id))), false);
        return 1;
    }

    private static int kitList(CommandContext<ServerCommandSource> ctx) {
        for (Kit kit : PvPCore.get().kitManager().all()) {
            ctx.getSource().sendFeedback(() -> Text.literal(TextUtil.colorize(
                    "&e" + kit.id + " &8- &f" + kit.displayName)), false);
        }
        return 1;
    }

    // ------------------------------------------------------------------
    // Debug commands
    // ------------------------------------------------------------------

    private static int debugSummary(CommandContext<ServerCommandSource> ctx) {
        var core = PvPCore.get();
        ctx.getSource().sendFeedback(() -> Text.literal(TextUtil.colorize(
                "&6PvP Core&7: duels=&f" + core.duelManager().allDuels().size()
                        + "&7 queues=&f" + core.queueManager().totalQueued()
                        + "&7 parties=&f" + core.partyManager().allParties().size()
                        + "&7 arenas=&f" + core.arenaManager().all().size()
                        + " &7(&f" + core.arenaManager().countUsable() + "&7 usable)")), false);
        return 1;
    }

    private static int debugState(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity target = EntityArgumentType.getPlayer(ctx, "player");
        var core = PvPCore.get();
        PlayerState state = core.playerManager().state(target);
        Duel duel = core.duelManager().duelOf(target);
        PartyManager.Party party = core.partyManager().partyOf(target);
        ctx.getSource().sendFeedback(() -> Text.literal(TextUtil.colorize(
                "&e" + target.getGameProfile().name()
                        + "&7: state=&f" + state
                        + "&7 loginSynced=&f" + core.playerManager().loginSynced(target)
                        + "&7 duel=&f" + (duel != null ? duel.kitId + " (" + duel.state + ")" : "none")
                        + "&7 party=&f" + (party != null ? party.members.size() + " members" : "none")
                        + "&7 queued=&f" + core.queueManager().isQueued(target))), false);
        return 1;
    }

    private static int debugDuels(CommandContext<ServerCommandSource> ctx) {
        for (Duel duel : PvPCore.get().duelManager().allDuels()) {
            ctx.getSource().sendFeedback(() -> Text.literal(TextUtil.colorize(
                    "&e" + duel.firstAName() + " vs " + duel.firstBName()
                            + " &7kit=&f" + duel.kitId
                            + "&7 state=&f" + duel.state
                            + "&7 arena=&f" + (duel.arena != null ? duel.arena.id : "?"))), false);
        }
        return 1;
    }

    private static int debugArenas(CommandContext<ServerCommandSource> ctx) {
        for (Arena arena : PvPCore.get().arenaManager().all()) {
            ctx.getSource().sendFeedback(() -> Text.literal(TextUtil.colorize(
                    "&e" + arena.id + " &7status=&f" + arena.status
                            + "&7 enabled=&f" + arena.enabled
                            + "&7 spawns=&f" + arena.spawn1Set + "/" + arena.spawn2Set)), false);
        }
        return 1;
    }

    private static int debugQueues(CommandContext<ServerCommandSource> ctx) {
        var entry = PvPCore.get().queueManager();
        ctx.getSource().sendFeedback(() -> Text.literal(TextUtil.colorize(
                "&7Total queued: &f" + entry.totalQueued())), false);
        return 1;
    }
}
