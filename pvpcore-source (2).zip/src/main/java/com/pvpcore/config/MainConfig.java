package com.pvpcore.config;

import com.google.gson.JsonObject;
import com.pvpcore.PvPCoreMod;

import java.nio.file.Path;
import java.util.List;

/**
 * settings.json - every gameplay/behavior value in the mod.
 * Everything is configurable (requirement: full admin configurability).
 */
public final class MainConfig {
    private transient Path file;
    private JsonObject root;

    public General general = new General();
    public Lobby lobby = new Lobby();
    public Duel duel = new Duel();
    public Elo elo = new Elo();
    public QueueSection queue = new QueueSection();
    public PartySection party = new PartySection();
    public Chat chat = new Chat();
    public ScoreboardSection scoreboard = new ScoreboardSection();
    public LobbyScoreboardSection lobbyScoreboard = new LobbyScoreboardSection();
    public KitSection kit = new KitSection();
    public SpectateSection spectate = new SpectateSection();
    public StorageSection storage = new StorageSection();

    public void load(Path configDir) {
        this.file = configDir.resolve("settings.json");
        JsonObject defaults = ConfigFile.GSON.toJsonTree(this).getAsJsonObject();
        JsonObject user = ConfigFile.load(file);
        root = ConfigFile.deepMerge(defaults, user);
        // read back into this object
        MainConfig loaded = ConfigFile.GSON.fromJson(root, MainConfig.class);
        this.general = loaded.general;
        this.lobby = loaded.lobby;
        this.duel = loaded.duel;
        this.elo = loaded.elo;
        this.queue = loaded.queue;
        this.party = loaded.party;
        this.chat = loaded.chat;
        this.scoreboard = loaded.scoreboard;
        this.lobbyScoreboard = loaded.lobbyScoreboard;
        this.kit = loaded.kit;
        this.spectate = loaded.spectate;
        this.storage = loaded.storage;
        // save merged file so admins can see every option (requirement: configure everything)
        ConfigFile.save(file, root);
        PvPCoreMod.LOGGER.info("Loaded settings.json");
    }

    public void save() {
        if (file == null) return;
        JsonObject defaults = ConfigFile.GSON.toJsonTree(this).getAsJsonObject();
        root = ConfigFile.deepMerge(defaults, root);
        ConfigFile.save(file, root);
    }

    public static class General {
        public String prefix = "&8[&6PvP&8] &r";
        public boolean debug = false;
    }

    public static class Lobby {
        /** Give lobby hotbar items. */
        public boolean giveItems = true;
        /** Lock inventory movement in lobby (requirement 1). */
        public boolean lockInventory = true;
        /**
         * Issue 8 (2.2.0): admins are locked too by default. Set true to let
         * op/admin players move items freely in the lobby.
         */
        public boolean adminBypassLock = false;
        /** Issue 8 (2.2.0): block using items (food, pearls, potions) while locked in the lobby. */
        public boolean blockItemUse = true;
        /** Issue 8 (2.2.0): block placing / breaking / interacting with blocks in the lobby. */
        public boolean blockWorldInteraction = true;
        /** Issue 8 (2.2.0): also lock the inventory of players spectating a duel. */
        public boolean lockSpectators = true;
        /**
         * Issue 4 (2.2.0): clear the whole inventory when a duel finishes so
         * players return to the lobby with only the lobby hotbar items.
         */
        public boolean clearInventoryAfterDuel = true;
        /** Issue 3 (2.2.0): teleport players to the lobby point when a duel finishes. */
        public boolean teleportAfterDuel = true;
        /**
         * Login synchronization mode for third-party login GUI compatibility (requirement 3):
         *  - SMART: wait until player moves OR any screen close is detected OR timeout elapses
         *  - TIMEOUT: wait the full timeout after join
         *  - INSTANT: apply immediately on join (for servers without login GUIs)
         */
        public String loginSyncMode = "SMART";
        /** Fallback timeout (ticks) after which lobby items/lock apply no matter what. */
        public int loginTimeoutTicks = 200;
        /** Players are invulnerable in lobby. */
        public boolean invulnerable = true;
        /** Teleport players to the lobby point on join. */
        public boolean teleportOnJoin = false;
        /** Lobby point (used by teleportOnJoin, /lobby and /pvpadmin setlobby). */
        public String lobbyWorld = "minecraft:overworld";
        public double lobbyX = 0, lobbyY = 64, lobbyZ = 0;
        public float lobbyYaw = 0, lobbyPitch = 0;
    }

    public static class Duel {
        public int countdownSeconds = 3;
        public int endDurationSeconds = 3;
        /** Hard timeout for a duel; 0 = unlimited. */
        public int timeoutMinutes = 15;
        /** Reconnect grace period (requirement: disconnect handling). */
        public int disconnectGraceSeconds = 10;
        /** Keep food full during duels. */
        public boolean disableHunger = true;
        /** Full heal + feed on duel start. */
        public boolean healOnStart = true;
        /** Full heal when returning to lobby after a duel. */
        public boolean healAfterDuel = true;
        /** Rematch offer expiry in seconds. */
        public int rematchExpirySeconds = 20;
        /** Show winner/loser titles. */
        public boolean showEndTitles = true;
        /** Issue 9 (2.1.0): duel requests show clickable chat buttons instead of a GUI. */
        public boolean challengeViaChat = true;
        /** Issue 6 (2.2.0): default number of rounds for queue matches and GUI challenges. */
        public int defaultBestOf = 1;
        /** Issue 6 (2.2.0): highest best-of a player may pick (BO1..BO{maxBestOf}). */
        public int maxBestOf = 9;
        /** Issue 5/6 (2.2.0): pause between rounds of a best-of duel, in seconds. */
        public int roundIntermissionSeconds = 5;
        /** Issue 5 (2.2.0): the round/match loser turns into a spectator until the next round or the duel ends. */
        public boolean loserSpectates = true;
    }

    public static class Elo {
        public int startRating = 1000;
        public int kFactor = 32;
        /** Search range expansion by queue wait time (ticks are seconds here). */
        public int range0to10s = 50;
        public int range10to20s = 100;
        public int range20to30s = 150;
        public int range30plus = 250;
    }

    public static class QueueSection {
        /** How often the matchmaker runs (in ticks). */
        public int matchmakingIntervalTicks = 10;
        /** Notify queued players of their position/range every N ticks. */
        public int statusIntervalTicks = 100;
    }

    public static class PartySection {
        public int maxSize = 8;
        public int inviteExpirySeconds = 60;
        public boolean membersCanInvite = true;
        /** Requirement 6: automatically create a party when the party item is clicked. */
        public boolean autoCreateOnItemClick = true;
    }

    public static class Chat {
        /** Master switch: when false, vanilla chat is untouched entirely. */
        public boolean manageChat = true;
        /** Requirement 5: isolate chat during duels. */
        public boolean isolateDuels = true;
        /** Hide global chat FROM players that are inside a duel. */
        public boolean hideGlobalFromDuelists = true;
        /** Duel chat is also visible to spectators of that duel. */
        public boolean duelChatIncludesSpectators = true;
        public String globalFormat = "&7{player}&8: &f{message}";
        public String duelFormat = "&8[&6Duel&8] &7{player}&8: &f{message}";
        public String partyFormat = "&8[&5Party&8] &d{player}&8: &f{message}";
        public String specFormat = "&8[&5Spec&8] &7{player}&8: &f{message}";
    }

    public static class ScoreboardSection {
        /** Requirement 13: per-duel sidebar scoreboard. */
        public boolean enabled = true;
        public String title = "&6&lDUEL";
        public List<String> lines = List.of(
                "&7&m----------------",
                "&6{kit}",
                "",
                "&e{player1} &f{score1} &8- &f{score2} {player2}",
                "&7Round: &f{round}&7/&f{rounds} &8- &7{duration}",
                "",
                "&7Hits: &f{hits1} &8/ &f{hits2}",
                "&7Ping: &a{ping1}ms &8/ &a{ping2}ms"
        );
        public int updateIntervalTicks = 20;
    }

    /**
     * Issue 10 (2.2.0): sidebar scoreboard shown in the LOBBY with player
     * info, a header and the server IP - every line customizable here.
     */
    public static class LobbyScoreboardSection {
        public boolean enabled = true;
        /** Header / title of the sidebar (supports & colors). */
        public String title = "&6&lPvP CORE";
        /** Shown via the {ip} placeholder - set it to your server address! */
        public String serverIp = "&eplay.example.com";
        public int updateIntervalTicks = 20;
        /**
         * Placeholders: {player} {online} {max} {ip} {ping} {wins} {losses}
         * {duels} {winrate} {elo} {rank} {streak} {beststreak} {party}
         * {queue} {world} {date} {time}
         */
        public List<String> lines = List.of(
                "&8&m------------------",
                "&7Player: &f{player}",
                "&7Rank: &f#{rank} &8(&f{elo}&8)",
                "&7Wins: &a{wins} &7Losses: &c{losses}",
                "&7Streak: &f{streak}",
                "",
                "&7Online: &f{online}&7/&f{max}",
                "&7Ping: &f{ping}ms",
                "",
                "{ip}",
                "&8&m------------------"
        );
    }

    public static class KitSection {
        /**
         * Issue 2 (2.2.0): the player kit editor always starts from the
         * ORIGINAL main kit template (as set the first time). Players edit a
         * copy of the original kit; their save becomes their personal layout.
         */
        public boolean editorBaseOnOriginal = true;
    }

    public static class SpectateSection {
        public boolean enabled = true;
        /** Hide spectators from fighters (invisibility). */
        public boolean hideFromFighters = true;
    }

    public static class StorageSection {
        /** Periodic autosave interval in seconds. */
        public int saveIntervalSeconds = 60;
    }
}
