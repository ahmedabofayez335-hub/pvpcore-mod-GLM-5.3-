package com.pvpcore.config;

import com.google.gson.ExclusionStrategy;
import com.google.gson.FieldAttributes;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.pvpcore.PvPCoreMod;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Map;

/**
 * Generic JSON config file loader/saver with atomic writes and deep merge
 * of user values over code defaults (so partial config files always work).
 */
public final class ConfigFile {
    public static final Gson GSON = new GsonBuilder()
            .setPrettyPrinting()
            .disableHtmlEscaping()
            .create();

    private ConfigFile() {}

    /** Load a JSON object from disk (empty if missing). */
    public static JsonObject load(Path file) {
        try {
            if (Files.exists(file)) {
                try (var reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
                    JsonElement el = JsonParser.parseReader(reader);
                    if (el != null && el.isJsonObject()) return el.getAsJsonObject();
                }
            }
        } catch (Exception e) {
            PvPCoreMod.LOGGER.error("Failed to load config {}", file, e);
        }
        return new JsonObject();
    }

    /** Atomically save a JSON object to disk. */
    public static void save(Path file, JsonObject obj) {
        try {
            Files.createDirectories(file.getParent());
            Path tmp = file.resolveSibling(file.getFileName() + ".tmp");
            Files.writeString(tmp, GSON.toJson(obj), StandardCharsets.UTF_8);
            Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException e) {
            PvPCoreMod.LOGGER.error("Failed to save config {}", file, e);
        }
    }

    /** Deep merge: values from {@code overrides} win over {@code base}. Returns base (mutated). */
    public static JsonObject deepMerge(JsonObject base, JsonObject overrides) {
        if (overrides == null) return base;
        for (Map.Entry<String, JsonElement> entry : overrides.entrySet()) {
            String key = entry.getKey();
            JsonElement value = entry.getValue();
            if (base.has(key) && base.get(key).isJsonObject() && value != null && value.isJsonObject()) {
                deepMerge(base.getAsJsonObject(key), value.getAsJsonObject());
            } else {
                base.add(key, value);
            }
        }
        return base;
    }
}
