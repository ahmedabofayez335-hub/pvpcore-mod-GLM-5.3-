package com.pvpcore.config;

import com.google.gson.JsonObject;
import com.pvpcore.PvPCoreMod;
import com.pvpcore.util.ItemCodecUtil;
import net.minecraft.item.ItemStack;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * guis.json - every GUI title, row count and every button item
 * (slot, material, name, lore, amount, glow, enabled) is configurable.
 * Requirement 7 + 12: admins can change any item, any name, anywhere.
 */
public final class GuiConfig {
    private transient Path file;
    private JsonObject root;

    /** Hotbar items shown in the lobby (requirement 10: exact configured slots). */
    public LobbyItems lobby = new LobbyItems();
    /** All chest GUIs. */
    public Map<String, GuiSpec> guis = new LinkedHashMap<>();

    public static class LobbyItems {
        public Map<String, ItemSpec> items = new LinkedHashMap<>();
    }

    public static class GuiSpec {
        public String title = "&8Menu";
        public int rows = 5;
        public Map<String, ItemSpec> items = new LinkedHashMap<>();
        /** Slots used for kit icons in kit list / kit picker GUIs (issue 6: customizable). */
        public List<Integer> kitSlots = new ArrayList<>(DEFAULT_KIT_SLOTS);
    }

    /** Default kit icon slots (3 rows of 7, skipping the border columns). */
    public static final List<Integer> DEFAULT_KIT_SLOTS = List.of(
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25,
            28, 29, 30, 31, 32, 33, 34);

    public static class ItemSpec {
        public boolean enabled = true;
        public int slot = 0;
        public String material = "STONE";
        public int amount = 1;
        public String name = "&fItem";
        public List<String> lore = new ArrayList<>();
        public boolean glow = false;
        /** "SELF" = the viewing player's skin head. */
        public String headOwner = "";
    }

    public void load(Path configDir) {
        this.file = configDir.resolve("guis.json");
        JsonObject defaults = ConfigFile.GSON.toJsonTree(buildDefaults()).getAsJsonObject();
        JsonObject user = ConfigFile.load(file);
        root = ConfigFile.deepMerge(defaults, user);
        sanitizeSlots(root, defaults); // self-heal slots that fall outside their GUI
        GuiConfig merged = ConfigFile.GSON.fromJson(root, GuiConfig.class);
        this.lobby = merged.lobby;
        this.guis = merged.guis;
        ConfigFile.save(file, root);
        PvPCoreMod.LOGGER.info("Loaded guis.json ({} guis)", guis.size());
    }

    public void save() {
        if (file == null) return;
        JsonObject defaults = ConfigFile.GSON.toJsonTree(buildDefaults()).getAsJsonObject();
        root = ConfigFile.deepMerge(defaults, root);
        ConfigFile.save(file, root);
    }

    /** Get a hotbar lobby item spec. */
    public ItemSpec lobbyItem(String key) {
        ItemSpec spec = lobby.items.get(key);
        return spec != null ? spec : fallback(key);
    }

    /** Get a GUI item spec. */
    public ItemSpec item(String guiKey, String itemKey) {
        GuiSpec spec = guis.get(guiKey);
        if (spec != null) {
            ItemSpec item = spec.items.get(itemKey);
            if (item != null) return item;
        }
        return fallback(itemKey);
    }

    /** GUI title (colored by consumers). */
    public String title(String guiKey) {
        GuiSpec spec = guis.get(guiKey);
        return spec != null ? spec.title : "&8Menu";
    }

    public int rows(String guiKey) {
        GuiSpec spec = guis.get(guiKey);
        return spec != null ? Math.max(1, Math.min(6, spec.rows)) : 5;
    }

    /** The slots kit icons occupy in a GUI (issue 6: fully configurable). */
    public List<Integer> kitSlots(String guiKey) {
        GuiSpec spec = guis.get(guiKey);
        if (spec != null && spec.kitSlots != null && !spec.kitSlots.isEmpty()) {
            return spec.kitSlots.stream().filter(s -> s >= 0 && s < 54).toList();
        }
        return DEFAULT_KIT_SLOTS;
    }

    private ItemSpec fallback(String key) {
        ItemSpec spec = new ItemSpec();
        // The filler is a safe, invisible pane - never show "Missing item" for it (issue 1)
        if ("filler".equals(key)) {
            spec.material = "GRAY_STAINED_GLASS_PANE";
            spec.name = "&r";
            spec.slot = 0;
            return spec;
        }
        spec.material = "GRAY_DYE";
        spec.name = "&cMissing item: " + key;
        spec.slot = 0;
        return spec;
    }

    public ItemStack buildItem(String guiKey, String itemKey) {
        return build(item(guiKey, itemKey));
    }

    public ItemStack buildLobbyItem(String key) {
        return build(lobbyItem(key));
    }

    /** Build an ItemStack from a spec. */
    public ItemStack build(ItemSpec spec) {
        ItemStack st = ItemCodecUtil.parseMaterial(spec.material);
        if (st.isEmpty()) st = ItemCodecUtil.parseMaterial("STONE");
        var b = com.pvpcore.item.ItemBuilder.of(st)
                .amount(spec.amount)
                .name(spec.name)
                .lore(spec.lore)
                .glow(spec.glow);
        return b.build();
    }

    // ------------------------------------------------------------------
    // Defaults for every GUI in the mod.
    // ------------------------------------------------------------------

    public GuiConfig buildDefaults() {
        GuiConfig cfg = new GuiConfig();

        // Lobby hotbar (requirement 10: exact slots; requirement 14: no settings item)
        cfg.lobby.items.put("unranked", item(0, "IRON_SWORD", "&b&lUnranked Queue", List.of("&7Click to browse kits", "&7and join the unranked queue.")));
        cfg.lobby.items.put("ranked", item(1, "NETHERITE_SWORD", "&6&lRanked Queue", List.of("&7Click to browse kits", "&7and join the ranked queue.", "&eELO is on the line!")));
        cfg.lobby.items.put("duel", item(2, "BLAZE_ROD", "&c&lDuel a Player", List.of("&7Click to pick an opponent", "&7and challenge them to a duel.")));
        cfg.lobby.items.put("kits", item(3, "BOOK", "&3&lKits", List.of("&7Browse, view and edit", "&7your kit layouts.")));
        cfg.lobby.items.put("party", item(4, "NAME_TAG", "&d&lParty", List.of("&7Click to open the party", "&7menu in chat!")));
        cfg.lobby.items.put("profile", item(6, "PLAYER_HEAD", "&e&lProfile", List.of("&7View your statistics", "&7and match history.")));
        cfg.lobby.items.put("spectate", item(7, "ENDER_EYE", "&5&lSpectate", List.of("&7Watch ongoing duels.")));
        // Item variants
        cfg.lobby.items.put("party_active", item(4, "NAME_TAG", "&d&lParty &7(Open Menu)", List.of("&7Click to open the party", "&7menu in chat: invite, kick,", "&7chat & party duels.")));
        cfg.lobby.items.put("queue_leave", item(0, "REDSTONE", "&c&lLeave Queue", List.of("&7You are queued.", "&7Click to leave the queue.")));
        cfg.lobby.items.put("spectate_return", item(7, "ENDER_PEARL", "&5&lReturn to Lobby", List.of("&7Click to stop spectating", "&7and return.")));
        cfg.lobby.items.put("filler", item(8, "GRAY_STAINED_GLASS_PANE", "&r", List.of()));
        // Issue 7: leaderboard hotbar item removed (disabled by default; admins can re-enable in guis.json)
        ItemSpec leaderboard = item(5, "EMERALD", "&a&lLeaderboards", List.of("&7View the top players", "&7by wins and ELO."));
        leaderboard.enabled = false;
        cfg.lobby.items.put("leaderboard", leaderboard);

        gui(cfg, "kit_list", "&8Kits", 5);
        cfg.guis.get("kit_list").items.put("info", item(4, "BOOK", "&3&lKits", List.of("&7Click a kit to open its details:", "&8- &fLeft-Click &7to edit your layout", "&8- &fRight-Click &7to reset to default")));
        // Issue 5: admin button - create a kit from the current inventory
        cfg.guis.get("kit_list").items.put("create", item(42, "LIME_DYE", "&a&lCreate Kit", List.of("&7Creates a NEW kit from YOUR", "&7current inventory.", "", "&7Armor, hotbar & inventory", "&7are copied exactly.", "&cAdmin only")));
        cfg.guis.get("kit_list").items.put("prev", item(39, "ARROW", "&ePrevious Page", List.of()));
        cfg.guis.get("kit_list").items.put("next", item(41, "ARROW", "&eNext Page", List.of()));
        // was 49 (outside the 45-slot GUI) - fixed
        cfg.guis.get("kit_list").items.put("close", item(40, "BARRIER", "&cClose", List.of()));

        gui(cfg, "kit_stats", "&8Kit Statistics", 5);
        cfg.guis.get("kit_stats").items.put("edit", item(38, "ANVIL", "&eEdit Layout", List.of("&7Open the kit editor for", "&7this kit.")));
        // Issue 8: admin button - edit the kit template everyone receives
        cfg.guis.get("kit_stats").items.put("edit_template", item(42, "COMMAND_BLOCK", "&c&lEdit Template", List.of("&7Edit the DEFAULT layout for", "&7this kit (all players).", "&cAdmin only")));
        cfg.guis.get("kit_stats").items.put("back", item(40, "ARROW", "&eBack", List.of()));
        cfg.guis.get("kit_stats").items.put("close", item(44, "BARRIER", "&cClose", List.of()));

        gui(cfg, "kit_editor", "&8Kit Editor", 6);
        cfg.guis.get("kit_editor").items.put("armor_info", item(5, "ARMOR_STAND", "&fArmor", List.of("&7Place armor pieces in the", "&7top-left 4 slots.")));
        cfg.guis.get("kit_editor").items.put("enchant_target", item(46, "YELLOW_STAINED_GLASS_PANE", "&e&lEnchant Slot", List.of("&7Place an item here,", "&7then click the Enchant", "&7button to enchant it.")));
        cfg.guis.get("kit_editor").items.put("save", item(49, "LIME_DYE", "&a&lSave Kit", List.of("&7Save this layout as", "&7your kit layout.")));
        cfg.guis.get("kit_editor").items.put("clear", item(50, "RED_DYE", "&c&lClear Kit", List.of("&7Remove all items from", "&7this layout.")));
        cfg.guis.get("kit_editor").items.put("palette", item(51, "CHEST", "&b&lItem Palette", List.of("&7Browse every item in the", "&7game and add it to the kit.")));
        cfg.guis.get("kit_editor").items.put("enchant", item(52, "ENCHANTED_BOOK", "&d&lEnchant Item", List.of("&7Enchant the item placed", "&7in the enchant slot.")));
        cfg.guis.get("kit_editor").items.put("back", item(45, "ARROW", "&eBack", List.of()));
        cfg.guis.get("kit_editor").items.put("close", item(53, "BARRIER", "&cClose", List.of()));
        cfg.guis.get("kit_editor").items.put("filler", item(4, "GRAY_STAINED_GLASS_PANE", "&r", List.of()));

        gui(cfg, "palette", "&8Item Palette", 6);
        cfg.guis.get("palette").items.put("prev", item(45, "ARROW", "&ePrevious Page", List.of()));
        cfg.guis.get("palette").items.put("back", item(48, "ARROW", "&eBack to Editor", List.of()));
        cfg.guis.get("palette").items.put("page", item(49, "PAPER", "&fPage &e{page}&f/&e{pages}", List.of()));
        cfg.guis.get("palette").items.put("next", item(53, "ARROW", "&eNext Page", List.of()));

        gui(cfg, "enchant", "&8Enchant Item", 6);
        cfg.guis.get("enchant").items.put("target", item(49, "PAPER", "&dTarget Item", List.of("&7Click an enchantment to", "&7cycle its level.")));
        cfg.guis.get("enchant").items.put("back", item(45, "ARROW", "&eBack to Editor", List.of()));

        gui(cfg, "queue", "&8Select a Kit", 5);
        cfg.guis.get("queue").items.put("prev", item(36, "ARROW", "&ePrevious Page", List.of()));
        cfg.guis.get("queue").items.put("next", item(44, "ARROW", "&eNext Page", List.of()));
        // was 49 (outside the 45-slot GUI) - fixed
        cfg.guis.get("queue").items.put("back", item(40, "ARROW", "&eBack", List.of()));

        gui(cfg, "player_picker", "&8Select a Player", 6);
        cfg.guis.get("player_picker").items.put("prev", item(45, "ARROW", "&ePrevious Page", List.of()));
        cfg.guis.get("player_picker").items.put("page", item(49, "PAPER", "&fPage &e{page}&f/&e{pages}", List.of()));
        cfg.guis.get("player_picker").items.put("next", item(53, "ARROW", "&eNext Page", List.of()));
        cfg.guis.get("player_picker").items.put("back", item(48, "ARROW", "&eBack", List.of()));

        gui(cfg, "challenge", "&8Duel Request", 3);
        cfg.guis.get("challenge").items.put("info", item(13, "PAPER", "&6{player} &7challenges you!", List.of("&7Kit: &f{kit}", "&7Click accept to duel!")));
        cfg.guis.get("challenge").items.put("accept", item(11, "LIME_DYE", "&a&lAccept", List.of("&7Accept the duel request.")));
        cfg.guis.get("challenge").items.put("deny", item(15, "RED_DYE", "&c&lDeny", List.of("&7Deny the duel request.")));

        gui(cfg, "rematch", "&8Rematch?", 3);
        cfg.guis.get("rematch").items.put("info", item(13, "PAPER", "&6{player} &7wants a rematch!", List.of("&7Kit: &f{kit}")));
        cfg.guis.get("rematch").items.put("accept", item(11, "LIME_DYE", "&a&lRematch", List.of("&7Duel again with the same kit.")));
        cfg.guis.get("rematch").items.put("deny", item(15, "RED_DYE", "&c&lDecline", List.of("&7Return to the lobby.")));

        // Issue 6 (2.2.0): pick how many rounds a challenge should have
        gui(cfg, "rounds", "&8Duel Rounds - {player}", 3);
        cfg.guis.get("rounds").items.put("info", item(13, "CLOCK", "&e&lHow many rounds?", List.of("&7Pick the format of the duel:", "&7first to win the majority", "&7of rounds wins the duel.")));
        cfg.guis.get("rounds").items.put("bo1", item(10, "PAPER", "&f&lBest of 1", List.of("&7One round - winner takes all.")));
        cfg.guis.get("rounds").items.put("bo3", item(11, "PAPER", "&f&lBest of 3", List.of("&7First to &f2 &7round wins.")));
        cfg.guis.get("rounds").items.put("bo5", item(15, "PAPER", "&f&lBest of 5", List.of("&7First to &f3 &7round wins.")));
        cfg.guis.get("rounds").items.put("bo7", item(16, "PAPER", "&f&lBest of 7", List.of("&7First to &f4 &7round wins.")));
        cfg.guis.get("rounds").items.put("back", item(22, "BARRIER", "&cClose", List.of("&7Cancel the challenge.")));

        gui(cfg, "stats", "&8Statistics", 6);
        cfg.guis.get("stats").items.put("back", item(45, "ARROW", "&eBack", List.of()));
        cfg.guis.get("stats").items.put("close", item(53, "BARRIER", "&cClose", List.of()));

        gui(cfg, "profile", "&8Profile", 5);
        cfg.guis.get("profile").items.put("head", item(13, "PLAYER_HEAD", "&e{player}", List.of("&7View your duel statistics.")));
        cfg.guis.get("profile").items.put("global", item(11, "NETHER_STAR", "&e&lGlobal Stats", List.of()));
        cfg.guis.get("profile").items.put("kit", item(15, "BOOK", "&e&lKit Stats", List.of("&7Click a kit to view details.")));
        cfg.guis.get("profile").items.put("close", item(31, "BARRIER", "&cClose", List.of()));

        gui(cfg, "leaderboard", "&8Leaderboards", 6);
        cfg.guis.get("leaderboard").items.put("global", item(4, "NETHER_STAR", "&e&lGlobal", List.of("&7Top players across", "&7all kits.")));
        cfg.guis.get("leaderboard").items.put("switch", item(49, "EMERALD", "&e&lTop by: &f{type}", List.of("&7Click to switch between", "&7Wins and ELO.")));
        cfg.guis.get("leaderboard").items.put("prev", item(45, "ARROW", "&ePrevious Page", List.of()));
        cfg.guis.get("leaderboard").items.put("next", item(53, "ARROW", "&eNext Page", List.of()));
        cfg.guis.get("leaderboard").items.put("back", item(48, "ARROW", "&eBack", List.of()));

        gui(cfg, "spectate", "&8Spectate Duels", 6);
        cfg.guis.get("spectate").items.put("info", item(4, "ENDER_EYE", "&5&lOngoing Duels", List.of("&7Click a duel to spectate it.")));
        cfg.guis.get("spectate").items.put("prev", item(45, "ARROW", "&ePrevious Page", List.of()));
        cfg.guis.get("spectate").items.put("next", item(53, "ARROW", "&eNext Page", List.of()));
        cfg.guis.get("spectate").items.put("back", item(49, "BARRIER", "&cClose", List.of()));

        gui(cfg, "confirm", "&8Confirm", 3);
        cfg.guis.get("confirm").items.put("info", item(13, "PAPER", "&e{title}", List.of("{lines}")));
        cfg.guis.get("confirm").items.put("yes", item(11, "LIME_DYE", "&a&lYes", List.of("&7Confirm the action.")));
        cfg.guis.get("confirm").items.put("no", item(15, "RED_DYE", "&c&lNo", List.of("&7Cancel the action.")));

        gui(cfg, "admin", "&8PvP Admin", 6);
        cfg.guis.get("admin").items.put("reload", item(20, "REPEATER", "&e&lReload Configs", List.of("&7Reload settings.json,", "&7guis.json and messages.json.")));
        cfg.guis.get("admin").items.put("save", item(21, "HOPPER", "&e&lSave Data", List.of("&7Force-save all player data", "&7kits and arenas.")));
        cfg.guis.get("admin").items.put("arenas", item(22, "GRASS_BLOCK", "&e&lArenas", List.of("&7Manage duel arenas.")));
        cfg.guis.get("admin").items.put("kits", item(23, "BOOK", "&e&lKits", List.of("&7Manage kits.")));
        cfg.guis.get("admin").items.put("setlobby", item(24, "BEACON", "&e&lSet Lobby", List.of("&7Set the lobby spawn to", "&7your current location.")));
        cfg.guis.get("admin").items.put("close", item(49, "BARRIER", "&cClose", List.of()));

        gui(cfg, "arenas", "&8Arenas", 6);
        cfg.guis.get("arenas").items.put("create", item(45, "LIME_DYE", "&a&lCreate Arena", List.of("&7Create a new arena.")));
        cfg.guis.get("arenas").items.put("info", item(4, "GRASS_BLOCK", "&e&lArenas &7({count})", List.of("&7Left-click an arena to edit.", "&7Right-click to teleport.")));
        cfg.guis.get("arenas").items.put("prev", item(48, "ARROW", "&ePrevious Page", List.of()));
        cfg.guis.get("arenas").items.put("next", item(52, "ARROW", "&eNext Page", List.of()));
        cfg.guis.get("arenas").items.put("back", item(49, "ARROW", "&eBack", List.of()));

        gui(cfg, "arena_editor", "&8Edit Arena", 5);
        cfg.guis.get("arena_editor").items.put("info", item(4, "PAPER", "&e&l{arena}", List.of("&7Status: {status}", "&7Spawns set: {spawns}")));
        cfg.guis.get("arena_editor").items.put("setspawn1", item(19, "RED_BED", "&c&lSet Spawn 1", List.of("&7Set spawn 1 to your", "&7current location.")));
        cfg.guis.get("arena_editor").items.put("setspawn2", item(20, "BLUE_BED", "&9&lSet Spawn 2", List.of("&7Set spawn 2 to your", "&7current location.")));
        cfg.guis.get("arena_editor").items.put("setspectator", item(21, "ENDER_EYE", "&5&lSet Spectator Spawn", List.of("&7Set the spectator spawn", "&7to your current location.")));
        cfg.guis.get("arena_editor").items.put("teleport", item(23, "ENDER_PEARL", "&d&lTeleport", List.of("&7Teleport to this arena.")));
        cfg.guis.get("arena_editor").items.put("enable", item(24, "LIME_DYE", "&a&lToggle Enabled", List.of("&7Currently: {status}")));
        cfg.guis.get("arena_editor").items.put("validate", item(25, "EMERALD", "&e&lValidate", List.of("&7Check that this arena", "&7is ready for duels.")));
        cfg.guis.get("arena_editor").items.put("rename", item(31, "ANVIL", "&e&lRename", List.of("&7Rename this arena.")));
        cfg.guis.get("arena_editor").items.put("delete", item(40, "TNT", "&c&lDelete Arena", List.of("&7Delete this arena", "&7permanently!")));
        cfg.guis.get("arena_editor").items.put("back", item(36, "ARROW", "&eBack", List.of()));

        // Issue 1: every GUI gets a filler item so no GUI ever shows "Missing item: filler"
        for (GuiSpec spec : cfg.guis.values()) {
            if (!spec.items.containsKey("filler")) {
                spec.items.put("filler", item(0, "GRAY_STAINED_GLASS_PANE", "&r", List.of()));
            }
        }

        return cfg;
    }

    private static void gui(GuiConfig cfg, String key, String title, int rows) {
        GuiSpec spec = new GuiSpec();
        spec.title = title;
        spec.rows = rows;
        cfg.guis.put(key, spec);
    }

    /**
     * Self-heal item slots that fall outside their GUI (e.g. old configs with
     * slot 49 in a 45-slot GUI). The item is moved to its default slot, or the
     * last slot of the GUI if the default is also out of range.
     */
    private static void sanitizeSlots(JsonObject root, JsonObject defaults) {
        try {
            JsonObject guis = root.getAsJsonObject("guis");
            JsonObject defGuis = defaults.getAsJsonObject("guis");
            if (guis == null) return;
            for (Map.Entry<String, com.google.gson.JsonElement> e : guis.entrySet()) {
                if (!e.getValue().isJsonObject()) continue;
                JsonObject spec = e.getValue().getAsJsonObject();
                int rows = spec.has("rows") && spec.get("rows").isJsonPrimitive() ? spec.get("rows").getAsInt() : 5;
                int size = Math.max(1, Math.min(6, rows)) * 9;
                JsonObject items = spec.has("items") && spec.get("items").isJsonObject()
                        ? spec.getAsJsonObject("items") : null;
                if (items == null) continue;
                JsonObject defSpec = defGuis != null && defGuis.has(e.getKey()) ? defGuis.getAsJsonObject(e.getKey()) : null;
                JsonObject defItems = defSpec != null && defSpec.has("items") ? defSpec.getAsJsonObject("items") : null;
                for (Map.Entry<String, com.google.gson.JsonElement> it : items.entrySet()) {
                    if (!it.getValue().isJsonObject()) continue;
                    JsonObject item = it.getValue().getAsJsonObject();
                    if (!item.has("slot") || !item.get("slot").isJsonPrimitive()) continue;
                    int slot = item.get("slot").getAsInt();
                    if (slot >= 0 && slot < size) continue;
                    int defSlot = 0;
                    if (defItems != null && defItems.has(it.getKey()) && defItems.get(it.getKey()).isJsonObject()) {
                        defSlot = defItems.getAsJsonObject(it.getKey()).get("slot").getAsInt();
                    }
                    if (defSlot < 0 || defSlot >= size) defSlot = size - 1;
                    item.addProperty("slot", defSlot);
                }
            }
        } catch (Exception ex) {
            PvPCoreMod.LOGGER.warn("Could not sanitize GUI slots: {}", ex.getMessage());
        }
    }

    private static ItemSpec item(int slot, String material, String name, List<String> lore) {
        ItemSpec spec = new ItemSpec();
        spec.slot = slot;
        spec.material = material;
        spec.name = name;
        spec.lore = new ArrayList<>(lore);
        return spec;
    }
}
