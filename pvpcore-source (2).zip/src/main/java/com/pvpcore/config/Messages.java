package com.pvpcore.config;

import com.google.gson.JsonObject;
import com.pvpcore.PvPCoreMod;
import com.pvpcore.util.TextUtil;

import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * messages.json - every single message in the mod is configurable
 * with & color codes and {placeholders} (requirement 7/12).
 */
public final class Messages {
    private transient Path file;
    private JsonObject root;
    private final Map<String, String> defaults = new LinkedHashMap<>();
    private final Map<String, String> values = new LinkedHashMap<>();

    public void load(Path configDir) {
        this.file = configDir.resolve("messages.json");
        if (defaults.isEmpty()) registerDefaults();
        JsonObject defObj = new JsonObject();
        defaults.forEach(defObj::addProperty);
        JsonObject user = ConfigFile.load(file);
        root = ConfigFile.deepMerge(defObj, user);
        values.clear();
        for (Map.Entry<String, com.google.gson.JsonElement> e : root.entrySet()) {
            if (e.getValue().isJsonPrimitive()) values.put(e.getKey(), e.getValue().getAsString());
        }
        ConfigFile.save(file, root);
        PvPCoreMod.LOGGER.info("Loaded messages.json ({} messages)", values.size());
    }

    public String raw(String key) {
        String v = values.get(key);
        if (v != null) return v;
        return defaults.getOrDefault(key, key);
    }

    /** Get a colored message with placeholders applied. */
    public String get(String key, Map<String, String> vars) {
        return TextUtil.colorAndPlace(raw(key), vars);
    }

    public String get(String key) {
        return TextUtil.colorize(raw(key));
    }

    public String plain(String key, Map<String, String> vars) {
        return TextUtil.placeholders(raw(key), vars);
    }

    /** Set a message value at runtime (used by the admin GUI/config editor). */
    public void set(String key, String value) {
        values.put(key, value);
        if (root == null) root = new JsonObject();
        root.addProperty(key, value);
    }

    public Map<String, String> all() {
        return values;
    }

    public void save() {
        if (file == null) return;
        ConfigFile.save(file, root);
    }

    private void reg(String key, String value) {
        defaults.put(key, value);
    }

    private void registerDefaults() {
        // General
        reg("prefix", "&8[&6PvP&8] &r");
        reg("no-permission", "&cYou don't have permission to do that.");
        reg("player-not-found", "&cPlayer &e{player} &cwas not found.");
        reg("player-only", "&cThis can only be used by players.");
        reg("not-in-lobby", "&cYou can't do that right now.");
        reg("reload-done", "&aReloaded all configs in &f{ms}ms&a.");
        reg("data-saved", "&aAll data saved.");

        // Lobby / login sync
        reg("lobby.applied", "&7Lobby items applied.");
        reg("lobby.items-locked", "&cYour lobby items are locked.");
        reg("lobby.teleported", "&7Teleported to the lobby.");
        reg("lobby.not-set", "&cThe lobby location is not set yet. An admin must run &f/pvpadmin setlobby&c.");

        // Queue
        reg("queue.joined", "&aYou joined the &e{type} &aqueue for kit &e{kit}&a.");
        reg("queue.left", "&cYou left the queue.");
        reg("queue.not-queued", "&cYou are not in a queue.");
        reg("queue.status", "&7In queue: &f{kit} &8({type}) &7- &f{position} &7player(s) waiting &f{range}");
        reg("queue.matched", "&aMatch found! &7Kit: &f{kit} &8| &7Arena: &f{arena}");
        reg("queue.already", "&cYou are already in a queue. Click the leave item or use /leavequeue.");

        // Duel
        reg("duel.challenge-sent", "&aChallenge sent to &e{player}&a. Kit: &f{kit}");
        reg("duel.challenge-received-title", "&6DUEL REQUEST");
        reg("duel.challenge-received-subtitle", "&e{player} &7challenged you!");
        reg("duel.challenge-expired", "&cThe duel request from &e{player} &cexpired.");
        reg("duel.challenge-expired-sender", "&cYour duel request to &e{player} &cexpired.");
        reg("duel.challenge-denied", "&c&e{player} &cdenied your duel request.");
        reg("duel.challenge-busy", "&c{player} is busy right now.");
        // Issue 9: clickable chat buttons for duel requests
        reg("duel.challenge-chat-header", "&e{player} &7challenged you to a &f{kit} &7duel!");
        reg("duel.challenge-accept-button", " [ACCEPT] ");
        reg("duel.challenge-deny-button", " [DENY] ");
        reg("duel.challenge-accept-hover", "&aClick to accept the duel");
        reg("duel.challenge-deny-hover", "&cClick to deny the duel");
        reg("duel.challenge-chat-expire", "&7This request expires in &f{seconds}s&7.");
        reg("duel.best-of-line", "&7Rounds: &fBest of {rounds}");
        reg("duel.already-in-duel", "&cYou are already in a duel! Finish it first.");
        reg("duel.busy", "&c{player} is busy right now.");
        reg("duel.round-won", "&e{winner} &awon round &f{round}&a! &7({score1} - {score2})");
        reg("duel.round-next", "&7Next round &f({round}&7/&f{rounds}&7) starts in &f{seconds}s&7...");
        reg("duel.round-countdown-title", "&6Round {round}");
        reg("duel.round-lost-subtitle", "&7You lost this round! Spectating until the next one...");
        reg("duel.no-request", "&cYou have no pending duel request.");
        // Issue 3: /leave
        reg("leave.duel-left", "&cYou left the duel. Your opponent wins.");
        reg("leave.queue-left", "&cYou left the queue.");
        reg("leave.nothing", "&cYou are not in a duel or a queue.");
        reg("duel.countdown-title", "&c{seconds}");
        reg("duel.fight-title", "&aFIGHT!");
        reg("duel.win-title", "&6&lVICTORY!");
        reg("duel.win-subtitle", "&7You defeated &f{loser}");
        reg("duel.lose-title", "&c&lDEFEAT");
        reg("duel.lose-subtitle", "&7You were defeated by &f{winner}");
        reg("duel.draw-title", "&e&lDRAW");
        reg("duel.started", "&7The duel &e{kit} &7between &f{player1} &7and &f{player2} &7has started in &f{arena}&7!");
        reg("duel.ended", "&e{winner} &adefeated &e{loser} &7in a &f{kit} &7duel &8(&f{duration}&8)");
        reg("duel.draw", "&7The duel between &f{player1} &7and &f{player2} &7ended in a draw &8(&f{duration}&8)");
        reg("duel.timeout", "&cThe duel timed out.");
        reg("duel.elo-change", "&7ELO: &f{kit} &8- &e{player1} {delta1} &8({rating1}) &7| &e{player2} {delta2} &8({rating2})");
        reg("duel.opponent-disconnected", "&e{player} &edisconnected! Waiting &f{seconds}s &efor them to reconnect...");
        reg("duel.opponent-returned", "&a{player} &areconnected!");
        reg("duel.won-by-disconnect", "&7Your opponent did not return in time.");
        reg("duel.rematch-sent", "&aRematch offer sent to &e{player}&a.");
        reg("duel.rematch-accepted", "&aRematch accepted!");
        reg("duel.rematch-declined", "&cRematch declined.");
        reg("duel.opponent-left", "&cYour opponent left.");

        // Kit
        reg("kit.not-found", "&cKit &e{kit} &cnot found.");
        reg("kit.layout-saved", "&aKit layout saved: &f{kit}");
        reg("kit.layout-reset", "&aKit layout reset to default: &f{kit}");
        reg("kit.cleared", "&7Kit layout cleared.");
        reg("kit.item-added", "&7Added &f{item} &7to your layout.");
        reg("kit.enchanted", "&7Enchanted: &f{enchant} {level}");
        reg("kit.enchant-removed", "&7Removed enchant: &f{enchant}");
        reg("kit.renamed", "&aKit renamed to &f{name}&a.");
        reg("kit.created", "&aKit &e{kit} &acreated.");
        reg("kit.deleted", "&cKit &e{kit} &cdeleted.");
        reg("kit.already-exists", "&cKit &e{kit} &calready exists.");
        reg("kit.invalid-name", "&cInvalid kit id. Use letters, numbers, - and _ only.");
        reg("kit.created-from-inventory", "&aKit &e{kit} &acreated from your inventory! Edit it in the Kits menu.");
        reg("kit.template-saved", "&aKit template saved: &f{kit} &7(all players get this layout by default).");
        reg("kit.no-item-to-enchant", "&cPlace an item in the enchant slot first.");
        reg("kit.save-hint", "&7Remember to press &aSave &7or close to auto-save.");
        reg("kit.editor-original", "&7Editing a copy of the &foriginal {kit} &7kit. Saving stores your personal layout.");

        // Party
        reg("party.created", "&dYou created a party! Invite players with &f/party invite <player>&d.");
        reg("party.disbanded", "&dThe party was disbanded.");
        reg("party.left", "&dYou left the party.");
        reg("party.joined", "&dYou joined &e{player}&d's party!");
        reg("party.player-joined", "&d{player} &djoined the party!");
        reg("party.player-left", "&d{player} &dleft the party.");
        reg("party.kicked", "&c{player} &cwas kicked from the party.");
        reg("party.you-kicked", "&cYou were kicked from the party.");
        reg("party.invite-sent", "&dInvite sent to &e{player}&d.");
        reg("party.invite-received-title", "&dPARTY INVITE");
        reg("party.invite-received-subtitle", "&e{player} &7invited you to their party!");
        reg("party.invite-expired", "&cThe party invite expired.");
        reg("party.invite-denied", "&c{player} &cdeclined the party invite.");
        reg("party.promoted", "&d{player} &dis now the party leader.");
        reg("party.you-promoted", "&dYou are now the party leader!");
        reg("party.full", "&cThe party is full &8({max}&c).");
        reg("party.already-in-party", "&cYou are already in a party.");
        reg("party.not-in-party", "&cYou are not in a party.");
        reg("party.not-leader", "&cOnly the party leader can do that.");
        reg("party.chat-on", "&dParty chat: &aON");
        reg("party.chat-off", "&dParty chat: &cOFF");
        reg("party.no-parties", "&cThere are no other parties to duel.");
        reg("party.challenge-sent", "&dParty duel challenge sent to &e{leader}&d's party!");
        reg("party.challenge-received-title", "&dPARTY DUEL");
        reg("party.challenge-received-subtitle", "&e{leader} &7challenged your party to a {kit} duel!");
        // Issue 1 (2.2.0): party management lives in CHAT, not a GUI
        reg("party.menu-header", "&8&m--------&r &d&lPARTY &7({online}&7/&f{max}&7) &8&m--------");
        reg("party.menu-members", "&dMembers: {members}");
        reg("party.invite-chat-header", "&d{player} &7invited you to their party!");
        reg("party.accept-button", " [ACCEPT] ");
        reg("party.deny-button", " [DENY] ");
        reg("party.accept-hover", "&aClick to join the party");
        reg("party.deny-hover", "&cClick to decline the invite");
        reg("party.menu-invite-players", "&dClick a player to invite them:");
        reg("party.menu-invite-none", "&7No online players can be invited right now.");
        reg("party.menu-invite-button", " [INVITE] ");
        reg("party.menu-invite-hover", "&aClick to pick players to invite");
        reg("party.menu-chat-button", " [CHAT: {status}] ");
        reg("party.menu-chat-hover", "&7Click to toggle party-only chat");
        reg("party.menu-duel-button", " [DUEL] ");
        reg("party.menu-duel-hover", "&7Click to challenge another party");
        reg("party.menu-duel-leaders", "&dClick a party leader to duel:");
        reg("party.menu-duel-none", "&7There are no other parties to duel right now.");
        reg("party.menu-manage-button", " [MANAGE] ");
        reg("party.menu-manage-hover", "&7Click to promote / kick members");
        reg("party.menu-members-line", "&d{player} &8-");
        reg("party.menu-leave-button", " [LEAVE] ");
        reg("party.menu-leave-hover", "&cClick to leave the party");
        reg("party.menu-disband-button", " [DISBAND] ");
        reg("party.menu-disband-hover", "&cClick to disband the party");
        reg("party.menu-close-button", " [CLOSE] ");
        reg("party.menu-close-hover", "&7Close the party menu");
        reg("party.menu-hint", "&7Tip: the party menu is always in chat - click your &dParty &7item!");
        reg("party.target-in-duel", "&c{player} is in a duel right now.");
        reg("party.target-no-party", "&c{player} is not in a party.");
        reg("party.you-in-duel", "&cYou can't manage parties while dueling!");
        reg("party.cant-while-dueling", "&cYou can't join a party while you are in a duel!");
        reg("party.menu-close-hint", "&7Click your &dParty &7item or use &f/party &7any time to reopen the menu.");

        // Spectate
        reg("spectate.started", "&5You are now spectating &e{player1} &7vs &e{player2}&7.");
        reg("spectate.ended", "&5You are no longer spectating.");
        reg("spectate.no-duels", "&7There are no ongoing duels right now.");
        reg("spectate.return", "&7Click the &5Return &7item or use this item again to go back.");
        // Issue 5 (2.2.0): the duel/round loser spectates after losing
        reg("spectate.loser-started", "&cYou lost the duel! You are now spectating. Click the &5Return &7item, the button below or use &f/leave &7to go back to the lobby.");
        reg("spectate.loser-return-button", " [RETURN TO LOBBY] ");
        reg("spectate.loser-return-hover", "&aClick to return to the lobby");

        // Stats / leaderboard
        reg("stats.header", "&8&m----------&r &e{player} &8&m----------");
        reg("stats.line", "&7{kit}: &f{wins}W&7/&f{losses}L &8- &f{elo} ELO");
        reg("leaderboard.header", "&8&m--------&r &eTop {type} &8[&f{kit}&8] &8&m--------");
        reg("leaderboard.entry", "&e#{position} &f{player} &8- &f{value}");
        reg("leaderboard.empty", "&7No entries yet. Be the first!");

        // Arena
        reg("arena.created", "&aArena &e{arena} &acreated! Set its spawns in the arena editor.");
        reg("arena.deleted", "&cArena &e{arena} &cdeleted.");
        reg("arena.spawn-set", "&a{arena}: &f{spawn} &aset to your current location.");
        reg("arena.enabled", "&aArena &e{arena} &aenabled.");
        reg("arena.disabled", "&cArena &e{arena} &cdisabled.");
        reg("arena.valid", "&aArena &e{arena} &ais valid and ready for duels!");
        reg("arena.invalid", "&cArena &e{arena} &cis not ready: {reason}");
        reg("arena.teleported", "&7Teleported to arena &f{arena}&7.");
        reg("arena.renamed", "&aArena renamed to &f{name}&a.");
        reg("arena.none", "&cNo arenas exist yet.");
        reg("arena.in-use", "&cThat arena is currently in use.");

        // Admin
        reg("admin.gui-opened", "&7Admin panel opened.");
        reg("admin.lobby-set", "&aLobby spawn set to your current location.");
        reg("admin.audit-recorded", "&7Logged: {entry}");

        // Anvil input
        reg("input.enter-name", "&7Type a name in the text field, then click &aConfirm&7.");
        reg("input.invalid-name", "&cInvalid name. Try again.");
    }
}
