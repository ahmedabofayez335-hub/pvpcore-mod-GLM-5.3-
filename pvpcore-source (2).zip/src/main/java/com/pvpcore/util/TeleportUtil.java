package com.pvpcore.util;

import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.TeleportTarget;

/**
 * Centralized teleport helpers (isolates version-specific TeleportTarget API).
 */
public final class TeleportUtil {

    private TeleportUtil() {}

    /** Teleport a player within/between worlds. */
    public static void teleport(ServerPlayerEntity player, ServerWorld world, double x, double y, double z, float yaw, float pitch) {
        if (player.getEntityWorld() == world) {
            player.networkHandler.requestTeleport(x, y, z, yaw, pitch);
        } else {
            player.teleportTo(new TeleportTarget(world, new Vec3d(x, y, z), Vec3d.ZERO, yaw, pitch, entity -> {}));
        }
    }

    /** Resolve a world by "modid:name" key. */
    public static ServerWorld world(MinecraftServer server, String key) {
        try {
            String[] parts = key.contains(":") ? key.split(":", 2) : new String[]{"minecraft", key};
            RegistryKey<net.minecraft.world.World> worldKey = RegistryKey.of(RegistryKeys.WORLD, Identifier.of(parts[0], parts[1]));
            return server.getWorld(worldKey);
        } catch (Exception e) {
            return null;
        }
    }

    /** Is the position inside the world's vertical limits (spawn sanity check)? */
    public static boolean isValidPos(ServerWorld world, double x, double y, double z) {
        return y >= world.getBottomY() && y <= world.getBottomY() + world.getHeight();
    }
}
