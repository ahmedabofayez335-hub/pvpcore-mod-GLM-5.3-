package com.pvpcore.util;

import net.minecraft.text.ClickEvent;
import net.minecraft.text.HoverEvent;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/**
 * Clickable chat buttons (issue 9: duel accept/deny live in chat, not a GUI).
 */
public final class ChatButtons {
    private ChatButtons() {}

    /** A bold, colored, clickable [BUTTON] with a hover tooltip that runs a command. */
    public static MutableText button(String label, String command, String hover, Formatting color) {
        return Text.literal(label).styled(s -> s
                .withColor(color)
                .withBold(true)
                .withClickEvent(new ClickEvent.RunCommand(command))
                .withHoverEvent(new HoverEvent.ShowText(TextUtil.text(hover))));
    }

    /** Compose parts into one chat line: [accept] [deny] etc. */
    public static MutableText line(Text... parts) {
        MutableText out = Text.literal("");
        for (Text p : parts) out.append(p);
        return out;
    }
}
