package com.pvpcore.util;

import net.minecraft.network.packet.s2c.play.SubtitleS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleFadeS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleS2CPacket;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

/**
 * Title/subtitle helpers (isolates packet API).
 */
public final class TitleUtil {

    private TitleUtil() {}

    public static void title(ServerPlayerEntity player, String title, String subtitle, int fadeIn, int stay, int fadeOut) {
        Text t = TextUtil.text(title);
        Text s = TextUtil.text(subtitle);
        player.networkHandler.sendPacket(new TitleFadeS2CPacket(fadeIn, stay, fadeOut));
        player.networkHandler.sendPacket(new TitleS2CPacket(t));
        if (!subtitle.isEmpty()) player.networkHandler.sendPacket(new SubtitleS2CPacket(s));
    }

    public static void title(ServerPlayerEntity player, String title, String subtitle) {
        title(player, title, subtitle, 5, 25, 5);
    }
}
