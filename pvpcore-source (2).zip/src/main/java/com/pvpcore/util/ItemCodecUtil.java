package com.pvpcore.util;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.StringNbtReader;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

/**
 * ItemStack <-> SNBT string serialization for JSON storage.
 */
public final class ItemCodecUtil {

    private ItemCodecUtil() {}

    /** Serialize an ItemStack to an SNBT string ("" for empty). */
    public static String toSnbt(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return "";
        var res = ItemStack.CODEC.encodeStart(NbtOps.INSTANCE, stack);
        var opt = res.result();
        if (opt.isEmpty()) return "";
        NbtElement el = opt.get();
        return el.toString();
    }

    /** Deserialize an ItemStack from an SNBT string (EMPTY for null/blank). */
    public static ItemStack fromSnbt(String s) {
        if (s == null || s.isBlank()) return ItemStack.EMPTY;
        try {
            NbtCompound compound = StringNbtReader.readCompound(s);
            var res = ItemStack.CODEC.parse(NbtOps.INSTANCE, compound);
            var opt = res.result();
            if (opt.isEmpty()) return ItemStack.EMPTY;
            ItemStack st = opt.get();
            if (st.getCount() <= 0) st.setCount(1);
            return st;
        } catch (Exception e) {
            return ItemStack.EMPTY;
        }
    }

    public static ItemStack copy(ItemStack st) {
        return st == null ? ItemStack.EMPTY : st.copy();
    }

    /** Parse a material name like "IRON_SWORD", "iron_sword" or "minecraft:iron_sword". */
    public static ItemStack parseMaterial(String name) {
        if (name == null || name.isBlank()) return ItemStack.EMPTY;
        String ns = "minecraft";
        String path = name.trim().toLowerCase();
        if (path.contains(":")) {
            String[] parts = path.split(":", 2);
            ns = parts[0];
            path = parts[1];
        }
        Identifier id = Identifier.tryParse(ns + ":" + path);
        if (id == null) return ItemStack.EMPTY;
        Item item = Registries.ITEM.get(id);
        return item == null ? ItemStack.EMPTY : new ItemStack(item);
    }
}
