package com.pvpcore.util;

import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Text helpers: color codes (& -> section sign), placeholders, time formatting.
 */
public final class TextUtil {
    private static final Pattern HEX_PATTERN = Pattern.compile("&(#([0-9a-fA-F]{6}))");

    private TextUtil() {}

    /** Translate & color codes (and &#rrggbb hex) into legacy section codes. */
    public static String colorize(String s) {
        if (s == null) return "";
        Matcher m = HEX_PATTERN.matcher(s);
        StringBuilder sb = new StringBuilder();
        while (m.find()) {
            String hex = m.group(2);
            StringBuilder rep = new StringBuilder("§x");
            for (char c : hex.toCharArray()) rep.append('§').append(Character.toLowerCase(c));
            m.appendReplacement(sb, Matcher.quoteReplacement(rep.toString()));
        }
        m.appendTail(sb);
        return sb.toString().replace('&', '§');
    }

    /** Apply {placeholders} from a map. */
    public static String placeholders(String s, Map<String, String> vars) {
        if (s == null) return "";
        if (vars != null) {
            for (Map.Entry<String, String> e : vars.entrySet()) {
                s = s.replace("{" + e.getKey() + "}", e.getValue() == null ? "" : e.getValue());
            }
        }
        return s;
    }

    public static String colorAndPlace(String s, Map<String, String> vars) {
        return colorize(placeholders(s, vars));
    }

    public static Text text(String s) {
        return Text.literal(colorize(s));
    }

    public static Text text(String s, Map<String, String> vars) {
        return Text.literal(colorAndPlace(s, vars));
    }

    /** mm:ss duration format from ticks. */
    public static String formatDurationTicks(long ticks) {
        long totalSeconds = Math.max(0, ticks / 20);
        return String.format("%02d:%02d", totalSeconds / 60, totalSeconds % 60);
    }

    public static String formatSeconds(long seconds) {
        seconds = Math.max(0, seconds);
        return String.format("%02d:%02d", seconds / 60, seconds % 60);
    }

    /** Strip all color codes from a string. */
    public static String stripColor(String s) {
        if (s == null) return "";
        return s.replaceAll("§[0-9a-fk-orx]", "").replaceAll("§x(§[0-9a-f]){6}", "");
    }

    /** Truncate to 40 chars (scoreboard line limit), preserving color codes. */
    public static String sbLine(String s) {
        String colored = colorize(s);
        // count visible chars
        StringBuilder out = new StringBuilder();
        int visible = 0;
        for (int i = 0; i < colored.length(); i++) {
            char c = colored.charAt(i);
            if (c == '§') {
                out.append(c);
                if (i + 1 < colored.length()) {
                    out.append(colored.charAt(++i));
                }
                continue;
            }
            if (visible >= 38) break;
            out.append(c);
            visible++;
        }
        return out.toString();
    }

    public static Formatting parseFormatting(String name, Formatting def) {
        try {
            return Formatting.valueOf(name.toUpperCase());
        } catch (IllegalArgumentException e) {
            return def;
        }
    }
}
