package com.pvpcore.util;

import com.pvpcore.PvPCore;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

/**
 * Enchantments are data-driven (dynamic registry) in modern versions -
 * this helper resolves them through the server's registry manager.
 */
public final class EnchantUtil {

    private EnchantUtil() {}

    public static Registry<Enchantment> registry() {
        return PvPCore.get().server().getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT);
    }

    /** Resolve an enchantment entry like "sharpness" or "minecraft:sharpness" (null if missing). */
    public static RegistryEntry<Enchantment> byId(String id) {
        if (id == null || id.isBlank()) return null;
        String s = id.trim().toLowerCase();
        if (!s.contains(":")) s = "minecraft:" + s;
        Identifier identifier = Identifier.tryParse(s);
        if (identifier == null) return null;
        return registry().getEntry(identifier).orElse(null);
    }

    /** All registered enchantment entries. */
    public static List<RegistryEntry<Enchantment>> all() {
        List<RegistryEntry<Enchantment>> out = new ArrayList<>();
        for (var e : registry().getEntrySet()) {
            RegistryEntry<Enchantment> entry = registry().getEntry(e.getValue());
            if (entry != null) out.add(entry);
        }
        return out;
    }
}
