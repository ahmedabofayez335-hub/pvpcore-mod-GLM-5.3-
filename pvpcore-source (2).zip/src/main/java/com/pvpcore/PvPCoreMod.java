package com.pvpcore;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.network.ServerPlayerEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * PvP Core - complete practice PvP core, 100% server side.
 * Vanilla clients can join without installing anything.
 */
public class PvPCoreMod implements ModInitializer {
    public static final String MOD_ID = "pvpcore";
    public static final Logger LOGGER = LoggerFactory.getLogger("PvP Core");

    @Override
    public void onInitialize() {
        PvPCore.init();

        ServerLifecycleEvents.SERVER_STARTED.register(server -> PvPCore.get().onServerStarted(server));
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> PvPCore.get().onServerStopping());

        // Player join / quit (these events may fire on netty threads -> hop to server thread)
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) ->
                server.execute(() -> PvPCore.get().playerManager().onJoin(handler.player)));
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) ->
                server.execute(() -> PvPCore.get().playerManager().onQuit(handler.player)));

        ServerTickEvents.END_SERVER_TICK.register(server -> PvPCore.get().tick());

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                com.pvpcore.command.PvPCommands.register(dispatcher));

        // Damage filtering: lobby protection, duel damage rules, spectator protection,
        // and lethal-damage capture (ends duels without a death screen).
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) ->
                PvPCore.get().duelManager().allowDamage(entity, source, amount));

        // Issue 10: chat routing via the Fabric message event. Cancelling the
        // raw signed-chat packet (the old mixin) breaks chat-chain bookkeeping;
        // ALLOW_CHAT_MESSAGE fires after validation, so cancelling here is safe.
        ServerMessageEvents.ALLOW_CHAT_MESSAGE.register((message, sender, params) -> {
            if (PvPCore.get().server() == null || PvPCore.get().chatRouter() == null) return true;
            if (!PvPCore.get().config().chat.manageChat) return true; // vanilla chat
            String content = message.getContent().getString();
            if (content == null || content.isBlank()) return true;
            PvPCore.get().chatRouter().handle(sender, content);
            return false; // we already delivered the message ourselves
        });

        // Lobby hotbar items -> GUI actions (requirement 11: everything is a GUI)
        com.pvpcore.lobby.LobbyItemListener.register();

        PvPCoreMod.LOGGER.info("PvP Core initialized (server-side practice core).");
    }
}
