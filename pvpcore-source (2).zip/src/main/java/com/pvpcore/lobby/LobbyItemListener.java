package com.pvpcore.lobby;

import com.pvpcore.PvPCore;
import com.pvpcore.item.ItemBuilder;
import com.pvpcore.player.PlayerState;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * Routes clicks on lobby hotbar items to actions (requirement 11) and locks
 * down the lobby world (issue 8 / 2.2.0):
 * - lobby items can not be moved, dropped, used or placed
 * - blocks can not be broken, placed or interacted with in the lobby
 * - other items (food, pearls, potions) can not be used while locked
 */
public final class LobbyItemListener {
    private LobbyItemListener() {}

    public static void register() {
        // Right click (air or block) with any item
        UseItemCallback.EVENT.register((player, world, hand) -> {
            if (world.isClient() || !(player instanceof ServerPlayerEntity sp)) {
                return ActionResult.PASS;
            }
            String action = ItemBuilder.actionOf(sp.getStackInHand(hand));
            if (action != null) {
                PvPCore.get().server().execute(() -> handle(sp, action));
                return ActionResult.SUCCESS;
            }
            // Issue 8: no using items (food, pearls, potions...) while locked
            if (PvPCore.get().isItemUseBlocked(sp)) {
                return ActionResult.FAIL;
            }
            return ActionResult.PASS;
        });

        // Right click ON a block (placement / interaction)
        // (Fabric 1.21.11: interact(player, world, hand, BlockHitResult))
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (world.isClient() || !(player instanceof ServerPlayerEntity sp)) return ActionResult.PASS;
            String action = ItemBuilder.actionOf(sp.getStackInHand(hand));
            if (action != null) {
                PvPCore.get().server().execute(() -> handle(sp, action));
                return ActionResult.SUCCESS;
            }
            // Issue 8: no placing blocks / opening chests in the lobby
            if (PvPCore.get().isWorldInteractionBlocked(sp)) {
                return ActionResult.FAIL;
            }
            return ActionResult.PASS;
        });

        // Left click on a block (breaking)
        AttackBlockCallback.EVENT.register((player, world, hand, pos, direction) -> {
            if (world.isClient() || !(player instanceof ServerPlayerEntity sp)) return ActionResult.PASS;
            String action = ItemBuilder.actionOf(sp.getStackInHand(hand));
            if (action != null) {
                PvPCore.get().server().execute(() -> handle(sp, action));
                return ActionResult.SUCCESS;
            }
            // Issue 8: no breaking blocks in the lobby
            if (PvPCore.get().isWorldInteractionBlocked(sp)) {
                return ActionResult.FAIL;
            }
            return ActionResult.PASS;
        });

        // Left click on an entity
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (world.isClient() || !(player instanceof ServerPlayerEntity sp)) return ActionResult.PASS;
            String action = ItemBuilder.actionOf(sp.getStackInHand(hand));
            if (action == null) return ActionResult.PASS;
            PvPCore.get().server().execute(() -> handle(sp, action));
            return ActionResult.SUCCESS;
        });
    }

    /** Central action dispatcher for lobby items. */
    public static void handle(ServerPlayerEntity player, String action) {
        if (player == null || player.isDisconnected()) return;
        var core = PvPCore.get();
        var pm = core.playerManager();
        var state = pm.state(player);

        // While spectating, the only action is returning
        if (core.spectateManager().isSpectating(player)) {
            if (action.equals("spectate")) {
                core.spectateManager().returnPlayer(player);
            }
            return;
        }

        if (state == PlayerState.DUELING) return; // in a fight: no menus

        switch (action) {
            case "unranked" -> new com.pvpcore.gui.guis.KitPickerGui(player, false, null).open(player);
            case "ranked" -> new com.pvpcore.gui.guis.KitPickerGui(player, true, null).open(player);
            case "queue_leave" -> core.queueManager().leave(player);
            case "duel" -> new com.pvpcore.gui.guis.PlayerPickerGui(player,
                    "&8Duel - Pick an Opponent",
                    target -> new com.pvpcore.gui.guis.KitPickerGui(player, false, target).open(player)).open(player);
            case "kits" -> new com.pvpcore.gui.guis.KitListGui(player).open(player);
            case "party" -> {
                // Issue 1 (2.2.0): the party menu opens in CHAT, not a GUI.
                // Requirement 6: the party is auto-created on first click.
                var party = core.partyManager().partyOf(player);
                if (party == null && core.config().party.autoCreateOnItemClick) {
                    core.partyManager().createParty(player);
                }
                core.partyManager().sendPartyMenu(player);
            }
            case "leaderboard" -> new com.pvpcore.gui.guis.LeaderboardGui(player).open(player);
            case "profile" -> new com.pvpcore.gui.guis.ProfileGui(player, player).open(player);
            case "spectate" -> new com.pvpcore.gui.guis.SpectateGui(player).open(player);
            default -> {}
        }
    }
}
