package com.pvpcore.party;

import com.pvpcore.PvPCore;
import com.pvpcore.util.ChatButtons;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Party system. Requirement 6: a party is created automatically when the
 * party item is clicked.
 *
 * Issue 1 (2.2.0): party management lives entirely in CHAT - invites arrive
 * as clickable [ACCEPT]/[DENY] buttons and the party item opens a clickable
 * chat menu (invite / kick / promote / chat / duel / leave / disband).
 */
public final class PartyManager {
    public static class PartyInvite {
        public final UUID partyId;
        public final UUID inviter;
        public final UUID target;
        public final long expiryTick;
        public PartyInvite(UUID partyId, UUID inviter, UUID target, long expiryTick) {
            this.partyId = partyId; this.inviter = inviter; this.target = target;
            this.expiryTick = expiryTick;
        }
    }

    public static class Party {
        public final UUID id = UUID.randomUUID();
        public UUID leader;
        public final Set<UUID> members = new HashSet<>();
        public Party(UUID leader) {
            this.leader = leader;
            this.members.add(leader);
        }
        public boolean isLeader(UUID player) { return leader.equals(player); }
        public List<ServerPlayerEntity> onlineMembers() {
            List<ServerPlayerEntity> out = new ArrayList<>();
            var pm = PvPCore.get().server().getPlayerManager();
            for (UUID u : members) {
                ServerPlayerEntity p = pm.getPlayer(u);
                if (p != null) out.add(p);
            }
            return out;
        }
        public List<UUID> onlineMemberUuids() {
            List<UUID> out = new ArrayList<>();
            var pm = PvPCore.get().server().getPlayerManager();
            for (UUID u : members) if (pm.getPlayer(u) != null) out.add(u);
            return out;
        }
    }

    private final Map<UUID, Party> parties = new ConcurrentHashMap<>(); // party id -> party
    private final Map<UUID, UUID> memberIndex = new ConcurrentHashMap<>(); // player uuid -> party id
    private final Map<UUID, PartyInvite> invites = new ConcurrentHashMap<>(); // target -> invite
    private long tick = 0;

    public Party partyOf(ServerPlayerEntity player) {
        if (player == null) return null;
        UUID partyId = memberIndex.get(player.getUuid());
        return partyId != null ? parties.get(partyId) : null;
    }

    public Party partyById(UUID id) {
        return parties.get(id);
    }

    public List<Party> allParties() {
        return new ArrayList<>(parties.values());
    }

    public PartyInvite inviteFor(UUID target) {
        return invites.get(target);
    }

    /** Requirement 6: create a party for this player (leader). */
    public Party createParty(ServerPlayerEntity player) {
        Party existing = partyOf(player);
        if (existing != null) return existing;
        Party party = new Party(player.getUuid());
        parties.put(party.id, party);
        memberIndex.put(player.getUuid(), party.id);
        player.sendMessage(Text.literal(PvPCore.get().messages().get("party.created")), false);
        refreshMembers(party);
        return party;
    }

    public void disband(ServerPlayerEntity player) {
        Party party = partyOf(player);
        if (party == null) return;
        if (!party.isLeader(player.getUuid())) return;
        var mm = PvPCore.get().messages();
        for (ServerPlayerEntity member : party.onlineMembers()) {
            member.sendMessage(Text.literal(mm.get("party.disbanded")), false);
        }
        for (UUID u : party.members) memberIndex.remove(u);
        parties.remove(party.id);
        refreshMembers(party);
    }

    public void leave(ServerPlayerEntity player) {
        Party party = partyOf(player);
        if (party == null) return;
        var mm = PvPCore.get().messages();
        if (party.isLeader(player.getUuid())) {
            if (party.members.size() <= 1) {
                disband(player);
                return;
            }
            // promote next member
            UUID next = party.members.stream()
                    .filter(u -> !u.equals(player.getUuid()))
                    .findFirst().orElse(null);
            party.members.remove(player.getUuid());
            memberIndex.remove(player.getUuid());
            if (next != null) {
                party.leader = next;
                ServerPlayerEntity nextP = PvPCore.get().server().getPlayerManager().getPlayer(next);
                if (nextP != null) {
                    nextP.sendMessage(Text.literal(mm.get("party.you-promoted")), false);
                }
            }
            player.sendMessage(Text.literal(mm.get("party.left")), false);
            broadcast(party, mm.get("party.player-left", Map.of(
                    "player", player.getGameProfile().name())));
        } else {
            party.members.remove(player.getUuid());
            memberIndex.remove(player.getUuid());
            player.sendMessage(Text.literal(mm.get("party.left")), false);
            broadcast(party, mm.get("party.player-left", Map.of(
                    "player", player.getGameProfile().name())));
        }
        refreshMembers(party);
    }

    public void kick(ServerPlayerEntity leader, ServerPlayerEntity target) {
        Party party = partyOf(leader);
        if (party == null || !party.isLeader(leader.getUuid())) return;
        if (!party.members.contains(target.getUuid())) return;
        party.members.remove(target.getUuid());
        memberIndex.remove(target.getUuid());
        var mm = PvPCore.get().messages();
        target.sendMessage(Text.literal(mm.get("party.you-kicked")), false);
        broadcast(party, mm.get("party.kicked", Map.of(
                "player", target.getGameProfile().name())));
        refreshMembers(party);
    }

    public void promote(ServerPlayerEntity leader, ServerPlayerEntity target) {
        Party party = partyOf(leader);
        if (party == null || !party.isLeader(leader.getUuid())) return;
        if (!party.members.contains(target.getUuid())) return;
        party.leader = target.getUuid();
        var mm = PvPCore.get().messages();
        broadcast(party, mm.get("party.promoted", Map.of(
                "player", target.getGameProfile().name())));
        target.sendMessage(Text.literal(mm.get("party.you-promoted")), false);
        refreshMembers(party);
    }

    /** Send an invite; the target receives clickable chat buttons (issue 1). */
    public boolean invite(ServerPlayerEntity inviter, ServerPlayerEntity target) {
        Party party = partyOf(inviter);
        if (party == null) return false;
        var cfg = PvPCore.get().config().party;
        var mm = PvPCore.get().messages();
        if (!party.isLeader(inviter.getUuid()) && !cfg.membersCanInvite) {
            inviter.sendMessage(Text.literal(mm.get("party.not-leader")), false);
            return false;
        }
        // Issue 9 (2.2.0): nobody can manage parties while inside a duel
        if (PvPCore.get().duelManager().duelOf(inviter) != null) {
            inviter.sendMessage(Text.literal(mm.get("party.you-in-duel")), false);
            return false;
        }
        if (PvPCore.get().duelManager().duelOf(target) != null) {
            inviter.sendMessage(Text.literal(mm.get("party.target-in-duel", Map.of(
                    "player", target.getGameProfile().name()))), false);
            return false;
        }
        if (partyOf(target) != null) {
            inviter.sendMessage(Text.literal(mm.get("party.already-in-party")), false);
            return false;
        }
        if (party.members.size() >= cfg.maxSize) {
            inviter.sendMessage(Text.literal(mm.get("party.full", Map.of(
                    "max", String.valueOf(cfg.maxSize)))), false);
            return false;
        }
        invites.remove(target.getUuid());
        PartyInvite invite = new PartyInvite(party.id, inviter.getUuid(), target.getUuid(),
                tick + (long) cfg.inviteExpirySeconds * 20);
        invites.put(target.getUuid(), invite);
        inviter.sendMessage(Text.literal(mm.get("party.invite-sent", Map.of(
                "player", target.getGameProfile().name()))), false);
        com.pvpcore.util.TitleUtil.title(target,
                mm.get("party.invite-received-title"),
                mm.get("party.invite-received-subtitle", Map.of(
                        "player", inviter.getGameProfile().name())));
        // Issue 1: invite in chat with clickable buttons, no GUI
        target.sendMessage(ChatButtons.line(Text.literal(mm.get("party.invite-chat-header", Map.of(
                "player", inviter.getGameProfile().name())))), false);
        target.sendMessage(ChatButtons.line(
                ChatButtons.button(mm.get("party.accept-button"), "/party accept",
                        mm.get("party.accept-hover"), Formatting.GREEN),
                Text.literal(" "),
                ChatButtons.button(mm.get("party.deny-button"), "/party deny",
                        mm.get("party.deny-hover"), Formatting.RED)), false);
        target.sendMessage(Text.literal(mm.get("duel.challenge-chat-expire", Map.of(
                "seconds", String.valueOf(cfg.inviteExpirySeconds)))), false);
        return true;
    }

    public void acceptInvite(ServerPlayerEntity player) {
        PartyInvite invite = invites.remove(player.getUuid());
        if (invite == null) return;
        Party party = parties.get(invite.partyId);
        if (party == null) return;
        var cfg = PvPCore.get().config().party;
        var mm = PvPCore.get().messages();
        // Issue 9 (2.2.0): no joining a party while in a duel
        if (PvPCore.get().duelManager().duelOf(player) != null) {
            player.sendMessage(Text.literal(mm.get("party.cant-while-dueling")), false);
            return;
        }
        if (party.members.size() >= cfg.maxSize) return;
        if (partyOf(player) != null) return;
        party.members.add(player.getUuid());
        memberIndex.put(player.getUuid(), party.id);
        player.sendMessage(Text.literal(mm.get("party.joined", Map.of(
                "player", nameOf(party.leader)))), false);
        broadcast(party, mm.get("party.player-joined", Map.of(
                "player", player.getGameProfile().name())));
        refreshMembers(party);
        sendPartyMenu(player);
    }

    public void denyInvite(ServerPlayerEntity player) {
        PartyInvite invite = invites.remove(player.getUuid());
        if (invite == null) return;
        ServerPlayerEntity inviter = PvPCore.get().server().getPlayerManager().getPlayer(invite.inviter);
        if (inviter != null) {
            inviter.sendMessage(Text.literal(PvPCore.get().messages().get("party.invite-denied", Map.of(
                    "player", player.getGameProfile().name()))), false);
        }
    }

    // ------------------------------------------------------------------
    // Issue 1 (2.2.0): the party menu lives in CHAT, not a GUI
    // ------------------------------------------------------------------

    /** Open the clickable chat party menu (auto-creates a party if none). */
    public void sendPartyMenu(ServerPlayerEntity player) {
        var mm = PvPCore.get().messages();
        Party party = partyOf(player);
        if (party == null) {
            if (PvPCore.get().config().party.autoCreateOnItemClick) {
                createParty(player);
                party = partyOf(player);
            }
            if (party == null) {
                player.sendMessage(Text.literal(mm.get("party.not-in-party")), false);
                return;
            }
        }
        boolean leader = party.isLeader(player.getUuid());

        // header + member list
        player.sendMessage(Text.literal(mm.get("party.menu-header", Map.of(
                "online", String.valueOf(party.onlineMembers().size()),
                "max", String.valueOf(PvPCore.get().config().party.maxSize)))), false);
        StringBuilder members = new StringBuilder();
        boolean first = true;
        for (UUID u : party.members) {
            if (!first) members.append("&7, ");
            members.append(party.leader.equals(u) ? "&6\u2605 " : "&d").append(nameOf(u));
            first = false;
        }
        player.sendMessage(Text.literal(mm.get("party.menu-members", Map.of(
                "members", members.toString()))), false);

        // button row 1: invite + chat toggle
        boolean partyChat = PvPCore.get().storage().get(player.getUuid(), player.getGameProfile().name()).partyChat;
        player.sendMessage(ChatButtons.line(
                ChatButtons.button(mm.get("party.menu-invite-button"), "/party menu invite",
                        mm.get("party.menu-invite-hover"), Formatting.GREEN),
                Text.literal(" "),
                ChatButtons.button(mm.get("party.menu-chat-button", Map.of(
                                "status", partyChat ? "&aON" : "&cOFF")), "/party chat",
                        mm.get("party.menu-chat-hover"), Formatting.LIGHT_PURPLE)), false);

        // button row 2: duel (leader) + manage (leader) / leave
        if (leader) {
            player.sendMessage(ChatButtons.line(
                    ChatButtons.button(mm.get("party.menu-duel-button"), "/party menu duel",
                            mm.get("party.menu-duel-hover"), Formatting.RED),
                    Text.literal(" "),
                    ChatButtons.button(mm.get("party.menu-manage-button"), "/party menu manage",
                            mm.get("party.menu-manage-hover"), Formatting.YELLOW)), false);
        }
        player.sendMessage(ChatButtons.line(
                ChatButtons.button(mm.get("party.menu-leave-button"), "/party leave",
                        mm.get("party.menu-leave-hover"), Formatting.RED),
                Text.literal(" "),
                leader ? ChatButtons.button(mm.get("party.menu-disband-button"), "/party disband",
                        mm.get("party.menu-disband-hover"), Formatting.DARK_RED)
                        : Text.literal(""),
                Text.literal(" "),
                ChatButtons.button(mm.get("party.menu-close-button"), "/party menu close",
                        mm.get("party.menu-close-hover"), Formatting.GRAY)), false);
    }

    /** Chat list of online players that can be invited (clickable names). */
    public void sendInviteTargets(ServerPlayerEntity player) {
        var mm = PvPCore.get().messages();
        Party party = partyOf(player);
        if (party == null) return;
        var pm = PvPCore.get().server().getPlayerManager();
        List<ServerPlayerEntity> candidates = new ArrayList<>();
        for (ServerPlayerEntity p : pm.getPlayerList()) {
            if (p.getUuid().equals(player.getUuid())) continue;
            if (partyOf(p) != null) continue;
            if (PvPCore.get().duelManager().duelOf(p) != null) continue;
            candidates.add(p);
        }
        if (candidates.isEmpty()) {
            player.sendMessage(Text.literal(mm.get("party.menu-invite-none")), false);
            return;
        }
        player.sendMessage(Text.literal(mm.get("party.menu-invite-players")), false);
        List<Text> parts = new ArrayList<>();
        for (ServerPlayerEntity p : candidates) {
            if (!parts.isEmpty()) parts.add(Text.literal(" "));
            parts.add(ChatButtons.button("&e" + p.getGameProfile().name(),
                    "/party invite " + p.getGameProfile().name(),
                    mm.get("party.accept-hover"), Formatting.YELLOW));
        }
        player.sendMessage(ChatButtons.line(parts.toArray(new Text[0])), false);
    }

    /** Chat list of other party leaders to duel (clickable names). */
    public void sendDuelTargets(ServerPlayerEntity player) {
        var mm = PvPCore.get().messages();
        Party myParty = partyOf(player);
        if (myParty == null || !myParty.isLeader(player.getUuid())) {
            player.sendMessage(Text.literal(mm.get("party.not-leader")), false);
            return;
        }
        List<ServerPlayerEntity> leaders = new ArrayList<>();
        for (Party other : allParties()) {
            if (other == myParty) continue;
            ServerPlayerEntity leader = PvPCore.get().server().getPlayerManager().getPlayer(other.leader);
            if (leader == null) continue;
            if (PvPCore.get().duelManager().duelOf(leader) != null) continue;
            leaders.add(leader);
        }
        if (leaders.isEmpty()) {
            player.sendMessage(Text.literal(mm.get("party.menu-duel-none")), false);
            return;
        }
        player.sendMessage(Text.literal(mm.get("party.menu-duel-leaders")), false);
        List<Text> parts = new ArrayList<>();
        for (ServerPlayerEntity leader : leaders) {
            if (!parts.isEmpty()) parts.add(Text.literal(" "));
            parts.add(ChatButtons.button("&e" + leader.getGameProfile().name(),
                    "/party duel " + leader.getGameProfile().name(),
                    mm.get("party.menu-duel-hover"), Formatting.YELLOW));
        }
        player.sendMessage(ChatButtons.line(parts.toArray(new Text[0])), false);
    }

    /** Chat list of members with [PROMOTE]/[KICK] buttons (leader only). */
    public void sendManageMembers(ServerPlayerEntity player) {
        var mm = PvPCore.get().messages();
        Party party = partyOf(player);
        if (party == null) return;
        if (!party.isLeader(player.getUuid())) {
            player.sendMessage(Text.literal(mm.get("party.not-leader")), false);
            return;
        }
        boolean any = false;
        for (UUID u : party.members) {
            if (u.equals(player.getUuid())) continue;
            ServerPlayerEntity member = PvPCore.get().server().getPlayerManager().getPlayer(u);
            if (member == null) continue;
            any = true;
            player.sendMessage(ChatButtons.line(
                    Text.literal(mm.get("party.menu-members-line", Map.of(
                            "player", member.getGameProfile().name()))),
                    ChatButtons.button("&a[PROMOTE]", "/party promote " + member.getGameProfile().name(),
                            "&7Promote to leader", Formatting.GREEN),
                    Text.literal(" "),
                    ChatButtons.button("&c[KICK]", "/party kick " + member.getGameProfile().name(),
                            "&cKick from party", Formatting.RED)), false);
        }
        if (!any) {
            player.sendMessage(Text.literal(mm.get("party.menu-invite-none")), false);
        }
    }

    private String nameOf(UUID uuid) {
        var p = PvPCore.get().server().getPlayerManager().getPlayer(uuid);
        return p != null ? p.getGameProfile().name() : "?";
    }

    private void broadcast(Party party, String message) {
        for (ServerPlayerEntity member : party.onlineMembers()) {
            member.sendMessage(Text.literal(message), false);
        }
    }

    /** Refresh lobby hotbar items for all members (party item state changed). */
    private void refreshMembers(Party party) {
        for (UUID u : party.members) {
            ServerPlayerEntity p = PvPCore.get().server().getPlayerManager().getPlayer(u);
            if (p != null) PvPCore.get().playerManager().refreshLobby(p);
        }
    }

    public void onQuit(ServerPlayerEntity player) {
        // remove pending invites
        invites.remove(player.getUuid());
        Party party = partyOf(player);
        if (party == null) return;
        if (party.members.size() <= 1) {
            for (UUID u : party.members) memberIndex.remove(u);
            parties.remove(party.id);
            return;
        }
        if (party.isLeader(player.getUuid())) {
            UUID next = party.members.stream()
                    .filter(u -> !u.equals(player.getUuid()))
                    .findFirst().orElse(null);
            party.members.remove(player.getUuid());
            memberIndex.remove(player.getUuid());
            if (next != null) {
                party.leader = next;
                ServerPlayerEntity nextP = PvPCore.get().server().getPlayerManager().getPlayer(next);
                if (nextP != null) {
                    nextP.sendMessage(Text.literal(PvPCore.get().messages().get("party.you-promoted")), false);
                }
            }
        } else {
            party.members.remove(player.getUuid());
            memberIndex.remove(player.getUuid());
        }
        broadcast(party, PvPCore.get().messages().get("party.player-left", Map.of(
                "player", player.getGameProfile().name())));
    }

    public void tick() {
        tick++;
        invites.entrySet().removeIf(e -> {
            if (tick >= e.getValue().expiryTick) {
                ServerPlayerEntity target = PvPCore.get().server().getPlayerManager().getPlayer(e.getKey());
                if (target != null) {
                    target.sendMessage(Text.literal(PvPCore.get().messages().get("party.invite-expired")), false);
                }
                return true;
            }
            return false;
        });
    }

    public void shutdown() {
        parties.clear();
        memberIndex.clear();
        invites.clear();
    }
}
